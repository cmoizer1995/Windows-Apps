<?php
/**
 * Plugin Name: CM GitHub Connector for Elementor
 * Description: Display a GitHub-style repository browser inside WordPress/Elementor with in-widget navigation and server-side GitHub API authentication.
 * Version: 1.4.2
 * Author: Connor Moizer
 * Author URI: https://connormoizer.com
 * Text Domain: cm-github-connector
 * Requires at least: 6.5
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'CMGC_VERSION', '1.4.2' );
define( 'CMGC_FILE', __FILE__ );
define( 'CMGC_DIR', plugin_dir_path( __FILE__ ) );
define( 'CMGC_URL', plugin_dir_url( __FILE__ ) );

require_once CMGC_DIR . 'includes/class-cmgc-api.php';
require_once CMGC_DIR . 'includes/class-cmgc-renderer.php';
require_once CMGC_DIR . 'includes/class-cmgc-rest.php';
require_once CMGC_DIR . 'includes/class-cmgc-admin.php';

final class CMGC_Plugin {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'init', array( $this, 'register_shortcode' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
        add_action( 'elementor/frontend/after_register_scripts', array( $this, 'register_assets' ) );
        add_action( 'elementor/widgets/register', array( $this, 'register_elementor_widget' ) );
        add_action( 'elementor/editor/after_enqueue_styles', array( $this, 'register_assets' ) );

        CMGC_REST::init();
        CMGC_Admin::init();
    }

    public function register_assets() {
        wp_register_style(
            'cmgc-github-browser',
            CMGC_URL . 'assets/css/github-browser.css',
            array(),
            CMGC_VERSION
        );

        wp_register_script(
            'cmgc-github-browser',
            CMGC_URL . 'assets/js/github-browser.js',
            array(),
            CMGC_VERSION,
            true
        );
    }

    public function register_shortcode() {
        add_shortcode( 'cm_github_browser', array( $this, 'shortcode' ) );
    }

    public function shortcode( $atts ) {
        $options = CMGC_Admin::get_options();
        $mapping = CMGC_Admin::get_current_mapping();

        $atts = shortcode_atts(
            array(
                'source'      => 'auto',
                'owner'       => '',
                'repo'        => '',
                'branch'      => '',
                'path'        => '',
                'access'      => '',
                'show_header' => '',
            ),
            $atts,
            'cm_github_browser'
        );

        $use_mapping = 'manual' !== $atts['source'] && is_array( $mapping );
        if ( $use_mapping ) {
            $owner       = isset( $mapping['owner'] ) ? $mapping['owner'] : '';
            $repo        = isset( $mapping['repo'] ) ? $mapping['repo'] : '';
            $branch      = $atts['branch'] ? $atts['branch'] : ( isset( $mapping['branch'] ) ? $mapping['branch'] : '' );
            $access      = $atts['access'] ? $atts['access'] : ( isset( $mapping['access'] ) ? $mapping['access'] : 'public' );
            $show_header = '' !== $atts['show_header'] ? 'no' !== $atts['show_header'] : ( ! isset( $mapping['show_header'] ) || 'no' !== $mapping['show_header'] );
        } else {
            $owner       = $atts['owner'] ? $atts['owner'] : $options['default_owner'];
            $repo        = $atts['repo'] ? $atts['repo'] : $options['default_repo'];
            $branch      = $atts['branch'] ? $atts['branch'] : $options['default_branch'];
            $access      = $atts['access'] ? $atts['access'] : 'public';
            $show_header = '' !== $atts['show_header'] ? 'no' !== $atts['show_header'] : true;
        }

        return CMGC_Renderer::render_browser(
            sanitize_text_field( $owner ),
            sanitize_text_field( $repo ),
            sanitize_text_field( $branch ),
            sanitize_text_field( $atts['path'] ),
            'logged_in' === $access ? 'logged_in' : 'public',
            $show_header
        );
    }

    public function register_elementor_widget( $widgets_manager ) {
        if ( ! did_action( 'elementor/loaded' ) && ! class_exists( '\\Elementor\\Widget_Base' ) ) {
            return;
        }

        require_once CMGC_DIR . 'includes/widgets/class-cmgc-github-browser-widget.php';
        $widgets_manager->register( new CMGC_GitHub_Browser_Widget() );
    }
}

CMGC_Plugin::instance();
