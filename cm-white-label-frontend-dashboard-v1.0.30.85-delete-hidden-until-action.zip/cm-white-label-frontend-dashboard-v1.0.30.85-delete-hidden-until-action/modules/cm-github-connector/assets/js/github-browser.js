(function () {
    'use strict';

    function initBrowser(browser) {
        if (!browser || browser.dataset.cmgcReady === '1') return;
        browser.dataset.cmgcReady = '1';

        const content = browser.querySelector('.cmgc-content');
        const loading = browser.querySelector('.cmgc-loading');
        const live = browser.querySelector('.cmgc-live-region');
        const branchMenu = browser.querySelector('.cmgc-branch-menu');
        const currentBranch = browser.querySelector('.cmgc-current-branch');
        const endpoint = browser.dataset.endpoint || '';
        let lastLiveRefresh = 0;
        let requestController = null;

        if (!content || !endpoint) return;

        async function browse(path, options) {
            options = options || {};
            const params = new URLSearchParams({
                owner: browser.dataset.owner || '',
                repo: browser.dataset.repo || '',
                branch: browser.dataset.branch || '',
                path: path || '',
                access: browser.dataset.access || 'public',
                signature: browser.dataset.signature || '',
                _cmgc_live: String(Date.now())
            });

            if (requestController) requestController.abort();
            requestController = (typeof AbortController !== 'undefined') ? new AbortController() : null;

            browser.classList.add('is-loading');
            if (loading) loading.hidden = false;
            if (live) live.textContent = 'Loading repository content';

            try {
                const fetchOptions = {
                    method: 'GET',
                    credentials: 'same-origin',
                    cache: 'no-store',
                    headers: {
                        'Accept': 'application/json',
                        'X-WP-Nonce': browser.dataset.restNonce || '',
                        'Cache-Control': 'no-cache',
                        'Pragma': 'no-cache'
                    }
                };
                if (requestController) fetchOptions.signal = requestController.signal;

                const response = await fetch(endpoint + '?' + params.toString(), fetchOptions);
                const data = await response.json();
                if (!response.ok) {
                    throw new Error((data && data.message) ? data.message : 'Unable to load GitHub content.');
                }
                content.innerHTML = data.html || '';
                browser.dataset.path = data.path || '';
                if (data.branch) {
                    browser.dataset.branch = data.branch;
                    if (currentBranch) currentBranch.textContent = data.branch;
                }
                lastLiveRefresh = Date.now();
                if (live) live.textContent = 'Repository content updated';
                if (options.scroll !== false) {
                    content.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                }
            } catch (error) {
                if (error && error.name === 'AbortError') return;
                content.innerHTML = '<div class="cmgc-error"></div>';
                const errorBox = content.querySelector('.cmgc-error');
                if (errorBox) errorBox.textContent = error.message || 'Unable to load GitHub content.';
                if (live) live.textContent = 'Unable to update repository content';
            } finally {
                browser.classList.remove('is-loading');
                if (loading) loading.hidden = true;
            }
        }

        function selectBranch(branch) {
            if (!branch) return;
            browser.dataset.branch = branch;
            browser.dataset.path = '';
            if (currentBranch) currentBranch.textContent = branch;
            if (branchMenu) branchMenu.removeAttribute('open');
            browser.querySelectorAll('.cmgc-branch-option').forEach(function (option) {
                const active = option.dataset.cmgcBranch === branch;
                option.classList.toggle('is-current', active);
                const check = option.querySelector('.cmgc-branch-check');
                if (check) check.textContent = active ? '✓' : '';
            });
            browse('');
        }

        function refreshLiveIfNeeded(force) {
            if (document.hidden) return;
            if (!force && Date.now() - lastLiveRefresh < 2000) return;
            browse(browser.dataset.path || '', { scroll: false });
        }

        browser.addEventListener('click', function (event) {
            const branchOption = event.target.closest('.cmgc-branch-option[data-cmgc-branch]');
            if (branchOption && browser.contains(branchOption)) {
                event.preventDefault();
                selectBranch(branchOption.dataset.cmgcBranch || '');
                return;
            }

            const nav = event.target.closest('[data-cmgc-path]');
            if (nav && browser.contains(nav)) {
                event.preventDefault();
                browse(nav.dataset.cmgcPath || '');
                return;
            }

            const refresh = event.target.closest('.cmgc-refresh-button');
            if (refresh && browser.contains(refresh)) {
                event.preventDefault();
                refreshLiveIfNeeded(true);
            }
        });

        // Public/Elementor view: immediately replace any cached HTML snapshot
        // with a fresh read from GitHub.
        refreshLiveIfNeeded(true);

        // If the page was left open while the dashboard changed GitHub,
        // refresh as soon as the visitor returns.
        document.addEventListener('visibilitychange', function () {
            if (!document.hidden) refreshLiveIfNeeded(false);
        });
        window.addEventListener('pageshow', function () {
            refreshLiveIfNeeded(false);
        });
        window.addEventListener('focus', function () {
            refreshLiveIfNeeded(false);
        });
    }

    function initAll(root) {
        (root || document).querySelectorAll('.cmgc-browser').forEach(initBrowser);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () { initAll(document); });
    } else {
        initAll(document);
    }

    document.addEventListener('elementor/popup/show', function () { initAll(document); });
})();
