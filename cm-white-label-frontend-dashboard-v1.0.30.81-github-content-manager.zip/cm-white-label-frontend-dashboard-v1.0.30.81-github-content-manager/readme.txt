= 1.0.30.81 =
* Rebuilt Content > GitHub from scratch as a GitHub-style file manager.
* View > GitHub / View All are unchanged.
* Settings > GitHub remains the shared PAT and exclusion settings page.
* Content now browses live repos/branches/folders, creates files, uploads files, edits text files and deletes files with Commit changes workflow.
* All write actions use WordPress server-side AJAX and GitHub's official repository Contents REST endpoints.

= 1.0.30.80 =
* GitHub Upload now follows the same server-side WordPress AJAX architecture as the known-working GitHub Repo Selector v1.6.5.
* Uses the saved PAT only in PHP, with the v1.6.5 GitHub auth/header style.
* Selected repo + selected branch are sent to GitHub Contents PUT and verified by reading the same path back from the same branch.

CM White Label Frontend Dashboard v1.0.30.77

= 1.0.30.77 =
* Fixed GitHub Upload when the selected destination already contains a file with the same name: the current GitHub SHA is now detected and supplied automatically so the file is replaced/updated.
* Added a retry for GitHub 422 SHA race errors.
* Isolated the dashboard Add/Upload/Edit/Delete action buttons from the standalone GitHub Repo Selector JavaScript, preventing duplicate write requests when both are installed.

CM White Label Frontend Dashboard v1.0.30.75

= 1.0.30.75 =
* Content > GitHub now has nested Add, Upload, Edit and Delete tabs.
* Add/Edit/Upload/Delete/README-load results open in an internal GitHub browser inside the dashboard.
* Latest GitHub edit URL now opens internally instead of going to GitHub.com.
* Fixed false login-required errors when switching branches in Dashboard > View.
* GitHub action repo/branch lists update in place without a page reload.

CM White Label Frontend Dashboard v1.0.30.69

= 1.0.30.69 =
* Added Settings > GitHub to the front-end dashboard.
* Integrates with the built-in GitHub Repo Selector v1.1.1 without opening wp-admin.
* GitHub screen can show token/account settings, cache refresh, repository/branch management, README editing, file creation/upload and delete tools.
* GitHub management is restricted to WordPress administrators.

CM White Label Frontend Dashboard v1.0.30.44
Clean authentication build from v1.0.30.37. Uses WordPress core login/logout only. No custom session/tab-close logout code.

CM White Label Frontend Dashboard v1.0.19

Fix:
- Content, Live Blog and Elementor selector forms now keep cm_wlfd=1 and view=... hidden query values.
- Changing Site/CPT can no longer drop the user onto the public site/archive/404 route.
- All Content and Live Blog selection/edit/add flows stay inside the frontend dashboard query route.
- Keeps the previous safe query URL system that avoided the multisite slug/path 404 issue.


= 1.0.15 =
* Rebuilt Elementor dashboard section as a safe multisite launcher. Select site, then open selected site cm-elementor-templates page in a new tab.
* Removed frontend Elementor create/template/condition routing from the dashboard screen.

= 1.0.16 =
* Elementor section now lists selected site's Pages and Elementor Templates inside the frontend dashboard.
* Each item opens the direct Elementor editor URL in a new tab: post.php?post=ID&action=elementor.
* Removed the backend cm-elementor-templates launcher flash from the main Elementor button flow.

= 1.0.19 =
* Elementor frontend dashboard can now create new pages and open direct in Elementor.
* Elementor frontend dashboard can now create new templates, save template type and display condition first, then open direct in Elementor.
* Existing templates now include a frontend Conditions popup row.

= 1.0.26 =
* Fixed editor publish/update form so Delete is no longer nested inside the Publish form.
* Prevents Publish from triggering Trash/Delete after a newly-created post reloads into edit mode.

= 1.0.30.6 =
* Added podcast media playlist builder for YouTube first, Spotify second, WordPress media fallback.

= 1.0.30.9 =
* Updated Podcast dashboard integration for CM Editorial Widgets v1.2.39.
* Podcast playlist builder now supports FAQ/accordion playlist rows, YouTube first, Spotify second, WordPress media fallback, and optional official song/info URLs.
* Podcast listing shows playlist item counts and info-link counts for episodes.


= 1.0.30.37 =
* Removed Podcast from the frontend dashboard menu, home cards, content/add-new CPT listings, and editor-specific dashboard logic.

= 1.0.30.10 =
* Added self-hosted WordPress REST API bridge for the dashboard app.
* Added custom REST endpoints for settings, sites, CPTs, content list, content read, content save and trash.
* REST API uses the logged-in WordPress user, WP REST nonces and normal WordPress permissions.
* Existing frontend dashboard screens remain in place; REST API is an app/WordPress.com-style communication layer.


= 1.0.30.37 =
* Added Edit in Elementor buttons to Content lists and Add/Edit Content screens when Elementor supports the selected post type.
* Added Publish & Open Elementor / Update & Open Elementor actions while keeping the v1.0.30.10 dashboard baseline and podcast removal intact.

= 1.0.30.42 =
* Added PWA-style popup handling for Edit/View/Elementor windows from the dashboard.

= 1.0.30.45 =
* Improved Work Blogs scanner so monthly posts under /blog/work/ and work-tag/category posts are detected across the network.

= 1.0.30.44 =
* Added Work Blogs home card and dedicated Work Blogs stats page.
* Scans the public Work archive/category and summarises total blogs, years covered, most recent, busiest month, longest shift and latest event.

= 1.0.30.45 =
* Improved Work Blogs scanner so monthly posts under /blog/work/ and work-tag/category posts are detected across the network.

= 1.0.30.44 =
* Work Blogs stats now includes quietest month and total hours worked.
* Latest Event is pulled from the newest monthly Work Blog content instead of using the blog title.
* Default paid hours stay hidden and are only used for total-hours calculation unless a custom hours value is written in the blog/event text.

= 1.0.30.46 =
* Added Network Header & Footer Setup dashboard section.
* Supports BBC-style Orbital theme logic: main site primary menu is the global header, main site footer menu is the global footer, and service menu stays local per child site.
* Added one-screen assignment/creation for the main site primary and footer menu locations.

= 1.0.30.47 =
* Moved Header/Footer menu tools, Media and Plugins under a new Settings page.
* Removed Work Blogs from the dashboard menu/cards.
* Added frontend menu item management for main-site header/footer menus: add pages, add custom links and remove items.

= 1.0.30.50 =
* Rebuilt the frontend Media page into a WordPress-style media browser.
* Clicking a media item now opens an Attachment Details panel with editable Title, Caption, Alt Text and Description fields.
* Added frontend save handling for attachment metadata without opening wp-admin.


= 1.0.30.56 =
* Fixed login submissions from an installed PWA returning a blank white page.
* Dashboard login is now processed before any page output.
* Successful PWA login always returns to the frontend dashboard homepage.
* Added no-store headers to prevent a blank authentication response being cached.

= 1.0.30.62 =
* Keeps all dashboard and editor navigation inside the installed PWA window on iPhone/iPad instead of opening Safari's in-app sheet.
* Elementor and other popup-target forms use the current PWA window when installed.
* Logout continues to return to the dashboard login screen.


1.0.30.59
- Built directly from v1.0.30.58 PWA Stay In App.
- Added private CM Corkboard integration.
- Added Cork Boards homepage card and sidebar item.
- Added dashboard board list, Add/Edit repeater editor, Delete, and View in Dashboard.
- Boards remain private and do not open as public WordPress posts.
- Requires the CM Corkboard Dashboard Private plugin to be active.


1.0.30.60
- Corkboard Add and Update now always return to the same frontend board editor, matching Add Content behaviour.
- New boards immediately reopen as Edit Board after first publish.
- View in Dashboard checks for board changes every 10 seconds and refreshes only when the board has been updated.
- Added board author plus modified date and time beneath the board title.
- Added creator username plus created date and time beneath every sticky-note/task title.
- Existing notes receive author/time information the next time the board is saved.


1.0.30.61
- Removed the username/date/time line from beneath the overall board title.
- Kept username | date and time directly beneath each sticky-note task title.
- Kept automatic View in Dashboard refresh and editor return behaviour.


1.0.30.62
- Sticky-note username, date and time now represent the original time that note was first posted.
- Editing the note text, title, colour, fastener, image, link, size, rotation or position does not change its posted username or timestamp.
- The original note metadata is now verified against saved server-side data rather than trusting editable form values.
- New notes receive their own posting username and timestamp when first saved.

v1.0.30.63
- Corkboard Update/Publish now saves by AJAX without reloading the dashboard editor.
- Open corkboard views replace only the live board content, avoiding full-page refreshes and screen flashes.
- Same-browser corkboard views update immediately through a storage event; other open devices check every 2 seconds.
- Preserves the original creator username and original posted date/time for existing sticky notes.


Version 1.0.30.64
- Restored a visible Full Screen button on View in Dashboard corkboards.
- Full-screen presentation hides the dashboard chrome and board description, leaving the corkboard itself on screen.
- Added a fixed-screen fallback for iPhone/PWA browsers that do not expose the native Fullscreen API.
- Existing AJAX save and live content-only refresh behaviour remains unchanged.


Version 1.0.30.66
- Fixed Add Task in the corkboard editor so the newly-created sticky-note card is appended reliably.
- The editor now scrolls directly to the new card after Add Task is clicked.
- Keyboard focus is placed in the new Task title field, ready for typing.
- Existing live AJAX updates, full-screen view and original note timestamps remain unchanged.


Version 1.0.30.66
- Desktop corkboards now use vertical stacks of five cards per column, with clear gaps between cards and columns.
- Mobile keeps the existing single stacked layout.

= 1.0.30.67 =
- Removed the decorative push-pin shown above sticky notes.
- Added a real Pinned to this board option; new notes are unpinned by default.
- Pinned notes display a small pin in the note corner and sort ahead of unpinned notes while preserving each group’s existing order.
- Preserved existing corkboard data and all live AJAX, full-screen, metadata, five-card desktop, mobile, and Add Task scrolling behaviour.


== v1.0.30.70 - Built-in GitHub module ==
* GitHub Repo Selector is now bundled inside the CM White Label Frontend Dashboard plugin.
* Only this dashboard ZIP is required for the dashboard + GitHub integration.
* Frontend route: Dashboard > Settings > GitHub.
* Includes GitHub token/account settings, repository/branch cache, repository/branch creation and deletion, README/file editing, file upload, and the Elementor GitHub Repos widget.
* The normal wp-admin GitHub Repo Selector settings page remains available.
* If the older standalone GitHub Repo Selector plugin is still active, this dashboard safely uses it and skips loading the bundled copy. You can deactivate/delete the old standalone copy after confirming this version works.


= 1.0.30.72 =
* Split built-in GitHub integration into two dashboard areas.
* Settings > GitHub now contains connection/token/cache settings only.
* Content now includes a GitHub tab for repository, branch, README, file and upload work.
* GitHub content tools remain administrator-only and use the saved Settings connection.


= 1.0.30.72 =
* Added Dashboard > View > View All and GitHub embedded repository browser.
* Added global Show All GitHub + exclusion settings under Settings > GitHub.
* Bundled CM GitHub Connector v1.4 viewer and shared the existing dashboard PAT.
