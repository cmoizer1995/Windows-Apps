<?php
/**
 * CM White Label Dashboard - GitHub Content Manager
 *
 * Fresh content-only GitHub manager for Dashboard > Content > GitHub.
 * View and Settings are intentionally handled elsewhere and are not modified here.
 */

namespace CM_WL_GitHub_Content;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Client {
    const API_BASE = 'https://api.github.com';
    const API_VERSION = '2026-03-10';

    private $token = '';

    public function __construct() {
        if ( class_exists( '\\CM_WL_GitHub\\Settings' ) ) {
            $this->token = trim( (string) \CM_WL_GitHub\Settings::get_github_token() );
        }
    }

    public function has_token() {
        return '' !== $this->token;
    }

    private function headers( $accept = 'application/vnd.github+json' ) {
        $headers = [
            'Accept'               => $accept,
            'X-GitHub-Api-Version' => self::API_VERSION,
            'User-Agent'           => 'CM-White-Label-Frontend-Dashboard/1.0.30.81',
        ];

        if ( $this->has_token() ) {
            $headers['Authorization'] = 'Bearer ' . $this->token;
        }

        return $headers;
    }

    public function request( $method, $endpoint, $body = null, $accept = 'application/vnd.github+json' ) {
        if ( ! $this->has_token() ) {
            return new \WP_Error( 'cm_ghfm_no_token', __( 'No GitHub PAT is saved. Open Settings → GitHub first.', 'cm-wlfd' ) );
        }

        $url = 0 === strpos( $endpoint, 'http' ) ? $endpoint : self::API_BASE . $endpoint;
        $args = [
            'method'      => strtoupper( $method ),
            'headers'     => $this->headers( $accept ),
            'timeout'     => 60,
            'redirection' => 3,
        ];

        if ( null !== $body ) {
            $args['headers']['Content-Type'] = 'application/json';
            $args['body'] = wp_json_encode( $body );
        }

        $response = wp_remote_request( $url, $args );
        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $status = (int) wp_remote_retrieve_response_code( $response );
        $raw    = (string) wp_remote_retrieve_body( $response );
        $data   = '' !== $raw ? json_decode( $raw, true ) : [];

        if ( $status < 200 || $status >= 300 ) {
            $message = is_array( $data ) && ! empty( $data['message'] ) ? (string) $data['message'] : sprintf( __( 'GitHub returned HTTP %d.', 'cm-wlfd' ), $status );
            if ( 409 === $status ) {
                $message .= ' ' . __( 'The branch or file may have changed on GitHub. Reload it and try again.', 'cm-wlfd' );
            } elseif ( 422 === $status ) {
                $message .= ' ' . __( 'Check the file path, branch rules and PAT permissions.', 'cm-wlfd' );
            }
            return new \WP_Error( 'cm_ghfm_github_error', $message, [ 'status' => $status, 'body' => $data ] );
        }

        return is_array( $data ) ? $data : [];
    }

    public function authenticated_user() {
        return $this->request( 'GET', '/user' );
    }

    public function list_repositories() {
        $repos = [];
        for ( $page = 1; $page <= 10; $page++ ) {
            $endpoint = '/user/repos?per_page=100&page=' . $page . '&sort=full_name&direction=asc&affiliation=owner%2Ccollaborator%2Corganization_member';
            $batch = $this->request( 'GET', $endpoint );
            if ( is_wp_error( $batch ) ) {
                return $batch;
            }
            if ( empty( $batch ) || ! is_array( $batch ) ) {
                break;
            }
            foreach ( $batch as $repo ) {
                if ( empty( $repo['full_name'] ) || empty( $repo['name'] ) || empty( $repo['owner']['login'] ) ) {
                    continue;
                }
                // Content manager is for writing. Do not offer repos the token cannot push to.
                if ( isset( $repo['permissions']['push'] ) && ! $repo['permissions']['push'] ) {
                    continue;
                }
                $repos[] = $repo;
            }
            if ( count( $batch ) < 100 ) {
                break;
            }
        }
        return $repos;
    }

    public function get_repository( $owner, $repo ) {
        return $this->request( 'GET', '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) );
    }

    public function list_branches( $owner, $repo ) {
        $branches = [];
        for ( $page = 1; $page <= 10; $page++ ) {
            $batch = $this->request( 'GET', '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/branches?per_page=100&page=' . $page );
            if ( is_wp_error( $batch ) ) {
                return $batch;
            }
            if ( empty( $batch ) || ! is_array( $batch ) ) {
                break;
            }
            foreach ( $batch as $branch ) {
                if ( ! empty( $branch['name'] ) ) {
                    $branches[] = (string) $branch['name'];
                }
            }
            if ( count( $batch ) < 100 ) {
                break;
            }
        }
        return array_values( array_unique( $branches ) );
    }

    public static function split_full_name( $full_name ) {
        $full_name = trim( (string) $full_name );
        if ( false === strpos( $full_name, '/' ) ) {
            return [ '', '' ];
        }
        list( $owner, $repo ) = array_pad( explode( '/', $full_name, 2 ), 2, '' );
        return [ sanitize_text_field( $owner ), sanitize_text_field( $repo ) ];
    }

    public static function clean_path( $path, $allow_empty = true ) {
        $path = trim( str_replace( '\\', '/', (string) $path ) );
        $path = trim( $path, '/' );
        if ( '' === $path ) {
            return $allow_empty ? '' : new \WP_Error( 'cm_ghfm_empty_path', __( 'A file path is required.', 'cm-wlfd' ) );
        }

        $clean = [];
        foreach ( explode( '/', $path ) as $segment ) {
            $segment = trim( wp_check_invalid_utf8( wp_unslash( $segment ) ) );
            if ( '' === $segment || '.' === $segment ) {
                continue;
            }
            if ( '..' === $segment ) {
                return new \WP_Error( 'cm_ghfm_bad_path', __( 'GitHub paths cannot contain ..', 'cm-wlfd' ) );
            }
            $segment = sanitize_text_field( $segment );
            if ( '' === $segment ) {
                return new \WP_Error( 'cm_ghfm_bad_path', __( 'The GitHub file path contains an invalid segment.', 'cm-wlfd' ) );
            }
            $clean[] = $segment;
        }
        if ( empty( $clean ) ) {
            return $allow_empty ? '' : new \WP_Error( 'cm_ghfm_empty_path', __( 'A file path is required.', 'cm-wlfd' ) );
        }
        return implode( '/', $clean );
    }

    public static function encode_path( $path ) {
        if ( '' === $path ) {
            return '';
        }
        return implode( '/', array_map( 'rawurlencode', explode( '/', $path ) ) );
    }

    public static function clean_filename( $name ) {
        $name = str_replace( '\\', '/', (string) $name );
        $name = wp_basename( $name );
        $name = trim( sanitize_text_field( wp_check_invalid_utf8( $name ) ) );
        if ( '' === $name || '.' === $name || '..' === $name || false !== strpos( $name, '/' ) || false !== strpos( $name, "\0" ) ) {
            return new \WP_Error( 'cm_ghfm_bad_filename', __( 'One uploaded file has an invalid filename.', 'cm-wlfd' ) );
        }
        return $name;
    }

    public function get_contents( $owner, $repo, $branch, $path = '' ) {
        $path = self::clean_path( $path, true );
        if ( is_wp_error( $path ) ) {
            return $path;
        }
        $endpoint = '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/contents';
        if ( '' !== $path ) {
            $endpoint .= '/' . self::encode_path( $path );
        }
        $endpoint .= '?ref=' . rawurlencode( $branch );
        return $this->request( 'GET', $endpoint );
    }

    public function get_file( $owner, $repo, $branch, $path ) {
        $path = self::clean_path( $path, false );
        if ( is_wp_error( $path ) ) {
            return $path;
        }
        $data = $this->get_contents( $owner, $repo, $branch, $path );
        if ( is_wp_error( $data ) ) {
            return $data;
        }
        if ( empty( $data['type'] ) || 'file' !== $data['type'] ) {
            return new \WP_Error( 'cm_ghfm_not_file', __( 'That path is not a normal GitHub file.', 'cm-wlfd' ) );
        }

        $decoded = '';
        $editable = false;
        $size = isset( $data['size'] ) ? (int) $data['size'] : 0;

        if ( ! empty( $data['content'] ) && 'base64' === ( $data['encoding'] ?? '' ) ) {
            $decoded = base64_decode( preg_replace( '/\s+/', '', (string) $data['content'] ), true );
            if ( false === $decoded ) {
                $decoded = '';
            }
        }

        // GitHub's normal contents response includes base64 directly for smaller files.
        // Restrict the browser editor to text files up to 1 MB to avoid corrupting binaries.
        if ( $size <= 1024 * 1024 && ( 0 === $size || '' !== $decoded ) && false === strpos( $decoded, "\0" ) && preg_match( '//u', $decoded ) ) {
            $editable = true;
        }

        return [
            'name'         => isset( $data['name'] ) ? (string) $data['name'] : basename( $path ),
            'path'         => $path,
            'sha'          => isset( $data['sha'] ) ? (string) $data['sha'] : '',
            'size'         => $size,
            'content'      => $editable ? $decoded : '',
            'editable'     => $editable,
            'download_url' => isset( $data['download_url'] ) ? (string) $data['download_url'] : '',
        ];
    }

    public function create_or_update_file( $owner, $repo, $branch, $path, $content, $message, $sha = '' ) {
        $path = self::clean_path( $path, false );
        if ( is_wp_error( $path ) ) {
            return $path;
        }
        $branch = trim( (string) $branch );
        if ( '' === $branch ) {
            return new \WP_Error( 'cm_ghfm_missing_branch', __( 'Select a branch first.', 'cm-wlfd' ) );
        }
        $message = trim( sanitize_text_field( $message ) );
        if ( '' === $message ) {
            $message = ( '' !== $sha ? 'Update ' : 'Create ' ) . $path;
        }

        $body = [
            'message' => $message,
            'content' => base64_encode( (string) $content ),
            'branch'  => $branch,
        ];
        if ( '' !== $sha ) {
            $body['sha'] = $sha;
        }

        return $this->request(
            'PUT',
            '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/contents/' . self::encode_path( $path ),
            $body
        );
    }

    public function delete_file( $owner, $repo, $branch, $path, $message ) {
        $file = $this->get_file( $owner, $repo, $branch, $path );
        if ( is_wp_error( $file ) ) {
            return $file;
        }
        if ( empty( $file['sha'] ) ) {
            return new \WP_Error( 'cm_ghfm_missing_sha', __( 'GitHub did not return the file SHA needed to delete this file.', 'cm-wlfd' ) );
        }
        $message = trim( sanitize_text_field( $message ) );
        if ( '' === $message ) {
            $message = 'Delete ' . $file['path'];
        }
        return $this->request(
            'DELETE',
            '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/contents/' . self::encode_path( $file['path'] ),
            [
                'message' => $message,
                'sha'     => $file['sha'],
                'branch'  => $branch,
            ]
        );
    }
}

class Manager {
    const NONCE_ACTION = 'cm_wlfd_github_content_manager';

    public static function init() {
        add_action( 'wp_ajax_cm_wlfd_ghfm_context', [ __CLASS__, 'ajax_context' ] );
        add_action( 'wp_ajax_cm_wlfd_ghfm_browse', [ __CLASS__, 'ajax_browse' ] );
        add_action( 'wp_ajax_cm_wlfd_ghfm_file', [ __CLASS__, 'ajax_file' ] );
        add_action( 'wp_ajax_cm_wlfd_ghfm_save', [ __CLASS__, 'ajax_save' ] );
        add_action( 'wp_ajax_cm_wlfd_ghfm_upload', [ __CLASS__, 'ajax_upload' ] );
        add_action( 'wp_ajax_cm_wlfd_ghfm_delete', [ __CLASS__, 'ajax_delete' ] );
    }

    private static function guard() {
        if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => __( 'GitHub content management is restricted to WordPress administrators.', 'cm-wlfd' ) ], 403 );
        }
        $nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
            wp_send_json_error( [ 'message' => __( 'Security check failed. Reload the dashboard and try again.', 'cm-wlfd' ) ], 403 );
        }
    }

    private static function repo_from_request( Client $client ) {
        $full_name = isset( $_POST['repo'] ) ? sanitize_text_field( wp_unslash( $_POST['repo'] ) ) : '';
        list( $owner, $repo ) = Client::split_full_name( $full_name );
        if ( '' === $owner || '' === $repo ) {
            wp_send_json_error( [ 'message' => __( 'Select a repository first.', 'cm-wlfd' ) ] );
        }

        $details = $client->get_repository( $owner, $repo );
        if ( is_wp_error( $details ) ) {
            self::send_error( $details );
        }
        if ( isset( $details['permissions']['push'] ) && ! $details['permissions']['push'] ) {
            wp_send_json_error( [ 'message' => __( 'This PAT can view that repository but cannot push changes to it.', 'cm-wlfd' ) ], 403 );
        }
        return [ $owner, $repo, $details ];
    }

    private static function branch_from_request() {
        $branch = isset( $_POST['branch'] ) ? sanitize_text_field( wp_unslash( $_POST['branch'] ) ) : '';
        if ( '' === $branch ) {
            wp_send_json_error( [ 'message' => __( 'Select a branch first.', 'cm-wlfd' ) ] );
        }
        return $branch;
    }

    private static function send_error( $error ) {
        if ( is_wp_error( $error ) ) {
            $data = $error->get_error_data();
            $status = is_array( $data ) && ! empty( $data['status'] ) ? (int) $data['status'] : 400;
            wp_send_json_error( [ 'message' => $error->get_error_message() ], $status );
        }
        wp_send_json_error( [ 'message' => __( 'Unknown GitHub error.', 'cm-wlfd' ) ] );
    }

    private static function excluded_repo( $full_name, $short_name ) {
        $excluded = get_option( 'cm_wlfd_github_view_excluded_repos', [] );
        if ( ! is_array( $excluded ) || empty( $excluded ) ) {
            return false;
        }
        $full_name = strtolower( trim( (string) $full_name ) );
        $short_name = strtolower( trim( (string) $short_name ) );
        foreach ( $excluded as $item ) {
            $item = strtolower( trim( (string) $item ) );
            if ( '' === $item ) {
                continue;
            }
            $parts = explode( '/', $item );
            $item_short = strtolower( trim( (string) end( $parts ) ) );
            if ( $item === $full_name || $item === $short_name || $item_short === $short_name ) {
                return true;
            }
        }
        return false;
    }

    public static function render() {
        if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) ) {
            return '<div class="cm-notice"><strong>Administrator access required.</strong> GitHub content changes are restricted to WordPress administrators.</div>';
        }

        $client = new Client();
        if ( ! $client->has_token() ) {
            return '<div class="cm-title"><h2>GitHub Content</h2></div><div class="cm-notice"><strong>GitHub is not connected.</strong> Save your PAT under Settings → GitHub first.</div>';
        }

        $repos = $client->list_repositories();
        if ( is_wp_error( $repos ) ) {
            return '<div class="cm-title"><h2>GitHub Content</h2></div><div class="cm-notice"><strong>Could not load writable repositories.</strong> ' . esc_html( $repos->get_error_message() ) . '</div>';
        }

        $visible = [];
        foreach ( $repos as $repo ) {
            if ( self::excluded_repo( $repo['full_name'], $repo['name'] ) ) {
                continue;
            }
            $visible[] = $repo;
        }

        ob_start();
        ?>
        <div class="cm-ghfm" data-cm-ghfm="1">
            <div class="cm-ghfm-head">
                <div>
                    <h2><?php esc_html_e( 'GitHub Content', 'cm-wlfd' ); ?></h2>
                    <p><?php esc_html_e( 'Work with repository files like GitHub’s Code page. The PAT stays on WordPress; browser actions go to WordPress first, then WordPress talks to GitHub.', 'cm-wlfd' ); ?></p>
                </div>
            </div>

            <div class="cm-ghfm-status" role="status" aria-live="polite" hidden></div>

            <?php if ( empty( $visible ) ) : ?>
                <div class="cm-notice"><strong><?php esc_html_e( 'No writable repositories are available.', 'cm-wlfd' ); ?></strong> <?php esc_html_e( 'Check the PAT and your GitHub exclusion settings.', 'cm-wlfd' ); ?></div>
            <?php else : ?>
                <div class="cm-ghfm-toolbar">
                    <label class="cm-ghfm-field">
                        <span><?php esc_html_e( 'Repository', 'cm-wlfd' ); ?></span>
                        <select class="cm-ghfm-repo">
                            <option value=""><?php esc_html_e( 'Select repository', 'cm-wlfd' ); ?></option>
                            <?php foreach ( $visible as $repo ) : ?>
                                <option value="<?php echo esc_attr( $repo['full_name'] ); ?>"><?php echo esc_html( $repo['full_name'] ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                    <label class="cm-ghfm-field">
                        <span><?php esc_html_e( 'Branch', 'cm-wlfd' ); ?></span>
                        <select class="cm-ghfm-branch" disabled><option value=""><?php esc_html_e( 'Select repository first', 'cm-wlfd' ); ?></option></select>
                    </label>
                    <div class="cm-ghfm-add-wrap">
                        <button type="button" class="cm-btn cm-ghfm-add-button" disabled><?php esc_html_e( 'Add file', 'cm-wlfd' ); ?> <span aria-hidden="true">▾</span></button>
                        <div class="cm-ghfm-add-menu" hidden>
                            <button type="button" data-ghfm-mode="create"><?php esc_html_e( 'Create new file', 'cm-wlfd' ); ?></button>
                            <button type="button" data-ghfm-mode="upload"><?php esc_html_e( 'Upload files', 'cm-wlfd' ); ?></button>
                        </div>
                    </div>
                </div>

                <div class="cm-ghfm-browser" hidden>
                    <div class="cm-ghfm-breadcrumb"></div>
                    <div class="cm-ghfm-list-wrap">
                        <div class="cm-ghfm-list-head"><strong class="cm-ghfm-list-title"><?php esc_html_e( 'Files', 'cm-wlfd' ); ?></strong><button type="button" class="cm-ghfm-refresh" title="<?php esc_attr_e( 'Refresh', 'cm-wlfd' ); ?>">↻</button></div>
                        <div class="cm-ghfm-list"></div>
                    </div>
                </div>

                <section class="cm-ghfm-workspace" hidden>
                    <div class="cm-ghfm-workspace-head">
                        <button type="button" class="cm-ghfm-back">← <?php esc_html_e( 'Back to files', 'cm-wlfd' ); ?></button>
                        <strong class="cm-ghfm-workspace-title"></strong>
                    </div>

                    <div class="cm-ghfm-mode cm-ghfm-create" data-mode="create" hidden>
                        <h3><?php esc_html_e( 'Create new file', 'cm-wlfd' ); ?></h3>
                        <label class="cm-ghfm-field"><span><?php esc_html_e( 'File path', 'cm-wlfd' ); ?></span><input type="text" class="cm-ghfm-create-path" placeholder="docs/notes.txt"></label>
                        <label class="cm-ghfm-field"><span><?php esc_html_e( 'File contents', 'cm-wlfd' ); ?></span><textarea class="cm-ghfm-create-content" rows="18" spellcheck="false"></textarea></label>
                        <div class="cm-ghfm-commit-box">
                            <h4><?php esc_html_e( 'Commit changes', 'cm-wlfd' ); ?></h4>
                            <label class="cm-ghfm-field"><span><?php esc_html_e( 'Commit message', 'cm-wlfd' ); ?></span><input type="text" class="cm-ghfm-create-message" placeholder="Create new file"></label>
                            <div class="cm-ghfm-actions"><button type="button" class="cm-btn cm-ghfm-create-commit"><?php esc_html_e( 'Commit changes', 'cm-wlfd' ); ?></button><button type="button" class="cm-btn ghost cm-ghfm-cancel"><?php esc_html_e( 'Cancel', 'cm-wlfd' ); ?></button></div>
                        </div>
                    </div>

                    <div class="cm-ghfm-mode cm-ghfm-upload" data-mode="upload" hidden>
                        <h3><?php esc_html_e( 'Upload files', 'cm-wlfd' ); ?></h3>
                        <label class="cm-ghfm-field"><span><?php esc_html_e( 'Destination folder (optional)', 'cm-wlfd' ); ?></span><input type="text" class="cm-ghfm-upload-folder" placeholder="releases"></label>
                        <label class="cm-ghfm-upload-drop"><input type="file" class="cm-ghfm-upload-files" multiple><span><?php esc_html_e( 'Choose files to upload', 'cm-wlfd' ); ?></span><small><?php esc_html_e( 'Existing files with the same path are updated on the selected branch.', 'cm-wlfd' ); ?></small></label>
                        <div class="cm-ghfm-upload-selected"></div>
                        <div class="cm-ghfm-commit-box">
                            <h4><?php esc_html_e( 'Commit changes', 'cm-wlfd' ); ?></h4>
                            <label class="cm-ghfm-field"><span><?php esc_html_e( 'Commit message', 'cm-wlfd' ); ?></span><input type="text" class="cm-ghfm-upload-message" placeholder="Upload files"></label>
                            <div class="cm-ghfm-actions"><button type="button" class="cm-btn cm-ghfm-upload-commit"><?php esc_html_e( 'Commit changes', 'cm-wlfd' ); ?></button><button type="button" class="cm-btn ghost cm-ghfm-cancel"><?php esc_html_e( 'Cancel', 'cm-wlfd' ); ?></button></div>
                        </div>
                    </div>

                    <div class="cm-ghfm-mode cm-ghfm-file" data-mode="file" hidden>
                        <div class="cm-ghfm-file-toolbar"><strong class="cm-ghfm-file-path"></strong><div><button type="button" class="cm-btn ghost cm-ghfm-edit-button"><?php esc_html_e( 'Edit', 'cm-wlfd' ); ?></button><button type="button" class="cm-btn ghost cm-ghfm-delete-button"><?php esc_html_e( 'Delete', 'cm-wlfd' ); ?></button></div></div>
                        <div class="cm-ghfm-file-meta"></div>
                        <pre class="cm-ghfm-file-preview"></pre>
                        <div class="cm-ghfm-file-binary" hidden><?php esc_html_e( 'This file is binary or too large for the browser editor. You can replace it using Upload files or delete it here.', 'cm-wlfd' ); ?></div>
                    </div>

                    <div class="cm-ghfm-mode cm-ghfm-edit" data-mode="edit" hidden>
                        <h3><?php esc_html_e( 'Edit file', 'cm-wlfd' ); ?></h3>
                        <div class="cm-ghfm-edit-path"></div>
                        <textarea class="cm-ghfm-edit-content" rows="20" spellcheck="false"></textarea>
                        <div class="cm-ghfm-commit-box">
                            <h4><?php esc_html_e( 'Commit changes', 'cm-wlfd' ); ?></h4>
                            <label class="cm-ghfm-field"><span><?php esc_html_e( 'Commit message', 'cm-wlfd' ); ?></span><input type="text" class="cm-ghfm-edit-message" placeholder="Update file"></label>
                            <div class="cm-ghfm-actions"><button type="button" class="cm-btn cm-ghfm-edit-commit"><?php esc_html_e( 'Commit changes', 'cm-wlfd' ); ?></button><button type="button" class="cm-btn ghost cm-ghfm-cancel-file-edit"><?php esc_html_e( 'Cancel', 'cm-wlfd' ); ?></button></div>
                        </div>
                    </div>

                    <div class="cm-ghfm-mode cm-ghfm-delete" data-mode="delete" hidden>
                        <h3><?php esc_html_e( 'Delete file', 'cm-wlfd' ); ?></h3>
                        <p><?php esc_html_e( 'This creates a commit that removes the selected file from this branch.', 'cm-wlfd' ); ?></p>
                        <div class="cm-ghfm-delete-path"></div>
                        <div class="cm-ghfm-commit-box cm-ghfm-danger-box">
                            <h4><?php esc_html_e( 'Commit changes', 'cm-wlfd' ); ?></h4>
                            <label class="cm-ghfm-field"><span><?php esc_html_e( 'Commit message', 'cm-wlfd' ); ?></span><input type="text" class="cm-ghfm-delete-message" placeholder="Delete file"></label>
                            <div class="cm-ghfm-actions"><button type="button" class="cm-btn cm-ghfm-delete-commit"><?php esc_html_e( 'Commit deletion', 'cm-wlfd' ); ?></button><button type="button" class="cm-btn ghost cm-ghfm-cancel-file-edit"><?php esc_html_e( 'Cancel', 'cm-wlfd' ); ?></button></div>
                        </div>
                    </div>
                </section>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function ajax_context() {
        self::guard();
        $client = new Client();
        list( $owner, $repo, $details ) = self::repo_from_request( $client );
        $branches = $client->list_branches( $owner, $repo );
        if ( is_wp_error( $branches ) ) {
            self::send_error( $branches );
        }
        $default = ! empty( $details['default_branch'] ) ? (string) $details['default_branch'] : ( ! empty( $branches[0] ) ? $branches[0] : '' );
        wp_send_json_success( [
            'repo'           => $owner . '/' . $repo,
            'branches'       => $branches,
            'default_branch' => $default,
        ] );
    }

    public static function ajax_browse() {
        self::guard();
        $client = new Client();
        list( $owner, $repo ) = self::repo_from_request( $client );
        $branch = self::branch_from_request();
        $path = isset( $_POST['path'] ) ? wp_unslash( $_POST['path'] ) : '';
        $path = Client::clean_path( $path, true );
        if ( is_wp_error( $path ) ) {
            self::send_error( $path );
        }
        $items = $client->get_contents( $owner, $repo, $branch, $path );
        if ( is_wp_error( $items ) ) {
            self::send_error( $items );
        }
        if ( isset( $items['type'] ) ) {
            wp_send_json_error( [ 'message' => __( 'That path is a file, not a folder.', 'cm-wlfd' ) ] );
        }
        $rows = [];
        foreach ( $items as $item ) {
            if ( empty( $item['name'] ) || empty( $item['path'] ) || empty( $item['type'] ) ) {
                continue;
            }
            $rows[] = [
                'name' => (string) $item['name'],
                'path' => (string) $item['path'],
                'type' => (string) $item['type'],
                'sha'  => isset( $item['sha'] ) ? (string) $item['sha'] : '',
                'size' => isset( $item['size'] ) ? (int) $item['size'] : 0,
            ];
        }
        usort( $rows, function( $a, $b ) {
            $adir = 'dir' === $a['type'];
            $bdir = 'dir' === $b['type'];
            if ( $adir !== $bdir ) {
                return $adir ? -1 : 1;
            }
            return strnatcasecmp( $a['name'], $b['name'] );
        } );
        $parent = '';
        if ( '' !== $path && false !== strpos( $path, '/' ) ) {
            $parent = dirname( $path );
            if ( '.' === $parent ) {
                $parent = '';
            }
        }
        wp_send_json_success( [ 'path' => $path, 'parent' => $parent, 'items' => $rows ] );
    }

    public static function ajax_file() {
        self::guard();
        $client = new Client();
        list( $owner, $repo ) = self::repo_from_request( $client );
        $branch = self::branch_from_request();
        $path = isset( $_POST['path'] ) ? wp_unslash( $_POST['path'] ) : '';
        $file = $client->get_file( $owner, $repo, $branch, $path );
        if ( is_wp_error( $file ) ) {
            self::send_error( $file );
        }
        $file['size_label'] = size_format( $file['size'], 1 );
        wp_send_json_success( $file );
    }

    public static function ajax_save() {
        self::guard();
        $client = new Client();
        list( $owner, $repo ) = self::repo_from_request( $client );
        $branch = self::branch_from_request();
        $path = isset( $_POST['path'] ) ? wp_unslash( $_POST['path'] ) : '';
        $content = isset( $_POST['content'] ) ? wp_unslash( $_POST['content'] ) : '';
        $message = isset( $_POST['message'] ) ? wp_unslash( $_POST['message'] ) : '';
        $sha = isset( $_POST['sha'] ) ? sanitize_text_field( wp_unslash( $_POST['sha'] ) ) : '';
        $path = Client::clean_path( $path, false );
        if ( is_wp_error( $path ) ) {
            self::send_error( $path );
        }

        if ( '' === $sha ) {
            // Create-new follows GitHub's behaviour: do not silently overwrite an existing file.
            $existing = $client->get_contents( $owner, $repo, $branch, $path );
            if ( ! is_wp_error( $existing ) && ! empty( $existing['sha'] ) ) {
                wp_send_json_error( [ 'message' => __( 'A file already exists at that path. Open the existing file and use Edit instead.', 'cm-wlfd' ) ], 409 );
            }
        }

        $result = $client->create_or_update_file( $owner, $repo, $branch, $path, $content, $message, $sha );
        if ( is_wp_error( $result ) ) {
            self::send_error( $result );
        }
        $new_sha = ! empty( $result['content']['sha'] ) ? (string) $result['content']['sha'] : '';
        $commit_sha = ! empty( $result['commit']['sha'] ) ? (string) $result['commit']['sha'] : '';
        wp_send_json_success( [
            'message'    => '' !== $sha ? __( 'File updated on GitHub.', 'cm-wlfd' ) : __( 'File created on GitHub.', 'cm-wlfd' ),
            'path'       => $path,
            'sha'        => $new_sha,
            'commit_sha' => $commit_sha,
        ] );
    }

    public static function ajax_upload() {
        self::guard();
        $client = new Client();
        list( $owner, $repo ) = self::repo_from_request( $client );
        $branch = self::branch_from_request();
        $folder = isset( $_POST['folder'] ) ? wp_unslash( $_POST['folder'] ) : '';
        $folder = Client::clean_path( $folder, true );
        if ( is_wp_error( $folder ) ) {
            self::send_error( $folder );
        }
        $message = isset( $_POST['message'] ) ? sanitize_text_field( wp_unslash( $_POST['message'] ) ) : '';

        if ( empty( $_FILES['files'] ) || empty( $_FILES['files']['name'] ) ) {
            wp_send_json_error( [ 'message' => __( 'Choose at least one file to upload.', 'cm-wlfd' ) ] );
        }

        $names = (array) $_FILES['files']['name'];
        $tmp_names = (array) $_FILES['files']['tmp_name'];
        $errors = (array) $_FILES['files']['error'];
        $sizes = (array) $_FILES['files']['size'];
        $max_upload = min( 50 * 1024 * 1024, (int) wp_max_upload_size() );
        $results = [];

        foreach ( $names as $index => $original_name ) {
            $error = isset( $errors[ $index ] ) ? (int) $errors[ $index ] : UPLOAD_ERR_NO_FILE;
            if ( UPLOAD_ERR_OK !== $error ) {
                wp_send_json_error( [ 'message' => sprintf( __( 'WordPress could not receive %s (upload error %d).', 'cm-wlfd' ), sanitize_file_name( $original_name ), $error ) ] );
            }
            $size = isset( $sizes[ $index ] ) ? (int) $sizes[ $index ] : 0;
            if ( $size > $max_upload ) {
                wp_send_json_error( [ 'message' => sprintf( __( '%1$s is larger than this dashboard upload limit of %2$s.', 'cm-wlfd' ), sanitize_file_name( $original_name ), size_format( $max_upload ) ) ] );
            }
            $tmp = isset( $tmp_names[ $index ] ) ? (string) $tmp_names[ $index ] : '';
            if ( '' === $tmp || ! is_uploaded_file( $tmp ) ) {
                wp_send_json_error( [ 'message' => sprintf( __( 'WordPress could not read the uploaded file %s.', 'cm-wlfd' ), sanitize_file_name( $original_name ) ) ] );
            }
            $filename = Client::clean_filename( $original_name );
            if ( is_wp_error( $filename ) ) {
                self::send_error( $filename );
            }
            $path = ( '' !== $folder ? $folder . '/' : '' ) . $filename;
            $body = file_get_contents( $tmp );
            if ( false === $body ) {
                wp_send_json_error( [ 'message' => sprintf( __( 'WordPress could not read %s.', 'cm-wlfd' ), $filename ) ] );
            }

            $existing = $client->get_contents( $owner, $repo, $branch, $path );
            $sha = '';
            if ( ! is_wp_error( $existing ) && ! empty( $existing['sha'] ) && ( $existing['type'] ?? '' ) === 'file' ) {
                $sha = (string) $existing['sha'];
            }

            $commit_message = '' !== trim( $message ) ? $message : ( '' !== $sha ? 'Update ' : 'Upload ' ) . $path;
            $result = $client->create_or_update_file( $owner, $repo, $branch, $path, $body, $commit_message, $sha );
            if ( is_wp_error( $result ) ) {
                self::send_error( $result );
            }
            $results[] = [
                'path'       => $path,
                'sha'        => ! empty( $result['content']['sha'] ) ? (string) $result['content']['sha'] : '',
                'commit_sha' => ! empty( $result['commit']['sha'] ) ? (string) $result['commit']['sha'] : '',
                'updated'    => '' !== $sha,
            ];
        }

        wp_send_json_success( [
            'message' => sprintf( _n( '%d file committed to GitHub.', '%d files committed to GitHub.', count( $results ), 'cm-wlfd' ), count( $results ) ),
            'folder'  => $folder,
            'files'   => $results,
        ] );
    }

    public static function ajax_delete() {
        self::guard();
        $client = new Client();
        list( $owner, $repo ) = self::repo_from_request( $client );
        $branch = self::branch_from_request();
        $path = isset( $_POST['path'] ) ? wp_unslash( $_POST['path'] ) : '';
        $message = isset( $_POST['message'] ) ? wp_unslash( $_POST['message'] ) : '';
        $result = $client->delete_file( $owner, $repo, $branch, $path, $message );
        if ( is_wp_error( $result ) ) {
            self::send_error( $result );
        }
        wp_send_json_success( [
            'message'    => __( 'File deleted from GitHub.', 'cm-wlfd' ),
            'path'       => Client::clean_path( $path, false ),
            'commit_sha' => ! empty( $result['commit']['sha'] ) ? (string) $result['commit']['sha'] : '',
        ] );
    }
}
