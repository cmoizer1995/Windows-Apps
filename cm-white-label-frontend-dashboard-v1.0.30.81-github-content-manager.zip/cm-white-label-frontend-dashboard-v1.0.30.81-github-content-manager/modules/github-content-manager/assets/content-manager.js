(function($){
    'use strict';

    function cfg(){
        return window.cmWlfdGithubContent || { ajaxurl: '/wp-admin/admin-ajax.php', nonce: '' };
    }

    function state($root){
        var s = $root.data('ghfmState');
        if(!s){
            s = { repo:'', branch:'', path:'', file:null, busy:false };
            $root.data('ghfmState', s);
        }
        return s;
    }

    function setBusy($root, busy){
        var s = state($root); s.busy = !!busy;
        $root.toggleClass('is-busy', !!busy);
        $root.find('button, select, input, textarea').each(function(){
            var $el=$(this);
            if(busy){
                if(typeof $el.data('ghfmWasDisabled') === 'undefined') $el.data('ghfmWasDisabled', !!$el.prop('disabled'));
                $el.prop('disabled', true);
            }else{
                var wasDisabled = !!$el.data('ghfmWasDisabled');
                $el.removeData('ghfmWasDisabled').prop('disabled', wasDisabled);
            }
        });
        if(!busy){
            $root.find('.cm-ghfm-repo').prop('disabled', false);
            $root.find('.cm-ghfm-branch').prop('disabled', !s.repo);
            $root.find('.cm-ghfm-add-button').prop('disabled', !s.repo || !s.branch);
            var f=s.file;
            if(f && !f.editable) $root.find('.cm-ghfm-edit-button').prop('disabled', true);
        }
    }

    function status($root, message, type){
        var $box = $root.find('.cm-ghfm-status');
        if(!message){ $box.attr('hidden', true).text('').removeClass('is-error is-success is-info'); return; }
        $box.removeAttr('hidden').removeClass('is-error is-success is-info').addClass(type === 'error' ? 'is-error' : (type === 'success' ? 'is-success' : 'is-info')).text(message);
    }

    function errorMessage(xhr, fallback){
        if(xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) return xhr.responseJSON.data.message;
        if(xhr && xhr.responseJSON && xhr.responseJSON.data && typeof xhr.responseJSON.data === 'string') return xhr.responseJSON.data;
        return fallback || 'GitHub request failed.';
    }

    function post($root, action, data){
        data = data || {};
        data.action = action;
        data.nonce = cfg().nonce || '';
        return $.ajax({ url: cfg().ajaxurl, method:'POST', data:data, dataType:'json' });
    }

    function currentRepo($root){ return $root.find('.cm-ghfm-repo').val() || ''; }
    function currentBranch($root){ return $root.find('.cm-ghfm-branch').val() || ''; }

    function showBrowser($root){
        $root.find('.cm-ghfm-workspace').attr('hidden', true);
        $root.find('.cm-ghfm-mode').attr('hidden', true);
        $root.find('.cm-ghfm-browser').removeAttr('hidden');
    }

    function showMode($root, mode, title){
        $root.find('.cm-ghfm-browser').attr('hidden', true);
        $root.find('.cm-ghfm-workspace').removeAttr('hidden');
        $root.find('.cm-ghfm-mode').attr('hidden', true);
        $root.find('.cm-ghfm-mode[data-mode="'+mode+'"]').removeAttr('hidden');
        $root.find('.cm-ghfm-workspace-title').text(title || '');
        $root.find('.cm-ghfm-add-menu').attr('hidden', true);
    }

    function folderOf(path){
        path = String(path || '').replace(/^\/+|\/+$/g,'');
        if(!path || path.indexOf('/') === -1) return '';
        return path.substring(0, path.lastIndexOf('/'));
    }

    function renderBreadcrumb($root, path){
        var s = state($root), $crumb = $root.find('.cm-ghfm-breadcrumb');
        $crumb.empty();
        var repoLabel = (s.repo.split('/')[1] || s.repo || 'Repository');
        $('<button type="button" class="cm-ghfm-crumb"></button>').text(repoLabel).attr('data-path','').appendTo($crumb);
        var built = '';
        String(path || '').split('/').filter(Boolean).forEach(function(part){
            $('<span class="cm-ghfm-crumb-sep">/</span>').appendTo($crumb);
            built += (built ? '/' : '') + part;
            $('<button type="button" class="cm-ghfm-crumb"></button>').text(part).attr('data-path',built).appendTo($crumb);
        });
    }

    function iconFor(type){
        if(type === 'dir') return '▸';
        if(type === 'symlink') return '↗';
        if(type === 'submodule') return '▣';
        return '▤';
    }

    function renderList($root, payload){
        var s = state($root), $list = $root.find('.cm-ghfm-list');
        s.path = payload.path || '';
        renderBreadcrumb($root, s.path);
        $root.find('.cm-ghfm-list-title').text(s.branch ? s.branch : 'Files');
        $list.empty();

        var items = payload.items || [];
        if(!items.length){
            $('<div class="cm-ghfm-empty">This folder is empty.</div>').appendTo($list);
            return;
        }

        items.forEach(function(item){
            var $row = $('<div class="cm-ghfm-row"></div>').attr('data-type', item.type).attr('data-path', item.path);
            $('<span class="cm-ghfm-row-icon" aria-hidden="true"></span>').text(iconFor(item.type)).appendTo($row);
            var $name = $('<button type="button" class="cm-ghfm-row-name"></button>').text(item.name).appendTo($row);
            if(item.type === 'dir') $name.addClass('is-dir'); else $name.addClass('is-file');
            var size = item.type === 'file' && item.size ? humanBytes(item.size) : '';
            $('<span class="cm-ghfm-row-meta"></span>').text(size).appendTo($row);
            $list.append($row);
        });
    }

    function humanBytes(bytes){
        bytes = Number(bytes || 0);
        if(bytes < 1024) return bytes + ' B';
        var units = ['KB','MB','GB'], n = bytes / 1024, u = 0;
        while(n >= 1024 && u < units.length-1){ n /= 1024; u++; }
        return n.toFixed(n < 10 ? 1 : 0) + ' ' + units[u];
    }

    function browse($root, path){
        var s = state($root);
        if(!s.repo || !s.branch) return;
        setBusy($root, true);
        status($root, 'Loading '+(path || 'repository')+'…', 'info');
        post($root, 'cm_wlfd_ghfm_browse', { repo:s.repo, branch:s.branch, path:path || '' })
            .done(function(res){
                if(res && res.success){
                    showBrowser($root);
                    renderList($root, res.data || {});
                    status($root, '', 'info');
                }else{
                    status($root, (res && res.data && res.data.message) ? res.data.message : 'Could not load repository files.', 'error');
                }
            })
            .fail(function(xhr){ status($root, errorMessage(xhr, 'Could not load repository files.'), 'error'); })
            .always(function(){ setBusy($root, false); });
    }

    function loadContext($root){
        var s = state($root), repo = currentRepo($root), $branch = $root.find('.cm-ghfm-branch');
        s.repo = repo; s.branch=''; s.path=''; s.file=null;
        $branch.empty().append($('<option>',{value:'',text:'Loading branches…'})).prop('disabled', true);
        $root.find('.cm-ghfm-browser,.cm-ghfm-workspace').attr('hidden', true);
        $root.find('.cm-ghfm-add-button').prop('disabled', true);
        if(!repo){
            $branch.empty().append($('<option>',{value:'',text:'Select repository first'}));
            return;
        }
        setBusy($root, true);
        status($root, 'Loading branches from GitHub…', 'info');
        post($root, 'cm_wlfd_ghfm_context', { repo:repo })
            .done(function(res){
                if(!(res && res.success)){ status($root, (res && res.data && res.data.message) ? res.data.message : 'Could not load branches.', 'error'); return; }
                var d = res.data || {}, branches = d.branches || [];
                $branch.empty();
                branches.forEach(function(name){ $branch.append($('<option>',{value:name,text:name})); });
                if(!branches.length){ $branch.append($('<option>',{value:'',text:'No branches'})); return; }
                var selected = d.default_branch && branches.indexOf(d.default_branch) !== -1 ? d.default_branch : branches[0];
                $branch.val(selected);
                s.branch = selected;
                status($root, '', 'info');
                setTimeout(function(){ browse($root, ''); }, 0);
            })
            .fail(function(xhr){ status($root, errorMessage(xhr, 'Could not load branches.'), 'error'); })
            .always(function(){ setBusy($root, false); });
    }

    function loadFile($root, path){
        var s = state($root);
        setBusy($root, true);
        status($root, 'Loading file from GitHub…', 'info');
        post($root, 'cm_wlfd_ghfm_file', { repo:s.repo, branch:s.branch, path:path })
            .done(function(res){
                if(!(res && res.success)){ status($root, (res && res.data && res.data.message) ? res.data.message : 'Could not load file.', 'error'); return; }
                s.file = res.data || {};
                var f = s.file;
                showMode($root, 'file', f.path || 'File');
                $root.find('.cm-ghfm-file-path').text(f.path || '');
                $root.find('.cm-ghfm-file-meta').text((f.size_label || humanBytes(f.size)) + (f.sha ? ' · '+f.sha.substring(0,7) : ''));
                $root.find('.cm-ghfm-file-preview').text(f.content || '').prop('hidden', !f.editable);
                $root.find('.cm-ghfm-file-binary').prop('hidden', !!f.editable);
                $root.find('.cm-ghfm-edit-button').prop('disabled', !f.editable).attr('title', f.editable ? '' : 'This file cannot be edited as text in the browser.');
                status($root, '', 'info');
            })
            .fail(function(xhr){ status($root, errorMessage(xhr, 'Could not load file.'), 'error'); })
            .always(function(){ setBusy($root, false); });
    }

    function afterSave($root, path, message, reopen){
        status($root, message || 'Committed to GitHub.', 'success');
        if(reopen){
            setTimeout(function(){ loadFile($root, path); }, 250);
        }else{
            setTimeout(function(){ browse($root, folderOf(path)); }, 250);
        }
    }

    $(document).on('change', '.cm-ghfm-repo', function(){ loadContext($(this).closest('.cm-ghfm')); });

    $(document).on('change', '.cm-ghfm-branch', function(){
        var $root = $(this).closest('.cm-ghfm'), s = state($root);
        s.branch = $(this).val() || ''; s.path=''; s.file=null;
        if(s.branch) browse($root, '');
    });

    $(document).on('click', '.cm-ghfm-refresh', function(){ var $root=$(this).closest('.cm-ghfm'); browse($root, state($root).path || ''); });
    $(document).on('click', '.cm-ghfm-crumb', function(){ var $root=$(this).closest('.cm-ghfm'); browse($root, $(this).attr('data-path') || ''); });

    $(document).on('click', '.cm-ghfm-row-name', function(){
        var $row=$(this).closest('.cm-ghfm-row'), $root=$(this).closest('.cm-ghfm'), path=$row.attr('data-path') || '';
        if($row.attr('data-type') === 'dir') browse($root, path); else loadFile($root, path);
    });

    $(document).on('click', '.cm-ghfm-add-button', function(e){
        e.stopPropagation();
        var $menu=$(this).siblings('.cm-ghfm-add-menu');
        $menu.prop('hidden', !$menu.prop('hidden'));
    });
    $(document).on('click', function(e){ if(!$(e.target).closest('.cm-ghfm-add-wrap').length) $('.cm-ghfm-add-menu').attr('hidden', true); });

    $(document).on('click', '[data-ghfm-mode="create"]', function(){
        var $root=$(this).closest('.cm-ghfm'), s=state($root), prefix=s.path ? s.path+'/' : '';
        showMode($root,'create','Create new file');
        $root.find('.cm-ghfm-create-path').val(prefix);
        $root.find('.cm-ghfm-create-content,.cm-ghfm-create-message').val('');
        setTimeout(function(){ $root.find('.cm-ghfm-create-path').focus(); }, 0);
    });
    $(document).on('click', '[data-ghfm-mode="upload"]', function(){
        var $root=$(this).closest('.cm-ghfm'), s=state($root);
        showMode($root,'upload','Upload files');
        $root.find('.cm-ghfm-upload-folder').val(s.path || '');
        $root.find('.cm-ghfm-upload-files').val('');
        $root.find('.cm-ghfm-upload-selected').empty();
        $root.find('.cm-ghfm-upload-message').val('');
    });

    $(document).on('change', '.cm-ghfm-upload-files', function(){
        var $root=$(this).closest('.cm-ghfm'), $list=$root.find('.cm-ghfm-upload-selected').empty(), files=this.files || [];
        Array.prototype.forEach.call(files,function(file){ $('<div class="cm-ghfm-upload-item"></div>').text(file.name+' · '+humanBytes(file.size)).appendTo($list); });
    });

    $(document).on('click', '.cm-ghfm-back,.cm-ghfm-cancel', function(){ var $root=$(this).closest('.cm-ghfm'); browse($root,state($root).path || ''); });

    $(document).on('click', '.cm-ghfm-edit-button', function(){
        var $root=$(this).closest('.cm-ghfm'), f=state($root).file;
        if(!f || !f.editable) return;
        showMode($root,'edit','Edit '+f.path);
        $root.find('.cm-ghfm-edit-path').text(f.path);
        $root.find('.cm-ghfm-edit-content').val(f.content || '');
        $root.find('.cm-ghfm-edit-message').val('Update '+f.path);
    });

    $(document).on('click', '.cm-ghfm-delete-button', function(){
        var $root=$(this).closest('.cm-ghfm'), f=state($root).file;
        if(!f) return;
        showMode($root,'delete','Delete '+f.path);
        $root.find('.cm-ghfm-delete-path').text(f.path);
        $root.find('.cm-ghfm-delete-message').val('Delete '+f.path);
    });

    $(document).on('click', '.cm-ghfm-cancel-file-edit', function(){
        var $root=$(this).closest('.cm-ghfm'), f=state($root).file;
        if(f) loadFile($root,f.path); else browse($root,state($root).path || '');
    });

    $(document).on('click', '.cm-ghfm-create-commit', function(){
        var $root=$(this).closest('.cm-ghfm'), s=state($root), path=$root.find('.cm-ghfm-create-path').val() || '', content=$root.find('.cm-ghfm-create-content').val() || '', message=$root.find('.cm-ghfm-create-message').val() || '';
        if(!path.trim()){ status($root,'Enter a file path.','error'); return; }
        setBusy($root,true); status($root,'Committing new file to '+s.branch+'…','info');
        post($root,'cm_wlfd_ghfm_save',{repo:s.repo,branch:s.branch,path:path,content:content,message:message,sha:''})
            .done(function(res){ if(res&&res.success) afterSave($root,res.data.path,res.data.message,true); else status($root,(res&&res.data&&res.data.message)||'Could not create file.','error'); })
            .fail(function(xhr){ status($root,errorMessage(xhr,'Could not create file.'),'error'); })
            .always(function(){ setBusy($root,false); });
    });

    $(document).on('click', '.cm-ghfm-edit-commit', function(){
        var $root=$(this).closest('.cm-ghfm'), s=state($root), f=s.file;
        if(!f) return;
        var content=$root.find('.cm-ghfm-edit-content').val() || '', message=$root.find('.cm-ghfm-edit-message').val() || '';
        setBusy($root,true); status($root,'Committing changes to '+s.branch+'…','info');
        post($root,'cm_wlfd_ghfm_save',{repo:s.repo,branch:s.branch,path:f.path,content:content,message:message,sha:f.sha || ''})
            .done(function(res){ if(res&&res.success){ if(res.data.sha) f.sha=res.data.sha; afterSave($root,f.path,res.data.message,true); } else status($root,(res&&res.data&&res.data.message)||'Could not update file.','error'); })
            .fail(function(xhr){ status($root,errorMessage(xhr,'Could not update file.'),'error'); })
            .always(function(){ setBusy($root,false); });
    });

    $(document).on('click', '.cm-ghfm-delete-commit', function(){
        var $root=$(this).closest('.cm-ghfm'), s=state($root), f=s.file;
        if(!f) return;
        var message=$root.find('.cm-ghfm-delete-message').val() || '';
        setBusy($root,true); status($root,'Deleting '+f.path+' from '+s.branch+'…','info');
        post($root,'cm_wlfd_ghfm_delete',{repo:s.repo,branch:s.branch,path:f.path,message:message})
            .done(function(res){ if(res&&res.success){ s.file=null; status($root,res.data.message,'success'); setTimeout(function(){ browse($root,folderOf(f.path)); },250); } else status($root,(res&&res.data&&res.data.message)||'Could not delete file.','error'); })
            .fail(function(xhr){ status($root,errorMessage(xhr,'Could not delete file.'),'error'); })
            .always(function(){ setBusy($root,false); });
    });

    $(document).on('click', '.cm-ghfm-upload-commit', function(){
        var $root=$(this).closest('.cm-ghfm'), s=state($root), input=$root.find('.cm-ghfm-upload-files').get(0), files=input ? input.files : null;
        if(!files || !files.length){ status($root,'Choose at least one file to upload.','error'); return; }
        var fd=new FormData();
        fd.append('action','cm_wlfd_ghfm_upload'); fd.append('nonce',cfg().nonce||''); fd.append('repo',s.repo); fd.append('branch',s.branch); fd.append('folder',$root.find('.cm-ghfm-upload-folder').val()||''); fd.append('message',$root.find('.cm-ghfm-upload-message').val()||'');
        Array.prototype.forEach.call(files,function(file){ fd.append('files[]',file,file.name); });
        setBusy($root,true); status($root,'Uploading and committing '+files.length+' file'+(files.length===1?'':'s')+' to '+s.branch+'…','info');
        $.ajax({url:cfg().ajaxurl,method:'POST',data:fd,processData:false,contentType:false,dataType:'json'})
            .done(function(res){
                if(res&&res.success){
                    status($root,res.data.message,'success');
                    var folder=res.data.folder || '';
                    $root.find('.cm-ghfm-upload-files').val(''); $root.find('.cm-ghfm-upload-selected').empty();
                    setTimeout(function(){ browse($root,folder); },250);
                }else status($root,(res&&res.data&&res.data.message)||'Could not upload files.','error');
            })
            .fail(function(xhr){ status($root,errorMessage(xhr,'Could not upload files.'),'error'); })
            .always(function(){ setBusy($root,false); });
    });

})(jQuery);
