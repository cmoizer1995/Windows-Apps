<?php
/**
 * Orbital Service Theme
 *
 * Author: Connor Moizer
 * Author URI: https://connormoizer.com
 * Copyright © Connor Moizer. All rights reserved.
 */
if (!defined('ABSPATH')) { exit; } ?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="site">
<header class="ost-global-header" role="banner">
  <div class="ost-wrap ost-header-row ost-global-row">
    <a class="ost-title-brand" href="<?php echo ost_main_header_url(); ?>" rel="home">
      <span class="ost-site-title" title="<?php echo esc_attr(function_exists('ost_main_header_title_text') ? ost_main_header_title_text() : get_bloginfo('name')); ?>"><?php echo ost_main_header_title_html(); ?></span>
      <span class="ost-site-description"><?php bloginfo('description'); ?></span>
    </a>
    <button class="ost-nav-toggle ost-mobile-toggle" type="button" aria-expanded="false" aria-controls="ost-primary-nav"><?php esc_html_e('Menu','orbital-service-theme'); ?></button>
    <nav id="ost-primary-nav" class="ost-nav-panel ost-primary-nav" aria-label="<?php esc_attr_e('Global navigation','orbital-service-theme'); ?>">
      <?php wp_nav_menu(array('theme_location'=>'primary','container'=>false,'menu_class'=>'ost-menu ost-header-menu','fallback_cb'=>'ost_default_primary_menu','walker'=>new OST_Accordion_Walker())); ?>
      <a class="ost-search-link" href="<?php echo esc_url(function_exists('ost_main_search_button_url') ? ost_main_search_button_url() : home_url('/?s=')); ?>"><?php esc_html_e('Search','orbital-service-theme'); ?></a>
    </nav>
  </div>
</header>
<?php if (ost_show_service_nav()) : ?>
<header class="ost-service-header" role="navigation" aria-label="<?php esc_attr_e('Service header','orbital-service-theme'); ?>">
  <div class="ost-wrap ost-header-row ost-service-row">
    <a class="ost-service-brand" href="<?php echo ost_service_title_url(); ?>">
      <span class="ost-service-title"><?php echo esc_html(ost_service_title_text()); ?></span>
      <span class="ost-service-description"><?php echo esc_html(function_exists('ost_service_subtitle_text') ? ost_service_subtitle_text() : get_theme_mod('ost_service_subtitle','Sections and updates')); ?></span>
    </a>
    <button class="ost-nav-toggle ost-service-mobile-toggle" type="button" aria-expanded="false" aria-controls="ost-service-nav"><?php esc_html_e('Menu','orbital-service-theme'); ?></button>
    <nav id="ost-service-nav" class="ost-nav-panel ost-service-nav-panel" aria-label="<?php esc_attr_e('Service navigation','orbital-service-theme'); ?>">
      <?php wp_nav_menu(array('theme_location'=>'service','container'=>false,'menu_class'=>'ost-menu ost-service-menu','menu_id'=>'ost-service-menu','fallback_cb'=>'ost_default_service_menu','walker'=>new OST_Accordion_Walker())); ?>
    </nav>
  </div>
</header>
<?php endif; ?>
<main id="primary" class="site-main <?php echo is_front_page() ? 'ost-home-blank-main ost-blank-main' : 'ost-content-main'; ?>">
<?php
/* v1.0.81: Force the normal page/CPT title above content automatically, even when Elementor is used for the page body. */
ost_render_page_title();
?>
