<?php
/**
 * Orbital Service Theme
 *
 * Author: Connor Moizer
 * Author URI: https://connormoizer.com
 * Copyright © Connor Moizer. All rights reserved.
 */

/**
 * Shared visible 404 template.
 *
 * Keeps the broken/current URL in the browser, returns a real 404 status,
 * and renders the same main-site styled 404 layout across multisite subsites.
 *
 * @package Orbital_Service_Theme
 */

status_header(404);
nocache_headers();

$ost_404_home_url   = function_exists('ost_global_404_home_url') ? ost_global_404_home_url() : home_url('/');
$ost_404_search_url = function_exists('ost_global_404_search_url') ? ost_global_404_search_url() : home_url('/');
$ost_404_broken_url = function_exists('ost_current_broken_url') ? ost_current_broken_url() : '';

get_header();
?>

<section class="cm-404-page" aria-labelledby="cm-404-title">
    <div class="cm-404-wrap">
        <div class="cm-404-inner">
            <p class="cm-404-kicker"><?php esc_html_e( 'Error 404', 'orbital-service-theme' ); ?></p>

            <h1 id="cm-404-title" class="cm-404-title"><?php esc_html_e( 'Page not found', 'orbital-service-theme' ); ?></h1>

            <p class="cm-404-text">
                <?php esc_html_e( 'The page you are looking for may have been removed, renamed, or is temporarily unavailable.', 'orbital-service-theme' ); ?>
            </p>

            <?php if ( $ost_404_broken_url ) : ?>
                <p class="cm-404-source">
                    <?php esc_html_e( 'Requested URL:', 'orbital-service-theme' ); ?>
                    <span><?php echo esc_html( $ost_404_broken_url ); ?></span>
                </p>
            <?php endif; ?>

            <div class="cm-404-actions">
                <a class="cm-404-button" href="<?php echo esc_url( $ost_404_home_url ); ?>">
                    <?php esc_html_e( 'Homepage', 'orbital-service-theme' ); ?>
                </a>

                <button type="button" class="cm-404-button cm-404-back">
                    <?php esc_html_e( 'Go Back', 'orbital-service-theme' ); ?>
                </button>
            </div>

            <form class="cm-404-search" role="search" method="get" action="<?php echo esc_url( $ost_404_search_url ); ?>">
                <label class="screen-reader-text" for="cm-404-search-field"><?php esc_html_e( 'Search', 'orbital-service-theme' ); ?></label>
                <input id="cm-404-search-field" type="search" name="s" value="" placeholder="<?php esc_attr_e( 'Search Connor Moizer', 'orbital-service-theme' ); ?>">
                <button type="submit"><?php esc_html_e( 'Search', 'orbital-service-theme' ); ?></button>
            </form>
        </div>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var backButton = document.querySelector('.cm-404-back');
    if (backButton) {
        backButton.addEventListener('click', function () {
            if (window.history.length > 1) {
                window.history.back();
            } else {
                window.location.href = '<?php echo esc_js( $ost_404_home_url ); ?>';
            }
        });
    }
});
</script>

<?php
get_footer();
