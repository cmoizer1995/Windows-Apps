<?php
/**
 * Orbital Service Theme
 *
 * Author: Connor Moizer
 * Author URI: https://connormoizer.com
 * Copyright © Connor Moizer. All rights reserved.
 */

get_header();
?>
<section class="ost-content-shell">
  <div class="ost-main-content ost-layout <?php echo esc_attr(function_exists('ost_layout_sidebar_position_class') ? ost_layout_sidebar_position_class() : 'ost-layout-sidebar-right'); ?>">
    <div class="ost-main">
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class('ost-entry'); ?>>
          <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
          <?php if (function_exists('ost_is_blog_style_post_type') && ost_is_blog_style_post_type(get_post_type())) { ost_itv_datetime_author_meta(get_the_ID(), 'full'); } ?>
          <div class="entry-content"><?php the_excerpt(); ?></div>
        </article>
      <?php endwhile; the_posts_pagination(); else : ?>
        <p><?php esc_html_e('No content found.', 'orbital-service-theme'); ?></p>
      <?php endif; ?>
    </div>
    <?php get_sidebar(); ?>
  </div>
</section>
<?php
get_footer();
