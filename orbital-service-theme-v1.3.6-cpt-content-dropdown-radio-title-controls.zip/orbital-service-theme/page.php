<?php
/**
 * Orbital Service Theme
 *
 * Author: Connor Moizer
 * Author URI: https://connormoizer.com
 * Copyright © Connor Moizer. All rights reserved.
 */

get_header();
?>
<section class="ost-content-shell">
  <div class="ost-main-content ost-layout <?php echo esc_attr(function_exists('ost_layout_sidebar_position_class') ? ost_layout_sidebar_position_class() : 'ost-layout-sidebar-right'); ?>">
    <div class="ost-main">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <article id="post-<?php the_ID(); ?>" <?php post_class('ost-entry'); ?>>
        <div class="entry-content">
          <?php the_content(); ?>
          <?php wp_link_pages(array('before'=>'<div class="page-links">','after'=>'</div>')); ?>
        </div>
      </article>
    <?php endwhile; endif; ?>
    </div>
    <?php get_sidebar(); ?>
  </div>
</section>
<?php
get_footer();
