<?php
/**
 * Orbital Service Theme
 *
 * Author: Connor Moizer
 * Author URI: https://connormoizer.com
 * Copyright © Connor Moizer. All rights reserved.
 */

/**
 * Search / content finder template.
 *
 * Shows CPT tabs before any search term is entered, then filters those same
 * tabs after a search. Supports current-site and multisite network search.
 */
get_header();

$search_query = get_search_query(false);
?>
<section class="ost-content-shell ost-search-results-shell">
  <div class="ost-main-content ost-search-fullwidth">
    <main class="ost-search-main" role="main">
      <?php ost_render_search_scope_controls($search_query); ?>
      <form role="search" method="get" class="search-form" action="<?php echo esc_url(ost_current_search_page_url()); ?>">
        <label>
          <span class="screen-reader-text"><?php esc_html_e('Search for:', 'orbital-service-theme'); ?></span>
          <input type="search" class="search-field" placeholder="<?php esc_attr_e('Search posts, blogs, CVs and portfolio', 'orbital-service-theme'); ?>" value="<?php echo esc_attr($search_query); ?>" name="s" />
        </label>
        <input type="hidden" name="ost_scope" value="<?php echo esc_attr(ost_search_requested_scope()); ?>" />
        <?php if (ost_search_requested_scope() === 'site') : ?>
          <input type="hidden" name="ost_site" value="<?php echo esc_attr(ost_search_requested_site_id()); ?>" />
        <?php endif; ?>
        <button type="submit" class="search-submit"><?php esc_html_e('Search', 'orbital-service-theme'); ?></button>
      </form>

      <p class="ost-search-count-label">
        <?php if ($search_query !== '') : ?>
          <?php printf(esc_html__('Showing filtered results for: %s', 'orbital-service-theme'), '<strong>' . esc_html($search_query) . '</strong>'); ?>
        <?php else : ?>
          <?php esc_html_e('Choose a tab below to browse posts, blogs, live blogs and plugin registered CPTs such as CV or Portfolio. Use the search box to filter these tabs down to matching items.', 'orbital-service-theme'); ?>
        <?php endif; ?>
      </p>

      <?php ost_render_theme_search_results($search_query); ?>
    </main>
  </div>
</section>
<?php
get_footer();
