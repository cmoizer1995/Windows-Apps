<?php
/**
 * Orbital Service Theme
 *
 * Author: Connor Moizer
 * Author URI: https://connormoizer.com
 * Copyright © Connor Moizer. All rights reserved.
 */

if (!defined('ABSPATH')) { exit; }

define('OST_VERSION', '1.3.6');

function ost_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
    add_theme_support('automatic-feed-links');
    register_nav_menus(array(
        'primary' => __('Global header menu', 'orbital-service-theme'),
        'service' => __('Mission/service menu', 'orbital-service-theme'),
        'footer' => __('Footer menu', 'orbital-service-theme'),
    ));
}
add_action('after_setup_theme', 'ost_setup');

function ost_assets() {
    wp_enqueue_style('ost-style', get_stylesheet_uri(), array(), OST_VERSION);
    wp_enqueue_script('ost-navigation', get_template_directory_uri() . '/assets/js/navigation.js', array(), OST_VERSION, true);
}
add_action('wp_enqueue_scripts', 'ost_assets');

function ost_get_site_initials() {
    $name = trim(wp_strip_all_tags(get_bloginfo('name')));
    if ($name === '') { return 'CM'; }

    $words = preg_split('/\s+/', $name, -1, PREG_SPLIT_NO_EMPTY);
    $word_count = is_array($words) ? count($words) : 0;

    if ($word_count <= 2) {
        return $name;
    }

    $initials = '';
    foreach ($words as $word) {
        $word = trim($word);
        if ($word === '') { continue; }
        $initials .= function_exists('mb_strtoupper') ? mb_strtoupper(mb_substr($word, 0, 1)) : strtoupper(substr($word, 0, 1));
        if (strlen($initials) >= 3) { break; }
    }

    return $initials ? $initials : $name;
}

function ost_main_network_blog_id() {
    if (is_multisite()) {
        if (function_exists('get_main_site_id')) {
            return absint(get_main_site_id());
        }
        if (defined('BLOG_ID_CURRENT_SITE')) {
            return absint(BLOG_ID_CURRENT_SITE);
        }
    }
    return get_current_blog_id();
}

function ost_main_network_site_title() {
    if (is_multisite()) {
        $main_blog_id = ost_main_network_blog_id();
        $main_title = trim(wp_strip_all_tags((string) get_blog_option($main_blog_id, 'blogname')));
        if ($main_title !== '') {
            return $main_title;
        }
    }

    $current_title = trim(wp_strip_all_tags(get_bloginfo('name')));
    return $current_title !== '' ? $current_title : 'Connor Moizer';
}

function ost_main_header_title_text() {
    $source = get_theme_mod('ost_main_header_title_source', 'current');

    if ($source === 'main_site') {
        return ost_main_network_site_title();
    }

    if ($source === 'custom') {
        $custom_title = trim(wp_strip_all_tags((string) get_theme_mod('ost_main_header_custom_title', '')));
        if ($custom_title !== '') {
            return $custom_title;
        }
    }

    $name = trim(wp_strip_all_tags(get_bloginfo('name')));
    return $name !== '' ? $name : 'Connor Moizer';
}

function ost_main_header_title_html() {
    /*
     * v1.0.74:
     * Main header title can use the current subsite title, the main network
     * site title, or a typed custom title. This lets a multisite subsite named
     * "Portfolio | Connor Moizer" still show "Connor Moizer" in the global
     * header, while the service header can show "Portfolio" separately.
     */
    return '<span class="ost-site-title-full">' . esc_html(ost_main_header_title_text()) . '</span>';
}

function ost_public_post_types_for_controls() {
    /*
     * v1.0.88:
     * True CPT listener for theme controls and widget areas.
     *
     * The previous version used get_post_types( array( 'public' => true ) ),
     * which missed some third-party and CPT UI post types depending on how the
     * plugin registered them. This version listens to every registered post
     * type after plugins have loaded, then removes only WordPress/template/form
     * internals that should not become front-end widget areas.
     *
     * Included examples:
     * - Built-in: post, page
     * - CPT UI: any registered CPT that is visible in admin/front-end
     * - Plugins: portfolios, services, blogs, live blogs, events, products, docs,
     *   projects and other real content types.
     */
    $types = get_post_types(array(), 'objects');

    $blocked_slugs = array(
        'attachment',
        'revision',
        'nav_menu_item',
        'custom_css',
        'customize_changeset',
        'oembed_cache',
        'user_request',
        'wp_global_styles',
        'wp_font_family',
        'wp_font_face',
        'wp_template',
        'wp_template_part',
        'wp_navigation',
        'wp_block',
        'elementor_library',
        'e-landing-page',
        'acf-field-group',
        'acf-field',
        'wpcf7_contact_form',
        'flamingo_contact',
        'flamingo_inbound',
        'fluentform',
        'fluentform_entries',
        'forminator_forms',
        'forminator_polls',
        'forminator_quizzes',
        'nf_sub',
        'wpforms',
        'frm_form_actions',
        'frm_styles',
    );

    $allowed = array();

    foreach ($types as $post_type => $object) {
        $post_type = sanitize_key($post_type);

        if ($post_type === '' || in_array($post_type, $blocked_slugs, true)) {
            continue;
        }

        $is_builtin_content = in_array($post_type, array('post', 'page'), true);
        $is_visible_content = !empty($object->public) || !empty($object->publicly_queryable) || !empty($object->show_ui) || !empty($object->show_in_menu) || !empty($object->show_in_nav_menus) || !empty($object->has_archive);

        if (!$is_builtin_content && !$is_visible_content) {
            continue;
        }

        $allowed[$post_type] = $object;
    }

    uasort($allowed, function($a, $b) {
        $a_label = isset($a->labels->name) ? $a->labels->name : $a->name;
        $b_label = isset($b->labels->name) ? $b->labels->name : $b->name;
        return strcasecmp($a_label, $b_label);
    });

    return $allowed;
}
function ost_service_title_url_choices($post_type = '') {
    $post_type = sanitize_key($post_type);
    $choices = array(
        'home' => __('Current site homepage', 'orbital-service-theme'),
    );

    if ($post_type === '') {
        $post_type = 'page';
    }

    $allowed_types = ost_public_post_types_for_controls();
    if (!isset($allowed_types[$post_type])) {
        return $choices;
    }

    $object = $allowed_types[$post_type];

    if ($post_type !== 'page' && !empty($object->has_archive)) {
        $choices['archive:' . $post_type] = sprintf(__('Archive: %s', 'orbital-service-theme'), $object->labels->name);
    }

    $items = get_posts(array(
        'post_type'      => $post_type,
        'post_status'    => array('publish', 'private', 'draft'),
        'posts_per_page' => 200,
        'orderby'        => 'title',
        'order'          => 'ASC',
        'no_found_rows'  => true,
    ));

    foreach ($items as $item) {
        $choices['post:' . $item->ID] = sprintf(__('%1$s: %2$s', 'orbital-service-theme'), $object->labels->singular_name, get_the_title($item));
    }

    return $choices;
}

function ost_sanitize_service_url_choice($choice) {
    $choice = sanitize_text_field($choice);

    if ($choice === 'home') {
        return $choice;
    }

    if (strpos($choice, 'post:') === 0) {
        $post_id = absint(substr($choice, 5));
        return get_post($post_id) ? 'post:' . $post_id : 'home';
    }

    if (strpos($choice, 'archive:') === 0) {
        $archive_post_type = sanitize_key(substr($choice, 8));
        $allowed_types = ost_public_post_types_for_controls();
        if (isset($allowed_types[$archive_post_type]) && !empty($allowed_types[$archive_post_type]->has_archive)) {
            return 'archive:' . $archive_post_type;
        }
    }

    return 'home';
}

function ost_post_type_setting_id($prefix, $post_type) {
    return $prefix . '_' . sanitize_key($post_type);
}

function ost_sanitize_checkbox($checked) {
    /* Save Customizer checkboxes as a strict integer so ticked = 1 and unticked = 0. */
    return (isset($checked) && (string) $checked === '1') ? 1 : 0;
}

function ost_sanitize_service_title_mode($value) {
    $value = sanitize_key($value);
    $allowed = array('site', 'cpt', 'single', 'custom');
    return in_array($value, $allowed, true) ? $value : 'site';
}

function ost_get_post_type_label_name($post_type) {
    $object = get_post_type_object($post_type);
    if ($object && !empty($object->labels->singular_name)) {
        return wp_strip_all_tags($object->labels->singular_name);
    }
    if ($object && !empty($object->labels->name)) {
        return wp_strip_all_tags($object->labels->name);
    }
    return ucwords(str_replace(array('_', '-'), ' ', (string) $post_type));
}

function ost_service_setting_key($prefix, $post_type) {
    return ost_post_type_setting_id($prefix, $post_type);
}

function ost_current_post_type_slug() {
    if (is_singular()) {
        return get_post_type();
    }
    if (is_post_type_archive()) {
        $post_type = get_query_var('post_type');
        if (is_array($post_type)) {
            return reset($post_type);
        }
        return $post_type;
    }
    if (is_home() || is_category() || is_tag() || is_date() || is_author()) {
        return 'post';
    }
    if (is_front_page()) {
        return 'page';
    }
    return '';
}

function ost_service_title_url() {
    $choice = 'home';
    $post_type = ost_current_post_type_slug();
    if ($post_type) {
        $choice = get_theme_mod(ost_post_type_setting_id('ost_service_title_target', $post_type), 'home');
    }

    if (strpos($choice, 'post:') === 0) {
        $post_id = absint(substr($choice, 5));
        $url = get_permalink($post_id);
        if ($url) {
            return esc_url($url);
        }
    }

    if (strpos($choice, 'archive:') === 0) {
        $archive_post_type = sanitize_key(substr($choice, 8));
        $url = get_post_type_archive_link($archive_post_type);
        if ($url) {
            return esc_url($url);
        }
    }

    return esc_url(home_url('/'));
}

function ost_service_title_text() {
    /*
     * v1.2.2: The service/mission title can now be controlled per CPT section.
     * Site = use the global/site title, CPT = use the CPT label/custom CPT title,
     * Single = use the current single item title, Custom = use typed CPT title.
     * Individual content can still override the title from the edit screen meta box.
     */
    $post_type = ost_current_post_type_slug();

    if (is_singular()) {
        $post_id = get_queried_object_id();
        $single_override = trim((string) get_post_meta($post_id, '_ost_service_title_override', true));
        if ($single_override !== '') {
            return $single_override;
        }
    }

    if ($post_type) {
        $mode = get_theme_mod(ost_service_setting_key('ost_service_title_mode', $post_type), 'site');
        $custom_cpt_title = trim((string) get_theme_mod(ost_service_setting_key('ost_service_title_custom', $post_type), ''));

        if ($mode === 'single' && is_singular()) {
            $title = trim(wp_strip_all_tags(get_the_title()));
            if ($title !== '') {
                return $title;
            }
        }

        if ($mode === 'custom' && $custom_cpt_title !== '') {
            return $custom_cpt_title;
        }

        if ($mode === 'cpt') {
            return $custom_cpt_title !== '' ? $custom_cpt_title : ost_get_post_type_label_name($post_type);
        }
    }

    $custom = trim((string) get_theme_mod('ost_service_title', ''));
    if ($custom !== '' && $custom !== 'Mission Programme') {
        return $custom;
    }
    $name = trim(wp_strip_all_tags(get_bloginfo('name')));
    return $name !== '' ? $name : __('Service', 'orbital-service-theme');
}

function ost_service_subtitle_text() {
    $post_type = ost_current_post_type_slug();

    if (is_singular()) {
        $post_id = get_queried_object_id();
        $single_override = trim((string) get_post_meta($post_id, '_ost_service_subtitle_override', true));
        if ($single_override !== '') {
            return $single_override;
        }
    }

    if ($post_type) {
        $custom_cpt_subtitle = trim((string) get_theme_mod(ost_service_setting_key('ost_service_subtitle_custom', $post_type), ''));
        if ($custom_cpt_subtitle !== '') {
            return $custom_cpt_subtitle;
        }
    }

    return get_theme_mod('ost_service_subtitle', 'Sections and updates');
}

function ost_service_override_meta_box() {
    foreach (ost_public_post_types_for_controls() as $post_type => $object) {
        add_meta_box(
            'ost_service_override_box',
            __('Orbital Service/Mission Header Override', 'orbital-service-theme'),
            'ost_service_override_meta_box_render',
            $post_type,
            'side',
            'default'
        );
    }
}
add_action('add_meta_boxes', 'ost_service_override_meta_box', 99);

function ost_service_override_meta_box_render($post) {
    wp_nonce_field('ost_save_service_override', 'ost_service_override_nonce');
    $title = get_post_meta($post->ID, '_ost_service_title_override', true);
    $subtitle = get_post_meta($post->ID, '_ost_service_subtitle_override', true);
    echo '<p>' . esc_html__('Leave blank to use the Customizer setting for this CPT. Fill these in only when this single item needs its own service/mission header wording.', 'orbital-service-theme') . '</p>';
    echo '<p><label for="ost_service_title_override"><strong>' . esc_html__('Service/mission title', 'orbital-service-theme') . '</strong></label></p>';
    echo '<input type="text" id="ost_service_title_override" name="ost_service_title_override" value="' . esc_attr($title) . '" style="width:100%;">';
    echo '<p><label for="ost_service_subtitle_override"><strong>' . esc_html__('Service/mission subtitle', 'orbital-service-theme') . '</strong></label></p>';
    echo '<input type="text" id="ost_service_subtitle_override" name="ost_service_subtitle_override" value="' . esc_attr($subtitle) . '" style="width:100%;">';
}

function ost_save_service_override_meta($post_id) {
    if (!isset($_POST['ost_service_override_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['ost_service_override_nonce'])), 'ost_save_service_override')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    $title = isset($_POST['ost_service_title_override']) ? sanitize_text_field(wp_unslash($_POST['ost_service_title_override'])) : '';
    $subtitle = isset($_POST['ost_service_subtitle_override']) ? sanitize_text_field(wp_unslash($_POST['ost_service_subtitle_override'])) : '';
    if ($title !== '') {
        update_post_meta($post_id, '_ost_service_title_override', $title);
    } else {
        delete_post_meta($post_id, '_ost_service_title_override');
    }
    if ($subtitle !== '') {
        update_post_meta($post_id, '_ost_service_subtitle_override', $subtitle);
    } else {
        delete_post_meta($post_id, '_ost_service_subtitle_override');
    }
}
add_action('save_post', 'ost_save_service_override_meta', 99);



/**
 * Appearance > Menus: embedded multisite content picker.
 *
 * This is a theme feature, not a plugin. When the theme is active it adds an
 * extra meta box beside the normal WordPress Pages / Posts / Custom Links menu
 * boxes. On multisite it lists the content from each public site in tabs; on a
 * single site it only shows the current site.
 */
function ost_menu_admin_available_sites() {
    $sites = array();

    if (is_multisite() && function_exists('get_sites')) {
        $network_sites = get_sites(array(
            'number'   => 100,
            'public'   => 1,
            'archived' => 0,
            'deleted'  => 0,
            'spam'     => 0,
        ));

        foreach ($network_sites as $site) {
            $blog_id = absint($site->blog_id);
            switch_to_blog($blog_id);
            $sites[] = array(
                'blog_id' => $blog_id,
                'name'    => get_bloginfo('name'),
                'url'     => home_url('/'),
            );
            restore_current_blog();
        }
    } else {
        $sites[] = array(
            'blog_id' => get_current_blog_id(),
            'name'    => get_bloginfo('name'),
            'url'     => home_url('/'),
        );
    }

    return $sites;
}

function ost_menu_admin_post_types() {
    /* Use the same real CPT listener as the Customizer/widget system so the
     * dashboard Multisite Content menu box sees built-in, CPT UI and plugin CPTs.
     */
    $types = ost_public_post_types_for_controls();

    foreach ($types as $slug => $object) {
        if (empty($object->show_in_nav_menus) && empty($object->public) && empty($object->publicly_queryable) && !in_array($slug, array('page', 'post'), true)) {
            unset($types[$slug]);
        }
    }

    return $types;
}
function ost_add_multisite_nav_menu_meta_box() {
    add_meta_box(
        'ost-multisite-content-menu-box',
        __('Multisite Content', 'orbital-service-theme'),
        'ost_render_multisite_nav_menu_meta_box',
        'nav-menus',
        'side',
        'default'
    );
}
add_action('admin_head-nav-menus.php', 'ost_add_multisite_nav_menu_meta_box');

function ost_render_multisite_nav_menu_meta_box() {
    $sites = ost_menu_admin_available_sites();
    $types = ost_menu_admin_post_types();
    $item_id = -900000;

    if (empty($sites) || empty($types)) {
        echo '<p>' . esc_html__('No multisite content is available for menus.', 'orbital-service-theme') . '</p>';
        return;
    }
    ?>
    <div class="ost-menu-admin-box">
        <p class="description"><?php esc_html_e('Choose a site tab, filter by content type, tick the items, then press Add to Menu. Items are added as real menu links using the correct site URL.', 'orbital-service-theme'); ?></p>

        <div class="ost-menu-site-tabs" role="tablist" aria-label="<?php esc_attr_e('Sites', 'orbital-service-theme'); ?>">
            <?php foreach ($sites as $index => $site) : ?>
                <button type="button" class="button ost-menu-site-tab<?php echo $index === 0 ? ' is-active' : ''; ?>" data-ost-site-tab="<?php echo esc_attr($site['blog_id']); ?>">
                    <?php echo esc_html($site['name'] ? $site['name'] : sprintf(__('Site %d', 'orbital-service-theme'), $site['blog_id'])); ?>
                </button>
            <?php endforeach; ?>
        </div>

        <?php foreach ($sites as $index => $site) : ?>
            <div class="tabs-panel ost-menu-site-panel<?php echo $index === 0 ? ' tabs-panel-active is-active' : ' tabs-panel-inactive'; ?>" data-ost-site-panel="<?php echo esc_attr($site['blog_id']); ?>">
                <p class="ost-menu-site-url"><strong><?php esc_html_e('Site URL:', 'orbital-service-theme'); ?></strong> <?php echo esc_html($site['url']); ?></p>

                <label class="screen-reader-text" for="ost-post-type-filter-<?php echo esc_attr($site['blog_id']); ?>"><?php esc_html_e('Filter content type', 'orbital-service-theme'); ?></label>
                <select id="ost-post-type-filter-<?php echo esc_attr($site['blog_id']); ?>" class="widefat ost-menu-post-type-filter">
                    <option value="all"><?php esc_html_e('All content types', 'orbital-service-theme'); ?></option>
                    <?php foreach ($types as $type_slug => $type_object) : ?>
                        <option value="<?php echo esc_attr($type_slug); ?>"><?php echo esc_html($type_object->labels->name); ?></option>
                    <?php endforeach; ?>
                </select>

                <ul class="categorychecklist form-no-clear ost-menu-content-list">
                    <?php
                    switch_to_blog(absint($site['blog_id']));
                    foreach ($types as $type_slug => $type_object) :
                        $items = get_posts(array(
                            'post_type'      => $type_slug,
                            'post_status'    => 'publish',
                            'posts_per_page' => 25,
                            'orderby'        => 'title',
                            'order'          => 'ASC',
                            'no_found_rows'  => true,
                        ));

                        if (empty($items)) {
                            continue;
                        }

                        foreach ($items as $post_item) :
                            $item_id--;
                            $title = get_the_title($post_item);
                            $url = get_permalink($post_item);
                            ?>
                            <li class="ost-menu-content-item" data-ost-post-type="<?php echo esc_attr($type_slug); ?>">
                                <label class="menu-item-title">
                                    <input type="checkbox" class="menu-item-checkbox" name="menu-item[<?php echo esc_attr($item_id); ?>][menu-item-object-id]" value="<?php echo esc_attr(absint($post_item->ID)); ?>">
                                    <?php echo esc_html($title); ?>
                                    <span class="ost-menu-type-label"><?php echo esc_html($type_object->labels->singular_name); ?></span>
                                </label>
                                <input type="hidden" name="menu-item[<?php echo esc_attr($item_id); ?>][menu-item-db-id]" value="0">
                                <input type="hidden" name="menu-item[<?php echo esc_attr($item_id); ?>][menu-item-object]" value="custom">
                                <input type="hidden" name="menu-item[<?php echo esc_attr($item_id); ?>][menu-item-parent-id]" value="0">
                                <input type="hidden" name="menu-item[<?php echo esc_attr($item_id); ?>][menu-item-type]" value="custom">
                                <input type="hidden" name="menu-item[<?php echo esc_attr($item_id); ?>][menu-item-title]" value="<?php echo esc_attr($title); ?>">
                                <input type="hidden" name="menu-item[<?php echo esc_attr($item_id); ?>][menu-item-url]" value="<?php echo esc_url($url); ?>">
                                <input type="hidden" name="menu-item[<?php echo esc_attr($item_id); ?>][menu-item-target]" value="">
                                <input type="hidden" name="menu-item[<?php echo esc_attr($item_id); ?>][menu-item-attr-title]" value="">
                                <input type="hidden" name="menu-item[<?php echo esc_attr($item_id); ?>][menu-item-classes]" value="">
                                <input type="hidden" name="menu-item[<?php echo esc_attr($item_id); ?>][menu-item-xfn]" value="">
                            </li>
                            <?php
                        endforeach;
                    endforeach;
                    restore_current_blog();
                    ?>
                </ul>
            </div>
        <?php endforeach; ?>

        <p class="button-controls wp-clearfix">
            <span class="list-controls">
                <a href="#" class="select-all ost-menu-select-all"><?php esc_html_e('Select All', 'orbital-service-theme'); ?></a>
            </span>
            <span class="add-to-menu">
                <input type="submit" class="button-secondary submit-add-to-menu right" value="<?php esc_attr_e('Add to Menu', 'orbital-service-theme'); ?>" name="add-post-type-menu-item" id="submit-ost-multisite-content-menu-box">
                <span class="spinner"></span>
            </span>
        </p>
    </div>
    <?php
}

function ost_nav_menus_admin_assets($hook) {
    if ($hook !== 'nav-menus.php') {
        return;
    }

    wp_enqueue_style('ost-menu-admin', get_template_directory_uri() . '/assets/css/menu-admin.css', array(), OST_VERSION);
    wp_enqueue_script('ost-menu-admin', get_template_directory_uri() . '/assets/js/menu-admin.js', array('jquery'), OST_VERSION, true);
}
add_action('admin_enqueue_scripts', 'ost_nav_menus_admin_assets');


function ost_cpt_widget_sidebar_id($post_type) {
    $post_type = sanitize_key($post_type);
    return $post_type ? 'ost-cpt-sidebar-' . $post_type : 'sidebar-1';
}

function ost_cpt_widget_setting_id($post_type) {
    return ost_post_type_setting_id('ost_cpt_widgets_mode', $post_type);
}

function ost_cpt_widget_position_setting_id($post_type) {
    return ost_post_type_setting_id('ost_cpt_widgets_position', $post_type);
}

function ost_sanitize_cpt_widget_mode($value) {
    return in_array($value, array('on', 'off'), true) ? $value : 'on';
}

function ost_sanitize_cpt_widget_position($value) {
    return in_array($value, array('left', 'right'), true) ? $value : 'right';
}


function ost_sanitize_cpt_widget_fallback_mode($value) {
    return in_array($value, array('on', 'off'), true) ? $value : 'on';
}

function ost_get_cpt_widget_fallback_mode() {
    /*
     * v1.0.94:
     * Fallback widgets are controlled separately from the independent CPT
     * widget areas. On multisite this is a network-wide option so switching it
     * on or off from any subsite applies the same behaviour across all sites.
     */
    if (is_multisite()) {
        return get_site_option('ost_cpt_widget_fallback_mode_network', 'off') === 'on' ? 'on' : 'off';
    }

    return get_theme_mod('ost_cpt_widget_fallback_mode', 'off') === 'on' ? 'on' : 'off';
}

function ost_cpt_widget_fallback_enabled() {
    return ost_get_cpt_widget_fallback_mode() !== 'off';
}

function ost_set_cpt_widget_fallback_mode($value) {
    $value = ost_sanitize_cpt_widget_fallback_mode($value);

    if (is_multisite()) {
        update_site_option('ost_cpt_widget_fallback_mode_network', $value);
    }

    set_theme_mod('ost_cpt_widget_fallback_mode', $value);
}

function ost_cpt_widget_network_option_key($type, $post_type) {
    $post_type = sanitize_key($post_type);
    $type = sanitize_key($type);
    return $post_type ? 'ost_' . $type . '_network_' . $post_type : '';
}

function ost_get_cpt_widget_mode($post_type = '') {
    $post_type = $post_type ? sanitize_key($post_type) : ost_current_post_type_slug();
    if (!$post_type) {
        return 'off';
    }

    /*
     * v1.1.6:
     * The CPT widget On/Off switch is now a real network-aware setting.
     * In multisite, every subsite reads the same site option so switching a
     * CPT widget area On or Off from any site produces the same front-end
     * result everywhere. The old theme_mod value is only used as a fallback
     * for backwards compatibility with previous builds.
     */
    if (is_multisite()) {
        $network_key = ost_cpt_widget_network_option_key('cpt_widgets_mode', $post_type);
        $network_value = $network_key ? get_site_option($network_key, null) : null;
        if ($network_value !== null && $network_value !== false) {
            return $network_value === 'on' ? 'on' : 'off';
        }
    }

    return get_theme_mod(ost_cpt_widget_setting_id($post_type), 'off') === 'on' ? 'on' : 'off';
}

function ost_set_cpt_widget_mode($post_type = '', $value = 'off') {
    $post_type = sanitize_key($post_type);
    if (!$post_type) {
        return;
    }

    $value = ost_sanitize_cpt_widget_mode($value);

    if (is_multisite()) {
        $network_key = ost_cpt_widget_network_option_key('cpt_widgets_mode', $post_type);
        if ($network_key) {
            update_site_option($network_key, $value);
        }
    }

    set_theme_mod(ost_cpt_widget_setting_id($post_type), $value);
}

function ost_get_cpt_widget_position($post_type = '') {
    $post_type = $post_type ? sanitize_key($post_type) : ost_current_post_type_slug();
    if (!$post_type) {
        return 'right';
    }

    if (is_multisite()) {
        $network_key = ost_cpt_widget_network_option_key('cpt_widgets_position', $post_type);
        $network_value = $network_key ? get_site_option($network_key, null) : null;
        if ($network_value !== null && $network_value !== false) {
            return $network_value === 'left' ? 'left' : 'right';
        }
    }

    return get_theme_mod(ost_cpt_widget_position_setting_id($post_type), 'right') === 'left' ? 'left' : 'right';
}

function ost_set_cpt_widget_position($post_type = '', $value = 'right') {
    $post_type = sanitize_key($post_type);
    if (!$post_type) {
        return;
    }

    $value = ost_sanitize_cpt_widget_position($value);

    if (is_multisite()) {
        $network_key = ost_cpt_widget_network_option_key('cpt_widgets_position', $post_type);
        if ($network_key) {
            update_site_option($network_key, $value);
        }
    }

    set_theme_mod(ost_cpt_widget_position_setting_id($post_type), $value);
}


/*
 * v1.1.6: keep Customizer CPT widget controls in sync with the network options.
 * WordPress Customizer saves these radio controls as theme_mod values by default.
 * This hook copies those saved values into the multisite network option store so
 * every subsite reads the same On/Off and left/right settings immediately.
 */
function ost_sync_customizer_cpt_widget_settings_to_network($wp_customize = null) {
    if (!is_multisite()) {
        return;
    }

    foreach (ost_public_post_types_for_controls() as $post_type => $object) {
        $post_type = sanitize_key($post_type);
        if (!$post_type) {
            continue;
        }

        $mode = get_theme_mod(ost_cpt_widget_setting_id($post_type), ost_get_cpt_widget_mode($post_type));
        $position = get_theme_mod(ost_cpt_widget_position_setting_id($post_type), ost_get_cpt_widget_position($post_type));

        ost_set_cpt_widget_mode($post_type, $mode);
        ost_set_cpt_widget_position($post_type, $position);
    }
}
add_action('customize_save_after', 'ost_sync_customizer_cpt_widget_settings_to_network', 99);

function ost_cpt_sidebar_has_active_widgets_on_blog($sidebar_id, $blog_id = 0) {
    $sidebar_id = sanitize_key($sidebar_id);
    if (!$sidebar_id) {
        return false;
    }

    $blog_id = absint($blog_id);
    $switched = false;

    if (is_multisite() && $blog_id > 0 && $blog_id !== get_current_blog_id() && function_exists('switch_to_blog')) {
        switch_to_blog($blog_id);
        $switched = true;
    }

    $active = is_active_sidebar($sidebar_id);

    if ($switched && function_exists('restore_current_blog')) {
        restore_current_blog();
    }

    return (bool) $active;
}

function ost_cpt_sidebar_has_widgets($post_type = '') {
    $post_type = $post_type ? sanitize_key($post_type) : ost_current_post_type_slug();

    if (!$post_type || !ost_should_show_cpt_widgets($post_type)) {
        return false;
    }

    $sidebar_ids = array(ost_cpt_widget_sidebar_id($post_type));

    if (function_exists('ost_cpt_widget_fallback_enabled') && ost_cpt_widget_fallback_enabled()) {
        $sidebar_ids[] = 'sidebar-1';
    }

    foreach ($sidebar_ids as $sidebar_id) {
        foreach (ost_network_widget_source_blog_ids() as $blog_id) {
            if (ost_cpt_sidebar_has_active_widgets_on_blog($sidebar_id, $blog_id)) {
                return true;
            }
        }
    }

    return false;
}

function ost_layout_sidebar_position_class($post_type = '') {
    /*
     * v1.0.98:
     * The layout class now follows the real widget state. If the current CPT
     * widget output is switched Off, or if no allowed widget area contains
     * widgets, the content wrapper becomes full-width instead of keeping the
     * empty 75/25 sidebar grid. This applies in single-site and multisite mode.
     */
    $post_type = $post_type ? sanitize_key($post_type) : ost_current_post_type_slug();

    if (!ost_cpt_sidebar_has_widgets($post_type)) {
        return 'ost-layout-no-sidebar';
    }

    $position = ost_get_cpt_widget_position($post_type);
    return $position === 'left' ? 'ost-layout-sidebar-left' : 'ost-layout-sidebar-right';
}

function ost_register_single_sidebar_once($args) {
    global $wp_registered_sidebars;
    if (empty($args['id'])) {
        return;
    }
    if (isset($wp_registered_sidebars[$args['id']])) {
        return;
    }
    register_sidebar($args);
}

function ost_register_fallback_and_footer_sidebars() {
    ost_register_single_sidebar_once(array(
        'name'          => __('Shared fallback sidebar widgets', 'orbital-service-theme'),
        'id'            => 'sidebar-1',
        'description'   => __('Fallback widgets used when a CPT-specific widget area is empty or unavailable.', 'orbital-service-theme'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));

    ost_register_single_sidebar_once(array(
        'name'          => __('Footer left', 'orbital-service-theme'),
        'id'            => 'footer-1',
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2>',
        'after_title'   => '</h2>',
    ));

    ost_register_single_sidebar_once(array(
        'name'          => __('Footer right', 'orbital-service-theme'),
        'id'            => 'footer-2',
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2>',
        'after_title'   => '</h2>',
    ));
}

function ost_register_all_cpt_widget_sidebars() {
    /*
     * v1.0.89:
     * This is the missing half of the CPT listener. Detection alone is not
     * enough; every detected post type must also be registered as a real
     * WordPress widget/sidebar area so it appears under Appearance > Widgets
     * and the Customizer widget editor. This runs late on widgets_init and
     * again in admin as a safety net for CPT UI and third-party plugins that
     * register post types later than normal.
     */
    $post_types = ost_public_post_types_for_controls();

    foreach ($post_types as $post_type => $object) {
        $post_type = sanitize_key($post_type);
        if (!$post_type) {
            continue;
        }

        $label = isset($object->labels->name) && $object->labels->name ? $object->labels->name : $post_type;
        $sidebar_id = ost_cpt_widget_sidebar_id($post_type);

        ost_register_single_sidebar_once(array(
            'name'          => sprintf(__('Orbital CPT Widgets — %s', 'orbital-service-theme'), $label),
            'id'            => $sidebar_id,
            'description'   => sprintf(__('Independent widget area for the %1$s post type. Detected automatically from WordPress core, CPT UI, ACF/Pods/JetEngine-style plugins and third-party plugins. Use Customizer > Orbital Service Theme > CPT Widget Areas to turn this CPT widget output on or off.', 'orbital-service-theme'), $label),
            'before_widget' => '<section id="%1$s" class="widget ost-cpt-widget ost-cpt-widget-' . esc_attr($post_type) . ' %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        ));
    }
}

function ost_widgets_init() {
    ost_register_fallback_and_footer_sidebars();
    ost_register_all_cpt_widget_sidebars();
}
add_action('widgets_init', 'ost_widgets_init', 999);

function ost_admin_register_late_cpt_widget_sidebars() {
    if (!is_admin()) {
        return;
    }
    ost_register_fallback_and_footer_sidebars();
    ost_register_all_cpt_widget_sidebars();
}
add_action('admin_init', 'ost_admin_register_late_cpt_widget_sidebars', 999);
add_action('customize_register', 'ost_admin_register_late_cpt_widget_sidebars', 1);

function ost_should_show_cpt_widgets($post_type = '') {
    $post_type = $post_type ? sanitize_key($post_type) : ost_current_post_type_slug();
    if (!$post_type) {
        return true;
    }
    return ost_get_cpt_widget_mode($post_type) !== 'off';
}

function ost_dynamic_sidebar_from_blog($sidebar_id, $blog_id = 0) {
    $sidebar_id = sanitize_key($sidebar_id);
    if (!$sidebar_id) {
        return false;
    }

    $blog_id = absint($blog_id);
    $switched = false;

    if (is_multisite() && $blog_id > 0 && $blog_id !== get_current_blog_id() && function_exists('switch_to_blog')) {
        switch_to_blog($blog_id);
        $switched = true;
    }

    $rendered = false;
    if (is_active_sidebar($sidebar_id)) {
        dynamic_sidebar($sidebar_id);
        $rendered = true;
    }

    if ($switched && function_exists('restore_current_blog')) {
        restore_current_blog();
    }

    return $rendered;
}

function ost_network_widget_source_blog_ids() {
    $ids = array(get_current_blog_id());

    /*
     * When fallback widgets are disabled, multisite behaves exactly like a
     * single site: only the current subsite's matching CPT widget area is
     * allowed to render. Main-site CPT widget fallbacks are not checked.
     */
    if (function_exists('ost_cpt_widget_fallback_enabled') && !ost_cpt_widget_fallback_enabled()) {
        return array_values(array_unique(array_filter(array_map('absint', $ids))));
    }

    if (is_multisite()) {
        if (function_exists('get_main_site_id')) {
            $ids[] = absint(get_main_site_id());
        }
        $ids[] = absint(ost_main_network_blog_id());
    }

    $ids = array_values(array_unique(array_filter(array_map('absint', $ids))));
    return $ids;
}

function ost_dynamic_cpt_sidebar_rendered($post_type = '') {
    /*
     * v1.0.93: Multisite widget rendering now follows the same path as
     * single-site rendering. The current site is checked first. If the current
     * subsite has no widgets in the matching CPT widget area, the theme falls
     * back to the main network site's matching CPT widget area, then the main
     * fallback sidebar. This means widgets built once on the main site can still
     * render across the network while each subsite can override them locally.
     */
    $post_type = $post_type ? sanitize_key($post_type) : ost_current_post_type_slug();
    if (!$post_type || !ost_should_show_cpt_widgets($post_type)) {
        return false;
    }

    $sidebar_ids = array(ost_cpt_widget_sidebar_id($post_type));

    if (function_exists('ost_cpt_widget_fallback_enabled') && ost_cpt_widget_fallback_enabled()) {
        $sidebar_ids[] = 'sidebar-1';
    }

    foreach ($sidebar_ids as $sidebar_id) {
        foreach (ost_network_widget_source_blog_ids() as $blog_id) {
            if (ost_dynamic_sidebar_from_blog($sidebar_id, $blog_id)) {
                return true;
            }
        }
    }

    return false;
}


/*
 * v1.0.98: Manual-only CPT widget output.
 *
 * Manual CPT widget sidebars and shared fallback widgets default to Off.
 * Automatic/pre-made related widget injection has been removed. The Related CPT
 * Posts widget remains available as a normal manual widget that can be placed in
 * each detected CPT widget area from Appearance > Widgets.
 */
function ost_sanitize_auto_related_widget_mode($value) {
    return 'off';
}

function ost_get_auto_related_widget_mode() {
    /*
     * v1.0.98:
     * Automatic/pre-made related widget output is removed from the theme flow.
     * Widgets are manual from this version onwards. The function is retained as
     * a backwards-compatible no-op so older saved settings cannot turn automatic
     * output back on by accident.
     */
    return 'off';
}

function ost_set_auto_related_widget_mode($value) {
    if (is_multisite()) {
        update_site_option('ost_auto_related_widget_mode_network', 'off');
    }
    set_theme_mod('ost_auto_related_widget_mode', 'off');
}

function ost_auto_related_widget_enabled() {
    return false;
}

function ost_auto_related_post_type_is_allowed($post_type = '') {
    /*
     * v1.0.96:
     * Automatic related widgets now use the same broad CPT listener idea as the
     * rest of the theme instead of relying only on names such as blog or
     * portfolio. This means a subsite called Blogs with a CPT called Work,
     * Reviews, Projects, Case Studies or any other public content type can show
     * the pre-made related widget automatically.
     *
     * Allowed:
     * - Core posts.
     * - CPT UI post types.
     * - Third-party plugin post types that behave like public front-end content.
     * - Matching CPTs on multisite subsites where that CPT is registered.
     *
     * Excluded:
     * - Standard pages.
     * - Attachments, menus, templates, forms and other system/internal types.
     */
    $post_type = $post_type ? sanitize_key($post_type) : ost_current_post_type_slug();
    if (!$post_type || !post_type_exists($post_type)) {
        return false;
    }

    if ($post_type === 'page') {
        return false;
    }

    $allowed = ost_public_post_types_for_controls();
    if (!isset($allowed[$post_type])) {
        return false;
    }

    $object = get_post_type_object($post_type);
    if (!$object) {
        return false;
    }

    if ($post_type === 'post') {
        return true;
    }

    /*
     * Treat any front-end content CPT as eligible. CPT UI and many plugins do
     * not always set has_archive, so requiring has_archive alone misses real
     * content types. The combined public/queryable/nav/archive checks allow
     * reviews, work, portfolio, projects and similar CPTs to work without a
     * hard-coded name list.
     */
    $is_front_end_content = !empty($object->public) || !empty($object->publicly_queryable) || !empty($object->show_in_nav_menus) || !empty($object->has_archive);

    return (bool) $is_front_end_content;
}

function ost_post_type_matches_blog_or_portfolio_names($post_type = '') {
    /*
     * Backwards-compatible wrapper retained for older theme code and widgets.
     * The actual decision is now made by ost_auto_related_post_type_is_allowed().
     */
    return ost_auto_related_post_type_is_allowed($post_type);
}

function ost_is_excluded_auto_related_page() {
    if (is_front_page() || is_home() || is_search() || is_404() || is_archive()) {
        return true;
    }

    if (!is_singular()) {
        return true;
    }

    $post_id = get_queried_object_id();
    if (!$post_id) {
        return true;
    }

    $post_type = get_post_type($post_id);
    if ($post_type === 'page') {
        $slug = get_post_field('post_name', $post_id);
        $blocked_slugs = array('home','homepage','front-page','contact','contact-us','about','about-me','about-us');
        if (in_array(sanitize_title($slug), $blocked_slugs, true)) {
            return true;
        }
        return true; // Standard pages do not get the automatic related CPT widget by default.
    }

    return false;
}

function ost_should_show_auto_related_widget($post_type = '') {
    if (!ost_auto_related_widget_enabled()) { return false; }
    if (ost_is_excluded_auto_related_page()) { return false; }
    $post_type = $post_type ? sanitize_key($post_type) : ost_current_post_type_slug();
    if (!$post_type || !post_type_exists($post_type)) { return false; }
    return ost_auto_related_post_type_is_allowed($post_type);
}

function ost_auto_related_query_posts_for_blog($blog_id, $post_type, $number, $order_setting) {
    $blog_id = absint($blog_id);
    $post_type = sanitize_key($post_type);
    $items = array();
    if (!$blog_id || !$post_type) { return $items; }

    $switched = false;
    if (is_multisite() && $blog_id !== get_current_blog_id() && function_exists('switch_to_blog')) {
        switch_to_blog($blog_id);
        $switched = true;
    }

    if (post_type_exists($post_type)) {
        $exclude = array();
        if (!$switched && is_singular()) {
            $exclude[] = get_queried_object_id();
        }
        $args = array(
            'post_type' => $post_type,
            'post_status' => 'publish',
            'posts_per_page' => $number,
            'post__not_in' => array_filter(array_map('absint', $exclude)),
            'no_found_rows' => true,
        );
        if ($order_setting === 'date_asc') { $args['orderby'] = 'date'; $args['order'] = 'ASC'; }
        elseif ($order_setting === 'rand') { $args['orderby'] = 'rand'; }
        else { $args['orderby'] = 'date'; $args['order'] = 'DESC'; }

        $q = new WP_Query($args);
        while ($q->have_posts()) {
            $q->the_post();
            $thumb = '';
            if (has_post_thumbnail()) {
                $thumb = get_the_post_thumbnail(get_the_ID(), 'medium');
            }
            $items[] = array(
                'title' => get_the_title(),
                'url' => get_permalink(),
                'thumb' => $thumb,
                'date' => get_the_time('U'),
                'blog_name' => get_bloginfo('name'),
            );
        }
        wp_reset_postdata();
    }

    if ($switched && function_exists('restore_current_blog')) {
        restore_current_blog();
    }

    return $items;
}

function ost_auto_related_network_blog_ids() {
    $ids = array(get_current_blog_id());
    if (is_multisite() && function_exists('get_sites')) {
        $sites = get_sites(array('number' => 250, 'public' => 1, 'archived' => 0, 'deleted' => 0, 'spam' => 0));
        foreach ($sites as $site) {
            $ids[] = absint($site->blog_id);
        }
    }
    return array_values(array_unique(array_filter(array_map('absint', $ids))));
}

function ost_render_auto_related_widget($post_type = '', $context = 'desktop') {
    $post_type = $post_type ? sanitize_key($post_type) : ost_current_post_type_slug();
    if (!ost_should_show_auto_related_widget($post_type)) { return false; }

    $number = 3;
    $items = array();
    foreach (ost_auto_related_network_blog_ids() as $blog_id) {
        if (count($items) >= $number) { break; }
        $items = array_merge($items, ost_auto_related_query_posts_for_blog($blog_id, $post_type, $number - count($items), 'date_desc'));
    }

    if (!$items) { return false; }

    echo '<section class="widget ost-default-related-widget ost-auto-cpt-related-widget ost-auto-cpt-related-widget-' . esc_attr($context) . '">';
    echo '<h2 class="widget-title">' . esc_html__('Related Posts', 'orbital-service-theme') . '</h2>';
    echo '<div class="ost-related-news ost-itv-related-news"><div class="ost-related-list">';
    foreach ($items as $item) {
        echo '<article class="ost-related-item">';
        echo '<a class="ost-related-thumb" href="' . esc_url($item['url']) . '" aria-hidden="true" tabindex="-1">';
        if (!empty($item['thumb'])) { echo $item['thumb']; }
        else { echo '<span class="ost-related-placeholder"></span>'; }
        echo '</a>';
        echo '<div class="ost-related-body">';
        echo '<h3 class="ost-related-title"><a href="' . esc_url($item['url']) . '">' . esc_html($item['title']) . '</a></h3>';
        $date_text = !empty($item['date']) ? human_time_diff((int) $item['date'], current_time('timestamp')) . ' ' . __('ago', 'orbital-service-theme') : '';
        echo '<div class="ost-itv-meta ost-itv-meta-relative"><span class="ost-itv-clock" aria-hidden="true"></span><span class="ost-itv-date">' . esc_html($date_text) . '</span></div>';
        if (is_multisite() && !empty($item['blog_name'])) {
            echo '<div class="ost-related-site-name">' . esc_html($item['blog_name']) . '</div>';
        }
        echo '</div></article>';
    }
    echo '</div></div></section>';
    return true;
}


/*
 * v1.0.92: Mobile CPT widgets above footer.
 *
 * Desktop keeps the normal left/right sidebar inside the content grid. Mobile now
 * gets a dedicated render point after the main content closes and before the
 * footer starts, so the current CPT widget area always appears above the footer.
 * CSS hides this duplicate mobile render on desktop and hides the in-grid sidebar
 * on mobile to prevent the same widgets appearing twice.
 */
function ost_render_mobile_cpt_widgets_above_footer() {
    if (!function_exists('ost_current_post_type_slug')) {
        return;
    }

    $post_type = ost_current_post_type_slug();
    if (!$post_type) {
        return;
    }

    $rendered = false;
    ob_start();
    if (function_exists('ost_should_show_cpt_widgets') && ost_should_show_cpt_widgets($post_type) && function_exists('ost_dynamic_cpt_sidebar_rendered')) {
        $rendered = ost_dynamic_cpt_sidebar_rendered($post_type);
    }

    if (!$rendered && function_exists('ost_cpt_widget_fallback_enabled') && ost_cpt_widget_fallback_enabled() && function_exists('ost_is_blog_style_post_type') && ost_is_blog_style_post_type($post_type)) {
        the_widget('OST_ITV_Related_CPT_Posts_Widget', array(
            'title' => 'Related News',
            'mode' => 'auto',
            'manual_post_type' => 'post',
            'number' => 3,
            'order' => 'date_desc',
        ), array(
            'before_widget' => '<section class="widget ost-default-related-widget">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        ));
        $rendered = true;
    }

    $widgets = trim(ob_get_clean());
    if (!$rendered || $widgets === '') {
        return;
    }
    ?>
    <section class="ost-mobile-cpt-widgets-above-footer" aria-label="<?php esc_attr_e('Content widgets', 'orbital-service-theme'); ?>">
        <div class="ost-mobile-cpt-widgets-wrap">
            <?php echo $widgets; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
        </div>
    </section>
    <?php
}





/*
 * v1.0.91: Real On/Off management for every detected CPT widget area.
 *
 * The CPT widget sidebars can exist before every Customizer control is visible,
 * especially when a third-party plugin registers its CPT late. This admin page
 * gives the theme a second, reliable control surface under Appearance so built-in,
 * CPT UI and plugin post types always have On/Off and desktop position controls.
 */
function ost_cpt_widget_admin_page_register() {
    add_theme_page(
        __('Orbital CPT Widget Areas', 'orbital-service-theme'),
        __('Orbital CPT Widget Areas', 'orbital-service-theme'),
        'edit_theme_options',
        'ost-cpt-widget-areas',
        'ost_cpt_widget_admin_page_render'
    );
}
add_action('admin_menu', 'ost_cpt_widget_admin_page_register', 99);

function ost_cpt_widget_admin_page_render() {
    if (!current_user_can('edit_theme_options')) {
        wp_die(esc_html__('You do not have permission to manage these settings.', 'orbital-service-theme'));
    }

    $post_types = ost_public_post_types_for_controls();

    if (isset($_POST['ost_cpt_widget_areas_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['ost_cpt_widget_areas_nonce'])), 'ost_save_cpt_widget_areas')) {
        $fallback_mode = isset($_POST['ost_cpt_widget_fallback_mode']) ? sanitize_text_field(wp_unslash($_POST['ost_cpt_widget_fallback_mode'])) : 'off';
        ost_set_cpt_widget_fallback_mode($fallback_mode);

        ost_set_auto_related_widget_mode('off');

        foreach ($post_types as $post_type => $object) {
            $post_type = sanitize_key($post_type);
            if (!$post_type) {
                continue;
            }

            $mode_key = ost_cpt_widget_setting_id($post_type);
            $position_key = ost_cpt_widget_position_setting_id($post_type);

            $mode = isset($_POST[$mode_key]) ? sanitize_text_field(wp_unslash($_POST[$mode_key])) : 'off';
            $position = isset($_POST[$position_key]) ? sanitize_text_field(wp_unslash($_POST[$position_key])) : 'right';

            ost_set_cpt_widget_mode($post_type, $mode);
            ost_set_cpt_widget_position($post_type, $position);
        }

        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('CPT widget area settings saved.', 'orbital-service-theme') . '</p></div>';
    }

    echo '<div class="wrap">';
    echo '<h1>' . esc_html__('Orbital CPT Widget Areas', 'orbital-service-theme') . '</h1>';
    echo '<p>' . esc_html__('These controls are generated from the same CPT listener as the widget areas. They include WordPress built-in content types, CPT UI post types and third-party plugin post types that are registered as real visible content.', 'orbital-service-theme') . '</p>';
    echo '<p>' . esc_html__('Use On/Off to control whether widgets appear on the front end for each content type. Use the desktop position control to choose left or right side output. Mobile output is always forced below the content.', 'orbital-service-theme') . '</p>';

    echo '<form method="post">';
    wp_nonce_field('ost_save_cpt_widget_areas', 'ost_cpt_widget_areas_nonce');
    echo '<h2>' . esc_html__('Default widget behaviour', 'orbital-service-theme') . '</h2>';
    echo '<table class="form-table" role="presentation"><tbody>';
    echo '<tr><th scope="row">' . esc_html__('Shared fallback widgets', 'orbital-service-theme') . '</th><td>';
    echo '<label><input type="radio" name="ost_cpt_widget_fallback_mode" value="on" ' . checked(ost_get_cpt_widget_fallback_mode(), 'on', false) . '> ' . esc_html__('On', 'orbital-service-theme') . '</label><br>';
    echo '<label><input type="radio" name="ost_cpt_widget_fallback_mode" value="off" ' . checked(ost_get_cpt_widget_fallback_mode(), 'off', false) . '> ' . esc_html__('Off by default', 'orbital-service-theme') . '</label>';
    echo '<p class="description">' . esc_html__('Off stops shared fallback sidebars, default mission links and main-site fallback widgets. This is network-wide on multisite.', 'orbital-service-theme') . '</p>';
    echo '</td></tr>';
    echo '<tr><th scope="row">' . esc_html__('Pre-made CPT Related Posts widget', 'orbital-service-theme') . '</th><td>';
    echo '<label><input type="radio" name="ost_auto_related_widget_mode" value="on" ' . checked(ost_get_auto_related_widget_mode(), 'on', false) . '> ' . esc_html__('On by default', 'orbital-service-theme') . '</label><br>';
    echo '<label><input type="radio" name="ost_auto_related_widget_mode" value="off" ' . checked(ost_get_auto_related_widget_mode(), 'off', false) . '> ' . esc_html__('Off', 'orbital-service-theme') . '</label>';
    echo '<p class="description">' . esc_html__('On automatically shows Related Posts on blog/news/article/post and portfolio/project/work single items across multisite, but not on Home, Contact, About Me or normal static pages.', 'orbital-service-theme') . '</p>';
    echo '</td></tr>';
    echo '</tbody></table>';
    echo '<table class="widefat striped" style="max-width:1100px;">';
    echo '<thead><tr><th>' . esc_html__('Content Type', 'orbital-service-theme') . '</th><th>' . esc_html__('Widget Area', 'orbital-service-theme') . '</th><th>' . esc_html__('Output', 'orbital-service-theme') . '</th><th>' . esc_html__('Desktop Position', 'orbital-service-theme') . '</th></tr></thead><tbody>';

    foreach ($post_types as $post_type => $object) {
        $post_type = sanitize_key($post_type);
        $label = isset($object->labels->name) && $object->labels->name ? $object->labels->name : $post_type;
        $mode_key = ost_cpt_widget_setting_id($post_type);
        $position_key = ost_cpt_widget_position_setting_id($post_type);
        $mode = ost_get_cpt_widget_mode($post_type);
        $position = ost_get_cpt_widget_position($post_type);
        $sidebar_id = ost_cpt_widget_sidebar_id($post_type);

        echo '<tr>';
        echo '<td><strong>' . esc_html($label) . '</strong><br><code>' . esc_html($post_type) . '</code></td>';
        echo '<td>' . esc_html(sprintf(__('Appearance > Widgets: Orbital CPT Widgets — %s', 'orbital-service-theme'), $label)) . '<br><code>' . esc_html($sidebar_id) . '</code></td>';
        echo '<td>';
        echo '<label><input type="radio" name="' . esc_attr($mode_key) . '" value="on" ' . checked($mode, 'on', false) . '> ' . esc_html__('On', 'orbital-service-theme') . '</label><br>';
        echo '<label><input type="radio" name="' . esc_attr($mode_key) . '" value="off" ' . checked($mode, 'off', false) . '> ' . esc_html__('Off', 'orbital-service-theme') . '</label>';
        echo '</td>';
        echo '<td>';
        echo '<label><input type="radio" name="' . esc_attr($position_key) . '" value="left" ' . checked($position, 'left', false) . '> ' . esc_html__('Left on desktop/tablet', 'orbital-service-theme') . '</label><br>';
        echo '<label><input type="radio" name="' . esc_attr($position_key) . '" value="right" ' . checked($position, 'right', false) . '> ' . esc_html__('Right on desktop/tablet', 'orbital-service-theme') . '</label><br>';
        echo '<span class="description">' . esc_html__('Mobile always displays at the bottom.', 'orbital-service-theme') . '</span>';
        echo '</td>';
        echo '</tr>';
    }

    echo '</tbody></table>';
    submit_button(__('Save CPT Widget Area Settings', 'orbital-service-theme'));
    echo '</form>';
    echo '</div>';
}

/* v1.0.30: ITV-style blog/live-post metadata and Related News widget. */
function ost_normalize_content_type_name($value) {
    $value = strtolower(wp_strip_all_tags((string) $value));
    $value = str_replace(array('-', '_'), ' ', $value);
    $value = preg_replace('/[^a-z0-9]+/', ' ', $value);
    return trim(preg_replace('/\s+/', ' ', $value));
}

function ost_post_type_matches_service_blog_names($post_type = '') {
    $post_type = $post_type ? sanitize_key($post_type) : ost_current_post_type_slug();
    if (!$post_type) { return false; }

    $names = array($post_type);
    $object = get_post_type_object($post_type);
    if ($object) {
        $names[] = isset($object->name) ? $object->name : '';
        $names[] = isset($object->label) ? $object->label : '';
        $names[] = isset($object->labels->name) ? $object->labels->name : '';
        $names[] = isset($object->labels->singular_name) ? $object->labels->singular_name : '';
        $names[] = isset($object->rewrite['slug']) ? $object->rewrite['slug'] : '';
        $names[] = is_string($object->has_archive) ? $object->has_archive : '';
    }

    $exact_matches = array(
        'post',
        'posts',
        'blog',
        'blogs',
        'liveblog',
        'liveblogs',
        'live blog',
        'live blogs',
        'live post',
        'live posts',
    );

    foreach (array_filter(array_unique($names)) as $name) {
        $normal = ost_normalize_content_type_name($name);
        if ($normal === '') { continue; }
        if (in_array($normal, $exact_matches, true)) { return true; }
        if (strpos($normal, 'blog') !== false) { return true; }
        if (strpos($normal, 'live post') !== false) { return true; }
        if (strpos($normal, 'live blogs') !== false || strpos($normal, 'live blog') !== false) { return true; }
    }

    return false;
}

function ost_multisite_blog_style_site_context_matches() {
    $haystack = strtolower(wp_strip_all_tags(get_bloginfo('name') . ' ' . get_bloginfo('description') . ' ' . home_url('/')));
    $haystack = str_replace(array('-', '_'), ' ', $haystack);
    $terms = array(
        'blog', 'blogs', 'post', 'posts', 'news', 'article', 'articles',
        'live blog', 'live blogs', 'live post', 'live posts', 'updates'
    );
    foreach ($terms as $term) {
        if (strpos($haystack, $term) !== false) { return true; }
    }
    return false;
}

function ost_is_blog_style_post_type($post_type = '') {
    $post_type = $post_type ? sanitize_key($post_type) : ost_current_post_type_slug();
    if (!$post_type || $post_type === 'page') { return false; }

    if (ost_post_type_matches_service_blog_names($post_type)) { return true; }

    /*
     * Multisite support: on subsites named/slugged like Blog, Blogs, Post,
     * Posts, News, Articles, Live Blog, etc. treat normal content/CPT entries
     * as editorial posts so the clock/date/author strip is added to the layout.
     */
    if (is_multisite() && ost_multisite_blog_style_site_context_matches()) { return true; }

    return false;
}

function ost_itv_datetime_author_meta($post_id = 0, $mode = 'full') {
    $post_id = $post_id ? absint($post_id) : get_the_ID();
    if (!$post_id) { return; }

    $author_id = (int) get_post_field('post_author', $post_id);
    $author = $author_id ? get_the_author_meta('display_name', $author_id) : get_bloginfo('name');

    if ($mode === 'relative') {
        $date_text = human_time_diff(get_the_time('U', $post_id), current_time('timestamp')) . ' ' . __('ago', 'orbital-service-theme');
    } else {
        $date_text = get_the_date('l j F Y', $post_id) . ' ' . __('at', 'orbital-service-theme') . ' ' . get_the_time('g:ia', $post_id);
    }

    echo '<div class="ost-itv-meta ost-itv-meta-' . esc_attr($mode) . '">';
    echo '<span class="ost-itv-clock" aria-hidden="true"></span>';
    echo '<span class="ost-itv-date">' . esc_html($date_text) . '</span>';
    if ($mode !== 'relative') {
        echo '<span class="ost-itv-separator" aria-hidden="true">|</span>';
        echo '<span class="ost-itv-author">' . esc_html($author) . '</span>';
    }
    echo '</div>';
}

function ost_related_widget_post_types() {
    $types = ost_public_post_types_for_controls();
    $choices = array();
    foreach ($types as $post_type => $object) {
        $choices[$post_type] = $object->labels->singular_name . ' (' . $post_type . ')';
    }
    return $choices;
}

class OST_ITV_Related_CPT_Posts_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct(
            'ost_itv_related_cpt_posts',
            __('Orbital: Related CPT Posts', 'orbital-service-theme'),
            array('description' => __('ITV-style related news/posts widget with image left, title right and date below.', 'orbital-service-theme'))
        );
    }

    public function form($instance) {
        $title = isset($instance['title']) ? $instance['title'] : __('Related News', 'orbital-service-theme');
        $mode = isset($instance['mode']) ? $instance['mode'] : 'auto';
        $manual = isset($instance['manual_post_type']) ? $instance['manual_post_type'] : 'post';
        $number = isset($instance['number']) ? absint($instance['number']) : 3;
        $order = isset($instance['order']) ? $instance['order'] : 'date_desc';
        ?>
        <p><strong><?php esc_html_e('Component: Related CPT Posts', 'orbital-service-theme'); ?></strong><br><?php esc_html_e('Auto pulls posts instead of manually building menus.', 'orbital-service-theme'); ?></p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Widget title:', 'orbital-service-theme'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('mode')); ?>"><?php esc_html_e('Post type mode:', 'orbital-service-theme'); ?></label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('mode')); ?>" name="<?php echo esc_attr($this->get_field_name('mode')); ?>">
                <option value="auto" <?php selected($mode, 'auto'); ?>><?php esc_html_e('Auto: current CPT being viewed', 'orbital-service-theme'); ?></option>
                <option value="manual" <?php selected($mode, 'manual'); ?>><?php esc_html_e('Manual: selected CPT below', 'orbital-service-theme'); ?></option>
            </select>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('manual_post_type')); ?>"><?php esc_html_e('Fallback / manual CPT:', 'orbital-service-theme'); ?></label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('manual_post_type')); ?>" name="<?php echo esc_attr($this->get_field_name('manual_post_type')); ?>">
                <?php foreach (ost_related_widget_post_types() as $post_type => $label) : ?>
                    <option value="<?php echo esc_attr($post_type); ?>" <?php selected($manual, $post_type); ?>><?php echo esc_html($label); ?></option>
                <?php endforeach; ?>
            </select>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('How many to show:', 'orbital-service-theme'); ?></label>
            <input id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="number" min="1" max="12" value="<?php echo esc_attr($number); ?>" style="width:80px;">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('order')); ?>"><?php esc_html_e('Order:', 'orbital-service-theme'); ?></label>
            <select class="widefat" id="<?php echo esc_attr($this->get_field_id('order')); ?>" name="<?php echo esc_attr($this->get_field_name('order')); ?>">
                <option value="date_desc" <?php selected($order, 'date_desc'); ?>><?php esc_html_e('Latest first', 'orbital-service-theme'); ?></option>
                <option value="date_asc" <?php selected($order, 'date_asc'); ?>><?php esc_html_e('Oldest first', 'orbital-service-theme'); ?></option>
                <option value="rand" <?php selected($order, 'rand'); ?>><?php esc_html_e('Random', 'orbital-service-theme'); ?></option>
            </select>
        </p>
        <p>
            <label><?php esc_html_e('Layout style:', 'orbital-service-theme'); ?></label>
            <select class="widefat" disabled><option><?php esc_html_e('ITV-style: image left, title right, date below', 'orbital-service-theme'); ?></option></select>
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        return array(
            'title' => sanitize_text_field($new_instance['title'] ?? __('Related News', 'orbital-service-theme')),
            'mode' => in_array(($new_instance['mode'] ?? 'auto'), array('auto','manual'), true) ? $new_instance['mode'] : 'auto',
            'manual_post_type' => sanitize_key($new_instance['manual_post_type'] ?? 'post'),
            'number' => min(12, max(1, absint($new_instance['number'] ?? 3))),
            'order' => in_array(($new_instance['order'] ?? 'date_desc'), array('date_desc','date_asc','rand'), true) ? $new_instance['order'] : 'date_desc',
        );
    }

    public function widget($args, $instance) {
        $title = !empty($instance['title']) ? $instance['title'] : __('Related News', 'orbital-service-theme');
        $mode = !empty($instance['mode']) ? $instance['mode'] : 'auto';
        $post_type = ($mode === 'auto') ? ost_current_post_type_slug() : '';
        if (!$post_type || !post_type_exists($post_type)) {
            $post_type = !empty($instance['manual_post_type']) ? sanitize_key($instance['manual_post_type']) : 'post';
        }
        if (!post_type_exists($post_type)) { $post_type = 'post'; }

        $number = min(12, max(1, absint($instance['number'] ?? 3)));
        $order_setting = $instance['order'] ?? 'date_desc';
        $query_args = array(
            'post_type' => $post_type,
            'post_status' => 'publish',
            'posts_per_page' => $number,
            'post__not_in' => is_singular() ? array(get_the_ID()) : array(),
            'no_found_rows' => true,
        );
        if ($order_setting === 'date_asc') { $query_args['orderby'] = 'date'; $query_args['order'] = 'ASC'; }
        elseif ($order_setting === 'rand') { $query_args['orderby'] = 'rand'; }
        else { $query_args['orderby'] = 'date'; $query_args['order'] = 'DESC'; }

        $related = new WP_Query($query_args);
        if (!$related->have_posts()) { return; }

        echo $args['before_widget'];
        echo '<div class="ost-related-news ost-itv-related-news">';
        if ($title) { echo $args['before_title'] . esc_html($title) . $args['after_title']; }
        echo '<div class="ost-related-list">';
        while ($related->have_posts()) { $related->the_post();
            echo '<article class="ost-related-item">';
            echo '<a class="ost-related-thumb" href="' . esc_url(get_permalink()) . '" aria-hidden="true" tabindex="-1">';
            if (has_post_thumbnail()) { the_post_thumbnail('medium'); }
            else { echo '<span class="ost-related-placeholder"></span>'; }
            echo '</a>';
            echo '<div class="ost-related-body">';
            echo '<h3 class="ost-related-title"><a href="' . esc_url(get_permalink()) . '">' . esc_html(get_the_title()) . '</a></h3>';
            ost_itv_datetime_author_meta(get_the_ID(), 'relative');
            echo '</div></article>';
        }
        wp_reset_postdata();
        echo '</div></div>';
        echo $args['after_widget'];
    }
}

function ost_register_itv_related_widget() {
    register_widget('OST_ITV_Related_CPT_Posts_Widget');
}
add_action('widgets_init', 'ost_register_itv_related_widget');

class OST_Accordion_Walker extends Walker_Nav_Menu {
    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $has_children = in_array('menu-item-has-children', $classes, true);
        $classes[] = 'ost-depth-' . (int) $depth;
        $class_names = implode(' ', array_filter(array_map('sanitize_html_class', $classes)));
        $output .= '<li class="' . esc_attr($class_names) . '">';
        $atts = array();
        $atts['href'] = !empty($item->url) ? $item->url : '#';
        $atts['class'] = 'ost-menu-link';
        $attributes = '';
        foreach ($atts as $attr => $value) {
            if (!empty($value)) { $attributes .= ' ' . $attr . '="' . esc_attr($value) . '"'; }
        }
        $title = apply_filters('the_title', $item->title, $item->ID);
        if ($has_children) { $output .= '<div class="ost-menu-item-wrap">'; }
        $output .= '<a' . $attributes . '>' . esc_html($title) . '</a>';
        if ($has_children) {
            $output .= '<button class="ost-submenu-toggle" type="button" aria-expanded="false"><span class="screen-reader-text">' . esc_html__('Toggle sub menu', 'orbital-service-theme') . '</span></button></div>';
        }
    }
}


function ost_sanitize_url_or_blank($url) {
    $url = trim((string) $url);
    if ($url === '') { return ''; }
    return esc_url_raw($url);
}



/* v1.0.31: Multisite detection with manual theme-settings override. */
function ost_sanitize_multisite_detection_mode($mode) {
    $mode = sanitize_key($mode);
    return in_array($mode, array('auto', 'force_on', 'force_off'), true) ? $mode : 'auto';
}

function ost_is_wordpress_multisite_active() {
    return is_multisite();
}

function ost_multisite_controls_enabled() {
    $mode = get_theme_mod('ost_multisite_detection_mode', 'auto');

    if ($mode === 'force_on') {
        return true;
    }

    if ($mode === 'force_off') {
        return false;
    }

    return ost_is_wordpress_multisite_active();
}

function ost_multisite_detection_label() {
    if (ost_is_wordpress_multisite_active()) {
        return __('WordPress multisite detected: ON', 'orbital-service-theme');
    }
    return __('WordPress multisite detected: OFF', 'orbital-service-theme');
}

function ost_available_site_url_choices() {
    $choices = array(
        'current' => sprintf(__('Current site: %s', 'orbital-service-theme'), home_url('/')),
    );

    if (ost_multisite_controls_enabled()) {
        $choices['network'] = sprintf(__('Main network site: %s', 'orbital-service-theme'), is_multisite() ? network_home_url('/') : home_url('/'));
    }

    if (ost_multisite_controls_enabled() && is_multisite() && function_exists('get_sites')) {
        $sites = get_sites(array(
            'number'   => 100,
            'public'   => 1,
            'archived' => 0,
            'deleted'  => 0,
            'spam'     => 0,
        ));
        foreach ($sites as $site) {
            $blog_id = absint($site->blog_id);
            $url = get_home_url($blog_id, '/');
            $name = '';
            switch_to_blog($blog_id);
            $name = get_bloginfo('name');
            restore_current_blog();
            $label = trim($name) !== '' ? $name : sprintf(__('Site %d', 'orbital-service-theme'), $blog_id);
            $choices['site_' . $blog_id] = sprintf(__('%1$s: %2$s', 'orbital-service-theme'), $label, $url);
        }
    }

    $choices['custom'] = __('Custom URL typed below', 'orbital-service-theme');
    return $choices;
}

function ost_sanitize_site_url_choice($choice) {
    $choice = sanitize_text_field($choice);
    if (in_array($choice, array('current', 'network', 'custom'), true)) {
        return $choice;
    }
    if (strpos($choice, 'site_') === 0) {
        $blog_id = absint(substr($choice, 5));
        if ($blog_id > 0 && ost_multisite_controls_enabled() && is_multisite() && function_exists('get_site')) {
            $site = get_site($blog_id);
            if ($site && empty($site->deleted) && empty($site->spam) && empty($site->archived)) {
                return 'site_' . $blog_id;
            }
        }
    }
    return 'current';
}

function ost_sanitize_main_header_title_source($source) {
    $source = sanitize_text_field($source);
    return in_array($source, array('current', 'main_site', 'custom'), true) ? $source : 'current';
}

function ost_selected_main_site_url() {
    $choice = get_theme_mod('ost_main_site_url_choice', is_multisite() ? 'network' : 'current');

    if ($choice === 'network') {
        return is_multisite() ? network_home_url('/') : home_url('/');
    }

    if ($choice === 'custom') {
        $custom_url = get_theme_mod('ost_main_site_url', '');
        return !empty($custom_url) ? $custom_url : home_url('/');
    }

    if (strpos($choice, 'site_') === 0) {
        $blog_id = absint(substr($choice, 5));
        if ($blog_id > 0 && is_multisite() && function_exists('get_home_url')) {
            return get_home_url($blog_id, '/');
        }
    }

    return home_url('/');
}

function ost_main_header_url() {
    $choice = get_theme_mod('ost_main_header_url_choice', ost_multisite_controls_enabled() ? 'network' : 'current');

    if (!ost_multisite_controls_enabled() && in_array($choice, array('network'), true)) {
        $choice = 'current';
    }

    if ($choice === 'network') {
        return esc_url(is_multisite() ? network_home_url('/') : home_url('/'));
    }

    if ($choice === 'custom') {
        $custom_url = get_theme_mod('ost_main_header_custom_url', '');
        return esc_url(!empty($custom_url) ? $custom_url : home_url('/'));
    }

    if (strpos($choice, 'site_') === 0) {
        $blog_id = absint(substr($choice, 5));
        if ($blog_id > 0 && is_multisite() && function_exists('get_home_url')) {
            return esc_url(get_home_url($blog_id, '/'));
        }
    }

    return esc_url(home_url('/'));
}

function ost_is_excluded_service_page() {
    /*
     * Contact pages are hidden by default, but v1.2.0 adds a dedicated
     * Customizer checkbox so Contact pages can use the service/mission header
     * on demo subsites when needed.
     */
    if (is_page() && !is_home()) {
        $post = get_queried_object();
        $is_contact = false;

        if ($post && isset($post->post_name)) {
            $slug = strtolower((string) $post->post_name);
            if (in_array($slug, array('contact', 'contact-us'), true)) {
                $is_contact = true;
            }
        }

        $title = strtolower(trim((string) get_the_title()));
        if (in_array($title, array('contact', 'contact us'), true)) {
            $is_contact = true;
        }

        if ($is_contact) {
            return absint(get_theme_mod('ost_service_show_contact', 0)) !== 1;
        }
    }
    return false;
}


/* v1.3.5: Per-content Customizer title controls. */
function ost_sanitize_multi_post_ids($value) {
    if (!is_array($value)) {
        $value = explode(',', (string) $value);
    }

    return implode(',', array_values(array_unique(array_filter(array_map('absint', $value)))));
}

function ost_multi_post_ids_from_theme_mod($setting_id) {
    $value = get_theme_mod($setting_id, '');

    if (is_array($value)) {
        return array_values(array_unique(array_filter(array_map('absint', $value))));
    }

    return array_values(array_unique(array_filter(array_map('absint', explode(',', (string) $value)))));
}

function ost_cpt_content_item_choices($post_type) {
    $post_type = sanitize_key($post_type);
    $choices = array();

    if (!$post_type) {
        return $choices;
    }

    $items = get_posts(array(
        'post_type'      => $post_type,
        'post_status'    => array('publish', 'draft', 'private', 'pending', 'future'),
        'posts_per_page' => 200,
        'orderby'        => 'title',
        'order'          => 'ASC',
        'no_found_rows'  => true,
    ));

    foreach ($items as $item) {
        $title = get_the_title($item);
        if (!$title) {
            $title = sprintf(__('Untitled #%d', 'orbital-service-theme'), $item->ID);
        }

        $status = get_post_status($item);
        $choices[$item->ID] = sprintf('%1$s (#%2$d - %3$s)', $title, $item->ID, $status);
    }

    return $choices;
}


function ost_sanitize_page_title_selected_mode($value) {
    return in_array($value, array('inherit', 'on', 'off'), true) ? $value : 'inherit';
}

function ost_post_type_title_selected_items_setting_id($post_type) {
    return ost_post_type_setting_id('ost_page_title_selected_items', $post_type);
}

function ost_post_type_title_selected_mode_setting_id($post_type) {
    return ost_post_type_setting_id('ost_page_title_selected_mode', $post_type);
}

function ost_individual_page_title_selected_ids($post_type) {
    return ost_multi_post_ids_from_theme_mod(ost_post_type_title_selected_items_setting_id($post_type));
}

function ost_individual_page_title_selected_mode($post_type) {
    return ost_sanitize_page_title_selected_mode(get_theme_mod(ost_post_type_title_selected_mode_setting_id($post_type), 'inherit'));
}

function ost_post_type_title_off_items_setting_id($post_type) {
    return ost_post_type_setting_id('ost_page_title_off_items', $post_type);
}

function ost_post_type_title_on_items_setting_id($post_type) {
    return ost_post_type_setting_id('ost_page_title_on_items', $post_type);
}

function ost_individual_page_title_off_ids($post_type) {
    return ost_multi_post_ids_from_theme_mod(ost_post_type_title_off_items_setting_id($post_type));
}

function ost_individual_page_title_on_ids($post_type) {
    return ost_multi_post_ids_from_theme_mod(ost_post_type_title_on_items_setting_id($post_type));
}


/* v1.2.3: CPT Customizer controls are grouped under one Individual CPT Controls tab so the main Orbital panel does not show every detected CPT as a separate top-level row. */
function ost_customize_register($wp_customize) {
    /*
     * Customizer is split into clear sections so the service-header controls
     * are not hidden in one long list. WordPress calls these panels/sections;
     * they work like tabs inside Appearance > Customizer.
     */
    $wp_customize->add_panel('ost_theme_options', array(
        'title'       => __('Orbital Service Theme', 'orbital-service-theme'),
        'description' => __('Header, service header, global display rules, grouped CPT controls, multisite links, footer and colours.', 'orbital-service-theme'),
        'priority'    => 30,
    ));

    $wp_customize->add_section('ost_tab_main_header', array(
        'title'    => __('Main Header', 'orbital-service-theme'),
        'panel'    => 'ost_theme_options',
        'priority' => 10,
    ));

    $wp_customize->add_section('ost_tab_service_header', array(
        'title'       => __('Service/Mission Header', 'orbital-service-theme'),
        'description' => __('Controls the second header row shown under the main header.', 'orbital-service-theme'),
        'panel'       => 'ost_theme_options',
        'priority'    => 20,
    ));

    $wp_customize->add_section('ost_tab_cpt_rules', array(
        'title'       => __('All Content Display Rules', 'orbital-service-theme'),
        'description' => __('Global controls for Home, Contact and the overall service/mission header. Individual CPT controls now live under the Individual CPT Controls tab so the main Customizer screen stays clean.', 'orbital-service-theme'),
        'panel'       => 'ost_theme_options',
        'priority'    => 30,
    ));

    $wp_customize->add_section('ost_tab_individual_cpt_controls', array(
        'title'       => __('Individual CPT Controls', 'orbital-service-theme'),
        'description' => __('All detected CPT tabs are grouped here. Scroll to the content type you want, then control service/mission header on/off, page title on/off, widgets on/off, desktop widget side, service/mission title mode, custom title, custom subtitle and service title link for that CPT only.', 'orbital-service-theme'),
        'panel'       => 'ost_theme_options',
        'priority'    => 35,
    ));

    $wp_customize->add_section('ost_tab_multisite', array(
        'title'       => __('Multisite Options', 'orbital-service-theme'),
        'description' => __('Controls where the main header site title/logo links on single-site or multisite installs.', 'orbital-service-theme'),
        'panel'       => 'ost_theme_options',
        'priority'    => 40,
    ));

    $wp_customize->add_section('ost_tab_footer', array(
        'title'    => __('Footer', 'orbital-service-theme'),
        'panel'    => 'ost_theme_options',
        'priority' => 50,
    ));

    $wp_customize->add_section('ost_tab_colours', array(
        'title'    => __('Colours', 'orbital-service-theme'),
        'panel'    => 'ost_theme_options',
        'priority' => 60,
    ));

    $wp_customize->add_section('ost_tab_layout', array(
        'title'       => __('Layout', 'orbital-service-theme'),
        'description' => __('Core layout is fixed to keep the NASA-style header and CMUK-style accordion behaviour stable.', 'orbital-service-theme'),
        'panel'       => 'ost_theme_options',
        'priority'    => 70,
    ));

    $wp_customize->add_section('ost_tab_mobile_menu', array(
        'title'       => __('Mobile Menu', 'orbital-service-theme'),
        'description' => __('Mobile menu buttons are borderless like CMUK and use + / − accordion toggles.', 'orbital-service-theme'),
        'panel'       => 'ost_theme_options',
        'priority'    => 80,
    ));


    $wp_customize->add_setting('ost_content_height_mode', array(
        'default'           => 'elementor',
        'sanitize_callback' => 'ost_sanitize_content_height_mode',
    ));
    $wp_customize->add_control('ost_content_height_mode', array(
        'label'       => __('Theme content height', 'orbital-service-theme'),
        'description' => __('Elementor Default removes the theme fixed content-height system so Elementor sections/widgets finish naturally. Theme Fixed Height restores the old theme behaviour that keeps the main content area tall for footer pushing.', 'orbital-service-theme'),
        'section'     => 'ost_tab_layout',
        'type'        => 'radio',
        'priority'    => 1,
        'choices'     => array(
            'elementor' => __('Elementor Default - content ends naturally', 'orbital-service-theme'),
            'theme'     => __('Theme Fixed Height - use old theme content height', 'orbital-service-theme'),
        ),
    ));


    $wp_customize->add_section('ost_tab_cpt_widgets', array(
        'title'       => __('All Widget Rules', 'orbital-service-theme'),
        'description' => __('Global widget rules only. Each detected CPT has its own tab-like Customizer section with its own widget on/off and desktop position controls.', 'orbital-service-theme'),
        'panel'       => 'ost_theme_options',
        'priority'    => 82,
    ));

    $wp_customize->add_setting('ost_cpt_widget_fallback_mode', array(
        'default'           => ost_get_cpt_widget_fallback_mode(),
        'sanitize_callback' => 'ost_sanitize_cpt_widget_fallback_mode',
    ));
    $wp_customize->add_control('ost_cpt_widget_fallback_mode', array(
        'label'       => __('Fallback widgets', 'orbital-service-theme'),
        'description' => __('On allows shared fallback sidebar widgets, default related/mission widgets and main-site multisite widget fallbacks. Off means only the current CPT widget area can display. On multisite this setting is saved network-wide so all subsites follow the same fallback rule.', 'orbital-service-theme'),
        'section'     => 'ost_tab_cpt_widgets',
        'type'        => 'radio',
        'priority'    => 1,
        'choices'     => array(
            'on'  => __('On - allow fallback widgets', 'orbital-service-theme'),
            'off' => __('Off - current CPT widget area only', 'orbital-service-theme'),
        ),
    ));



    /* v1.0.98: Automatic CPT Related Posts Customizer control removed. Use manual widget areas only. */

    $colour_settings = array(
        'ost_header_bg'  => array('#05060a', 'Global header background'),
        'ost_service_bg' => array('#1b1f2a', 'Service header background'),
        'ost_accent'     => array('#ff4b2b', 'Accent colour'),
        'ost_footer_bg'  => array('#0b0c0c', 'Footer background'),
        'ost_link'       => array('#1d70b8', 'Content link colour'),
    );
    foreach ($colour_settings as $id => $data) {
        $wp_customize->add_setting($id, array(
            'default'           => $data[0],
            'sanitize_callback' => 'sanitize_hex_color',
        ));
        $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, $id, array(
            'label'   => __($data[1], 'orbital-service-theme'),
            'section' => 'ost_tab_colours',
        )));
    }

    $wp_customize->add_setting('ost_service_title', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('ost_service_title', array(
        'label'       => __('Mission/service title', 'orbital-service-theme'),
        'description' => __('Leave blank to use the current site/section title automatically. Type a value only if you want to override it.', 'orbital-service-theme'),
        'section'     => 'ost_tab_service_header',
        'type'        => 'text',
    ));

    $wp_customize->add_setting('ost_service_subtitle', array(
        'default'           => 'Sections and updates',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('ost_service_subtitle', array(
        'label'   => __('Mission/service subtitle', 'orbital-service-theme'),
        'section' => 'ost_tab_service_header',
        'type'    => 'text',
    ));

    $wp_customize->add_setting('ost_multisite_detection_mode', array(
        'default'           => 'auto',
        'sanitize_callback' => 'ost_sanitize_multisite_detection_mode',
    ));
    $wp_customize->add_control('ost_multisite_detection_mode', array(
        'label'       => __('Multisite detection mode', 'orbital-service-theme'),
        'description' => ost_multisite_detection_label() . ' — Auto uses real WordPress multisite when available. Force ON lets you show/use multisite-style URL controls on a single-site install. Force OFF hides network behaviour.',
        'section'     => 'ost_tab_multisite',
        'type'        => 'radio',
        'choices'     => array(
            'auto'      => __('Auto detect WordPress multisite', 'orbital-service-theme'),
            'force_on'  => __('Force multisite controls ON', 'orbital-service-theme'),
            'force_off' => __('Force multisite controls OFF', 'orbital-service-theme'),
        ),
    ));

    $wp_customize->add_setting('ost_main_header_title_source', array(
        'default'           => 'current',
        'sanitize_callback' => 'ost_sanitize_main_header_title_source',
    ));
    $wp_customize->add_control('ost_main_header_title_source', array(
        'label'       => __('Main header title source', 'orbital-service-theme'),
        'description' => __('Current Site Title uses this subsite title. Main Network Site Title uses the main site name across subsites. Custom Title uses the typed title below.', 'orbital-service-theme'),
        'section'     => 'ost_tab_multisite',
        'type'        => 'radio',
        'choices'     => array(
            'current'   => __('Current Site Title', 'orbital-service-theme'),
            'main_site' => __('Main Network Site Title', 'orbital-service-theme'),
            'custom'    => __('Custom Title typed below', 'orbital-service-theme'),
        ),
    ));

    $wp_customize->add_setting('ost_main_header_custom_title', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('ost_main_header_custom_title', array(
        'label'       => __('Main header custom title', 'orbital-service-theme'),
        'description' => __('Only used when Main header title source is set to Custom Title.', 'orbital-service-theme'),
        'section'     => 'ost_tab_multisite',
        'type'        => 'text',
    ));

    $wp_customize->add_setting('ost_main_header_url_choice', array(
        'default'           => ost_multisite_controls_enabled() ? 'network' : 'current',
        'sanitize_callback' => 'ost_sanitize_site_url_choice',
    ));
    $wp_customize->add_control('ost_main_header_url_choice', array(
        'label'       => __('Main header site-title URL', 'orbital-service-theme'),
        'description' => __('This controls the top/main header only. On multisite it lists every detected site so the main header can link network-wide. The service header title stays local to the current site/CPT rules.', 'orbital-service-theme'),
        'section'     => 'ost_tab_multisite',
        'type'        => 'radio',
        'choices'     => ost_available_site_url_choices(),
    ));

    $wp_customize->add_setting('ost_main_header_custom_url', array(
        'default'           => '',
        'sanitize_callback' => 'ost_sanitize_url_or_blank',
    ));
    $wp_customize->add_control('ost_main_header_custom_url', array(
        'label'       => __('Main header custom URL fallback', 'orbital-service-theme'),
        'description' => __('Only used when the main header radio selector above is set to Custom URL typed below.', 'orbital-service-theme'),
        'section'     => 'ost_tab_multisite',
        'type'        => 'url',
    ));

    $wp_customize->add_setting('ost_service_show_home', array(
        'default'           => 1,
        'sanitize_callback' => 'ost_sanitize_checkbox',
    ));
    $wp_customize->add_control('ost_service_show_home', array(
        'label'       => __('Show service header on Home page', 'orbital-service-theme'),
        'description' => __('Ticked means the homepage shows the service/mission header. Unticked means the homepage hides it.', 'orbital-service-theme'),
        'section'     => 'ost_tab_cpt_rules',
        'type'        => 'checkbox',
    ));

    $wp_customize->add_setting('ost_service_show_contact', array(
        'default'           => 0,
        'sanitize_callback' => 'ost_sanitize_checkbox',
    ));
    $wp_customize->add_control('ost_service_show_contact', array(
        'label'       => __('Show service header on Contact pages', 'orbital-service-theme'),
        'description' => __('Ticked means pages with the slug or title Contact / Contact Us can show the service/mission header. Unticked keeps Contact pages hidden by default.', 'orbital-service-theme'),
        'section'     => 'ost_tab_cpt_rules',
        'type'        => 'checkbox',
    ));

    $wp_customize->add_setting('ost_page_title_show_home', array(
        'default'           => 0,
        'sanitize_callback' => 'ost_sanitize_checkbox',
    ));
    $wp_customize->add_control('ost_page_title_show_home', array(
        'label'       => __('Show page title on Home page', 'orbital-service-theme'),
        'description' => __('Ticked means the homepage shows the normal page title banner. Unticked keeps the homepage title hidden.', 'orbital-service-theme'),
        'section'     => 'ost_tab_cpt_rules',
        'type'        => 'checkbox',
    ));

    if (class_exists('WP_Customize_Control') && !class_exists('OST_Customize_Heading_Control')) {
        class OST_Customize_Heading_Control extends WP_Customize_Control {
            public $type = 'ost_heading';
            public $description = '';
            public function render_content() {
                echo '<hr style="margin:22px 0 14px;border:0;border-top:1px solid #c3c4c7;">';
                echo '<h2 style="margin:0 0 8px;font-size:18px;line-height:1.3;">' . esc_html($this->label) . '</h2>';
                if (!empty($this->description)) {
                    echo '<p class="description" style="margin:0 0 12px;">' . esc_html($this->description) . '</p>';
                }
            }
        }
    }

    
    
    if (class_exists('WP_Customize_Control') && !class_exists('OST_Customize_Dropdown_Multi_Checkbox_Control')) {
        class OST_Customize_Dropdown_Multi_Checkbox_Control extends WP_Customize_Control {
            public $type = 'ost_dropdown_multi_checkbox';

            public function render_content() {
                if (empty($this->choices)) {
                    return;
                }

                $values = $this->value();
                if (!is_array($values)) {
                    $values = explode(',', (string) $values);
                }
                $values = array_values(array_unique(array_filter(array_map('absint', $values))));
                $count = count($values);
                ?>
                <span class="customize-control-title"><?php echo esc_html($this->label); ?></span>
                <?php if (!empty($this->description)) : ?>
                    <span class="description customize-control-description"><?php echo wp_kses_post($this->description); ?></span>
                <?php endif; ?>

                <details style="margin-top:8px;border:1px solid #ccd0d4;background:#fff;">
                    <summary style="padding:10px 12px;cursor:pointer;font-weight:600;">
                        <?php
                        if ($count > 0) {
                            printf(esc_html__('%d selected', 'orbital-service-theme'), $count);
                        } else {
                            esc_html_e('Select content', 'orbital-service-theme');
                        }
                        ?>
                    </summary>
                    <div style="max-height:260px;overflow:auto;border-top:1px solid #ccd0d4;padding:8px 10px;">
                        <?php foreach ($this->choices as $value => $label) : ?>
                            <p style="margin:0 0 8px;">
                                <label>
                                    <input type="checkbox"
                                        value="<?php echo esc_attr($value); ?>"
                                        <?php checked(in_array(absint($value), $values, true)); ?>
                                        onchange="(function(cb){var wrap=cb.closest('.customize-control');var hidden=wrap.querySelector('input[type=hidden]');var selected=[];wrap.querySelectorAll('input[type=checkbox]:checked').forEach(function(item){selected.push(item.value);});hidden.value=selected.join(',');hidden.dispatchEvent(new Event('change',{bubbles:true}));})(this);"
                                    />
                                    <?php echo esc_html($label); ?>
                                </label>
                            </p>
                        <?php endforeach; ?>
                    </div>
                </details>

                <input type="hidden" <?php $this->link(); ?> value="<?php echo esc_attr(is_array($this->value()) ? implode(',', $this->value()) : $this->value()); ?>" />
                <?php
            }
        }
    }

if (class_exists('WP_Customize_Control') && !class_exists('OST_Customize_Multi_Checkbox_Control')) {
        class OST_Customize_Multi_Checkbox_Control extends WP_Customize_Control {
            public $type = 'ost_multi_checkbox';

            public function render_content() {
                if (empty($this->choices)) {
                    return;
                }

                $values = $this->value();
                if (!is_array($values)) {
                    $values = explode(',', (string) $values);
                }
                $values = array_map('absint', $values);
                ?>
                <span class="customize-control-title"><?php echo esc_html($this->label); ?></span>
                <?php if (!empty($this->description)) : ?>
                    <span class="description customize-control-description"><?php echo wp_kses_post($this->description); ?></span>
                <?php endif; ?>

                <ul style="max-height:220px;overflow:auto;border:1px solid #ccd0d4;background:#fff;padding:8px 10px;margin:8px 0;">
                    <?php foreach ($this->choices as $value => $label) : ?>
                        <li style="margin-bottom:6px;">
                            <label>
                                <input type="checkbox"
                                    value="<?php echo esc_attr($value); ?>"
                                    <?php checked(in_array(absint($value), $values, true)); ?>
                                    onchange="(function(cb){var wrap=cb.closest('.customize-control');var hidden=wrap.querySelector('input[type=hidden]');var selected=[];wrap.querySelectorAll('input[type=checkbox]:checked').forEach(function(item){selected.push(item.value);});hidden.value=selected.join(',');hidden.dispatchEvent(new Event('change',{bubbles:true}));})(this);"
                                />
                                <?php echo esc_html($label); ?>
                            </label>
                        </li>
                    <?php endforeach; ?>
                </ul>
                <input type="hidden" <?php $this->link(); ?> value="<?php echo esc_attr(is_array($this->value()) ? implode(',', $this->value()) : $this->value()); ?>" />
                <?php
            }
        }
    }

foreach (ost_public_post_types_for_controls() as $post_type => $object) {
        $cpt_section = 'ost_tab_individual_cpt_controls';
        $heading_id = 'ost_cpt_heading_' . sanitize_key($post_type);
        $wp_customize->add_setting($heading_id, array(
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        if (class_exists('OST_Customize_Heading_Control')) {
            $wp_customize->add_control(new OST_Customize_Heading_Control($wp_customize, $heading_id, array(
                'label'       => sprintf(__('CPT: %s', 'orbital-service-theme'), $object->labels->name),
                'description' => sprintf(__('Controls below affect %1$s only. Other CPTs keep their own settings.', 'orbital-service-theme'), $object->labels->name),
                'section'     => $cpt_section,
                'priority'    => 90,
            )));
        }

        $enabled_id = ost_post_type_setting_id('ost_service_show', $post_type);
        $target_id  = ost_post_type_setting_id('ost_service_title_target', $post_type);

        $wp_customize->add_setting($enabled_id, array(
            'default'           => 1,
            'sanitize_callback' => 'ost_sanitize_checkbox',
        ));
        $wp_customize->add_control($enabled_id, array(
            'label'       => sprintf(__('Show service header on %s', 'orbital-service-theme'), $object->labels->name),
            'description' => __('On shows the service/mission header for this CPT. Off hides it for this CPT only. Home and Contact are controlled in All Content Display Rules.', 'orbital-service-theme'),
            'section'     => $cpt_section,
            'type'        => 'radio',
            'choices'     => array(
                '1' => __('On - show service/mission header for this CPT', 'orbital-service-theme'),
                '0' => __('Off - hide service/mission header for this CPT', 'orbital-service-theme'),
            ),
        ));

        $page_title_id = ost_post_type_setting_id('ost_page_title_show', $post_type);
        $wp_customize->add_setting($page_title_id, array(
            'default'           => 1,
            'sanitize_callback' => 'ost_sanitize_checkbox',
        ));
        $wp_customize->add_control($page_title_id, array(
            'label'       => sprintf(__('Show page title on %s', 'orbital-service-theme'), $object->labels->name),
            'description' => __('On shows the normal page title line above this CPT content. Off hides it for this CPT only.', 'orbital-service-theme'),
            'section'     => $cpt_section,
            'type'        => 'radio',
            'choices'     => array(
                '1' => __('On - show page title for this CPT', 'orbital-service-theme'),
                '0' => __('Off - hide page title for this CPT', 'orbital-service-theme'),
            ),
        ));



        $content_choices = ost_cpt_content_item_choices($post_type);

        if (!empty($content_choices) && class_exists('OST_Customize_Dropdown_Multi_Checkbox_Control')) {
            $selected_items_id = ost_post_type_title_selected_items_setting_id($post_type);
            $wp_customize->add_setting($selected_items_id, array(
                'default'           => '',
                'sanitize_callback' => 'ost_sanitize_multi_post_ids',
            ));
            $wp_customize->add_control(new OST_Customize_Dropdown_Multi_Checkbox_Control($wp_customize, $selected_items_id, array(
                'label'       => sprintf(__('Select individual %s content', 'orbital-service-theme'), $object->labels->name),
                'description' => __('Open the dropdown and tick one or more content items from this CPT. Then use the radio buttons below to decide whether selected items show or hide the page title.', 'orbital-service-theme'),
                'section'     => $cpt_section,
                'choices'     => $content_choices,
            )));

            $selected_mode_id = ost_post_type_title_selected_mode_setting_id($post_type);
            $wp_customize->add_setting($selected_mode_id, array(
                'default'           => 'inherit',
                'sanitize_callback' => 'ost_sanitize_page_title_selected_mode',
            ));
            $wp_customize->add_control($selected_mode_id, array(
                'label'       => sprintf(__('Page title for selected %s content', 'orbital-service-theme'), $object->labels->name),
                'description' => __('This applies to the selected content items above only. Use CPT setting means the selected items follow the CPT-wide page title setting.', 'orbital-service-theme'),
                'section'     => $cpt_section,
                'type'        => 'radio',
                'choices'     => array(
                    'inherit' => __('Use CPT setting', 'orbital-service-theme'),
                    'on'      => __('On - show page title for selected content', 'orbital-service-theme'),
                    'off'     => __('Off - hide page title for selected content', 'orbital-service-theme'),
                ),
            ));
        }



        if (!empty($content_choices) && class_exists('OST_Customize_Multi_Checkbox_Control')) {
            $title_off_items_id = ost_post_type_title_off_items_setting_id($post_type);
            $wp_customize->add_setting($title_off_items_id, array(
                'default'           => '',
                'sanitize_callback' => 'ost_sanitize_multi_post_ids',
            ));
            $wp_customize->add_control(new OST_Customize_Multi_Checkbox_Control($wp_customize, $title_off_items_id, array(
                'label'       => sprintf(__('Hide page title for selected %s content', 'orbital-service-theme'), $object->labels->name),
                'description' => __('Tick one or more individual items from this CPT. The page title will be hidden only on those selected content items. This overrides the CPT-wide page title setting above.', 'orbital-service-theme'),
                'section'     => $cpt_section,
                'choices'     => $content_choices,
            )));

            $title_on_items_id = ost_post_type_title_on_items_setting_id($post_type);
            $wp_customize->add_setting($title_on_items_id, array(
                'default'           => '',
                'sanitize_callback' => 'ost_sanitize_multi_post_ids',
            ));
            $wp_customize->add_control(new OST_Customize_Multi_Checkbox_Control($wp_customize, $title_on_items_id, array(
                'label'       => sprintf(__('Force show page title for selected %s content', 'orbital-service-theme'), $object->labels->name),
                'description' => __('Tick one or more individual items from this CPT. These selected items will show the page title even if the CPT-wide page title setting above is Off.', 'orbital-service-theme'),
                'section'     => $cpt_section,
                'choices'     => $content_choices,
            )));
        }

        $widget_mode_id = ost_cpt_widget_setting_id($post_type);
        $wp_customize->add_setting($widget_mode_id, array(
            'default'           => ost_get_cpt_widget_mode($post_type),
            'sanitize_callback' => 'ost_sanitize_cpt_widget_mode',
        ));
        $wp_customize->add_control($widget_mode_id, array(
            'label'       => sprintf(__('Widgets for %s', 'orbital-service-theme'), $object->labels->name),
            'description' => sprintf(__('On creates and displays the independent widget area named CPT Widgets: %1$s. Off hides widgets on this content type only, without affecting other CPT widget areas.', 'orbital-service-theme'), $object->labels->name),
            'section'     => $cpt_section,
            'type'        => 'radio',
            'choices'     => array(
                'on'  => __('On - use this CPT independent widget area', 'orbital-service-theme'),
                'off' => __('Off - hide widgets for this CPT', 'orbital-service-theme'),
            ),
        ));

        $widget_position_id = ost_cpt_widget_position_setting_id($post_type);
        $wp_customize->add_setting($widget_position_id, array(
            'default'           => ost_get_cpt_widget_position($post_type),
            'sanitize_callback' => 'ost_sanitize_cpt_widget_position',
        ));
        $wp_customize->add_control($widget_position_id, array(
            'label'       => sprintf(__('Desktop widget position for %s', 'orbital-service-theme'), $object->labels->name),
            'description' => __('Desktop can be left or right for this CPT. Mobile is always forced to the bottom under the content.', 'orbital-service-theme'),
            'section'     => $cpt_section,
            'type'        => 'radio',
            'choices'     => array(
                'left'  => __('Left side on desktop/tablet', 'orbital-service-theme'),
                'right' => __('Right side on desktop/tablet', 'orbital-service-theme'),
            ),
        ));

        $title_mode_id = ost_service_setting_key('ost_service_title_mode', $post_type);
        $wp_customize->add_setting($title_mode_id, array(
            'default'           => 'site',
            'sanitize_callback' => 'ost_sanitize_service_title_mode',
        ));
        $wp_customize->add_control($title_mode_id, array(
            'label'       => sprintf(__('Service/mission title mode for %s', 'orbital-service-theme'), $object->labels->name),
            'description' => __('All content can use the site/global title, all content can use the CPT title, single content can use its own post title, or you can type a custom CPT title below. Individual items can still override this from the edit screen meta box.', 'orbital-service-theme'),
            'section'     => $cpt_section,
            'type'        => 'radio',
            'choices'     => array(
                'site'   => __('All content - use global/site service title', 'orbital-service-theme'),
                'cpt'    => __('All content - use this CPT title', 'orbital-service-theme'),
                'single' => __('Single content - use current item title', 'orbital-service-theme'),
                'custom' => __('All content - use custom title typed below', 'orbital-service-theme'),
            ),
        ));

        $custom_title_id = ost_service_setting_key('ost_service_title_custom', $post_type);
        $wp_customize->add_setting($custom_title_id, array(
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control($custom_title_id, array(
            'label'       => sprintf(__('Custom service/mission title for %s', 'orbital-service-theme'), $object->labels->name),
            'description' => __('Used when the title mode is CPT/custom. Leave blank to use the CPT label automatically.', 'orbital-service-theme'),
            'section'     => $cpt_section,
            'type'        => 'text',
        ));

        $custom_subtitle_id = ost_service_setting_key('ost_service_subtitle_custom', $post_type);
        $wp_customize->add_setting($custom_subtitle_id, array(
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control($custom_subtitle_id, array(
            'label'       => sprintf(__('Custom service/mission subtitle for %s', 'orbital-service-theme'), $object->labels->name),
            'description' => __('Leave blank to use the global service/mission subtitle. Type a value when this CPT needs its own subtitle.', 'orbital-service-theme'),
            'section'     => $cpt_section,
            'type'        => 'text',
        ));

        $wp_customize->add_setting($target_id, array(
            'default'           => 'home',
            'sanitize_callback' => 'ost_sanitize_service_url_choice',
        ));
        $wp_customize->add_control($target_id, array(
            'label'       => sprintf(__('Service title link for %s', 'orbital-service-theme'), $object->labels->name),
            'description' => __('This dropdown only lists content from this same CPT plus the current site homepage. It does not use the multisite-wide main header setting.', 'orbital-service-theme'),
            'section'     => $cpt_section,
            'type'        => 'select',
            'choices'     => ost_service_title_url_choices($post_type),
        ));
    }

    $footer_text_settings = array(
        'ost_footer_updated_label'  => array('Page Last Updated:', 'Footer updated label'),
        'ost_footer_updated_value'  => array('May 27, 2026', 'Footer updated value'),
        'ost_footer_editor_label'   => array('Page Editor:', 'Footer editor label'),
        'ost_footer_editor_value'   => array('Connor Moizer', 'Footer editor value'),
        'ost_footer_official_label' => array('Responsible Site Owner:', 'Footer responsible owner label'),
        'ost_footer_official_value' => array('Connor Moizer', 'Footer responsible owner value'),
    );
    foreach ($footer_text_settings as $id => $data) {
        $wp_customize->add_setting($id, array(
            'default'           => $data[0],
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control($id, array(
            'label'   => __($data[1], 'orbital-service-theme'),
            'section' => 'ost_tab_footer',
            'type'    => 'text',
        ));
    }

    $wp_customize->add_setting('ost_footer_credit_url', array(
        'default'           => 'https://connormoizer.com/',
        'sanitize_callback' => 'ost_sanitize_url_or_blank',
    ));
    $wp_customize->add_control('ost_footer_credit_url', array(
        'label'       => __('Footer credit link URL', 'orbital-service-theme'),
        'description' => __('Used for the Made with love by Connor Moizer link. Default points to ConnorMoizer.com.', 'orbital-service-theme'),
        'section'     => 'ost_tab_footer',
        'type'        => 'url',
    ));
}
add_action('customize_register', 'ost_customize_register', 999);

function ost_custom_css() {
    $header = get_theme_mod('ost_header_bg', '#05060a');
    $service = get_theme_mod('ost_service_bg', '#1b1f2a');
    $accent = get_theme_mod('ost_accent', '#ff4b2b');
    $footer = get_theme_mod('ost_footer_bg', '#0b0c0c');
    $link = get_theme_mod('ost_link', '#1d70b8');
    echo '<style id="ost-custom-css">:root{--ost-bg:' . esc_attr($header) . ';--ost-bg-2:' . esc_attr($service) . ';--ost-accent:' . esc_attr($accent) . ';--ost-footer:' . esc_attr($footer) . ';--ost-link:' . esc_attr($link) . ';}</style>';
}
add_action('wp_head', 'ost_custom_css', 20);

function ost_show_service_nav() {
    if (is_front_page()) {
        return absint(get_theme_mod('ost_service_show_home', 1)) === 1;
    }

    if (ost_is_excluded_service_page()) {
        return false;
    }

    $post_type = ost_current_post_type_slug();

    /*
     * v1.0.70: Service/mission header is ON by default everywhere, but the
     * Display Rules checkbox must always be respected. That means posts,
     * blogs, live blogs, pages and third-party CPTs no longer bypass the
     * checkbox. Ticked = show. Unticked = hide.
     */
    if (!$post_type && (is_home() || is_category() || is_tag() || is_date() || is_author())) {
        $post_type = 'post';
    }

    if (!$post_type) {
        return true;
    }

    $allowed_types = ost_public_post_types_for_controls();

    if (!isset($allowed_types[$post_type])) {
        return true;
    }

    $setting_id = ost_post_type_setting_id('ost_service_show', $post_type);
    $value      = get_theme_mod($setting_id, 1);

    return absint($value) === 1;
}


function ost_show_home_page_title() {
    return absint(get_theme_mod('ost_page_title_show_home', 0)) === 1;
}

/**
 * Return whether the normal white page-title strip should display for the
 * current page/post/CPT context. This is intentionally the same style of
 * control as "Show page title on Home page"; it is not a new title banner.
 */
function ost_show_page_title_for_current_context() {
    if (is_front_page()) {
        return ost_show_home_page_title();
    }

    $post_type = ost_current_post_type_slug();

    if (!$post_type && (is_home() || is_category() || is_tag() || is_date() || is_author())) {
        $post_type = 'post';
    }

    if (!$post_type) {
        return true;
    }

    $allowed_types = ost_public_post_types_for_controls();

    if (!isset($allowed_types[$post_type])) {
        return true;
    }

    if (is_singular()) {
        $current_id = absint(get_queried_object_id());

        if ($current_id) {
            $selected_ids  = ost_individual_page_title_selected_ids($post_type);
            $selected_mode = ost_individual_page_title_selected_mode($post_type);

            if (in_array($current_id, $selected_ids, true)) {
                if ($selected_mode === 'on') {
                    return true;
                }

                if ($selected_mode === 'off') {
                    return false;
                }
            }

            $force_on_ids  = ost_individual_page_title_on_ids($post_type);
            $force_off_ids = ost_individual_page_title_off_ids($post_type);

            if (in_array($current_id, $force_on_ids, true)) {
                return true;
            }

            if (in_array($current_id, $force_off_ids, true)) {
                return false;
            }
        }
    }

    $setting_id = ost_post_type_setting_id('ost_page_title_show', $post_type);
    $value      = get_theme_mod($setting_id, 1);

    return absint($value) === 1;
}

function ost_get_current_page_title_text() {
    if (is_front_page()) {
        $front_id = (int) get_option('page_on_front');
        $title = $front_id ? get_the_title($front_id) : get_bloginfo('name');
        return $title ? $title : get_bloginfo('name');
    }

    if (is_singular()) {
        return get_the_title();
    }

    if (is_archive()) {
        return get_the_archive_title();
    }

    if (is_search()) {
        return __('Search', 'orbital-service-theme');
    }

    return get_bloginfo('name');
}

function ost_render_page_title() {
    if (!ost_show_page_title_for_current_context()) { return; }

    $title = ost_get_current_page_title_text();
    if (!$title) { return; }

    echo '<section class="ost-page-title ost-page-title-white ost-page-title-forced" aria-label="' . esc_attr__('Page title', 'orbital-service-theme') . '"><div class="ost-wrap">';
    echo '<h1>' . esc_html($title) . '</h1>';
    if (is_singular() && ost_is_blog_style_post_type(get_post_type())) {
        ost_itv_datetime_author_meta(get_the_ID(), 'full');
    }
    echo '</div></section>';
}

function ost_page_title() {
    /*
     * Backwards-compatible wrapper. v1.0.81 renders the page title once from
     * header.php immediately after <main>, so Elementor-built pages/CPTs still
     * get the title above their content instead of relying on the template file.
     */
    ost_render_page_title();
}


/**
 * v1.2.5: Safe reader for the theme content-height mode.
 *
 * v1.2.4 added the Customizer control but the helper used by body_class was
 * missing, causing a fatal error. Keep this function deliberately small and
 * defensive so the front end can never crash if the option is missing, empty,
 * or contains an older value.
 */
function ost_sanitize_content_height_mode($value) {
    $value = is_string($value) ? strtolower(trim($value)) : '';
    return in_array($value, array('elementor', 'theme'), true) ? $value : 'elementor';
}

function ost_content_height_mode() {
    $mode = get_theme_mod('ost_content_height_mode', 'elementor');
    return ost_sanitize_content_height_mode($mode);
}

function ost_body_classes($classes) {
    $classes[] = 'ost-theme';
    if (ost_content_height_mode() === 'theme') {
        $classes[] = 'ost-theme-content-height-on';
    } else {
        $classes[] = 'ost-theme-content-height-elementor';
    }
    return $classes;
}
add_filter('body_class','ost_body_classes');

function ost_default_primary_menu() {
    echo '<ul class="ost-menu"><li><a href="'.esc_url(home_url('/')).'">'.esc_html__('Home','orbital-service-theme').'</a></li><li class="menu-item-has-children"><div class="ost-menu-item-wrap"><a href="#">'.esc_html__('Sections','orbital-service-theme').'</a><button class="ost-submenu-toggle" type="button" aria-expanded="false"><span class="screen-reader-text">'.esc_html__('Toggle sub menu','orbital-service-theme').'</span></button></div><ul class="sub-menu"><li><a href="#">'.esc_html__('News','orbital-service-theme').'</a></li><li><a href="#">'.esc_html__('Updates','orbital-service-theme').'</a></li></ul></li></ul>';
}
function ost_default_service_menu() {
    echo '<ul id="ost-service-menu" class="ost-service-menu"><li><a href="#overview">'.esc_html__('Overview','orbital-service-theme').'</a></li><li><a href="#crew">'.esc_html__('Crew','orbital-service-theme').'</a></li><li><a href="#launch">'.esc_html__('Launch','orbital-service-theme').'</a></li><li><a href="#systems">'.esc_html__('Systems','orbital-service-theme').'</a></li><li><a href="#updates">'.esc_html__('Updates','orbital-service-theme').'</a></li></ul>';
}

/* v1.0.48: search load-more now hides multisite site headings/groups until their own content is visible. */
function ost_search_target_names() {
    return array('post', 'posts', 'blog', 'blogs', 'live blog', 'live blogs', 'live-blog', 'live-blogs', 'live_blog', 'live_blogs', 'liveblog', 'liveblogs');
}

function ost_normalize_search_cpt_name($value) {
    $value = strtolower(wp_strip_all_tags((string) $value));
    $value = str_replace(array('_', '-'), ' ', $value);
    $value = preg_replace('/[^a-z0-9 ]+/', ' ', $value);
    $value = preg_replace('/\s+/', ' ', $value);
    return trim($value);
}

function ost_compact_search_cpt_name($value) {
    return preg_replace('/\s+/', '', ost_normalize_search_cpt_name($value));
}

function ost_search_cpt_matches_required_names($slug, $object = null) {
    $slug = sanitize_key($slug);
    if ($slug === '' || in_array($slug, ost_search_excluded_post_type_slugs(), true)) { return false; }

    /* Pages are now part of the tabbed search for single site and multisite. */
    if ($slug === 'page') { return true; }

    /* Always keep the original listener group working. */
    if ($slug && ost_post_type_matches_service_blog_names($slug)) { return true; }

    $targets = array_map('ost_normalize_search_cpt_name', ost_search_target_names());
    $compact_targets = array_map('ost_compact_search_cpt_name', ost_search_target_names());
    $checks = array($slug);

    if ($object) {
        $checks[] = isset($object->name) ? $object->name : '';
        $checks[] = isset($object->label) ? $object->label : '';
        $checks[] = isset($object->labels->name) ? $object->labels->name : '';
        $checks[] = isset($object->labels->singular_name) ? $object->labels->singular_name : '';
        $checks[] = isset($object->labels->menu_name) ? $object->labels->menu_name : '';
        $checks[] = isset($object->labels->all_items) ? $object->labels->all_items : '';
        $checks[] = isset($object->rewrite['slug']) ? $object->rewrite['slug'] : '';
        $checks[] = isset($object->rest_base) ? $object->rest_base : '';
        if (!empty($object->has_archive) && is_string($object->has_archive)) { $checks[] = $object->has_archive; }
    }

    foreach (array_filter(array_unique($checks)) as $check) {
        $normalized = ost_normalize_search_cpt_name($check);
        $compact = ost_compact_search_cpt_name($check);
        $singular = rtrim($normalized, 's');
        $compact_singular = rtrim($compact, 's');
        if ($normalized === '') { continue; }
        if (in_array($normalized, $targets, true) || in_array($compact, $compact_targets, true)) { return true; }
        if (in_array($singular, $targets, true) || in_array($compact_singular, $compact_targets, true)) { return true; }
        if (strpos($normalized, 'blog') !== false || strpos($normalized, 'live post') !== false || strpos($normalized, 'live blog') !== false) { return true; }
    }

    /* New behaviour: also listen to plugin/theme registered public CPTs on every site.
       This catches CPT UI/plugin slugs like cv, portfolio, projects, case-studies, etc. */
    if ($object) {
        $is_builtin = !empty($object->_builtin);
        $is_public_like = !empty($object->public) || !empty($object->publicly_queryable) || !empty($object->show_ui);
        if (!$is_builtin && $is_public_like) { return true; }
        if ($slug === 'post') { return true; }
    }

    /* If content exists in the posts table for an unregistered plugin CPT, show it too.
       This protects multisite cases where a CPT is registered by a plugin only on one subsite. */
    if ($object === null && $slug !== 'page') { return true; }

    return false;
}

function ost_search_post_type_group($post_type, $object = null) {
    $checks = array($post_type);
    if ($object) {
        $checks[] = isset($object->name) ? $object->name : '';
        $checks[] = isset($object->label) ? $object->label : '';
        $checks[] = isset($object->labels->name) ? $object->labels->name : '';
        $checks[] = isset($object->labels->singular_name) ? $object->labels->singular_name : '';
        $checks[] = isset($object->labels->menu_name) ? $object->labels->menu_name : '';
        $checks[] = isset($object->rewrite['slug']) ? $object->rewrite['slug'] : '';
        $checks[] = isset($object->rest_base) ? $object->rest_base : '';
    }

    $combined = ost_normalize_search_cpt_name(implode(' ', array_filter($checks)));
    $compact  = ost_compact_search_cpt_name($combined);

    if (sanitize_key($post_type) === 'page' || preg_match('/(^| )pages?( |$)/', $combined)) {
        return array('key' => 'pages', 'label' => __('Pages', 'orbital-service-theme'));
    }

    if (strpos($combined, 'live blog') !== false || strpos($compact, 'liveblog') !== false) {
        return array('key' => 'live_blog', 'label' => __('Live Blog', 'orbital-service-theme'));
    }

    if (preg_match('/(^| )blogs?( |$)/', $combined) || strpos($combined, 'blog') !== false) {
        return array('key' => 'blog', 'label' => __('Blog', 'orbital-service-theme'));
    }

    if (preg_match('/(^| )posts?( |$)/', $combined) || in_array(sanitize_key($post_type), array('post', 'posts'), true)) {
        return array('key' => 'posts', 'label' => __('Posts', 'orbital-service-theme'));
    }

    $fallback_label = ($object && !empty($object->labels->name)) ? $object->labels->name : ucwords(str_replace(array('-', '_'), ' ', $post_type));
    $fallback_slug_label = ost_normalize_search_cpt_name($fallback_label);
    $fallback_slug_type  = ost_normalize_search_cpt_name($post_type);
    $fallback_base = $fallback_slug_label !== '' ? $fallback_slug_label : $fallback_slug_type;
    if (strlen($fallback_base) > 3 && substr($fallback_base, -1) === 's') {
        $fallback_base = rtrim($fallback_base, 's');
    }
    $fallback_key = sanitize_key(str_replace(' ', '_', $fallback_base));
    return array('key' => $fallback_key ? $fallback_key : sanitize_key($post_type), 'label' => $fallback_label);
}

function ost_search_post_type_key($post_type, $object = null) {
    $group = ost_search_post_type_group($post_type, $object);
    return $group['key'];
}

function ost_search_requested_scope() {
    $scope = isset($_GET['ost_scope']) ? sanitize_key(wp_unslash($_GET['ost_scope'])) : '';
    if (!in_array($scope, array('single', 'multi', 'site'), true)) { $scope = is_multisite() ? 'multi' : 'single'; }
    if (!is_multisite()) { $scope = 'single'; }
    if ($scope === 'site') {
        $site_id = isset($_GET['ost_site']) ? absint(wp_unslash($_GET['ost_site'])) : 0;
        if (!$site_id) { $scope = 'single'; }
    }
    return $scope;
}

function ost_search_force_native_query_post_types($query) {
    if (is_admin() || !$query->is_main_query() || !$query->is_search()) { return; }
    $types = array_keys(ost_searchable_post_types_for_current_site());
    if (!empty($types)) {
        $query->set('post_type', $types);
        $query->set('post_status', 'publish');
        $query->set('ignore_sticky_posts', true);
    }
}
add_action('pre_get_posts', 'ost_search_force_native_query_post_types', 20);

function ost_search_requested_site_id() {
    $site_id = isset($_GET['ost_site']) ? absint(wp_unslash($_GET['ost_site'])) : 0;
    if (!$site_id) { return get_current_blog_id(); }
    if (is_multisite() && function_exists('get_sites')) {
        $found = get_sites(array('number'=>1, 'site__in'=>array($site_id), 'archived'=>0, 'deleted'=>0, 'spam'=>0, 'fields'=>'ids'));
        if (!empty($found)) { return $site_id; }
    }
    return get_current_blog_id();
}

function ost_search_available_sites($scope = '') {
    $scope = $scope ? $scope : ost_search_requested_scope();
    if ($scope === 'site') { return array(ost_search_requested_site_id()); }
    if ($scope === 'single' || !is_multisite() || !function_exists('get_sites')) { return array(get_current_blog_id()); }

    $sites = array();
    $network_sites = get_sites(array('number'=>0, 'archived'=>0, 'deleted'=>0, 'spam'=>0));
    foreach ($network_sites as $site) { $sites[] = absint($site->blog_id); }
    if (empty($sites)) { $sites[] = get_current_blog_id(); }
    return array_values(array_unique(array_filter($sites)));
}

function ost_search_all_network_site_ids() {
    if (!is_multisite() || !function_exists('get_sites')) { return array(get_current_blog_id()); }
    $ids = get_sites(array('number'=>0, 'archived'=>0, 'deleted'=>0, 'spam'=>0, 'fields'=>'ids'));
    $ids = is_array($ids) ? array_map('absint', $ids) : array();
    if (empty($ids)) { $ids[] = get_current_blog_id(); }
    return array_values(array_unique(array_filter($ids)));
}

function ost_maybe_switch_to_search_blog($blog_id) {
    $blog_id = absint($blog_id);
    if (is_multisite() && function_exists('switch_to_blog') && $blog_id && $blog_id !== get_current_blog_id()) { switch_to_blog($blog_id); return true; }
    return false;
}
function ost_maybe_restore_search_blog($switched) { if ($switched && function_exists('restore_current_blog')) { restore_current_blog(); } }
function ost_search_site_label($blog_id) { $switched = ost_maybe_switch_to_search_blog($blog_id); $name = trim(wp_strip_all_tags(get_bloginfo('name'))); ost_maybe_restore_search_blog($switched); return $name !== '' ? $name : sprintf(__('Site %d', 'orbital-service-theme'), absint($blog_id)); }

function ost_search_excluded_post_type_slugs() {
    return array(
        'attachment', 'elementor_library', 'e-landing-page', 'wp_template', 'wp_template_part', 'wp_navigation', 'wp_block',
        'acf-field-group', 'acf-field', 'nav_menu_item', 'revision', 'custom_css', 'customize_changeset', 'oembed_cache', 'user_request',
        /* Keep admin/internal/demo CPTs out of the public search tabs. */
        'dashboard', 'dashboards', 'form', 'forms', 'test', 'tests', 'work', 'works'
    );
}

function ost_search_excluded_tab_keys() {
    return array('dashboard', 'dashboards', 'form', 'forms', 'test', 'tests', 'work', 'works');
}

function ost_search_group_is_excluded($group) {
    if (empty($group) || !is_array($group)) { return false; }
    $key = isset($group['key']) ? sanitize_key($group['key']) : '';
    $label = isset($group['label']) ? ost_normalize_search_cpt_name($group['label']) : '';
    $compact_label = ost_compact_search_cpt_name($label);
    $excluded = ost_search_excluded_tab_keys();
    if ($key !== '' && in_array($key, $excluded, true)) { return true; }
    if ($label !== '' && in_array($label, array('dashboard', 'dashboards', 'form', 'forms', 'test', 'tests', 'work', 'works'), true)) { return true; }
    if ($compact_label !== '' && in_array($compact_label, array('dashboard', 'dashboards', 'form', 'forms', 'test', 'tests', 'work', 'works'), true)) { return true; }
    return false;
}

function ost_search_distinct_post_type_slugs_current_site() {
    global $wpdb;
    $slugs = array();
    if (!isset($wpdb->posts)) { return $slugs; }
    $results = $wpdb->get_col("SELECT DISTINCT post_type FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type <> '' ORDER BY post_type ASC");
    if (is_array($results)) {
        foreach ($results as $slug) {
            $slug = sanitize_key($slug);
            if ($slug !== '') { $slugs[] = $slug; }
        }
    }
    return array_values(array_unique($slugs));
}

function ost_searchable_post_types_for_current_site() {
    $registered = get_post_types(array(), 'objects');
    $registered_public = get_post_types(array('public' => true), 'objects');
    $candidate_slugs = array_unique(array_merge(array_keys($registered_public), ost_search_distinct_post_type_slugs_current_site()));
    $matched = array();

    foreach ($candidate_slugs as $slug) {
        $slug = sanitize_key($slug);
        if ($slug === '' || in_array($slug, ost_search_excluded_post_type_slugs(), true)) { continue; }
        $object = isset($registered[$slug]) ? $registered[$slug] : null;

        /* Match the real registered key/slug first. This catches CPT UI slugs like the screenshot: blog. */
        if (!ost_search_cpt_matches_required_names($slug, $object)) { continue; }
        $matched[$slug] = $object;
    }

    return $matched;
}

function ost_search_collect_network_post_types($scope = '') {
    $collected = array();
    foreach (ost_search_available_sites($scope) as $blog_id) {
        $switched = ost_maybe_switch_to_search_blog($blog_id);
        $site_label = trim(wp_strip_all_tags(get_bloginfo('name')));
        if ($site_label === '') { $site_label = sprintf(__('Site %d', 'orbital-service-theme'), absint($blog_id)); }
        foreach (ost_searchable_post_types_for_current_site() as $post_type => $object) {
            $group = ost_search_post_type_group($post_type, $object);
            if (ost_search_group_is_excluded($group)) { continue; }
            $key = $group['key'];
            $label = $group['label'];
            if (!isset($collected[$key])) {
                $collected[$key] = array('label'=>$label, 'sites'=>array());
            }
            if (!isset($collected[$key]['sites'][absint($blog_id)])) {
                $collected[$key]['sites'][absint($blog_id)] = array('post_types'=>array(), 'site_label'=>$site_label, 'labels'=>array());
            }
            $collected[$key]['sites'][absint($blog_id)]['post_types'][] = $post_type;
            $collected[$key]['sites'][absint($blog_id)]['post_types'] = array_values(array_unique($collected[$key]['sites'][absint($blog_id)]['post_types']));
            $source_label = ($object && !empty($object->labels->name)) ? $object->labels->name : ucwords(str_replace(array('-', '_'), ' ', $post_type));
            $collected[$key]['sites'][absint($blog_id)]['labels'][] = $source_label;
            $collected[$key]['sites'][absint($blog_id)]['labels'] = array_values(array_unique($collected[$key]['sites'][absint($blog_id)]['labels']));
        }
        ost_maybe_restore_search_blog($switched);
    }
    $order = array('pages' => 5, 'blog' => 10, 'live_blog' => 20, 'posts' => 30);
    uasort($collected, function($a, $b) use ($order) {
        $ak = array_search($a['label'], array(__('Pages', 'orbital-service-theme'), __('Blog', 'orbital-service-theme'), __('Live Blog', 'orbital-service-theme'), __('Posts', 'orbital-service-theme')), true);
        $bk = array_search($b['label'], array(__('Pages', 'orbital-service-theme'), __('Blog', 'orbital-service-theme'), __('Live Blog', 'orbital-service-theme'), __('Posts', 'orbital-service-theme')), true);
        if ($ak !== false || $bk !== false) { return (int) $ak - (int) $bk; }
        return strcasecmp($a['label'], $b['label']);
    });
    return $collected;
}

function ost_search_item_description($post_id) {
    $excerpt = trim(wp_strip_all_tags(get_the_excerpt($post_id)));
    if ($excerpt !== '') { return $excerpt; }
    $post = get_post($post_id);
    if (!$post) { return ''; }
    $content = trim(wp_strip_all_tags(strip_shortcodes($post->post_content)));
    return $content === '' ? '' : wp_trim_words($content, 34, '…');
}
function ost_search_item_type_label($post_id) { $type = get_post_type($post_id); $object = $type ? get_post_type_object($type) : null; return ($object && !empty($object->labels->singular_name)) ? $object->labels->singular_name : ($type ? ucwords(str_replace(array('-', '_'), ' ', $type)) : __('Content', 'orbital-service-theme')); }

function ost_search_item_permalink($post_id) {
    $type = get_post_type($post_id);
    if ($type && get_post_type_object($type)) { return get_permalink($post_id); }
    return add_query_arg(array('p' => absint($post_id), 'post_type' => $type), home_url('/'));
}

function ost_render_search_result_item($post_id, $site_label = '') {
    $title = get_the_title($post_id); if ($title === '') { $title = __('Untitled', 'orbital-service-theme'); }
    $description = ost_search_item_description($post_id); $permalink = ost_search_item_permalink($post_id); ?>
    <article id="post-<?php echo esc_attr($post_id); ?>" <?php post_class('ost-search-result-item', $post_id); ?> data-ost-load-item>
      <h2 class="ost-search-result-title"><a href="<?php echo esc_url($permalink); ?>"><?php echo esc_html($title); ?></a></h2>
      <div class="ost-search-result-meta">
        <?php $meta_bits = array(); $meta_bits[] = sprintf('%1$s %2$s', esc_html(get_the_date('', $post_id)), esc_html(get_the_time('', $post_id))); $meta_bits[] = esc_html(ost_search_item_type_label($post_id)); if ($site_label !== '') { $meta_bits[] = esc_html($site_label); } echo wp_kses_post(implode(' <span aria-hidden="true">|</span> ', $meta_bits)); ?>
      </div>
      <?php if ($description !== '') : ?><p class="ost-search-result-description"><?php echo esc_html($description); ?></p><?php endif; ?>
    </article><?php
}

function ost_search_count_for_site_type($search_query, $blog_id, $site_type_data) {
    $search_query = trim((string) $search_query);
    $switched = ost_maybe_switch_to_search_blog($blog_id);
    $args = array('post_type'=>array_values(array_unique((array) $site_type_data['post_types'])), 'post_status'=>'publish', 'posts_per_page'=>1, 'fields'=>'ids', 'ignore_sticky_posts'=>true);
    if ($search_query !== '') { $args['s'] = $search_query; }
    $query = new WP_Query($args);
    $count = absint($query->found_posts);
    wp_reset_postdata();
    ost_maybe_restore_search_blog($switched);
    return $count;
}

function ost_search_count_for_collected_type($search_query, $type_data) {
    $count = 0;
    foreach ($type_data['sites'] as $blog_id => $site_type_data) {
        $count += ost_search_count_for_site_type($search_query, $blog_id, $site_type_data);
    }
    return $count;
}

function ost_search_filter_empty_sites_for_type($search_query, $type_data) {
    if (empty($type_data['sites']) || !is_array($type_data['sites'])) { return $type_data; }
    foreach ($type_data['sites'] as $blog_id => $site_type_data) {
        $site_count = ost_search_count_for_site_type($search_query, $blog_id, $site_type_data);
        if ($site_count < 1) {
            unset($type_data['sites'][$blog_id]);
            continue;
        }
        $type_data['sites'][$blog_id]['count'] = $site_count;
    }
    return $type_data;
}

function ost_render_search_post_type_panel($search_query, $type_key, $type_data, $index, $scope = '') {
    $panel_id = 'ost-search-tab-panel-' . sanitize_html_class($type_key); $found_for_type = false; $search_query = trim((string) $search_query); ?>
    <section id="<?php echo esc_attr($panel_id); ?>" class="ost-search-tab-panel<?php echo $index === 0 ? ' is-active' : ''; ?>" role="tabpanel" data-ost-search-panel="<?php echo esc_attr($type_key); ?>" <?php echo $index === 0 ? '' : 'hidden'; ?>>
      <h2 class="ost-search-tab-heading"><?php echo esc_html($type_data['label']); ?></h2>
      <?php foreach ($type_data['sites'] as $blog_id => $site_type_data) {
          $switched = ost_maybe_switch_to_search_blog($blog_id);
          $args = array('post_type'=>array_values(array_unique((array) $site_type_data['post_types'])), 'post_status'=>'publish', 'posts_per_page'=>-1, 'ignore_sticky_posts'=>true, 'orderby'=>'date', 'order'=>'DESC');
          if ($search_query !== '') { $args['s'] = $search_query; }
          $query = new WP_Query($args);
          if ($query->have_posts()) {
              $found_for_type = true;
              echo '<div class="ost-search-site-group" data-ost-site-group>';
              if (is_multisite() && $scope !== 'single') { echo '<h3 class="ost-search-site-heading">' . esc_html($site_type_data['site_label']) . '</h3>'; }
              while ($query->have_posts()) { $query->the_post(); ost_render_search_result_item(get_the_ID(), (is_multisite() && $scope !== 'single') ? $site_type_data['site_label'] : ''); }
              echo '</div>';
          }
          wp_reset_postdata(); ost_maybe_restore_search_blog($switched);
      }
      if (!$found_for_type) { echo '<p class="ost-search-empty">' . esc_html__('No content found in this tab.', 'orbital-service-theme') . '</p>'; }
      if ($found_for_type) : ?>
        <div class="ost-search-load-more-wrap" data-ost-load-more-wrap hidden>
          <button type="button" class="ost-search-load-more" data-ost-load-more><?php esc_html_e('Load more', 'orbital-service-theme'); ?></button>
        </div>
      <?php endif; ?>
    </section><?php
}

function ost_render_theme_search_results($search_query) {
    $scope = ost_search_requested_scope();
    $post_types = ost_search_collect_network_post_types($scope);
    $tabs = array();
    foreach ($post_types as $type_key => $type_data) {
        if (ost_search_group_is_excluded(array('key'=>$type_key, 'label'=>isset($type_data['label']) ? $type_data['label'] : ''))) { continue; }
        $type_data = ost_search_filter_empty_sites_for_type($search_query, $type_data);
        $count = ost_search_count_for_collected_type($search_query, $type_data);
        if ($count > 0 && !empty($type_data['sites'])) { $type_data['count'] = $count; $tabs[$type_key] = $type_data; }
    }
    if (empty($tabs)) { echo '<p class="ost-search-empty">' . esc_html__('No searchable post types or pages or plugin CPT content was found for this search scope.', 'orbital-service-theme') . '</p>'; return; } ?>
    <div class="ost-search-tabs" data-ost-search-tabs>
      <div class="ost-search-tab-list" role="tablist" aria-label="<?php esc_attr_e('Search result content types', 'orbital-service-theme'); ?>">
        <?php $tab_index = 0; foreach ($tabs as $type_key => $tab) : $tab_id = 'ost-search-tab-' . sanitize_html_class($type_key); $panel_id = 'ost-search-tab-panel-' . sanitize_html_class($type_key); ?>
          <button id="<?php echo esc_attr($tab_id); ?>" class="ost-search-tab<?php echo $tab_index === 0 ? ' is-active' : ''; ?>" type="button" role="tab" aria-selected="<?php echo $tab_index === 0 ? 'true' : 'false'; ?>" aria-controls="<?php echo esc_attr($panel_id); ?>" data-ost-search-tab="<?php echo esc_attr($type_key); ?>">
            <span><?php echo esc_html($tab['label']); ?></span><strong><?php echo esc_html(number_format_i18n($tab['count'])); ?></strong>
          </button>
        <?php $tab_index++; endforeach; ?>
      </div>
      <div class="ost-search-tab-panels">
        <?php $panel_index = 0; foreach ($tabs as $type_key => $tab) : ost_render_search_post_type_panel($search_query, $type_key, $tab, $panel_index, $scope); $panel_index++; endforeach; ?>
      </div>
    </div><?php
}


function ost_current_search_page_url() {
    $scheme = is_ssl() ? 'https://' : 'http://';
    $host   = isset($_SERVER['HTTP_HOST']) ? wp_unslash($_SERVER['HTTP_HOST']) : '';
    $uri    = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '';

    if ($host && $uri) {
        $path = strtok($uri, '?');
        if (!$path) {
            $path = '/';
        }
        return esc_url_raw($scheme . $host . $path);
    }

    return esc_url_raw(get_search_link());
}

function ost_search_reset_url() {
    /*
     * v1.0.59: Reset clears the search box and triggers the search form submit button.
     * It keeps the selected All Sites / individual site scope and removes the typed search query.
     */
    $base_url = ost_current_search_page_url();
    $args = array();
    $scope = ost_search_requested_scope();

    if ($scope === 'multi') {
        $args['ost_scope'] = 'multi';
    } elseif ($scope === 'site') {
        $args['ost_scope'] = 'site';
        $args['ost_site']  = ost_search_requested_site_id();
    }

    return esc_url_raw(empty($args) ? $base_url : add_query_arg($args, $base_url));
}

function ost_network_main_site_url($path = '/') {
    $path = '/' . ltrim((string) $path, '/');

    if (is_multisite() && function_exists('get_main_site_id')) {
        return esc_url_raw(get_site_url(get_main_site_id(), $path));
    }

    return esc_url_raw(home_url($path));
}

function ost_main_search_button_url() {
    /*
     * v1.0.76: Header Search must always go back to the main site search.
     * This keeps subsite headers pointing to https://connormoizer.com/?s
     * instead of /3/?s or any subsite search URL.
     */
    return esc_url_raw(ost_network_main_site_url('/?s'));
}

function ost_global_404_home_url() {
    return esc_url_raw(ost_network_main_site_url('/'));
}

function ost_global_404_search_url() {
    return esc_url_raw(ost_network_main_site_url('/'));
}

function ost_current_broken_url() {
    $scheme = is_ssl() ? 'https://' : 'http://';
    $host = isset($_SERVER['HTTP_HOST']) ? wp_unslash($_SERVER['HTTP_HOST']) : '';
    $uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '';

    if ($host && $uri) {
        return esc_url_raw($scheme . $host . $uri);
    }

    return '';
}

function ost_render_search_scope_controls($search_query = '') {
    if (!is_multisite()) { return; }
    $scope = ost_search_requested_scope();
    $active_site = ost_search_requested_site_id();
    $base_url = ost_current_search_page_url(); ?>
    <div class="ost-search-scope-tabs" role="tablist" aria-label="<?php esc_attr_e('Search by site', 'orbital-service-theme'); ?>">
      <a class="ost-search-scope-tab<?php echo $scope === 'multi' ? ' is-active' : ''; ?>" role="tab" href="<?php echo esc_url(add_query_arg(array('s'=>$search_query, 'ost_scope'=>'multi'), $base_url)); ?>"><?php esc_html_e('All sites', 'orbital-service-theme'); ?></a>
      <?php foreach (ost_search_all_network_site_ids() as $blog_id) :
          $label = ost_search_site_label($blog_id);
          $is_active = ($scope === 'site' && absint($active_site) === absint($blog_id)); ?>
          <a class="ost-search-scope-tab<?php echo $is_active ? ' is-active' : ''; ?>" role="tab" href="<?php echo esc_url(add_query_arg(array('s'=>$search_query, 'ost_scope'=>'site', 'ost_site'=>absint($blog_id)), $base_url)); ?>"><?php echo esc_html($label); ?></a>
      <?php endforeach; ?>
      <a class="ost-search-scope-tab ost-search-reset-tab" href="<?php echo esc_url(ost_search_reset_url()); ?>"><?php esc_html_e('Reset', 'orbital-service-theme'); ?></a>
    </div><?php
}

function ost_search_tabs_script() {
    if (!is_search()) { return; }
    ?>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
      var initialItems = 10;
      var stepItems = 10;

      document.querySelectorAll('.ost-search-reset-tab').forEach(function (button) {
        button.addEventListener('click', function (event) {
          event.preventDefault();

          /* v1.0.59: Reset clears the search bar and presses the Search button.
           * This keeps the user on the same search page/scope and lets the form rebuild
           * the tabs with an empty search value instead of doing a browser refresh.
           */
          var searchForm = document.querySelector('.ost-search-main form.search-form') || document.querySelector('form.search-form');

          document.querySelectorAll('.ost-search-main input[name="s"], form.search-form input[name="s"]').forEach(function (input) {
            input.value = '';
          });

          if (searchForm) {
            var submitButton = searchForm.querySelector('button[type="submit"], input[type="submit"]');
            if (searchForm.requestSubmit) {
              searchForm.requestSubmit(submitButton || undefined);
            } else if (submitButton) {
              submitButton.click();
            } else {
              searchForm.submit();
            }
          }
        });
      });

      function setupLoadMore(panel) {
        var items = Array.prototype.slice.call(panel.querySelectorAll('[data-ost-load-item]'));
        var button = panel.querySelector('[data-ost-load-more]');
        var wrap = panel.querySelector('[data-ost-load-more-wrap]');
        if (!button || !wrap || !items.length) { return; }

        function shownCount() {
          return items.filter(function (item) { return !item.hasAttribute('hidden'); }).length;
        }

        function updateSiteGroups() {
          Array.prototype.slice.call(panel.querySelectorAll('[data-ost-site-group]')).forEach(function (group) {
            var groupItems = Array.prototype.slice.call(group.querySelectorAll('[data-ost-load-item]'));
            var hasVisibleItem = groupItems.some(function (item) { return !item.hasAttribute('hidden'); });
            if (hasVisibleItem) {
              group.removeAttribute('hidden');
            } else {
              group.setAttribute('hidden', 'hidden');
            }
          });
        }

        function updateButton() {
          var visible = shownCount();
          updateSiteGroups();
          if (items.length > visible) {
            wrap.removeAttribute('hidden');
            button.textContent = '<?php echo esc_js(__('Load more', 'orbital-service-theme')); ?>' + ' (' + (items.length - visible) + ')';
          } else {
            wrap.setAttribute('hidden', 'hidden');
          }
        }

        items.forEach(function (item, index) {
          if (index >= initialItems) {
            item.setAttribute('hidden', 'hidden');
          } else {
            item.removeAttribute('hidden');
          }
        });

        button.addEventListener('click', function () {
          var visible = shownCount();
          items.slice(visible, visible + stepItems).forEach(function (item) {
            item.removeAttribute('hidden');
          });
          updateButton();
        });

        updateButton();
      }

      document.querySelectorAll('[data-ost-search-panel]').forEach(setupLoadMore);

      document.querySelectorAll('[data-ost-search-tabs]').forEach(function (wrap) {
        var tabs = Array.prototype.slice.call(wrap.querySelectorAll('[data-ost-search-tab]'));
        var panels = Array.prototype.slice.call(wrap.querySelectorAll('[data-ost-search-panel]'));
        tabs.forEach(function (tab) {
          tab.addEventListener('click', function () {
            var target = tab.getAttribute('data-ost-search-tab');
            tabs.forEach(function (item) {
              var active = item === tab;
              item.classList.toggle('is-active', active);
              item.setAttribute('aria-selected', active ? 'true' : 'false');
            });
            panels.forEach(function (panel) {
              var active = panel.getAttribute('data-ost-search-panel') === target;
              panel.classList.toggle('is-active', active);
              if (active) {
                panel.removeAttribute('hidden');
              } else {
                panel.setAttribute('hidden', 'hidden');
              }
            });
          });
        });
      });
    });
    </script>
    <?php
}
add_action('wp_footer', 'ost_search_tabs_script', 20);


/**
 * v1.0.75: Multisite menu sync on normal Save/Update with source-site links.
 *
 * No extra sync button is shown. When the menu assigned to the Global header
 * menu location is saved/updated in Appearance > Menus, this theme copies it to
 * every public sub site and assigns it to the same Global header menu location. Synced items are stored as custom absolute links so they keep pointing to the site they came from and do not turn red/invalid on target subsites.
 */
function ost_get_primary_menu_id_for_blog($blog_id = 0) {
    $blog_id = absint($blog_id ? $blog_id : get_current_blog_id());

    if (is_multisite() && $blog_id !== get_current_blog_id()) {
        switch_to_blog($blog_id);
        $locations = get_nav_menu_locations();
        $menu_id = isset($locations['primary']) ? absint($locations['primary']) : 0;
        restore_current_blog();
        return $menu_id;
    }

    $locations = get_nav_menu_locations();
    return isset($locations['primary']) ? absint($locations['primary']) : 0;
}

function ost_mark_menu_as_network_global_header($menu_id) {
    $menu_id = absint($menu_id);
    if ($menu_id && function_exists('update_term_meta')) {
        update_term_meta($menu_id, '_ost_network_global_header_menu', '1');
    }
}

function ost_is_network_global_header_menu($menu_id) {
    $menu_id = absint($menu_id);
    if (!$menu_id) {
        return false;
    }

    $primary_menu_id = ost_get_primary_menu_id_for_blog(get_current_blog_id());
    if ($primary_menu_id && $menu_id === $primary_menu_id) {
        return true;
    }

    if (function_exists('get_term_meta') && get_term_meta($menu_id, '_ost_network_global_header_menu', true) === '1') {
        return true;
    }

    return false;
}

function ost_force_primary_menu_location($menu_id) {
    $menu_id = absint($menu_id);
    if (!$menu_id) {
        return;
    }

    /*
     * v1.2.0: The Global header menu tick/assignment is part of the sync.
     * Preserve service/mission and footer menu locations, but always assign
     * the synced menu to the primary Global header location on the active site.
     */
    $locations = get_nav_menu_locations();
    if (!is_array($locations)) {
        $locations = array();
    }
    $locations['primary'] = $menu_id;
    set_theme_mod('nav_menu_locations', $locations);
}

function ost_schedule_network_header_menu_sync($menu_id) {
    if (!is_multisite() || !current_user_can('manage_options')) {
        return;
    }

    $menu_id = absint($menu_id);
    if (!$menu_id) {
        return;
    }

    $GLOBALS['ost_network_header_menu_sync_scheduled'] = array(
        'blog_id' => get_current_blog_id(),
        'menu_id' => $menu_id,
    );
}

function ost_run_scheduled_network_header_menu_sync() {
    if (empty($GLOBALS['ost_network_header_menu_sync_scheduled']) || !is_multisite() || !current_user_can('manage_options')) {
        return;
    }

    $scheduled = $GLOBALS['ost_network_header_menu_sync_scheduled'];
    $menu_id = isset($scheduled['menu_id']) ? absint($scheduled['menu_id']) : 0;
    $blog_id = isset($scheduled['blog_id']) ? absint($scheduled['blog_id']) : get_current_blog_id();

    if (!$menu_id || !ost_is_network_global_header_menu($menu_id)) {
        return;
    }

    ost_mark_menu_as_network_global_header($menu_id);
    $result = ost_sync_primary_menu_to_all_sites($blog_id, $menu_id, true);
    set_transient('ost_menu_auto_sync_notice_' . get_current_user_id(), $result, MINUTE_IN_SECONDS * 5);
}
add_action('shutdown', 'ost_run_scheduled_network_header_menu_sync', 99);

function ost_get_menu_item_setting_value($item, $key, $default = '') {
    return isset($item->$key) ? $item->$key : $default;
}

function ost_normalise_synced_menu_url($url, $source_home_url = '') {
    $url = trim((string) $url);

    if ($url === '') {
        return '#';
    }

    if (strpos($url, '#') === 0) {
        return $url;
    }

    if (strpos($url, '//') === 0) {
        return is_ssl() ? 'https:' . $url : 'http:' . $url;
    }

    if (preg_match('#^[a-z][a-z0-9+.-]*:#i', $url)) {
        return $url;
    }

    if (strpos($url, '/') === 0 && $source_home_url) {
        return trailingslashit($source_home_url) . ltrim($url, '/');
    }

    return $url;
}

function ost_copy_single_menu_item($target_menu_id, $source_item, $new_parent_id = 0, $source_home_url = '') {
    $classes = ost_get_menu_item_setting_value($source_item, 'classes', array());
    if (is_array($classes)) {
        $classes = implode(' ', array_filter($classes));
    }

    $classes = trim($classes . ' ost-synced-network-link');
    $source_url = ost_normalise_synced_menu_url(ost_get_menu_item_setting_value($source_item, 'url', ''), $source_home_url);

    /*
     * Sync everything as a custom absolute link.
     * This keeps links pointing back to the site they came from and prevents
     * copied Page/Post/CPT menu items turning red/invalid on other subsites
     * where the original object ID does not exist.
     */
    $args = array(
        'menu-item-db-id'       => 0,
        'menu-item-object-id'   => 0,
        'menu-item-object'      => 'custom',
        'menu-item-parent-id'   => absint($new_parent_id),
        'menu-item-position'    => absint(ost_get_menu_item_setting_value($source_item, 'menu_order', 0)),
        'menu-item-type'        => 'custom',
        'menu-item-title'       => wp_strip_all_tags(ost_get_menu_item_setting_value($source_item, 'title', '')),
        'menu-item-url'         => esc_url_raw($source_url),
        'menu-item-description' => wp_strip_all_tags(ost_get_menu_item_setting_value($source_item, 'description', '')),
        'menu-item-attr-title'  => wp_strip_all_tags(ost_get_menu_item_setting_value($source_item, 'attr_title', '')),
        'menu-item-target'      => sanitize_text_field(ost_get_menu_item_setting_value($source_item, 'target', '')),
        'menu-item-classes'     => sanitize_text_field($classes),
        'menu-item-xfn'         => sanitize_text_field(ost_get_menu_item_setting_value($source_item, 'xfn', '')),
        'menu-item-status'      => 'publish',
    );

    return wp_update_nav_menu_item($target_menu_id, 0, $args);
}

function ost_copy_primary_menu_to_blog($source_menu_name, $source_items, $replace_existing = true, $source_home_url = '') {
    $target_menu_name = $source_menu_name ? $source_menu_name : __('Global Header Menu', 'orbital-service-theme');
    $existing = wp_get_nav_menu_object($target_menu_name);

    if ($existing && $replace_existing) {
        wp_delete_nav_menu($existing->term_id);
        $existing = false;
    }

    if ($existing) {
        $target_menu_id = absint($existing->term_id);
    } else {
        $created = wp_create_nav_menu($target_menu_name);
        if (is_wp_error($created)) {
            return $created;
        }
        $target_menu_id = absint($created);
    }

    $id_map = array();
    $remaining = $source_items;
    $safety = 0;

    while (!empty($remaining) && $safety < 20) {
        $safety++;
        foreach ($remaining as $index => $item) {
            $old_parent = absint($item->menu_item_parent);
            if ($old_parent && empty($id_map[$old_parent])) {
                continue;
            }

            $new_parent = $old_parent && !empty($id_map[$old_parent]) ? absint($id_map[$old_parent]) : 0;
            $new_item_id = ost_copy_single_menu_item($target_menu_id, $item, $new_parent, $source_home_url);
            if (is_wp_error($new_item_id)) {
                return $new_item_id;
            }

            $id_map[absint($item->ID)] = absint($new_item_id);
            unset($remaining[$index]);
        }
    }

    ost_mark_menu_as_network_global_header($target_menu_id);
    ost_force_primary_menu_location($target_menu_id);

    return $target_menu_id;
}

function ost_sync_primary_menu_to_all_sites($source_blog_id = 0, $source_menu_id = 0, $replace_existing = true) {
    static $running = false;

    if ($running || !is_multisite() || !current_user_can('manage_options')) {
        return array('synced' => 0, 'failed' => 0, 'empty' => false);
    }

    $running = true;
    $source_blog_id = absint($source_blog_id ? $source_blog_id : get_current_blog_id());
    $source_menu_id = absint($source_menu_id ? $source_menu_id : ost_get_primary_menu_id_for_blog($source_blog_id));

    switch_to_blog($source_blog_id);
    $source_menu = $source_menu_id ? wp_get_nav_menu_object($source_menu_id) : false;
    if ($source_menu_id) {
        ost_mark_menu_as_network_global_header($source_menu_id);
        ost_force_primary_menu_location($source_menu_id);
    }
    $source_menu_name = $source_menu ? $source_menu->name : __('Global Header Menu', 'orbital-service-theme');
    $source_items = $source_menu_id ? wp_get_nav_menu_items($source_menu_id, array('post_status' => 'publish')) : array();
    $source_home_url = home_url('/');
    restore_current_blog();

    if (empty($source_items)) {
        $running = false;
        return array('synced' => 0, 'failed' => 0, 'empty' => true);
    }

    $sites = get_sites(array(
        'number'   => 0,
        'public'   => 1,
        'archived' => 0,
        'deleted'  => 0,
        'spam'     => 0,
    ));

    $synced = 0;
    $failed = 0;

    foreach ($sites as $site) {
        $blog_id = absint($site->blog_id);
        if ($blog_id === $source_blog_id) {
            continue;
        }

        switch_to_blog($blog_id);
        $result = ost_copy_primary_menu_to_blog($source_menu_name, $source_items, $replace_existing, $source_home_url);
        if (is_wp_error($result)) {
            $failed++;
        } else {
            $synced++;
        }
        restore_current_blog();
    }

    $running = false;
    return array('synced' => $synced, 'failed' => $failed, 'empty' => false);
}

function ost_auto_sync_primary_menu_on_save($menu_id) {
    if (!is_multisite() || !current_user_can('manage_options')) {
        return;
    }

    $menu_id = absint($menu_id);

    /*
     * Schedule this for shutdown rather than syncing immediately. WordPress can
     * fire menu hooks before every item edit, drag/drop order, URL change and
     * location tick has fully finished saving. Running at shutdown makes any
     * site in the network a valid source and syncs the final rendered menu to
     * every other site.
     */
    if (ost_is_network_global_header_menu($menu_id)) {
        ost_schedule_network_header_menu_sync($menu_id);
    }
}
add_action('wp_update_nav_menu', 'ost_auto_sync_primary_menu_on_save', 20, 1);


/**
 * v1.0.82: Also sync when the Global header menu location checkbox is ticked.
 * v1.0.83: Fix multisite content menu picker so WordPress Add to Menu sees the active tab.
 * v1.0.84: Two-way global header menu sync from any multisite after menu edits fully save.
 * v1.0.85: Front-end Customizer menu edits now trigger the same network sync.
 *
 * WordPress can save a menu and assign it to a location in the same request. The
 * wp_update_nav_menu hook can fire before that new location assignment is stored,
 * so this option hook catches the final saved nav_menu_locations theme mod and
 * syncs the newly selected Global header menu to the whole multisite network.
 */
function ost_auto_sync_primary_menu_on_location_change($old_value, $value, $option_name) {
    if (!is_multisite() || !is_admin() || !current_user_can('manage_options')) {
        return;
    }

    $old_locations = (is_array($old_value) && isset($old_value['nav_menu_locations']) && is_array($old_value['nav_menu_locations'])) ? $old_value['nav_menu_locations'] : array();
    $new_locations = (is_array($value) && isset($value['nav_menu_locations']) && is_array($value['nav_menu_locations'])) ? $value['nav_menu_locations'] : array();

    $old_primary = isset($old_locations['primary']) ? absint($old_locations['primary']) : 0;
    $new_primary = isset($new_locations['primary']) ? absint($new_locations['primary']) : 0;

    if (!$new_primary || $new_primary === $old_primary) {
        return;
    }

    ost_mark_menu_as_network_global_header($new_primary);
    ost_schedule_network_header_menu_sync($new_primary);
}
add_action('update_option_theme_mods_' . get_option('stylesheet'), 'ost_auto_sync_primary_menu_on_location_change', 20, 3);

function ost_auto_sync_primary_menu_notice() {
    if (!is_admin() || !is_multisite() || !current_user_can('manage_options')) {
        return;
    }

    $key = 'ost_menu_auto_sync_notice_' . get_current_user_id();
    $result = get_transient($key);
    if (!$result || !is_array($result)) {
        return;
    }
    delete_transient($key);

    $synced = isset($result['synced']) ? absint($result['synced']) : 0;
    $failed = isset($result['failed']) ? absint($result['failed']) : 0;
    $empty = !empty($result['empty']);

    if ($empty) {
        printf('<div class="notice notice-error is-dismissible"><p>%s</p></div>', esc_html__('The Global header menu was saved, but it has no published items to sync.', 'orbital-service-theme'));
    } elseif ($failed > 0) {
        printf('<div class="notice notice-warning is-dismissible"><p>%s</p></div>', esc_html(sprintf(__('Global header menu saved and synced to %1$d site(s). %2$d site(s) failed.', 'orbital-service-theme'), $synced, $failed)));
    } else {
        printf('<div class="notice notice-success is-dismissible"><p>%s</p></div>', esc_html(sprintf(__('Global header menu saved and synced to %d site(s).', 'orbital-service-theme'), $synced)));
    }
}
add_action('admin_notices', 'ost_auto_sync_primary_menu_notice');


/**
 * v1.0.85: Customizer menu edits also trigger the multisite global header sync.
 *
 * The front-end Customizer saves menus through the Customizer changeset flow,
 * not only through nav-menus.php. This catches the completed Customizer save,
 * marks the currently assigned Global header menu as network-controlled, and
 * schedules the same final shutdown sync used by Appearance > Menus.
 */
function ost_auto_sync_primary_menu_from_customizer($wp_customize = null) {
    if (!is_multisite() || !current_user_can('manage_options')) {
        return;
    }

    $menu_id = ost_get_primary_menu_id_for_blog(get_current_blog_id());
    if (!$menu_id) {
        return;
    }

    ost_mark_menu_as_network_global_header($menu_id);
    ost_schedule_network_header_menu_sync($menu_id);
}
function ost_sync_widget_network_modes_from_customizer($wp_customize) {
    if (!is_multisite()) {
        return;
    }
    ost_set_cpt_widget_fallback_mode(get_theme_mod('ost_cpt_widget_fallback_mode', ost_get_cpt_widget_fallback_mode()));
    ost_set_auto_related_widget_mode('off');
}
add_action('customize_save_after', 'ost_sync_widget_network_modes_from_customizer', 20, 1);

add_action('customize_save_after', 'ost_auto_sync_primary_menu_from_customizer', 99, 1);

/**
 * Also catch Customizer nav menu item saves directly. Some WordPress versions
 * update menu items inside the nav menu Customizer manager before the wider
 * customize_save_after hook, so scheduling here gives the shutdown sync a valid
 * menu source even when only menu items were changed and no theme mod changed.
 */
function ost_auto_sync_primary_menu_from_customizer_nav_menus($setting = null) {
    if (!is_multisite() || !current_user_can('manage_options')) {
        return;
    }

    $menu_id = ost_get_primary_menu_id_for_blog(get_current_blog_id());
    if ($menu_id && ost_is_network_global_header_menu($menu_id)) {
        ost_schedule_network_header_menu_sync($menu_id);
    }
}
add_action('customize_save_nav_menus_created_posts', 'ost_auto_sync_primary_menu_from_customizer_nav_menus', 99, 1);

/**
 * v1.0.86: Add multisite content to the front-end Customizer menu item picker.
 *
 * This makes Appearance > Customize > Menus > Add Items show the same network
 * content source as the dashboard Menus screen. Items are added as custom
 * absolute links so they render correctly from every subsite, then the existing
 * Customizer global-menu sync copies the saved menu to the whole network.
 */
function ost_customizer_multisite_nav_menu_item_types($item_types) {
    if (!is_multisite() || !current_user_can('manage_options')) {
        return $item_types;
    }

    $item_types[] = array(
        'title'  => __('Multisite Content', 'orbital-service-theme'),
        'type'   => 'custom',
        'object' => 'ost_multisite_content',
    );

    return $item_types;
}
add_filter('customize_nav_menu_available_item_types', 'ost_customizer_multisite_nav_menu_item_types');

function ost_customizer_multisite_nav_menu_available_items($items, $type, $object, $page) {
    if (!is_multisite() || !current_user_can('manage_options') || $type !== 'custom' || $object !== 'ost_multisite_content') {
        return $items;
    }

    if (!function_exists('get_sites')) {
        return $items;
    }

    $page = max(0, absint($page));
    $per_page = 20;
    $offset = $page * $per_page;
    $found = 0;
    $output = array();

    $sites = get_sites(array(
        'number'   => 0,
        'public'   => 1,
        'archived' => 0,
        'deleted'  => 0,
        'spam'     => 0,
    ));

    $types = ost_menu_admin_post_types();

    foreach ($sites as $site) {
        $blog_id = absint($site->blog_id);
        switch_to_blog($blog_id);

        $site_name = get_bloginfo('name');
        $site_name = $site_name ? $site_name : sprintf(__('Site %d', 'orbital-service-theme'), $blog_id);

        foreach ($types as $type_slug => $type_object) {
            if (!post_type_exists($type_slug)) {
                continue;
            }

            $posts = get_posts(array(
                'post_type'      => $type_slug,
                'post_status'    => 'publish',
                'posts_per_page' => 30,
                'orderby'        => 'date',
                'order'          => 'DESC',
                'no_found_rows'  => true,
            ));

            foreach ($posts as $post_item) {
                if ($found++ < $offset) {
                    continue;
                }

                if (count($output) >= $per_page) {
                    break 3;
                }

                $title = get_the_title($post_item);
                if (!$title) {
                    $title = sprintf(__('Untitled %s', 'orbital-service-theme'), $type_object->labels->singular_name);
                }

                $url = get_permalink($post_item);

                $output[] = array(
                    'id'         => 'ost-ms-' . $blog_id . '-' . $type_slug . '-' . absint($post_item->ID),
                    'title'      => sprintf('%1$s — %2$s', wp_strip_all_tags($title), $site_name),
                    'type'       => 'custom',
                    'type_label' => sprintf('%1$s / %2$s', $site_name, $type_object->labels->singular_name),
                    'object'     => 'custom',
                    'object_id'  => 0,
                    'url'        => esc_url_raw($url),
                );
            }
        }

        restore_current_blog();
    }

    return $output;
}
add_filter('customize_nav_menu_available_items', 'ost_customizer_multisite_nav_menu_available_items', 10, 4);

function ost_customizer_multisite_nav_menu_searched_items($items, $args) {
    if (!is_multisite() || !current_user_can('manage_options')) {
        return $items;
    }

    if (empty($args['type']) || empty($args['object']) || $args['type'] !== 'custom' || $args['object'] !== 'ost_multisite_content') {
        return $items;
    }

    if (!function_exists('get_sites')) {
        return $items;
    }

    $search = isset($args['s']) ? sanitize_text_field(wp_unslash($args['s'])) : '';
    if ($search === '') {
        return ost_customizer_multisite_nav_menu_available_items(array(), 'custom', 'ost_multisite_content', 0);
    }

    $output = array();
    $sites = get_sites(array(
        'number'   => 0,
        'public'   => 1,
        'archived' => 0,
        'deleted'  => 0,
        'spam'     => 0,
    ));

    $types = ost_menu_admin_post_types();

    foreach ($sites as $site) {
        $blog_id = absint($site->blog_id);
        switch_to_blog($blog_id);

        $site_name = get_bloginfo('name');
        $site_name = $site_name ? $site_name : sprintf(__('Site %d', 'orbital-service-theme'), $blog_id);

        foreach ($types as $type_slug => $type_object) {
            if (!post_type_exists($type_slug)) {
                continue;
            }

            $posts = get_posts(array(
                'post_type'      => $type_slug,
                'post_status'    => 'publish',
                'posts_per_page' => 20,
                's'              => $search,
                'orderby'        => 'date',
                'order'          => 'DESC',
                'no_found_rows'  => true,
            ));

            foreach ($posts as $post_item) {
                if (count($output) >= 20) {
                    break 3;
                }

                $title = get_the_title($post_item);
                if (!$title) {
                    $title = sprintf(__('Untitled %s', 'orbital-service-theme'), $type_object->labels->singular_name);
                }

                $output[] = array(
                    'id'         => 'ost-ms-search-' . $blog_id . '-' . $type_slug . '-' . absint($post_item->ID),
                    'title'      => sprintf('%1$s — %2$s', wp_strip_all_tags($title), $site_name),
                    'type'       => 'custom',
                    'type_label' => sprintf('%1$s / %2$s', $site_name, $type_object->labels->singular_name),
                    'object'     => 'custom',
                    'object_id'  => 0,
                    'url'        => esc_url_raw(get_permalink($post_item)),
                );
            }
        }

        restore_current_blog();
    }

    return $output;
}
add_filter('customize_nav_menu_searched_items', 'ost_customizer_multisite_nav_menu_searched_items', 10, 2);



/**
 * v1.3.4: Hard-forced automatic Media Library / inserted image alt text under real article images, with frontend JS fallback so alt text shows by default.
 *
 * Priority order: Media Caption, Media Alt Text, Inserted Image Alt Text, Description, Title.
 * Works with Gutenberg image blocks, classic editor images and linked images.
 * Skips emoji, smilies and existing visible captions so it does not duplicate text.
 */
function ost_is_editorial_caption_post_type() {
    if (!is_singular()) {
        return false;
    }

    $post_type = get_post_type();
    $allowed = array('post', 'posts', 'blog', 'blogs', 'news', 'article', 'articles', 'live_blog', 'live-blog', 'liveblogs', 'live_blogs');

    return in_array($post_type, $allowed, true);
}

function ost_get_attachment_editorial_text($attachment_id) {
    $attachment_id = absint($attachment_id);
    if (!$attachment_id) {
        return '';
    }

    $caption = wp_get_attachment_caption($attachment_id);
    if (!empty($caption)) {
        return $caption;
    }

    $alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
    if (!empty($alt)) {
        return $alt;
    }

    $attachment = get_post($attachment_id);
    if ($attachment && !empty($attachment->post_content)) {
        return $attachment->post_content;
    }

    if ($attachment && !empty($attachment->post_title)) {
        return $attachment->post_title;
    }

    return '';
}

function ost_is_real_editorial_img_html($img_html) {
    if (stripos($img_html, '<img') === false) {
        return false;
    }

    if (preg_match('/class=["\'][^"\']*(emoji|wp-smiley|smiley|avatar|custom-logo|site-logo|icon)[^"\']*["\']/i', $img_html)) {
        return false;
    }

    if (preg_match('/\b(width|height)=["\']?(1[0-9]|2[0-9]|3[0-9]|4[0-9])\b/i', $img_html) && !preg_match('/wp-image-|data-attachment-id|data-id/i', $img_html)) {
        return false;
    }

    return true;
}

function ost_attachment_id_from_img_html($img_html) {
    if (!ost_is_real_editorial_img_html($img_html)) {
        return 0;
    }

    if (preg_match('/\bwp-image-(\d+)\b/i', $img_html, $m)) {
        return absint($m[1]);
    }

    if (preg_match('/\bdata-(?:attachment-)?id=["\'](\d+)["\']/i', $img_html, $m)) {
        return absint($m[1]);
    }

    if (preg_match('/\bsrc=["\']([^"\']+)["\']/i', $img_html, $m)) {
        $src = html_entity_decode($m[1], ENT_QUOTES, get_bloginfo('charset'));
        $id = attachment_url_to_postid($src);
        if ($id) {
            return absint($id);
        }

        // WordPress resized filenames often end in -1024x683.ext. Try the original file URL too.
        $clean_src = preg_replace('/-\d+x\d+(?=\.(?:jpe?g|png|gif|webp|avif)\b)/i', '', $src);
        if ($clean_src && $clean_src !== $src) {
            $id = attachment_url_to_postid($clean_src);
            if ($id) {
                return absint($id);
            }
        }
    }

    return 0;
}

function ost_has_existing_image_text($html) {
    if (stripos($html, 'ost-auto-image-caption') !== false) {
        return true;
    }

    if (preg_match('/<figcaption\b[^>]*>(.*?)<\/figcaption>/is', $html, $m)) {
        return trim(wp_strip_all_tags($m[1])) !== '';
    }

    if (preg_match('/class=["\'][^"\']*wp-caption-text[^"\']*["\'][^>]*>(.*?)<\//is', $html, $m)) {
        return trim(wp_strip_all_tags($m[1])) !== '';
    }

    return false;
}

function ost_img_attr_value($img_html, $attr) {
    if (!is_string($img_html) || $img_html === '') {
        return '';
    }

    $attr = preg_quote($attr, '/');
    if (preg_match('/\b' . $attr . '\s*=\s*(["\'])(.*?)\1/is', $img_html, $m)) {
        return trim(wp_strip_all_tags(html_entity_decode($m[2], ENT_QUOTES, get_bloginfo('charset'))));
    }

    return '';
}

function ost_get_editorial_text_from_attachment_or_img($attachment_id = 0, $img_html = '') {
    $attachment_id = absint($attachment_id);

    if ($attachment_id) {
        $caption = wp_get_attachment_caption($attachment_id);
        if (!empty($caption)) {
            return $caption;
        }

        $alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
        if (!empty($alt)) {
            return $alt;
        }
    }

    // This is the hard fallback that fixes the WordPress Image Details modal:
    // sometimes the editor adds alt text to the inserted <img> but does not save it
    // back to the Media Library attachment meta. In that case we still show it.
    $inserted_alt = ost_img_attr_value($img_html, 'alt');
    if ($inserted_alt !== '') {
        return $inserted_alt;
    }

    if ($attachment_id) {
        $attachment = get_post($attachment_id);
        if ($attachment && !empty($attachment->post_content)) {
            return $attachment->post_content;
        }

        if ($attachment && !empty($attachment->post_title)) {
            return $attachment->post_title;
        }
    }

    $inserted_title = ost_img_attr_value($img_html, 'title');
    if ($inserted_title !== '') {
        return $inserted_title;
    }

    return '';
}

function ost_auto_media_caption_html($attachment_id, $tag = 'span', $img_html = '') {
    $text = ost_get_editorial_text_from_attachment_or_img($attachment_id, $img_html);
    if ($text === '') {
        return '';
    }

    $tag = ($tag === 'figcaption') ? 'figcaption' : 'span';
    return '<' . $tag . ' class="ost-auto-image-caption" data-ost-media-text="1">' . wp_kses_post($text) . '</' . $tag . '>';
}

function ost_auto_media_text_render_block($block_content, $block) {
    if (is_admin() || !ost_is_editorial_caption_post_type() || empty($block_content)) {
        return $block_content;
    }

    if (empty($block['blockName']) || $block['blockName'] !== 'core/image') {
        return $block_content;
    }

    if (ost_has_existing_image_text($block_content)) {
        return $block_content;
    }

    $attachment_id = !empty($block['attrs']['id']) ? absint($block['attrs']['id']) : 0;
    if (!$attachment_id) {
        $attachment_id = ost_attachment_id_from_img_html($block_content);
    }

    $caption = ost_auto_media_caption_html($attachment_id, 'figcaption', $block_content);
    if ($caption === '') {
        return $block_content;
    }

    if (preg_match('/<figure\b/i', $block_content)) {
        if (preg_match('/<figcaption\b[^>]*>\s*<\/figcaption>/is', $block_content)) {
            return preg_replace('/<figcaption\b[^>]*>\s*<\/figcaption>/is', $caption, $block_content, 1);
        }
        return preg_replace('/<\/figure>\s*$/i', $caption . '</figure>', $block_content, 1);
    }

    return '<figure class="wp-block-image ost-auto-media-figure">' . $block_content . $caption . '</figure>';
}
add_filter('render_block', 'ost_auto_media_text_render_block', 20, 2);

function ost_auto_media_text_for_content_images($content) {
    if (is_admin() || !ost_is_editorial_caption_post_type() || empty($content)) {
        return $content;
    }

    $protected = array();

    // Handle whole figure blocks first and mask them so plain img logic cannot duplicate captions.
    $content = preg_replace_callback('/<figure\b[^>]*>.*?<\/figure>/is', function ($m) use (&$protected) {
        $figure = $m[0];

        if (ost_has_existing_image_text($figure)) {
            $key = '%%OST_MEDIA_PROTECTED_' . count($protected) . '%%';
            $protected[$key] = $figure;
            return $key;
        }

        if (!preg_match('/<img\b[^>]*>/is', $figure, $img_match)) {
            return $figure;
        }

        $attachment_id = ost_attachment_id_from_img_html($img_match[0]);
        $caption = ost_auto_media_caption_html($attachment_id, 'figcaption', $img_match[0]);

        if ($caption !== '') {
            if (preg_match('/<figcaption\b[^>]*>\s*<\/figcaption>/is', $figure)) {
                $figure = preg_replace('/<figcaption\b[^>]*>\s*<\/figcaption>/is', $caption, $figure, 1);
            } else {
                $figure = preg_replace('/<\/figure>\s*$/i', $caption . '</figure>', $figure, 1);
            }
        }

        $key = '%%OST_MEDIA_PROTECTED_' . count($protected) . '%%';
        $protected[$key] = $figure;
        return $key;
    }, $content);

    // Handle classic editor images and linked images.
    $content = preg_replace_callback('/(<a\b[^>]*>\s*)?<img\b[^>]*>(\s*<\/a>)?/is', function ($m) {
        $full = $m[0];

        if (ost_has_existing_image_text($full) || !ost_is_real_editorial_img_html($full)) {
            return $full;
        }

        $attachment_id = ost_attachment_id_from_img_html($full);
        $caption = ost_auto_media_caption_html($attachment_id, 'span', $full);

        if ($caption === '') {
            return $full;
        }

        return '<span class="ost-auto-media-wrap">' . $full . $caption . '</span>';
    }, $content);

    if (!empty($protected)) {
        $content = strtr($content, $protected);
    }

    return $content;
}
add_filter('the_content', 'ost_auto_media_text_for_content_images', 999);



/**
 * v1.3.4: Frontend hard fallback.
 * If PHP/render_block misses an inserted image, JS reads the real rendered img alt/title
 * and writes it under the image by default. Emoji, smilies, icons, logos and avatars are ignored.
 */
function ost_auto_media_text_frontend_fallback_script() {
    if (is_admin() || !ost_is_editorial_caption_post_type()) {
        return;
    }
    ?>
    <script id="ost-auto-media-text-fallback">
    (function(){
        function isRealImage(img){
            if(!img || !img.tagName || img.tagName.toLowerCase() !== 'img'){ return false; }
            var cls = img.className || '';
            if(/emoji|wp-smiley|smiley|avatar|custom-logo|site-logo|icon/i.test(cls)){ return false; }
            if(!/wp-image-\d+|size-|alignleft|alignright|aligncenter|alignnone/i.test(cls) && !img.closest('figure.wp-block-image,.wp-caption')){ return false; }
            var w = parseInt(img.getAttribute('width') || img.naturalWidth || 0, 10);
            var h = parseInt(img.getAttribute('height') || img.naturalHeight || 0, 10);
            if((w && w < 45) || (h && h < 45)){ return false; }
            return true;
        }
        function hasCaptionAround(img){
            var figure = img.closest('figure,.wp-caption,.ost-auto-media-wrap');
            if(figure && figure.querySelector('figcaption,.wp-caption-text,.ost-auto-image-caption')){
                var cap = figure.querySelector('figcaption,.wp-caption-text,.ost-auto-image-caption');
                if(cap && cap.textContent.trim() !== ''){ return true; }
            }
            var next = img.nextElementSibling;
            if(next && next.classList && next.classList.contains('ost-auto-image-caption') && next.textContent.trim() !== ''){ return true; }
            return false;
        }
        function addCaption(img){
            if(!isRealImage(img) || hasCaptionAround(img)){ return; }
            var text = (img.getAttribute('alt') || img.getAttribute('title') || '').trim();
            if(!text){ return; }
            var cap = document.createElement('span');
            cap.className = 'ost-auto-image-caption ost-auto-image-caption-js';
            cap.setAttribute('data-ost-media-text','1');
            cap.textContent = text;
            var figure = img.closest('figure.wp-block-image,.wp-caption');
            if(figure){
                var emptyCap = figure.querySelector('figcaption:empty,.wp-caption-text:empty');
                if(emptyCap){ emptyCap.replaceWith(cap); }
                else { figure.appendChild(cap); }
            } else {
                var wrapper = img.closest('a') || img;
                wrapper.insertAdjacentElement('afterend', cap);
            }
        }
        function run(){
            document.querySelectorAll('.entry-content img, .ost-main img').forEach(addCaption);
        }
        if(document.readyState === 'loading'){
            document.addEventListener('DOMContentLoaded', run);
        } else {
            run();
        }
        window.addEventListener('load', run);
    })();
    </script>
    <?php
}
add_action('wp_footer', 'ost_auto_media_text_frontend_fallback_script', 99);
