(function () {
    'use strict';

    function initBrowser(browser) {
        if (!browser || browser.dataset.cmgcReady === '1') return;
        browser.dataset.cmgcReady = '1';

        const content = browser.querySelector('.cmgc-content');
        const loading = browser.querySelector('.cmgc-loading');
        const live = browser.querySelector('.cmgc-live-region');
        const branchMenu = browser.querySelector('.cmgc-branch-menu');
        const currentBranch = browser.querySelector('.cmgc-current-branch');
        const endpoint = browser.dataset.endpoint || '';
        let lastLiveRefresh = 0;
        let requestController = null;

        if (!content || !endpoint) return;

        async function browse(path, options) {
            options = options || {};
            const params = new URLSearchParams({
                owner: browser.dataset.owner || '',
                repo: browser.dataset.repo || '',
                branch: browser.dataset.branch || '',
                path: path || '',
                access: browser.dataset.access || 'public',
                signature: browser.dataset.signature || '',
                _cmgc_live: String(Date.now())
            });

            if (requestController) {
                requestController.abort();
            }
            requestController = (typeof AbortController !== 'undefined') ? new AbortController() : null;

            browser.classList.add('is-loading');
            if (loading) loading.hidden = false;
            if (live) live.textContent = 'Loading repository content';

            try {
                const fetchOptions = {
                    method: 'GET',
                    credentials: 'same-origin',
                    cache: 'no-store',
                    headers: {
                        'Accept': 'application/json',
                        'Cache-Control': 'no-cache',
                        'Pragma': 'no-cache'
                    }
                };
                if (requestController) fetchOptions.signal = requestController.signal;

                const response = await fetch(endpoint + '?' + params.toString(), fetchOptions);
                const data = await response.json();
                if (!response.ok) {
                    throw new Error((data && data.message) ? data.message : 'Unable to load GitHub content.');
                }
                content.innerHTML = data.html || '';
                browser.dataset.path = data.path || '';
                if (data.branch) {
                    browser.dataset.branch = data.branch;
                    if (currentBranch) currentBranch.textContent = data.branch;
                }
                lastLiveRefresh = Date.now();
                if (live) live.textContent = 'Repository content updated';
                if (options.scroll !== false) {
                    content.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                }
            } catch (error) {
                if (error && error.name === 'AbortError') return;
                content.innerHTML = '<div class="cmgc-error"></div>';
                const errorBox = content.querySelector('.cmgc-error');
                if (errorBox) errorBox.textContent = error.message || 'Unable to load GitHub content.';
                if (live) live.textContent = 'Repository content failed to load';
            } finally {
                browser.classList.remove('is-loading');
                if (loading) loading.hidden = true;
            }
        }

        function setBranch(branch) {
            if (!branch) return;

            browser.dataset.branch = branch;
            if (currentBranch) currentBranch.textContent = branch;

            browser.querySelectorAll('.cmgc-branch-option').forEach(function (item) {
                const selected = item.getAttribute('data-cmgc-branch') === branch;
                item.classList.toggle('is-current', selected);
                const check = item.querySelector('.cmgc-branch-check');
                if (check) check.textContent = selected ? '✓' : '';
            });

            if (branchMenu) branchMenu.removeAttribute('open');
        }

        function selectBranch(button) {
            const branch = button.getAttribute('data-cmgc-branch') || '';
            if (!branch) return;

            setBranch(branch);
            browser.dataset.path = '';
            browse('');
        }

        function refreshLiveIfNeeded(force) {
            if (document.hidden) return;
            if (!force && Date.now() - lastLiveRefresh < 1500) return;
            browse(browser.dataset.path || '', { scroll: false });
        }

        browser.addEventListener('click', function (event) {
            const branchOption = event.target.closest('.cmgc-branch-option[data-cmgc-branch]');
            if (branchOption && browser.contains(branchOption)) {
                event.preventDefault();
                selectBranch(branchOption);
                return;
            }

            const nav = event.target.closest('.cmgc-nav-link[data-cmgc-path]');
            if (nav && browser.contains(nav)) {
                event.preventDefault();

                const targetBranch = nav.getAttribute('data-cmgc-branch') || browser.dataset.branch || '';
                const targetPath = nav.getAttribute('data-cmgc-path') || '';

                if (targetBranch && targetBranch !== (browser.dataset.branch || '')) {
                    setBranch(targetBranch);
                }

                browse(targetPath);
                return;
            }

            const refresh = event.target.closest('.cmgc-refresh-button');
            if (refresh && browser.contains(refresh)) {
                event.preventDefault();
                refreshLiveIfNeeded(true);
            }
        });

        // Replace any stale server/page-cache snapshot as soon as the browser appears.
        refreshLiveIfNeeded(true);

        // If this public page was already open while GitHub was edited elsewhere,
        // refresh automatically as soon as the visitor returns to the tab/page.
        document.addEventListener('visibilitychange', function () {
            if (!document.hidden) refreshLiveIfNeeded(false);
        });
        window.addEventListener('pageshow', function () {
            refreshLiveIfNeeded(false);
        });
        window.addEventListener('focus', function () {
            refreshLiveIfNeeded(false);
        });
    }

    function initAll(root) {
        (root || document).querySelectorAll('.cmgc-browser').forEach(initBrowser);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () { initAll(document); });
    } else {
        initAll(document);
    }

    if (window.jQuery) {
        window.jQuery(window).on('elementor/frontend/init', function () {
            if (window.elementorFrontend && elementorFrontend.hooks) {
                elementorFrontend.hooks.addAction('frontend/element_ready/cmgc_github_browser.default', function ($scope) {
                    initAll($scope && $scope[0] ? $scope[0] : document);
                });
            }
        });
    }
})();
