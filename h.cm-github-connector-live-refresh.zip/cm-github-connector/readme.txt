=== CM GitHub Connector for Elementor ===
Contributors: Connor Moizer
Tags: github, elementor, repository, cpt, wordpress
Requires at least: 6.5
Requires PHP: 7.4
Stable tag: 1.4.0
License: GPLv2 or later

Display GitHub repositories inside WordPress/Elementor with GitHub-style file, folder, branch, code and README browsing.

== Description ==

CM GitHub Connector keeps GitHub as the repository source while displaying repository content natively inside WordPress and Elementor.

Version 1.3 uses an individual content relationship:
* The GitHub account/login is detected automatically from the saved Personal Access Token when Refresh / Update is pressed.
* Every normal registered WordPress Page, Post and CPT Add/Edit screen gets a GitHub Repository field. CPT UI-created post types are included automatically.
* The repository is selected on the content item itself, like an ACF-style field. There is no global Page/CPT-to-repository assignment.
* Each Page/Post/CPT item can connect to a different repository.
* Publish/Update saves the relationship as post meta on that individual content item.
* Elementor Auto mode reads the repository saved on the current Page/Post/CPT.
* The public browser starts on the repository default branch (for example main) and provides a GitHub-style branch dropdown for the other branches.
* File/folder navigation, code files and README links stay inside the WordPress repository browser.
* The Personal Access Token remains server-side.

== Installation ==

1. Upload and activate the plugin.
2. Open Settings -> GitHub Connector.
3. Save a GitHub Personal Access Token.
4. Press Refresh / Update GitHub Data. The GitHub account name is detected from the token and the repository dropdown data is loaded.
5. Open any Page, Post or registered CPT Add New/Edit screen.
6. In the GitHub Repository field, choose the repository for that individual content item.
7. Press Publish or Update.
8. Add the GitHub Repository Browser widget to the Elementor page/template and leave Repository Source set to Connected repository for this Page / CPT.

== Changelog ==

= 1.4.1 =
* Public repository browser now live-refreshes on page load, tab return/focus, and Refresh.
* Repository contents and rendered README requests bypass the old content transient cache so GitHub add/edit/delete changes appear immediately.
* REST responses and browser fetches explicitly disable caching.


= 1.4.0 =
* Added Elementor Repository Source: All repositories.
* All Repositories mode displays every repository loaded by the saved GitHub token as its own GitHub-style browser.
* Added per-repository Exclude switches in Elementor so selected repositories can be hidden from an All Repositories widget.
* All Repositories mode uses each repository's own default branch and keeps independent branch/file/README navigation for every displayed repository.


= 1.3.2 =
* Keep README links to the connected GitHub repository inside the WordPress repository viewer.
* README links from one branch to another now switch the branch and path in-place instead of opening GitHub in a new tab.
* External websites and non-repository links still open normally.

= 1.3.1 =
* Removed the GitHub-style Code tab/grey strip beneath the repository header.
* Added "Last updated repo: DD/MM/YYYY" in its place.
* The date uses the repository pushed_at value from GitHub, with updated_at as a fallback, and is displayed in UK date format.

= 1.3.0 =
* Repository selection is now an individual Page/Post/CPT editor field, not a global CPT assignment.
* GitHub Repository field is added to all normal registered WordPress content types, including CPT UI types.
* Publishing/updating saves the repository relationship as post meta for that specific content item.
* Global settings now focus on token, detected GitHub account, cache, and Refresh / Update.
* Repository connections are public by default and the front-end branch menu starts at the repository default branch.


= 1.2.0 =
* Detect GitHub account owner/login from Personal Access Token.
* Move per-item repository selection to Page/Post/CPT Add/Edit screens.
* Add settings control for which registered content types get the repository selector.
* Add GitHub-style current branch dropdown/menu on the front end.

= 1.1.0 =
* Added repository catalog refresh.
* Added Page/Post/CPT repository mappings.
* Added automatic Elementor repository source.
