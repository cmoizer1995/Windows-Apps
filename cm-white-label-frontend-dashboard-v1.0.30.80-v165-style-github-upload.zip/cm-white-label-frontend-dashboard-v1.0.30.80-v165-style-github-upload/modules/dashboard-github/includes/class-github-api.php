<?php
/**
 * GitHub API Handler
 */

namespace CM_WL_GitHub;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GitHub_API {
	private $token = '';
	private $base_url = 'https://api.github.com';
	private $cache_duration = 3600; // 1 hour

	public function __construct() {
		$this->token = get_option( 'github_repo_selector_token', '' );
	}

	/**
	 * Get the GitHub account connected to the saved token.
	 */
	public function get_authenticated_user() {
		$cache_key = 'github_authenticated_user';
		$cached = get_transient( $cache_key );

		if ( $cached ) {
			if ( ! empty( $cached['login'] ) ) {
				update_option( 'github_repo_selector_connected_username', sanitize_text_field( $cached['login'] ), false );
			}
			return $cached;
		}

		if ( empty( $this->token ) ) {
			return [];
		}

		$response = $this->make_request( $this->base_url . '/user' );

		if ( is_wp_error( $response ) || empty( $response['login'] ) ) {
			return [];
		}

		update_option( 'github_repo_selector_connected_username', sanitize_text_field( $response['login'] ), false );
		set_transient( $cache_key, $response, $this->cache_duration );

		return $response;
	}

	/**
	 * Get the GitHub username/login connected to the saved token.
	 */
	public function get_authenticated_username() {
		$user = $this->get_authenticated_user();
		return ! empty( $user['login'] ) ? $user['login'] : '';
	}

	/**
	 * Get user repositories
	 */
	public function get_user_repos( $username = '', $force_refresh = false ) {
		$authenticated_username = $this->get_authenticated_username();
		$username = ! empty( $username ) ? sanitize_text_field( $username ) : $authenticated_username;

		if ( empty( $username ) ) {
			return [];
		}

		$cache_key = 'github_repos_' . $username;
		$cached = get_transient( $cache_key );

		if ( $cached && ! $force_refresh ) {
			return $cached;
		}

		if ( ! empty( $authenticated_username ) && strtolower( $username ) === strtolower( $authenticated_username ) ) {
			$url = $this->base_url . '/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator,organization_member';
		} else {
			$url = $this->base_url . '/users/' . rawurlencode( $username ) . '/repos?per_page=100&sort=updated';
		}

		$response = $this->make_paginated_request( $url );

		if ( is_wp_error( $response ) ) {
			return [];
		}

		set_transient( $cache_key, $response, $this->cache_duration );

		return $response;
	}

	/**
	 * Get repository branches
	 */
	public function get_repo_branches( $owner, $repo, $force_refresh = false ) {
		$owner = sanitize_text_field( $owner );
		$repo  = sanitize_text_field( $repo );

		$cache_key = 'github_branches_' . $owner . '_' . $repo;
		$cached = get_transient( $cache_key );

		if ( $cached && ! $force_refresh ) {
			return $cached;
		}

		$url = $this->base_url . '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/branches?per_page=100';
		$response = $this->make_paginated_request( $url );

		if ( is_wp_error( $response ) ) {
			return [];
		}

		set_transient( $cache_key, $response, $this->cache_duration );

		return $response;
	}

	/**
	 * Refresh repositories and branch caches together.
	 *
	 * This is used by the Update Repositories button so new GitHub branches
	 * appear on the website without needing to wait for old transients to expire.
	 */
	public function refresh_repositories_and_branches( $username = '' ) {
		$username = ! empty( $username ) ? sanitize_text_field( $username ) : $this->get_authenticated_username();

		if ( empty( $username ) ) {
			return [
				'username' => '',
				'repos' => [],
				'repo_count' => 0,
				'branch_count' => 0,
				'branches_by_repo' => [],
			];
		}

		delete_transient( 'github_repos_' . $username );

		$repos = $this->get_user_repos( $username, true );
		$branches_by_repo = [];
		$total_branches = 0;

		if ( is_array( $repos ) ) {
			foreach ( $repos as $repo ) {
				if ( empty( $repo['name'] ) ) {
					continue;
				}

				$owner = ! empty( $repo['owner']['login'] ) ? $repo['owner']['login'] : $username;
				$repo_name = $repo['name'];

				delete_transient( 'github_branches_' . $owner . '_' . $repo_name );
				delete_transient( 'github_repo_details_' . $owner . '_' . $repo_name );

				$branches = $this->get_repo_branches( $owner, $repo_name, true );
				$branch_names = [];

				if ( is_array( $branches ) ) {
					foreach ( $branches as $branch ) {
						if ( ! empty( $branch['name'] ) ) {
							$branch_names[] = $branch['name'];
						}
					}
				}

				$branches_by_repo[ $repo_name ] = $branch_names;
				$total_branches += count( $branch_names );
			}
		}

		update_option( 'github_repo_selector_branch_options', $branches_by_repo, false );
		update_option( 'github_repo_selector_branch_cache_updated', current_time( 'mysql' ), false );

		return [
			'username' => $username,
			'repos' => is_array( $repos ) ? $repos : [],
			'repo_count' => is_array( $repos ) ? count( $repos ) : 0,
			'branch_count' => $total_branches,
			'branches_by_repo' => $branches_by_repo,
		];
	}

	/**
	 * Get repository details
	 */
	public function get_repo_details( $owner, $repo, $force_refresh = false ) {
		$cache_key = 'github_repo_details_' . $owner . '_' . $repo;
		$cached = get_transient( $cache_key );

		if ( $cached && ! $force_refresh ) {
			return $cached;
		}

		$url = $this->base_url . '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo );
		$response = $this->make_request( $url );

		if ( is_wp_error( $response ) ) {
			return [];
		}

		set_transient( $cache_key, $response, $this->cache_duration );

		return $response;
	}

	/**
	 * Get repository README
	 */
	public function get_repo_readme( $owner, $repo, $branch = 'main', $force_refresh = false ) {
		$owner = sanitize_text_field( $owner );
		$repo = sanitize_text_field( $repo );
		$branch = sanitize_text_field( $branch );

		$cache_key = 'github_readme_' . $owner . '_' . $repo . '_' . $branch;
		$cached = get_transient( $cache_key );

		if ( $cached && ! $force_refresh ) {
			return $cached;
		}

		$possible_files = [ 'README.md', 'readme.md', 'README.MD', 'Readme.md', 'README', 'readme' ];

		$args = [
			'headers' => [
				'Accept' => 'application/vnd.github.v3.raw',
			],
		];

		if ( ! empty( $this->token ) ) {
			$args['headers']['Authorization'] = 'token ' . $this->token;
		}

		foreach ( $possible_files as $readme_file ) {
			$url = $this->base_url . '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/contents/' . rawurlencode( $readme_file ) . '?ref=' . rawurlencode( $branch );
			$response = wp_remote_get( $url, $args );

			if ( is_wp_error( $response ) ) {
				continue;
			}

			$status_code = wp_remote_retrieve_response_code( $response );
			if ( 200 === (int) $status_code ) {
				$body = wp_remote_retrieve_body( $response );
				set_transient( $cache_key, $body, $this->cache_duration );
				return $body;
			}
		}

		return '';
	}

	public function get_repo_files( $owner, $repo, $branch = 'main', $path = '' ) {
		$owner = sanitize_text_field( $owner );
		$repo = sanitize_text_field( $repo );
		$branch = sanitize_text_field( $branch );
		$path = trim( str_replace( '\\', '/', sanitize_text_field( $path ) ), '/' );

		$url = $this->base_url . '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/contents';
		if ( ! empty( $path ) ) {
			$url .= '/' . implode( '/', array_map( 'rawurlencode', explode( '/', $path ) ) );
		}
		$url .= '?ref=' . rawurlencode( $branch );

		$response = $this->make_request( $url );

		if ( is_wp_error( $response ) || ! is_array( $response ) ) {
			return [];
		}

		$files = [];
		foreach ( $response as $item ) {
			if ( empty( $item['path'] ) || empty( $item['type'] ) ) {
				continue;
			}

			if ( 'file' === $item['type'] ) {
				$files[] = [
					'path' => $item['path'],
					'name' => ! empty( $item['name'] ) ? $item['name'] : basename( $item['path'] ),
					'sha'  => ! empty( $item['sha'] ) ? $item['sha'] : '',
				];
			}
		}

		return $files;
	}

	public function delete_file( $owner, $repo, $path, $branch = 'main', $message = '' ) {
		$owner = sanitize_text_field( $owner );
		$repo = sanitize_text_field( $repo );
		$path = trim( str_replace( '\\', '/', sanitize_text_field( $path ) ), '/' );
		$branch = sanitize_text_field( $branch );

		if ( empty( $owner ) || empty( $repo ) || empty( $path ) || empty( $branch ) ) {
			return new \WP_Error( 'missing_file_delete_data', __( 'Repository, branch and file path are required.', 'github-repo-selector' ) );
		}

		$existing = $this->make_request(
			$this->base_url . '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/contents/' . implode( '/', array_map( 'rawurlencode', explode( '/', $path ) ) ) . '?ref=' . rawurlencode( $branch )
		);

		if ( is_wp_error( $existing ) || empty( $existing['sha'] ) ) {
			return new \WP_Error( 'file_not_found', __( 'Could not find that file on GitHub.', 'github-repo-selector' ) );
		}

		if ( empty( $message ) ) {
			$message = 'Delete ' . $path . ' from WordPress dashboard';
		}

		return $this->make_write_request(
			'DELETE',
			'/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/contents/' . implode( '/', array_map( 'rawurlencode', explode( '/', $path ) ) ),
			[
				'message' => sanitize_text_field( $message ),
				'sha'     => $existing['sha'],
				'branch'  => $branch,
			]
		);
	}

	/**
	 * Make authenticated GitHub write request.
	 */
	public function make_write_request( $method, $endpoint, $body = null ) {
		if ( empty( $this->token ) ) {
			return new \WP_Error( 'github_no_token', __( 'No GitHub token saved.', 'github-repo-selector' ) );
		}

		$args = [
			'method'  => strtoupper( $method ),
			'headers' => [
				'Accept'               => 'application/vnd.github+json',
				'Content-Type'         => 'application/json',
				'Authorization'        => 'Bearer ' . $this->token,
				'X-GitHub-Api-Version' => '2026-03-10',
				'User-Agent'           => 'CM-White-Label-Frontend-Dashboard/1.0.30.79',
			],
			'timeout' => 60,
		];

		if ( null !== $body ) {
			$args['body'] = wp_json_encode( $body );
		}

		$url = 0 === strpos( $endpoint, 'http' ) ? $endpoint : $this->base_url . $endpoint;
		$response = wp_remote_request( $url, $args );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		$decoded = json_decode( $response_body, true );

		if ( $status_code < 200 || $status_code >= 300 ) {
			$message = ! empty( $decoded['message'] ) ? $decoded['message'] : 'GitHub API Error: ' . $status_code;
			return new \WP_Error( 'github_write_api_error', $message, [ 'status' => $status_code, 'body' => $decoded ] );
		}

		return is_array( $decoded ) ? $decoded : [ 'success' => true, 'status' => $status_code ];
	}

	public function create_repository( $name, $description = '', $private = false ) {
		$name = sanitize_title( $name );
		if ( empty( $name ) ) {
			return new \WP_Error( 'missing_repo_name', __( 'Repository name is required.', 'github-repo-selector' ) );
		}

		return $this->make_write_request(
			'POST',
			'/user/repos',
			[
				'name'        => $name,
				'description' => sanitize_text_field( $description ),
				'private'     => (bool) $private,
				'auto_init'   => true,
			]
		);
	}

	public function delete_repository( $owner, $repo ) {
		$owner = sanitize_text_field( $owner );
		$repo  = sanitize_text_field( $repo );

		if ( empty( $owner ) || empty( $repo ) ) {
			return new \WP_Error( 'missing_repo', __( 'Owner and repository are required.', 'github-repo-selector' ) );
		}

		return $this->make_write_request( 'DELETE', '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) );
	}

	public function create_branch( $owner, $repo, $new_branch, $source_branch = '' ) {
		$owner = sanitize_text_field( $owner );
		$repo = sanitize_text_field( $repo );
		$new_branch = sanitize_text_field( $new_branch );
		$source_branch = sanitize_text_field( $source_branch );

		if ( empty( $owner ) || empty( $repo ) || empty( $new_branch ) ) {
			return new \WP_Error( 'missing_branch_data', __( 'Repository and branch name are required.', 'github-repo-selector' ) );
		}

		if ( empty( $source_branch ) ) {
			$details = $this->get_repo_details( $owner, $repo, true );
			$source_branch = ! empty( $details['default_branch'] ) ? $details['default_branch'] : 'main';
		}

		$source_ref = $this->make_request( $this->base_url . '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/git/ref/heads/' . implode( '/', array_map( 'rawurlencode', explode( '/', $source_branch ) ) ) );

		if ( is_wp_error( $source_ref ) || empty( $source_ref['object']['sha'] ) ) {
			return new \WP_Error( 'source_branch_not_found', __( 'Could not find the source branch SHA.', 'github-repo-selector' ) );
		}

		return $this->make_write_request(
			'POST',
			'/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/git/refs',
			[
				'ref' => 'refs/heads/' . $new_branch,
				'sha' => $source_ref['object']['sha'],
			]
		);
	}


	public function put_file_contents( $owner, $repo, $path, $content, $branch = '', $message = '' ) {
		$owner = sanitize_text_field( $owner );
		$repo = sanitize_text_field( $repo );
		$path = ltrim( str_replace( '\\', '/', sanitize_text_field( $path ) ), '/' );
		$branch = sanitize_text_field( $branch );
		$message = sanitize_text_field( $message );

		if ( empty( $owner ) || empty( $repo ) || empty( $path ) ) {
			return new \WP_Error( 'missing_file_data', __( 'Repository and file path are required.', 'github-repo-selector' ) );
		}

		if ( empty( $branch ) ) {
			$details = $this->get_repo_details( $owner, $repo, true );
			$branch = ! empty( $details['default_branch'] ) ? sanitize_text_field( $details['default_branch'] ) : '';
		}
		if ( empty( $branch ) ) {
			return new \WP_Error( 'missing_branch', __( 'GitHub did not return a branch for this repository.', 'github-repo-selector' ) );
		}

		// Verify the exact selected branch before writing. This prevents an upload
		// from ever falling back to the repository default branch silently.
		$branch_ref_endpoint = '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/git/ref/heads/' . implode( '/', array_map( 'rawurlencode', explode( '/', $branch ) ) );
		$branch_ref = $this->make_request( $this->base_url . $branch_ref_endpoint );
		if ( is_wp_error( $branch_ref ) || empty( $branch_ref['object']['sha'] ) ) {
			return new \WP_Error(
				'github_branch_not_found',
				sprintf( __( 'GitHub could not find the selected branch "%s". Refresh repositories and branches, then select it again.', 'github-repo-selector' ), $branch )
			);
		}

		if ( empty( $message ) ) {
			$message = 'Upload ' . $path . ' from WordPress dashboard';
		}

		$endpoint = '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/contents/' . implode( '/', array_map( 'rawurlencode', explode( '/', $path ) ) );

		// GitHub's official Create or update file contents endpoint requires the
		// current blob SHA only when replacing an existing file on this branch.
		$existing_sha = '';
		$existing = $this->make_request( $this->base_url . $endpoint . '?ref=' . rawurlencode( $branch ) );
		if ( is_array( $existing ) && isset( $existing['type'], $existing['sha'] ) && 'file' === $existing['type'] ) {
			$existing_sha = sanitize_text_field( $existing['sha'] );
		} elseif ( is_array( $existing ) && ! empty( $existing['sha'] ) ) {
			$existing_sha = sanitize_text_field( $existing['sha'] );
		} elseif ( is_wp_error( $existing ) ) {
			$error_data = $existing->get_error_data();
			$status = is_array( $error_data ) && isset( $error_data['status'] ) ? (int) $error_data['status'] : 0;
			if ( 404 !== $status ) {
				return $existing;
			}
		}

		$body = [
			'message' => $message,
			'content' => base64_encode( $content ),
			'branch'  => $branch,
		];
		if ( $existing_sha ) {
			$body['sha'] = $existing_sha;
		}

		$result = $this->make_write_request( 'PUT', $endpoint, $body );

		// If another write changed the file between our GET and PUT, re-read the
		// exact branch and retry once using GitHub's newest SHA.
		if ( is_wp_error( $result ) ) {
			$error_data = $result->get_error_data();
			$status = is_array( $error_data ) && isset( $error_data['status'] ) ? (int) $error_data['status'] : 0;
			$error_message = $result->get_error_message();
			if ( in_array( $status, [ 409, 422 ], true ) && false !== stripos( $error_message, 'sha' ) ) {
				$retry_existing = $this->make_request( $this->base_url . $endpoint . '?ref=' . rawurlencode( $branch ) );
				if ( is_array( $retry_existing ) && ! empty( $retry_existing['sha'] ) ) {
					$body['sha'] = sanitize_text_field( $retry_existing['sha'] );
					$result = $this->make_write_request( 'PUT', $endpoint, $body );
				}
			}
		}
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		// Do not report success until GitHub can read the same file back from the
		// exact selected branch. This makes the dashboard's success state match
		// what is actually present in the GitHub repository.
		$written_sha = is_array( $result ) && ! empty( $result['content']['sha'] ) ? sanitize_text_field( $result['content']['sha'] ) : '';
		$commit_sha = is_array( $result ) && ! empty( $result['commit']['sha'] ) ? sanitize_text_field( $result['commit']['sha'] ) : '';
		$verified = $this->make_request( $this->base_url . $endpoint . '?ref=' . rawurlencode( $branch ) . '&_cm_verify=' . rawurlencode( (string) microtime( true ) ) );
		if ( is_wp_error( $verified ) || empty( $verified['sha'] ) || ( $written_sha && ! hash_equals( strtolower( $written_sha ), strtolower( sanitize_text_field( $verified['sha'] ) ) ) ) ) {
			return new \WP_Error(
				'github_upload_verification_failed',
				sprintf( __( 'GitHub accepted the upload request, but the file could not be verified at %1$s on branch %2$s. The dashboard has not marked this as successful.', 'github-repo-selector' ), $path, $branch ),
				[ 'branch' => $branch, 'path' => $path, 'commit_sha' => $commit_sha, 'write_response' => $result ]
			);
		}

		$result['_cm_verified'] = true;
		$result['_cm_branch'] = $branch;
		$result['_cm_path'] = $path;
		$result['_cm_file_sha'] = sanitize_text_field( $verified['sha'] );
		$result['_cm_commit_sha'] = $commit_sha;
		return $result;
	}


	/**
	 * Upload a binary/text file by creating real Git objects and advancing the
	 * exact selected branch reference. This mirrors a normal Git commit and does
	 * not depend on the Contents API's existing-file SHA replacement behaviour.
	 *
	 * Official GitHub flow:
	 * 1. Read refs/heads/{branch}
	 * 2. Read its commit/tree
	 * 3. Create a blob (base64 for binary-safe uploads)
	 * 4. Create a tree using the current tree as base_tree
	 * 5. Create a commit with the current branch commit as parent
	 * 6. Fast-forward refs/heads/{branch} to the new commit
	 * 7. Read the file back from the same branch and verify the blob SHA
	 */
	public function upload_file_via_git_commit( $owner, $repo, $path, $content, $branch, $message = '' ) {
		$owner  = sanitize_text_field( $owner );
		$repo   = sanitize_text_field( $repo );
		$branch = sanitize_text_field( $branch );
		$path   = trim( str_replace( '\\', '/', sanitize_text_field( $path ) ), '/' );
		$message = sanitize_text_field( $message );

		if ( empty( $owner ) || empty( $repo ) || empty( $branch ) || empty( $path ) ) {
			return new \WP_Error( 'missing_git_upload_data', __( 'Repository, branch and file path are required.', 'github-repo-selector' ) );
		}
		if ( '' === $message ) {
			$message = 'Upload ' . $path . ' from WordPress dashboard';
		}

		$repo_endpoint = '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo );
		$ref_suffix = 'heads/' . implode( '/', array_map( 'rawurlencode', explode( '/', $branch ) ) );

		// Exact branch head commit.
		$ref = $this->make_request( $this->base_url . $repo_endpoint . '/git/ref/' . $ref_suffix );
		if ( is_wp_error( $ref ) || empty( $ref['object']['sha'] ) ) {
			return new \WP_Error(
				'github_branch_not_found',
				sprintf( __( 'GitHub could not find the selected branch "%s".', 'github-repo-selector' ), $branch )
			);
		}
		$parent_commit_sha = sanitize_text_field( $ref['object']['sha'] );

		// Read current commit so its tree can be preserved as base_tree.
		$parent_commit = $this->make_request( $this->base_url . $repo_endpoint . '/git/commits/' . rawurlencode( $parent_commit_sha ) );
		if ( is_wp_error( $parent_commit ) || empty( $parent_commit['tree']['sha'] ) ) {
			return new \WP_Error( 'github_parent_commit_failed', __( 'GitHub could not read the selected branch commit tree.', 'github-repo-selector' ) );
		}
		$base_tree_sha = sanitize_text_field( $parent_commit['tree']['sha'] );

		// Binary-safe blob. GitHub documents base64 for arbitrary file data.
		$blob = $this->make_write_request(
			'POST',
			$repo_endpoint . '/git/blobs',
			[
				'content'  => base64_encode( $content ),
				'encoding' => 'base64',
			]
		);
		if ( is_wp_error( $blob ) || empty( $blob['sha'] ) ) {
			return is_wp_error( $blob ) ? $blob : new \WP_Error( 'github_blob_failed', __( 'GitHub did not create the uploaded file blob.', 'github-repo-selector' ) );
		}
		$blob_sha = sanitize_text_field( $blob['sha'] );

		// Preserve everything already on the branch and replace/add just this path.
		$tree = $this->make_write_request(
			'POST',
			$repo_endpoint . '/git/trees',
			[
				'base_tree' => $base_tree_sha,
				'tree'      => [
					[
						'path' => $path,
						'mode' => '100644',
						'type' => 'blob',
						'sha'  => $blob_sha,
					],
				],
			]
		);
		if ( is_wp_error( $tree ) || empty( $tree['sha'] ) ) {
			return is_wp_error( $tree ) ? $tree : new \WP_Error( 'github_tree_failed', __( 'GitHub did not create the new repository tree.', 'github-repo-selector' ) );
		}

		$commit = $this->make_write_request(
			'POST',
			$repo_endpoint . '/git/commits',
			[
				'message' => $message,
				'tree'    => sanitize_text_field( $tree['sha'] ),
				'parents' => [ $parent_commit_sha ],
			]
		);
		if ( is_wp_error( $commit ) || empty( $commit['sha'] ) ) {
			return is_wp_error( $commit ) ? $commit : new \WP_Error( 'github_commit_failed', __( 'GitHub did not create the upload commit.', 'github-repo-selector' ) );
		}
		$new_commit_sha = sanitize_text_field( $commit['sha'] );

		// Fast-forward only. Never force-overwrite branch history.
		$updated_ref = $this->make_write_request(
			'PATCH',
			$repo_endpoint . '/git/refs/' . $ref_suffix,
			[
				'sha'   => $new_commit_sha,
				'force' => false,
			]
		);
		if ( is_wp_error( $updated_ref ) ) {
			return $updated_ref;
		}
		if ( empty( $updated_ref['object']['sha'] ) || ! hash_equals( strtolower( $new_commit_sha ), strtolower( sanitize_text_field( $updated_ref['object']['sha'] ) ) ) ) {
			return new \WP_Error( 'github_ref_update_failed', __( 'GitHub created the commit but did not move the selected branch to it.', 'github-repo-selector' ) );
		}

		// Verify through the normal repository contents endpoint on the exact branch.
		$contents_endpoint = $repo_endpoint . '/contents/' . implode( '/', array_map( 'rawurlencode', explode( '/', $path ) ) );
		$verified = $this->make_request( $this->base_url . $contents_endpoint . '?ref=' . rawurlencode( $branch ) . '&_cm_verify=' . rawurlencode( (string) microtime( true ) ) );
		if ( is_wp_error( $verified ) || empty( $verified['sha'] ) || ! hash_equals( strtolower( $blob_sha ), strtolower( sanitize_text_field( $verified['sha'] ) ) ) ) {
			return new \WP_Error(
				'github_git_upload_verification_failed',
				sprintf( __( 'The commit was created, but GitHub did not verify %1$s on branch %2$s.', 'github-repo-selector' ), $path, $branch ),
				[ 'branch' => $branch, 'path' => $path, 'commit_sha' => $new_commit_sha, 'blob_sha' => $blob_sha ]
			);
		}

		return [
			'_cm_verified'   => true,
			'_cm_method'     => 'git-database',
			'_cm_branch'     => $branch,
			'_cm_path'       => $path,
			'_cm_file_sha'   => $blob_sha,
			'_cm_commit_sha' => $new_commit_sha,
			'_cm_commit_url' => 'https://github.com/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/commit/' . rawurlencode( $new_commit_sha ),
			'content'        => $verified,
			'commit'         => $commit,
		];
	}


	/**
	 * Upload using the same simple server-side request architecture as the
	 * known-working GitHub Repo Selector v1.6.5: browser -> admin-ajax.php ->
	 * WordPress PHP -> GitHub with the saved PAT. No browser GitHub auth, no
	 * REST cookie dependency and no Git database/ref manipulation.
	 */
	public function upload_file_v165_style( $owner, $repo, $path, $content, $branch, $message = '' ) {
		$owner  = sanitize_text_field( $owner );
		$repo   = sanitize_text_field( $repo );
		$branch = sanitize_text_field( $branch );
		$path   = trim( str_replace( '\\', '/', sanitize_text_field( $path ) ), '/' );
		$message = sanitize_text_field( $message );

		if ( empty( $owner ) || empty( $repo ) || empty( $branch ) || empty( $path ) ) {
			return new \WP_Error( 'missing_upload_data', __( 'Repository, branch and file path are required.', 'github-repo-selector' ) );
		}
		if ( empty( $this->token ) ) {
			return new \WP_Error( 'github_no_token', __( 'No GitHub token saved.', 'github-repo-selector' ) );
		}
		if ( '' === $message ) {
			$message = 'Upload ' . $path . ' from WordPress dashboard';
		}

		$endpoint = $this->base_url . '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/contents/' . implode( '/', array_map( 'rawurlencode', explode( '/', $path ) ) );
		$ref_url  = $endpoint . '?ref=' . rawurlencode( $branch );

		// Same auth/header style as the working v1.6.5 plugin.
		$headers = [
			'Accept'        => 'application/vnd.github.v3+json',
			'Authorization' => 'token ' . $this->token,
			'User-Agent'    => 'CM-White-Label-Frontend-Dashboard/1.0.30.80',
		];

		// Read the exact path from the exact branch first. A 404 means create;
		// an existing file supplies the SHA GitHub requires for replacement.
		$existing_response = wp_remote_get( $ref_url, [ 'headers' => $headers, 'timeout' => 60 ] );
		if ( is_wp_error( $existing_response ) ) {
			return $existing_response;
		}
		$existing_status = (int) wp_remote_retrieve_response_code( $existing_response );
		$existing_body   = json_decode( wp_remote_retrieve_body( $existing_response ), true );
		$existing_sha    = '';
		if ( 200 === $existing_status && is_array( $existing_body ) && ! empty( $existing_body['sha'] ) ) {
			$existing_sha = sanitize_text_field( $existing_body['sha'] );
		} elseif ( 404 !== $existing_status ) {
			$msg = is_array( $existing_body ) && ! empty( $existing_body['message'] ) ? $existing_body['message'] : 'GitHub API Error: ' . $existing_status;
			return new \WP_Error( 'github_upload_lookup_error', $msg, [ 'status' => $existing_status, 'body' => $existing_body ] );
		}

		$payload = [
			'message' => $message,
			'content' => base64_encode( $content ),
			'branch'  => $branch,
		];
		if ( $existing_sha ) {
			$payload['sha'] = $existing_sha;
		}

		$write_headers = $headers;
		$write_headers['Content-Type'] = 'application/json';
		$write_response = wp_remote_request( $endpoint, [
			'method'  => 'PUT',
			'headers' => $write_headers,
			'body'    => wp_json_encode( $payload ),
			'timeout' => 120,
		] );
		if ( is_wp_error( $write_response ) ) {
			return $write_response;
		}
		$write_status = (int) wp_remote_retrieve_response_code( $write_response );
		$write_body   = json_decode( wp_remote_retrieve_body( $write_response ), true );

		// If GitHub says the SHA changed between lookup and write, refresh it once.
		if ( in_array( $write_status, [ 409, 422 ], true ) ) {
			$retry_get = wp_remote_get( $ref_url, [ 'headers' => $headers, 'timeout' => 60 ] );
			if ( ! is_wp_error( $retry_get ) && 200 === (int) wp_remote_retrieve_response_code( $retry_get ) ) {
				$retry_body = json_decode( wp_remote_retrieve_body( $retry_get ), true );
				if ( is_array( $retry_body ) && ! empty( $retry_body['sha'] ) ) {
					$payload['sha'] = sanitize_text_field( $retry_body['sha'] );
					$write_response = wp_remote_request( $endpoint, [
						'method'  => 'PUT',
						'headers' => $write_headers,
						'body'    => wp_json_encode( $payload ),
						'timeout' => 120,
					] );
					if ( is_wp_error( $write_response ) ) {
						return $write_response;
					}
					$write_status = (int) wp_remote_retrieve_response_code( $write_response );
					$write_body   = json_decode( wp_remote_retrieve_body( $write_response ), true );
				}
			}
		}

		if ( ! in_array( $write_status, [ 200, 201 ], true ) ) {
			$msg = is_array( $write_body ) && ! empty( $write_body['message'] ) ? $write_body['message'] : 'GitHub API Error: ' . $write_status;
			return new \WP_Error( 'github_upload_write_error', $msg, [ 'status' => $write_status, 'body' => $write_body ] );
		}

		// Read back through the same v1.6.5-style server-side GitHub request.
		$verify_response = wp_remote_get( $ref_url . '&cm_verify=' . rawurlencode( (string) time() ), [ 'headers' => $headers, 'timeout' => 60 ] );
		if ( is_wp_error( $verify_response ) ) {
			return $verify_response;
		}
		$verify_status = (int) wp_remote_retrieve_response_code( $verify_response );
		$verify_body   = json_decode( wp_remote_retrieve_body( $verify_response ), true );
		if ( 200 !== $verify_status || ! is_array( $verify_body ) || empty( $verify_body['sha'] ) ) {
			return new \WP_Error( 'github_upload_verify_error', sprintf( __( 'GitHub did not return the uploaded file from %1$s on branch %2$s.', 'github-repo-selector' ), $path, $branch ) );
		}

		$written_sha = is_array( $write_body ) && ! empty( $write_body['content']['sha'] ) ? sanitize_text_field( $write_body['content']['sha'] ) : '';
		$verified_sha = sanitize_text_field( $verify_body['sha'] );
		if ( $written_sha && ! hash_equals( strtolower( $written_sha ), strtolower( $verified_sha ) ) ) {
			return new \WP_Error( 'github_upload_sha_mismatch', __( 'GitHub returned a different file SHA during upload verification.', 'github-repo-selector' ) );
		}

		$commit_sha = is_array( $write_body ) && ! empty( $write_body['commit']['sha'] ) ? sanitize_text_field( $write_body['commit']['sha'] ) : '';
		$write_body['_cm_verified']   = true;
		$write_body['_cm_branch']     = $branch;
		$write_body['_cm_path']       = $path;
		$write_body['_cm_file_sha']   = $verified_sha;
		$write_body['_cm_commit_sha'] = $commit_sha;
		$write_body['_cm_html_url']   = ! empty( $verify_body['html_url'] ) ? esc_url_raw( $verify_body['html_url'] ) : '';
		return $write_body;
	}

	public function delete_branch( $owner, $repo, $branch ) {
		$owner = sanitize_text_field( $owner );
		$repo = sanitize_text_field( $repo );
		$branch = sanitize_text_field( $branch );

		if ( empty( $owner ) || empty( $repo ) || empty( $branch ) ) {
			return new \WP_Error( 'missing_branch', __( 'Repository and branch are required.', 'github-repo-selector' ) );
		}

		return $this->make_write_request( 'DELETE', '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/git/refs/heads/' . implode( '/', array_map( 'rawurlencode', explode( '/', $branch ) ) ) );
	}


	/**
	 * Make API request
	 */
	private function make_request( $url ) {
		$args = [
			'headers' => [
				'Accept'               => 'application/vnd.github+json',
				'X-GitHub-Api-Version' => '2026-03-10',
				'User-Agent'           => 'CM-White-Label-Frontend-Dashboard/1.0.30.79',
			],
			'timeout' => 60,
		];

		if ( ! empty( $this->token ) ) {
			$args['headers']['Authorization'] = 'Bearer ' . $this->token;
		}

		$response = wp_remote_get( $url, $args );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$status_code = wp_remote_retrieve_response_code( $response );

		$body = wp_remote_retrieve_body( $response );
		$decoded = json_decode( $body, true );

		if ( $status_code !== 200 ) {
			$message = is_array( $decoded ) && ! empty( $decoded['message'] ) ? $decoded['message'] : 'GitHub API Error: ' . $status_code;
			return new \WP_Error( 'github_api_error', $message, [ 'status' => (int) $status_code, 'body' => $decoded ] );
		}

		return is_array( $decoded ) ? $decoded : [];
	}


	/**
	 * Make paginated API requests and merge array results.
	 */
	private function make_paginated_request( $url ) {
		$all = [];
		$page = 1;

		while ( $page <= 10 ) {
			$separator = strpos( $url, '?' ) === false ? '?' : '&';
			$page_url = $url . $separator . 'page=' . $page;
			$response = $this->make_request( $page_url );

			if ( is_wp_error( $response ) ) {
				return $response;
			}

			if ( empty( $response ) || ! is_array( $response ) ) {
				break;
			}

			$all = array_merge( $all, $response );

			if ( count( $response ) < 100 ) {
				break;
			}

			$page++;
		}

		return $all;
	}

	/**
	 * Clear cache
	 */
	public function clear_cache( $owner = '', $repo = '', $delete_saved_options = true ) {
		if ( ! empty( $owner ) && ! empty( $repo ) ) {
			delete_transient( 'github_branches_' . $owner . '_' . $repo );
			delete_transient( 'github_repo_details_' . $owner . '_' . $repo );
			delete_transient( 'github_readme_' . $owner . '_' . $repo . '_main' );
			delete_transient( 'github_readme_' . $owner . '_' . $repo . '_master' );
		} else {
			$old_username = $this->get_authenticated_username();
			delete_transient( 'github_authenticated_user' );
			if ( ! empty( $old_username ) ) {
				delete_transient( 'github_repos_' . $old_username );
			}
			if ( $delete_saved_options ) {
				delete_option( 'github_repo_selector_repo_options' );
			}
		}
	}
}
