<?php
/**
 * AJAX Handlers
 */

namespace CM_WL_GitHub;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AJAX_Handler {
	public static function init() {
		add_action( 'wp_ajax_cm_wlfd_github_update_cache', [ __CLASS__, 'fetch_github_repos' ] );
		add_action( 'wp_ajax_cm_wlfd_github_update_cache_legacy', [ __CLASS__, 'fetch_github_repos' ] );
		add_action( 'wp_ajax_cm_wlfd_github_dashboard_action', [ __CLASS__, 'dashboard_action' ] );
		add_action( 'wp_ajax_cm_wlfd_github_fetch_readme', [ __CLASS__, 'fetch_github_repo_readme' ] );
		add_action( 'wp_ajax_cm_wlfd_github_load_readme_for_edit', [ __CLASS__, 'load_readme_for_edit' ] );
		add_action( 'wp_ajax_cm_wlfd_github_load_files_for_delete', [ __CLASS__, 'load_files_for_delete' ] );
		add_action( 'wp_ajax_cm_wlfd_github_render_internal_view', [ __CLASS__, 'render_internal_view' ] );
		add_action( 'wp_ajax_nopriv_cm_wlfd_github_fetch_readme', [ __CLASS__, 'fetch_github_repo_readme' ] );
	}

	public static function fetch_github_repos() {
		// Security check
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				[
					'message' => __( 'Insufficient permissions', 'github-repo-selector' ),
				],
				403
			);
		}

		// Verify nonce
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
		if ( ! wp_verify_nonce( $nonce, 'github_repo_selector_nonce' ) ) {
			wp_send_json_error(
				[
					'message' => __( 'Security check failed', 'github-repo-selector' ),
				],
				403
			);
		}

		// Fetch repositories for the GitHub account connected to the saved token.
		$api = new GitHub_API();
		$username = $api->get_authenticated_username();

		if ( empty( $username ) ) {
			wp_send_json_error(
				[
					'message' => __( 'No GitHub account found from the saved token. Add a valid token in Settings > GitHub Repo Selector.', 'github-repo-selector' ),
				]
			);
		}

		$api->clear_cache( '', '', false );
		$refresh = $api->refresh_repositories_and_branches( $username );
		$repos = $refresh['repos'];

		if ( empty( $repos ) || ! is_array( $repos ) ) {
			wp_send_json_error(
				[
					'message' => __( 'No repositories found or error fetching repositories. Check that the token has repository Contents read access.', 'github-repo-selector' ),
				]
			);
		}

		// Save repo names so dashboard write tools have current options.
		$repo_options = Settings::save_repo_options_from_repos( $repos );

		// v1.0.30.72: the same refresh also feeds the newer CM GitHub Connector
		// used by View → GitHub and Elementor.
		if ( class_exists( '\CM_WL_CMGC_Admin' ) ) {
			$cmgc_catalog = [];
			foreach ( $repos as $repo_item ) {
				if ( empty( $repo_item['name'] ) ) continue;
				$owner = ! empty( $repo_item['owner']['login'] ) ? $repo_item['owner']['login'] : $username;
				$cmgc_catalog[] = [
					'full_name'      => $owner . '/' . $repo_item['name'],
					'owner'          => $owner,
					'name'           => $repo_item['name'],
					'default_branch' => ! empty( $repo_item['default_branch'] ) ? $repo_item['default_branch'] : 'main',
					'private'        => ! empty( $repo_item['private'] ),
					'description'    => isset( $repo_item['description'] ) ? (string) $repo_item['description'] : '',
				];
			}
			update_option( \CM_WL_CMGC_Admin::OPTION_CATALOG, $cmgc_catalog, false );
			$cmgc_options = \CM_WL_CMGC_Admin::get_options();
			$cmgc_options['default_owner'] = $username;
			update_option( \CM_WL_CMGC_Admin::OPTION_SETTINGS, $cmgc_options, false );
			if ( class_exists( '\CM_WL_CMGC_API' ) ) \CM_WL_CMGC_API::flush_cache();
		}

		// Mirror the same catalog into the normal CMGC Elementor layer when it is
		// available, so Elementor "All repositories" uses this one dashboard refresh too.
		if ( class_exists( '\CMGC_Admin' ) ) {
			update_option( \CMGC_Admin::OPTION_CATALOG, $cmgc_catalog, false );
			$elementor_options = \CMGC_Admin::get_options();
			$elementor_options['default_owner'] = $username;
			update_option( \CMGC_Admin::OPTION_SETTINGS, $elementor_options, false );
			if ( class_exists( '\CMGC_API' ) ) \CMGC_API::flush_cache();
		}

		// Format response
		$formatted_repos = [];
		foreach ( $repos as $repo ) {
			$formatted_repos[] = [
				'name' => $repo['name'],
				'description' => $repo['description'] ?? '',
				'url' => $repo['html_url'],
				'stars' => $repo['stargazers_count'],
				'language' => $repo['language'] ?? 'Unknown',
			];
		}


		wp_send_json_success(
			[
				'repos' => $formatted_repos,
				'count' => count( $formatted_repos ),
				'branch_count' => isset( $refresh['branch_count'] ) ? (int) $refresh['branch_count'] : 0,
				'branches_by_repo' => isset( $refresh['branches_by_repo'] ) ? $refresh['branches_by_repo'] : [],
				'username' => $username,
				'options'  => $repo_options,
			]
		);
	}


	private static function sync_viewer_catalog( $repos, $username ) {
		$catalog = [];
		if ( is_array( $repos ) ) {
			foreach ( $repos as $repo_item ) {
				if ( empty( $repo_item['name'] ) ) continue;
				$owner = ! empty( $repo_item['owner']['login'] ) ? $repo_item['owner']['login'] : $username;
				$catalog[] = [
					'full_name'      => $owner . '/' . $repo_item['name'],
					'owner'          => $owner,
					'name'           => $repo_item['name'],
					'default_branch' => ! empty( $repo_item['default_branch'] ) ? $repo_item['default_branch'] : 'main',
					'private'        => ! empty( $repo_item['private'] ),
					'description'    => isset( $repo_item['description'] ) ? (string) $repo_item['description'] : '',
				];
			}
		}
		if ( class_exists( '\CM_WL_CMGC_Admin' ) ) {
			update_option( \CM_WL_CMGC_Admin::OPTION_CATALOG, $catalog, false );
			$options = \CM_WL_CMGC_Admin::get_options();
			$options['default_owner'] = $username;
			update_option( \CM_WL_CMGC_Admin::OPTION_SETTINGS, $options, false );
			if ( class_exists( '\CM_WL_CMGC_API' ) ) \CM_WL_CMGC_API::flush_cache();
		}
		if ( class_exists( '\CMGC_Admin' ) ) {
			update_option( \CMGC_Admin::OPTION_CATALOG, $catalog, false );
			$options = \CMGC_Admin::get_options();
			$options['default_owner'] = $username;
			update_option( \CMGC_Admin::OPTION_SETTINGS, $options, false );
			if ( class_exists( '\CMGC_API' ) ) \CMGC_API::flush_cache();
		}
		return $catalog;
	}

	private static function get_default_branch( $api, $username, $repo, $fallback = '' ) {
		if ( empty( $repo ) ) return $fallback;
		$details = $api->get_repo_details( $username, $repo, true );
		if ( is_array( $details ) && ! empty( $details['default_branch'] ) ) return sanitize_text_field( $details['default_branch'] );
		return $fallback;
	}

	private static function internal_view_payload( $username, $repo, $branch = '', $path = '', $message = '' ) {
		$repo = sanitize_text_field( $repo );
		$branch = sanitize_text_field( $branch );
		$path = trim( str_replace( '\\', '/', sanitize_text_field( $path ) ), '/' );
		if ( empty( $username ) || empty( $repo ) || ! class_exists( '\CM_WL_CMGC_Renderer' ) ) {
			return [ 'repo' => $repo, 'branch' => $branch, 'path' => $path, 'html' => '', 'message' => $message ];
		}
		if ( class_exists( '\CM_WL_CMGC_API' ) ) \CM_WL_CMGC_API::flush_cache();
		$html = \CM_WL_CMGC_Renderer::render_browser( $username, $repo, $branch, $path, 'dashboard', true );
		$github_url = 'https://github.com/' . rawurlencode( $username ) . '/' . rawurlencode( $repo );
		if ( $branch ) $github_url .= '/tree/' . implode( '/', array_map( 'rawurlencode', explode( '/', $branch ) ) );
		return [
			'owner'      => $username,
			'repo'       => $repo,
			'branch'     => $branch,
			'path'       => $path,
			'github_url' => $github_url,
			'html'       => $html,
			'message'    => $message,
		];
	}

	private static function save_latest_internal_view( $username, $repo, $branch = '', $path = '' ) {
		if ( empty( $username ) || empty( $repo ) ) {
			delete_option( 'cm_wlfd_github_latest_internal_view' );
			return;
		}
		update_option( 'cm_wlfd_github_latest_internal_view', [
			'owner'  => sanitize_text_field( $username ),
			'repo'   => sanitize_text_field( $repo ),
			'branch' => sanitize_text_field( $branch ),
			'path'   => trim( str_replace( '\\', '/', sanitize_text_field( $path ) ), '/' ),
		], false );
	}

	public static function render_internal_view() {
		if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'GitHub management is restricted to WordPress administrators.', 'github-repo-selector' ) ], 403 );
		}
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
		if ( ! wp_verify_nonce( $nonce, 'github_repo_selector_nonce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Security check failed.', 'github-repo-selector' ) ], 403 );
		}
		$api = new GitHub_API();
		$username = $api->get_authenticated_username();
		$repo = isset( $_POST['repo'] ) ? sanitize_text_field( wp_unslash( $_POST['repo'] ) ) : '';
		$branch = isset( $_POST['branch'] ) ? sanitize_text_field( wp_unslash( $_POST['branch'] ) ) : '';
		$path = isset( $_POST['path'] ) ? sanitize_text_field( wp_unslash( $_POST['path'] ) ) : '';
		if ( empty( $username ) || empty( $repo ) ) wp_send_json_error( [ 'message' => __( 'Select a repository first.', 'github-repo-selector' ) ] );
		if ( empty( $branch ) ) $branch = self::get_default_branch( $api, $username, $repo, '' );
		self::save_latest_internal_view( $username, $repo, $branch, $path );
		wp_send_json_success( [ 'viewer' => self::internal_view_payload( $username, $repo, $branch, $path ) ] );
	}

	public static function dashboard_action() {
		if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'GitHub management is restricted to WordPress administrators.', 'github-repo-selector' ) ], 403 );
		}

		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
		if ( ! wp_verify_nonce( $nonce, 'github_repo_selector_nonce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Security check failed.', 'github-repo-selector' ) ], 403 );
		}

		$api = new GitHub_API();
		$username = $api->get_authenticated_username();
		if ( empty( $username ) ) wp_send_json_error( [ 'message' => __( 'No GitHub account found from the saved token.', 'github-repo-selector' ) ] );

		$github_action = isset( $_POST['github_action'] ) ? sanitize_text_field( wp_unslash( $_POST['github_action'] ) ) : '';
		$repo = isset( $_POST['repo'] ) ? sanitize_text_field( wp_unslash( $_POST['repo'] ) ) : '';
		$branch = isset( $_POST['branch'] ) ? sanitize_text_field( wp_unslash( $_POST['branch'] ) ) : '';
		$source_branch = isset( $_POST['source_branch'] ) ? sanitize_text_field( wp_unslash( $_POST['source_branch'] ) ) : '';
		$description = isset( $_POST['description'] ) ? sanitize_text_field( wp_unslash( $_POST['description'] ) ) : '';
		$file_path = isset( $_POST['file_path'] ) ? sanitize_text_field( wp_unslash( $_POST['file_path'] ) ) : '';
		$file_content = isset( $_POST['file_content'] ) ? sanitize_textarea_field( wp_unslash( $_POST['file_content'] ) ) : '';
		$commit_message = isset( $_POST['commit_message'] ) ? sanitize_text_field( wp_unslash( $_POST['commit_message'] ) ) : '';
		$file_to_delete = isset( $_POST['file_to_delete'] ) ? sanitize_text_field( wp_unslash( $_POST['file_to_delete'] ) ) : '';
		$viewer_repo = $repo;
		$viewer_branch = $branch;
		$viewer_path = '';

		switch ( $github_action ) {
			case 'create_repo':
				$result = $api->create_repository( $repo, $description, false );
				$success_message = __( 'Repository created on GitHub.', 'github-repo-selector' );
				break;
			case 'create_branch':
				$result = $api->create_branch( $username, $repo, $branch, $source_branch );
				$success_message = __( 'Branch created on GitHub.', 'github-repo-selector' );
				break;
			case 'delete_branch':
				$result = $api->delete_branch( $username, $repo, $branch );
				$success_message = __( 'Branch deleted from GitHub.', 'github-repo-selector' );
				$viewer_branch = '';
				break;
			case 'delete_repo':
				$result = $api->delete_repository( $username, $repo );
				$success_message = __( 'Repository deleted from GitHub.', 'github-repo-selector' );
				$viewer_repo = '';
				break;
			case 'delete_file':
				$result = $api->delete_file( $username, $repo, $file_to_delete, $branch, $commit_message );
				$success_message = __( 'File deleted from GitHub.', 'github-repo-selector' );
				$viewer_path = '';
				break;
			case 'create_file':
				$result = $api->put_file_contents( $username, $repo, $file_path, $file_content, $branch, $commit_message );
				$success_message = __( 'File created or updated on GitHub.', 'github-repo-selector' );
				$viewer_path = $file_path;
				break;
			case 'upload_file':
				if ( empty( $repo ) ) wp_send_json_error( [ 'message' => __( 'Select the repository you want to upload to.', 'github-repo-selector' ) ] );
				if ( empty( $branch ) ) wp_send_json_error( [ 'message' => __( 'Select the branch you want to upload to.', 'github-repo-selector' ) ] );
				if ( empty( $_FILES['github_file_upload'] ) || ! is_uploaded_file( $_FILES['github_file_upload']['tmp_name'] ) ) wp_send_json_error( [ 'message' => __( 'No file was uploaded.', 'github-repo-selector' ) ] );
				$uploaded_file = $_FILES['github_file_upload'];
				if ( ! empty( $uploaded_file['size'] ) && $uploaded_file['size'] > 50 * 1024 * 1024 ) wp_send_json_error( [ 'message' => __( 'File is too large for this dashboard upload. Maximum size is 50MB.', 'github-repo-selector' ) ] );
				$filename = sanitize_file_name( $uploaded_file['name'] );
				if ( empty( $filename ) ) wp_send_json_error( [ 'message' => __( 'The uploaded file does not have a valid filename.', 'github-repo-selector' ) ] );

				// The upload text field is a destination FOLDER, not an alternate filename.
				// This makes `releases`, `releases/` and `builds/v4` all behave as users expect.
				$destination_folder = trim( str_replace( '\\', '/', $file_path ), '/' );
				$target_path = ( '' !== $destination_folder ? $destination_folder . '/' : '' ) . $filename;

				$file_body = file_get_contents( $uploaded_file['tmp_name'] );
				if ( false === $file_body ) wp_send_json_error( [ 'message' => __( 'WordPress could not read the uploaded file.', 'github-repo-selector' ) ] );
				$result = $api->upload_file_v165_style( $username, $repo, $target_path, $file_body, $branch, $commit_message );
				$success_message = sprintf(
					/* translators: 1: filename, 2: repository, 3: branch, 4: destination path */
					__( '%1$s uploaded to %2$s on branch %3$s at %4$s.', 'github-repo-selector' ),
					$filename,
					$repo,
					$branch,
					$target_path
				);
				$viewer_path = $destination_folder;
				break;
			default:
				wp_send_json_error( [ 'message' => __( 'Unknown GitHub dashboard action.', 'github-repo-selector' ) ] );
		}

		if ( is_wp_error( $result ) ) wp_send_json_error( [ 'message' => $result->get_error_message() ] );

		// A GitHub write invalidates the embedded repository viewer cache so View
		// shows the new commit/file immediately instead of a cached directory tree.
		if ( class_exists( '\\CM_WL_CMGC_API' ) ) {
			\CM_WL_CMGC_API::flush_cache();
		}

		if ( 'upload_file' === $github_action && is_array( $result ) && ! empty( $result['_cm_verified'] ) ) {
			$commit_short = ! empty( $result['_cm_commit_sha'] ) ? substr( sanitize_text_field( $result['_cm_commit_sha'] ), 0, 7 ) : '';
			$success_message = sprintf(
				__( '%1$s is confirmed on GitHub in %2$s → %3$s at %4$s%5$s using the dashboard WordPress → GitHub upload.', 'github-repo-selector' ),
				$filename,
				$repo,
				$branch,
				$target_path,
				$commit_short ? ' (commit ' . $commit_short . ')' : ''
			);
		}

		if ( 'create_repo' === $github_action && is_array( $result ) && ! empty( $result['name'] ) ) {
			$viewer_repo = sanitize_text_field( $result['name'] );
			$repo = $viewer_repo;
		}

		$refresh = $api->refresh_repositories_and_branches( $username );
		Settings::save_repo_options_from_repos( $refresh['repos'] );
		$repo_options = Settings::get_content_repo_options();
		self::sync_viewer_catalog( $refresh['repos'], $username );

		if ( $viewer_repo && empty( $viewer_branch ) ) $viewer_branch = self::get_default_branch( $api, $username, $viewer_repo, '' );

		if ( $viewer_repo ) {
			$github_latest_url = 'https://github.com/' . rawurlencode( $username ) . '/' . rawurlencode( $viewer_repo );
			if ( $viewer_branch ) $github_latest_url .= '/tree/' . implode( '/', array_map( 'rawurlencode', explode( '/', $viewer_branch ) ) );
			update_option( 'github_repo_selector_latest_edit_url', esc_url_raw( $github_latest_url ), false );
			self::save_latest_internal_view( $username, $viewer_repo, $viewer_branch, $viewer_path );
			$viewer = self::internal_view_payload( $username, $viewer_repo, $viewer_branch, $viewer_path, $success_message );
		} else {
			delete_option( 'github_repo_selector_latest_edit_url' );
			self::save_latest_internal_view( '', '' );
			$viewer = [ 'html' => '', 'deleted_repo' => true, 'message' => $success_message ];
		}

		wp_send_json_success( [
			'message'          => $success_message,
			'count'            => isset( $refresh['repo_count'] ) ? (int) $refresh['repo_count'] : 0,
			'branch_count'     => isset( $refresh['branch_count'] ) ? (int) $refresh['branch_count'] : 0,
			'branches_by_repo' => isset( $refresh['branches_by_repo'] ) ? $refresh['branches_by_repo'] : [],
			'options'          => $repo_options,
			'username'         => $username,
			'viewer'           => $viewer,
		] );
	}



	public static function load_files_for_delete() {
		if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'GitHub management is restricted to WordPress administrators.', 'github-repo-selector' ) ], 403 );
		}

		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
		if ( ! wp_verify_nonce( $nonce, 'github_repo_selector_nonce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Security check failed.', 'github-repo-selector' ) ], 403 );
		}

		$api = new GitHub_API();
		$username = $api->get_authenticated_username();
		$repo = isset( $_POST['repo'] ) ? sanitize_text_field( wp_unslash( $_POST['repo'] ) ) : '';
		$branch = isset( $_POST['branch'] ) ? sanitize_text_field( wp_unslash( $_POST['branch'] ) ) : '';

		if ( empty( $username ) || empty( $repo ) || empty( $branch ) ) {
			wp_send_json_error( [ 'message' => __( 'Select a repository and branch first.', 'github-repo-selector' ) ] );
		}

		$files = $api->get_repo_files( $username, $repo, $branch );

		wp_send_json_success( [ 'files' => $files ] );
	}


	public static function load_readme_for_edit() {
		if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'GitHub management is restricted to WordPress administrators.', 'github-repo-selector' ) ], 403 );
		}
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
		if ( ! wp_verify_nonce( $nonce, 'github_repo_selector_nonce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Security check failed.', 'github-repo-selector' ) ], 403 );
		}
		$api = new GitHub_API();
		$username = $api->get_authenticated_username();
		$repo = isset( $_POST['repo'] ) ? sanitize_text_field( wp_unslash( $_POST['repo'] ) ) : '';
		$branch = isset( $_POST['branch'] ) ? sanitize_text_field( wp_unslash( $_POST['branch'] ) ) : '';
		if ( empty( $username ) || empty( $repo ) || empty( $branch ) ) wp_send_json_error( [ 'message' => __( 'Select a repository and branch first.', 'github-repo-selector' ) ] );

		$readme = $api->get_repo_readme( $username, $repo, $branch, true );
		$github_url = 'https://github.com/' . rawurlencode( $username ) . '/' . rawurlencode( $repo ) . '/tree/' . implode( '/', array_map( 'rawurlencode', explode( '/', $branch ) ) );
		update_option( 'github_repo_selector_latest_edit_url', esc_url_raw( $github_url ), false );
		self::save_latest_internal_view( $username, $repo, $branch, '' );

		wp_send_json_success( [
			'readme'     => $readme,
			'title'      => $repo,
			'github_url' => $github_url,
			'viewer'     => self::internal_view_payload( $username, $repo, $branch, '', __( 'README loaded from GitHub.', 'github-repo-selector' ) ),
		] );
	}


	public static function fetch_github_repo_readme() {
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
		if ( ! empty( $nonce ) && ! wp_verify_nonce( $nonce, 'github_repo_selector_nonce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Security check failed', 'github-repo-selector' ) ], 403 );
		}

		$owner  = isset( $_POST['owner'] ) ? sanitize_text_field( wp_unslash( $_POST['owner'] ) ) : '';
		$repo   = isset( $_POST['repo'] ) ? sanitize_text_field( wp_unslash( $_POST['repo'] ) ) : '';
		$branch = isset( $_POST['branch'] ) ? sanitize_text_field( wp_unslash( $_POST['branch'] ) ) : '';

		if ( empty( $owner ) || empty( $repo ) || empty( $branch ) ) {
			wp_send_json_error( [ 'message' => __( 'Missing repository or branch.', 'github-repo-selector' ) ] );
		}

		$api = new GitHub_API();
		$readme = $api->get_repo_readme( $owner, $repo, $branch );

		if ( '' === $readme ) {
			wp_send_json_error( [ 'message' => __( 'No README available for this branch.', 'github-repo-selector' ) ] );
		}

		wp_send_json_success( [ 'readme' => wp_kses_post( self::markdown_to_html( $readme ) ) ] );
	}

	private static function markdown_to_html( $markdown ) {
		$markdown = preg_replace( '/^### (.*?)$/m', '<h3>$1</h3>', $markdown );
		$markdown = preg_replace( '/^## (.*?)$/m', '<h2>$1</h2>', $markdown );
		$markdown = preg_replace( '/^# (.*?)$/m', '<h1>$1</h1>', $markdown );
		$markdown = preg_replace( '/\*\*(.*?)\*\*/', '<strong>$1</strong>', $markdown );
		$markdown = preg_replace( '/__(.+?)__/', '<strong>$1</strong>', $markdown );
		$markdown = preg_replace( '/`([^`]+)`/', '<code>$1</code>', $markdown );
		$markdown = preg_replace( '/\[(.*?)\]\((.*?)\)/', '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>', $markdown );
		return nl2br( $markdown );
	}
}

// Initialize AJAX handlers
AJAX_Handler::init();
