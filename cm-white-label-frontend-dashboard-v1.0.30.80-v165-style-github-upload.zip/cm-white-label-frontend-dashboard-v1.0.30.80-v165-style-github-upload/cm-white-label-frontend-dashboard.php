<?php
/**
 * Plugin Name: CM White Label Frontend Dashboard
 * Description: White-label frontend dashboard for WordPress Multisite with content tools, settings, media, plugins, GitHub editing and an embedded GitHub repository viewer.
 * Version: 1.0.30.80
 * Author: Connor Moizer
 * Network: true
 */

if (!defined('ABSPATH')) exit;

// v1.0.30.72: use the newer CM GitHub Connector as the single Elementor/viewer
// layer while keeping the bundled GitHub Repo Selector as the dashboard write/editor layer.
if (!defined('CM_WL_DASHBOARD_USE_CMGC_VIEWER')) {
    define('CM_WL_DASHBOARD_USE_CMGC_VIEWER', true);
}
if (!defined('CM_WL_DASHBOARD_BUNDLED_CMGC')) {
    define('CM_WL_DASHBOARD_BUNDLED_CMGC', true);
}

/**
 * Built-in GitHub loaders.
 *
 * CM_WL_GitHub is deliberately isolated from any standalone GitHub Repo Selector
 * plugin. This prevents an older standalone copy from blocking Dashboard >
 * Settings > GitHub or Content > GitHub.
 */
function cm_wlfd_load_bundled_github_modules(){
    if (!defined('CM_WL_DASHBOARD_BUNDLED_GITHUB')) define('CM_WL_DASHBOARD_BUNDLED_GITHUB', true);

    $base = plugin_dir_path(__FILE__) . 'modules/dashboard-github/';
    foreach (['class-github-api.php','class-settings.php','class-ajax-handler.php','class-frontend-dashboard.php'] as $file) {
        $path = $base . 'includes/' . $file;
        if (is_readable($path)) require_once $path;
    }

    // Load a dashboard-private repository browser. It has its own class names
    // and REST route, so a standalone CM GitHub Connector cannot override it.
    if (!defined('CM_WL_CMGC_VERSION')) define('CM_WL_CMGC_VERSION', '1.4.1-dashboard');
    if (!defined('CM_WL_CMGC_FILE')) define('CM_WL_CMGC_FILE', __FILE__);
    if (!defined('CM_WL_CMGC_DIR')) define('CM_WL_CMGC_DIR', plugin_dir_path(__FILE__) . 'modules/dashboard-cmgc/');
    if (!defined('CM_WL_CMGC_URL')) define('CM_WL_CMGC_URL', plugin_dir_url(__FILE__) . 'modules/dashboard-cmgc/');
    foreach (['class-cmgc-api.php','class-cmgc-renderer.php','class-cmgc-rest.php','class-cmgc-admin.php'] as $file) {
        $path = CM_WL_CMGC_DIR . 'includes/' . $file;
        if (is_readable($path)) require_once $path;
    }
    if (class_exists('CM_WL_CMGC_REST')) CM_WL_CMGC_REST::init();

    // Keep the normal bundled CMGC Elementor widget available when no standalone
    // copy is active. Dashboard View itself never depends on that standalone copy.
    if (!class_exists('CMGC_Plugin', false) && !defined('CMGC_VERSION')) {
        $viewer_module = plugin_dir_path(__FILE__) . 'modules/cm-github-connector/cm-github-connector.php';
        if (is_readable($viewer_module)) require_once $viewer_module;
    }
}
add_action('plugins_loaded', 'cm_wlfd_load_bundled_github_modules', 1);

final class CM_WL_Frontend_Dashboard {
    const VERSION = '1.0.30.80';
    const SLUG = 'cm-wl-dashboard';
    private static $instance = null;
    private $login_error = '';

    public static function instance(){
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct(){
        add_action('init', [$this,'rewrite']);
        add_filter('auth_cookie_expiration', [$this,'remember_cookie_expiration'], 20, 3);
        add_filter('query_vars', [$this,'query_vars']);
        add_action('template_redirect', [$this,'render_route']);
        add_action('wp_enqueue_scripts', [$this,'assets']);
        add_filter('show_admin_bar', [$this,'hide_admin_bar'], 999);
        add_action('after_setup_theme', [$this,'force_no_admin_bar'], 999);
        add_action('wp_head', [$this,'admin_bar_css'], 1);
        add_action('wp_head', [$this,'button_styles']);
        add_shortcode('cm_white_label_dashboard', [$this,'shortcode']);
        add_action('admin_post_cm_wlfd_save_post', [$this,'save_post']);
        add_action('admin_post_cm_wlfd_save_corkboard', [$this,'save_corkboard']);
        add_action('wp_ajax_cm_wlfd_corkboard_modified', [$this,'ajax_corkboard_modified']);
        add_action('wp_ajax_cm_wlfd_save_corkboard_ajax', [$this,'ajax_save_corkboard']);
        add_action('wp_ajax_cm_wlfd_corkboard_content', [$this,'ajax_corkboard_content']);
        add_action('wp_ajax_cm_wlfd_content_tab', [$this,'ajax_content_tab']);
        add_action('admin_post_cm_wlfd_delete_post', [$this,'delete_post']);
        add_action('admin_post_cm_wlfd_elementor_create_page', [$this,'elementor_create_page']);
        add_action('admin_post_cm_wlfd_elementor_create_template', [$this,'elementor_create_template']);
        add_action('admin_post_cm_wlfd_elementor_condition', [$this,'elementor_save_condition']);
        add_action('admin_post_cm_wlfd_profile', [$this,'save_profile']);
        add_action('admin_post_cm_wlfd_media_upload', [$this,'media_upload']);
        add_action('admin_post_cm_wlfd_media_update', [$this,'media_update']);
        add_action('admin_post_cm_wlfd_network_nav_setup', [$this,'save_network_nav_setup']);
        add_action('admin_post_cm_wlfd_menu_item_add', [$this,'menu_item_add']);
        add_action('admin_post_cm_wlfd_menu_item_remove', [$this,'menu_item_remove']);
        add_action('admin_post_cm_wlfd_menu_editor_save', [$this,'menu_editor_save']);
        add_action('admin_post_cm_wlfd_add_to_service_menu', [$this,'add_to_service_menu']);
        add_action('rest_api_init', [$this,'register_rest_routes']);
        register_activation_hook(__FILE__, [__CLASS__, 'activate']);
        register_deactivation_hook(__FILE__, [__CLASS__, 'deactivate']);
    }

    public static function activate(){ self::add_rules(); flush_rewrite_rules(); }
    public static function deactivate(){ flush_rewrite_rules(); }
    public function rewrite(){ self::add_rules(); }
    public static function add_rules(){
        add_rewrite_rule('^dashboard/?(.*)?','index.php?cm_wlfd=1&cm_wlfd_path=$matches[1]','top');
    }
    public function query_vars($vars){ $vars[]='cm_wlfd'; $vars[]='cm_wlfd_path'; return $vars; }
    public function assets(){
        if (!$this->is_dashboard()) return;
        wp_enqueue_style('dashicons');
        wp_enqueue_media();
        if (function_exists('wp_enqueue_editor')) wp_enqueue_editor();
        wp_enqueue_style('cm-wlfd', plugin_dir_url(__FILE__).'assets/dashboard.css', [], self::VERSION);
        wp_enqueue_script('cm-wlfd', plugin_dir_url(__FILE__).'assets/dashboard.js', ['jquery'], self::VERSION, true);
        // Always use the dashboard's isolated GitHub tool assets, even if an older standalone GitHub plugin is active.
        wp_enqueue_style('cm-wlfd-github-tools', plugin_dir_url(__FILE__).'modules/dashboard-github/assets/css/widget.css', [], self::VERSION);
        wp_enqueue_script('cm-wlfd-github-tools', plugin_dir_url(__FILE__).'modules/dashboard-github/assets/js/frontend.js', ['jquery'], self::VERSION, true);
        wp_localize_script('cm-wlfd-github-tools', 'cmWlfdGithubFrontend', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('github_repo_selector_nonce'),
        ]);
        wp_register_style('cm-wlfd-github-browser', plugin_dir_url(__FILE__).'modules/dashboard-cmgc/assets/css/github-browser.css', [], self::VERSION);
        wp_register_script('cm-wlfd-github-browser', plugin_dir_url(__FILE__).'modules/dashboard-cmgc/assets/js/github-browser.js', [], self::VERSION, true);
        // Content → GitHub can inject this browser after an AJAX action, so its
        // assets must already be present even before a repository is rendered.
        wp_enqueue_style('cm-wlfd-github-browser');
        wp_enqueue_script('cm-wlfd-github-browser');
        // The embedded CMGC viewer is rendered after wp_head() on the custom
        // dashboard route, so make sure its registered assets are enqueued here.
        if (class_exists('CMGC_Plugin')) {
            CMGC_Plugin::instance()->register_assets();
            wp_enqueue_style('cmgc-github-browser');
            wp_enqueue_script('cmgc-github-browser');
        }
        wp_localize_script('cm-wlfd', 'cmWlfdCorkboardRefresh', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('cm_wlfd_corkboard_refresh'),
            'interval'=> 2000,
            'saveAction' => 'cm_wlfd_save_corkboard_ajax',
            'contentAction' => 'cm_wlfd_corkboard_content',
        ]);
        wp_localize_script('cm-wlfd', 'cmWlfdPwa', [
            'enabled' => false,
        ]);
        wp_localize_script('cm-wlfd', 'cmWlfdTabs', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('cm_wlfd_content_tab'),
            'action'  => 'cm_wlfd_content_tab',
        ]);
    }
    private function is_dashboard(){ return (bool)get_query_var('cm_wlfd') || is_page('dashboard'); }
    public function hide_admin_bar($show){ return $this->is_dashboard() ? false : $show; }
    public function force_no_admin_bar(){ if ($this->is_dashboard()) show_admin_bar(false); }
    public function admin_bar_css(){ if ($this->is_dashboard()) echo '<style id="cm-wlfd-no-adminbar">html{margin-top:0!important}#wpadminbar{display:none!important}body{padding-top:0!important}</style>'; }
    public function shortcode(){ return $this->dashboard_html(); }
    public function render_route(){
        if (!$this->is_dashboard()) return;

        // Process dashboard authentication before any HTML is sent. The old flow
        // attempted to redirect after the <head> had started, which could leave an
        // installed PWA on a blank white response instead of returning home.
        $this->handle_dashboard_login();

        $path = trim((string)get_query_var('cm_wlfd_path'), '/');
        if (!$path && isset($_GET['view'])) $path = sanitize_key(wp_unslash($_GET['view']));
        if (($path === 'login') && is_user_logged_in() && empty($_GET['loggedout'])) {
            wp_safe_redirect($this->url('home'));
            exit;
        }

        status_header(200);
        nocache_headers();
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        echo '<!doctype html><html '.get_language_attributes().'><head><meta charset="'.esc_attr(get_bloginfo('charset')).'"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">';
        if (function_exists('acf_form_head')) acf_form_head();
        wp_head();
        echo '</head><body class="cm-wlfd-body">';
        echo $this->dashboard_html();
        wp_footer();
        echo '</body></html>'; exit;
    }

    public function remember_cookie_expiration($length, $user_id, $remember){
        return $remember ? 30 * DAY_IN_SECONDS : $length;
    }

    private function require_login(){
        $path = trim((string)get_query_var('cm_wlfd_path'), '/');
        if (!$path && isset($_GET['view'])) $path = sanitize_key($_GET['view']);
        if ($path === 'login') return '';
        if (!is_user_logged_in()) {
            return $this->login_page();
        }
        return '';
    }

    private function handle_dashboard_login(){
        if (empty($_POST['cm_wlfd_login'])) return;
        if (!isset($_POST['cm_wlfd_login_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['cm_wlfd_login_nonce'])), 'cm_wlfd_login')) {
            $this->login_error = 'Security check failed. Please try again.';
            return;
        }
        $creds = [
            'user_login'    => sanitize_user(wp_unslash($_POST['log'] ?? '')),
            'user_password' => (string)wp_unslash($_POST['pwd'] ?? ''),
            'remember'      => !empty($_POST['rememberme']),
        ];
        $user = wp_signon($creds, is_ssl());
        if (is_wp_error($user)) {
            $this->login_error = 'The username/email or password is not correct.';
            return;
        }
        // Explicitly refresh the WordPress authentication cookie using the Remember Me choice.
        wp_set_auth_cookie($user->ID, !empty($creds['remember']), is_ssl());
        wp_set_current_user($user->ID);
        $home = $this->url('home');
        $redirect = isset($_POST['redirect_to']) ? esc_url_raw(wp_unslash($_POST['redirect_to'])) : $home;
        $redirect = wp_validate_redirect($redirect, $home);

        // A login submitted from the installed app must always return to a
        // frontend-dashboard route, never wp-admin or a blank intermediary page.
        if (empty($redirect) || strpos($redirect, 'cm_wlfd=1') === false) {
            $redirect = $home;
        }
        wp_safe_redirect($redirect);
        exit;
    }

    private function login_page(){
        if (is_user_logged_in()) {
            return '<div class="cm-wlfd-login cm-wlfd-login-card"><h1>Dashboard</h1><p>You are already logged in.</p><a class="cm-btn" href="'.$this->url('home').'">Open dashboard</a></div>';
        }
        $redirect = isset($_GET['redirect_to']) ? esc_url_raw(wp_unslash($_GET['redirect_to'])) : $this->url('home');
        $message = '';
        if (!empty($_GET['loggedout'])) $message = '<div class="cm-login-message">You have been logged out.</div>';
        if ($this->login_error) $message = '<div class="cm-login-error">'.esc_html($this->login_error).'</div>';
        ob_start();
        echo '<div class="cm-wlfd-login-wrap"><div class="cm-wlfd-login-panel">';
        echo '<div class="cm-login-brand"><span class="cm-mark">CM</span><div><h1>Dashboard Login</h1><p>Sign in with your WordPress account.</p></div></div>';
        echo $message;
        echo '<form method="post" action="'.$this->url('login').'" class="cm-dashboard-login-form">';
        wp_nonce_field('cm_wlfd_login', 'cm_wlfd_login_nonce');
        echo '<input type="hidden" name="cm_wlfd_login" value="1">';
        echo '<input type="hidden" name="cm_wlfd_pwa_login" value="1">';
        echo '<input type="hidden" name="redirect_to" value="'.esc_attr($redirect).'">';
        echo '<label>Username or Email Address<input type="text" name="log" autocomplete="username" required></label>';
        echo '<label>Password<input type="password" name="pwd" autocomplete="current-password" required></label>';
        echo '<label class="cm-login-remember"><input type="checkbox" name="rememberme" value="forever"> Remember me</label>';
        echo '<button type="submit" class="cm-btn cm-login-submit">Log in</button>';
        echo '</form>';
        echo '<p class="cm-login-links"><a href="'.esc_url(wp_lostpassword_url($this->url('login'))).'">Lost your password?</a></p>';
        echo '</div></div>';
        return ob_get_clean();
    }
    private function dashboard_html(){
        $path = trim((string)get_query_var('cm_wlfd_path'), '/');
        if (!$path && isset($_GET['view'])) $path = sanitize_key($_GET['view']);
        $view = $path ?: 'home';
        $login = $this->require_login();
        if ($login) return $login;
        ob_start();
        echo '<div class="cm-wlfd-shell">'.$this->sidebar($view).'<main class="cm-wlfd-main">'.$this->topbar();
        echo '<section class="cm-wlfd-content">';
        if ($view === 'login') echo $this->login_page();
        elseif ($view === 'content') echo $this->content_tabs();
        elseif ($view === 'view') echo $this->view_tabs();
        elseif ($view === 'add-new') echo $this->editor_screen(0);
        elseif ($view === 'edit') echo $this->editor_screen(absint($_GET['post_id'] ?? 0));
        elseif ($view === 'cpts') echo $this->cpts_screen();
        elseif ($view === 'live-blog') echo $this->live_blog_screen();
        elseif ($view === 'corkboards') echo $this->corkboards_screen();
        elseif ($view === 'corkboard-edit') echo $this->corkboard_editor(absint($_GET['post_id'] ?? 0));
        elseif ($view === 'corkboard-view') echo $this->corkboard_view(absint($_GET['post_id'] ?? 0));
        elseif ($view === 'podcast') echo $this->home_screen();
        elseif ($view === 'elementor') echo $this->elementor_screen();
        elseif ($view === 'settings') echo $this->settings_screen();
        elseif ($view === 'github') echo $this->github_screen();
        elseif ($view === 'media') echo $this->media_screen();
        elseif ($view === 'profile') echo $this->profile_screen();
        elseif ($view === 'plugins') echo $this->plugins_screen();
        elseif ($view === 'network-nav') echo $this->network_nav_screen();
        elseif ($view === 'work-blogs') echo $this->work_blogs_screen();
        elseif ($view === 'card-list') echo $this->card_list_screen();
        else echo $this->home_screen();
        echo '</section></main></div>';
        return ob_get_clean();
    }
    private function url($view='home', $args=[]){
        // Use query-mode dashboard URLs instead of pretty /dashboard/content routes.
        // This avoids multisite 404s when a subsite does not have the dashboard
        // rewrite flushed or when a CPT/archive slug conflicts with dashboard paths.
        $root = is_multisite() ? network_home_url('/') : home_url('/');
        $args = array_merge(['cm_wlfd' => 1], (array)$args);
        if ($view && $view !== 'home') $args['view'] = sanitize_key($view);
        return esc_url(add_query_arg($args, $root));
    }

    private function query_hidden($view){
        // Any frontend-dashboard GET form must carry these values.
        // Without them, changing a Site/CPT dropdown can drop back onto the
        // public multisite URL and WordPress may render an archive/404 instead
        // of the frontend dashboard screen.
        return '<input type="hidden" name="cm_wlfd" value="1"><input type="hidden" name="view" value="'.esc_attr(sanitize_key($view)).'">';
    }

    private function edit_url_after_save($site_id, $post_id, $pt, $back='content'){
        // Build the post-save editor URL explicitly and independently of the
        // current blog context. This prevents admin-post.php or a switched blog
        // from dropping the user back to the dashboard home after Publish.
        $args = [
            'cm_wlfd'   => 1,
            'view'      => 'edit',
            'site_id'   => absint($site_id),
            'post_id'   => absint($post_id),
            'post_type' => sanitize_key($pt),
            'message'   => 1,
            'cm_saved'  => time(),
        ];
        if ($back === 'live-blog') $args['back'] = 'live-blog';
        $root = is_multisite() ? network_home_url('/') : home_url('/');
        return add_query_arg($args, $root);
    }
    private function dashboard_admin_post_url(){
        // Always post to the dashboard/origin site's admin-post.php. The save handler
        // then switch_to_blog() for the selected site. This avoids multisite subsites
        // returning the user to an archive/public view after save.
        return is_multisite() ? network_site_url('/wp-admin/admin-post.php') : admin_url('admin-post.php');
    }

    private function sidebar($view){
        $items = ['home'=>['Dashboard','dashboard'],'content'=>['Content','admin-post'],'view'=>['View','visibility'],'settings'=>['Settings','admin-settings'],'profile'=>['Profile','admin-users']];
        $out = '<aside class="cm-wlfd-sidebar"><div class="cm-brand"><span class="cm-mark">CM</span><strong>Dashboard</strong></div><nav>';
        foreach($items as $k=>$it){ $active = $view===$k?' is-active':''; $out.='<a class="'.$active.'" href="'.$this->url($k).'"><span class="dashicons dashicons-'.$it[1].'"></span>'.$it[0].'</a>'; }
        $out .= '<a href="'.esc_url(wp_logout_url($this->url('login',['loggedout'=>1]))).'"><span class="dashicons dashicons-migrate"></span>Logout</a></nav></aside>';
        return $out;
    }
    private function topbar(){
        $u = wp_get_current_user();
        $now_iso = esc_attr(current_time('c'));
        return '<header class="cm-wlfd-top"><div><h1>White Label Frontend Dashboard</h1><p>Welcome '.esc_html($u->display_name ?: $u->user_login).', '.esc_html(date_i18n('l j F Y')).' <span class="cm-live-clock" data-cm-now="'.$now_iso.'">'.esc_html(date_i18n('H:i:s')).'</span></p></div><div class="cm-toplinks"><a href="'.esc_url(home_url('/')).'">My Site</a><a href="'.esc_url(admin_url()).'">Admin</a><a href="'.esc_url(wp_logout_url($this->url('login',['loggedout'=>1]))).'">Logout</a></div></header>';
    }
    private function home_screen(){
        $counts = $this->network_counts();
        $work = $this->work_blogs_stats();
        $cards = [
            ['sites','Sites',$counts['sites'],'networking','card-list'],
            ['content','Content',$counts['posts'],'admin-post','card-list'],
            ['drafts','Drafts',$counts['drafts'],'edit-page','card-list'],
            ['view','View','View All','visibility','view'],
            ['settings','Settings','Menus, media, plugins & GitHub','admin-settings','settings'],
            ['themes','Themes',$counts['themes'],'admin-appearance','card-list'],
            ['updates','Updates',$counts['updates'],'update','card-list'],
            ['corkboards','Cork Boards',$this->corkboard_count(),'sticky','corkboards']
        ];
        $out='<div class="cm-title"><h2>Dashboard</h2><p>Network-wide content tools in the white-label style.</p></div><div class="cm-cards">';
        foreach($cards as $c) {
            $href = in_array($c[4], ['view','settings','network-nav','media','plugins','corkboards'], true) ? $this->url($c[4]) : $this->url('card-list',['card'=>$c[0]]);
            $extra = '';
            $out.='<a class="cm-card cm-card-link" href="'.$href.'"><span class="dashicons dashicons-'.$c[3].'"></span><strong>'.esc_html($c[2]).'</strong><p>'.esc_html($c[1]).'</p>'.$extra.'</a>';
        }
        return $out.'</div>';
    }


    private function work_blogs_screen(){
        $stats = $this->work_blogs_stats(true);
        $public = esc_url('https://connormoizer.com/blog/work/');
        $out = '<div class="cm-title"><h2>Work Blogs</h2><p><a href="'.$this->url('home').'">← Back to dashboard</a> · <a class="cm-pwa-popup" data-cm-pwa-popup="1" target="_blank" rel="noopener" href="'.$public.'">Open public Work archive</a></p></div>';
        $out .= '<div class="cm-work-stats">';
        $out .= $this->work_stat_box('Total blogs', $stats['total_blogs']);
        $out .= $this->work_stat_box('Years covered', $stats['years_covered'] ?: 'N/A');
        $out .= $this->work_stat_box('Most recent', $stats['most_recent'] ?: 'N/A');
        $out .= $this->work_stat_box('Busiest month', ($stats['busiest_month'] ?: 'N/A'), ($stats['busiest_events'] ? $stats['busiest_events'].' events' : ''));
        $out .= $this->work_stat_box('Quietest month', ($stats['quietest_month'] ?: 'N/A'), ($stats['quietest_events'] ? $stats['quietest_events'].' events' : ''));
        $out .= $this->work_stat_box('Longest shift', ($stats['longest_shift'] ?: 'N/A'), $stats['longest_shift_label']);
        $out .= $this->work_stat_box('Total hours worked', ($stats['total_hours'] ?: '0').' hrs');
        $out .= $this->work_stat_box('Latest event', ($stats['latest_event'] ?: 'N/A'), $stats['latest_event_date']);
        $out .= '</div>';
        $out .= '<div class="cm-list cm-work-list"><article class="cm-row"><div><strong>Public page</strong><small>'.$public.'</small></div><div class="cm-row-actions"><a class="cm-btn cm-pwa-popup" data-cm-pwa-popup="1" target="_blank" rel="noopener" href="'.$public.'">Open</a></div></article>';
        if (!empty($stats['items'])) {
            foreach ($stats['items'] as $item) {
                $out .= '<article class="cm-row"><div><strong>'.esc_html($item['title']).'</strong><small>'.esc_html($item['date'].' · '.$item['site'].' · '.$item['events'].' events found').'</small></div><div class="cm-row-actions"><a class="cm-btn cm-pwa-popup" data-cm-pwa-popup="1" target="_blank" rel="noopener" href="'.esc_url($item['url']).'">View</a></div></article>';
            }
        } else {
            $out .= '<article class="cm-row"><div><strong>No Work Blog posts found yet</strong><small>It looks for posts in the Work category/archive, including the /blog/work/ structure.</small></div></article>';
        }
        return $out.'</div>';
    }
    private function work_stat_box($label, $value, $note=''){
        return '<article class="cm-work-stat"><span>'.esc_html($label).'</span><strong>'.esc_html((string)$value).'</strong>'.($note !== '' ? '<small>'.esc_html($note).'</small>' : '').'</article>';
    }
    private function work_blogs_stats($include_items=false){
        $cache_key = 'cm_wlfd_work_blog_stats_v5_'.($include_items ? 'full' : 'mini');
        $cached = get_site_transient($cache_key);
        if (is_array($cached)) return $cached;
        $stats = ['total_blogs'=>0,'years_covered'=>'','most_recent'=>'','busiest_month'=>'','busiest_events'=>0,'quietest_month'=>'','quietest_events'=>0,'longest_shift'=>'','longest_shift_label'=>'','total_hours'=>0,'latest_event'=>'','latest_event_date'=>'','items'=>[]];
        $years = [];
        $latest_ts = 0;
        $longest = 0;
        $month_counts = [];
        $sites = is_multisite() ? get_sites(['number'=>500]) : [(object)['blog_id'=>get_current_blog_id()]];
        foreach($sites as $site){
            if (is_multisite()) switch_to_blog($site->blog_id);
            $posts = $this->work_blog_posts_for_current_site();
            foreach($posts as $post){
                $stats['total_blogs']++;
                $ts = strtotime($post->post_date_gmt ?: $post->post_date);
                if (!$ts) $ts = strtotime($post->post_date);
                $years[] = (int)date_i18n('Y', $ts);
                $month = date_i18n('F Y', $ts);
                $content_raw = (string)$post->post_content;
                $content = wp_strip_all_tags(strip_shortcodes($content_raw));
                $events = $this->estimate_work_event_count($content_raw);
                $month_counts[$month] = ($month_counts[$month] ?? 0) + $events;
                if ($events > $stats['busiest_events']) { $stats['busiest_events'] = $events; $stats['busiest_month'] = $month; }

                $custom_hours = $this->work_hours_from_content($content);
                if ($custom_hours) {
                    foreach($custom_hours as $hit){
                        $hours = (float)$hit['hours'];
                        $stats['total_hours'] += $hours;
                        if ($hours > $longest) {
                            $longest = $hours;
                            $stats['longest_shift'] = rtrim(rtrim(number_format($hours, 1), '0'), '.').' hours';
                            $stats['longest_shift_label'] = $hit['label'] ?: (get_the_title($post) ?: '');
                        }
                    }
                } else {
                    $stats['total_hours'] += ($events * 7);
                    if (7 > $longest) {
                        $longest = 7;
                        $stats['longest_shift'] = '7 hours';
                        $stats['longest_shift_label'] = get_the_title($post) ?: '';
                    }
                }

                if ($ts > $latest_ts) {
                    $latest_ts = $ts;
                    $stats['most_recent'] = $month;
                    $latest = $this->latest_event_from_work_blog($content_raw, $ts, get_the_title($post));
                    $stats['latest_event'] = $latest['title'];
                    $stats['latest_event_date'] = $latest['date'];
                }
                if ($include_items) $stats['items'][] = ['title'=>get_the_title($post) ?: '(no title)','date'=>date_i18n('j F Y', $ts),'site'=>$this->site_name($site->blog_id),'events'=>$events,'url'=>get_permalink($post)];
            }
            if (is_multisite()) restore_current_blog();
        }
        if ($month_counts) {
            arsort($month_counts);
            $stats['busiest_month'] = (string)array_key_first($month_counts);
            $stats['busiest_events'] = (int)reset($month_counts);
            asort($month_counts);
            $stats['quietest_month'] = (string)array_key_first($month_counts);
            $stats['quietest_events'] = (int)reset($month_counts);
        }
        $years = array_values(array_unique(array_filter($years))); sort($years);
        if ($years) $stats['years_covered'] = count($years) === 1 ? (string)$years[0] : (min($years).'–'.max($years));
        if (!$stats['busiest_month'] && $stats['most_recent']) $stats['busiest_month'] = $stats['most_recent'];
        if (!$stats['busiest_events'] && $stats['total_blogs']) $stats['busiest_events'] = 1;
        $stats['total_hours'] = rtrim(rtrim(number_format((float)$stats['total_hours'], 1), '0'), '.');
        set_site_transient($cache_key, $stats, 6 * HOUR_IN_SECONDS);
        return $stats;
    }

    private function work_hours_from_content($content){
        $hits = [];
        $plain = trim(preg_replace('/\s+/', ' ', wp_strip_all_tags(strip_shortcodes((string)$content))));
        if ($plain === '') return $hits;
        if (preg_match_all('/(^|[^0-9])(\d{1,2}(?:\.\d+)?)\s*(?:hours|hrs|hr|h)\b/i', $plain, $m, PREG_OFFSET_CAPTURE)) {
            foreach($m[2] as $hit){
                $hours = (float)$hit[0];
                if ($hours <= 0 || $hours > 24) continue;
                $offset = max(0, $hit[1] - 80);
                $label = trim(preg_replace('/\s+/', ' ', substr($plain, $offset, 180)));
                $hits[] = ['hours'=>$hours,'label'=>$label];
            }
        }
        return $hits;
    }

    private function latest_event_from_work_blog($content, $fallback_ts, $fallback_title){
        $plain = wp_strip_all_tags(strip_shortcodes((string)$content));
        $lines = preg_split('/\r\n|\r|\n/', $plain);
        $latest = ['title'=>$fallback_title ?: 'Latest work blog','date'=>date_i18n('j F Y', $fallback_ts)];
        foreach($lines as $line){
            $line = trim(preg_replace('/\s+/', ' ', $line));
            if ($line === '') continue;
            $date_text = '';
            if (preg_match('/\b([0-3]?\d)(st|nd|rd|th)?\s+(january|february|march|april|may|june|july|august|september|october|november|december)\s+(20\d{2})\b/i', $line, $m)) {
                $date_text = $m[1].' '.$m[3].' '.$m[4];
            } elseif (preg_match('/\b([0-3]?\d)(st|nd|rd|th)?\s+(january|february|march|april|may|june|july|august|september|october|november|december)\b/i', $line, $m)) {
                $date_text = $m[1].' '.$m[3].' '.date_i18n('Y', $fallback_ts);
            }
            if ($date_text !== '') {
                $event = trim(preg_replace('/\b([0-3]?\d)(st|nd|rd|th)?\s+(january|february|march|april|may|june|july|august|september|october|november|december)(\s+20\d{2})?\b/i', '', $line));
                $event = trim($event, " -–—:|•\t");
                if ($event === '') $event = $fallback_title ?: 'Latest event';
                $dt = strtotime($date_text);
                $latest = ['title'=>$event,'date'=>$dt ? date_i18n('j F Y', $dt) : $date_text];
            }
        }
        return $latest;
    }

    private function work_blog_posts_for_current_site(){
        $found = [];
        $post_types = get_post_types(['public'=>true], 'names');
        if (!in_array('post', $post_types, true)) $post_types[] = 'post';
        $work_term_ids = [];
        foreach(['category','post_tag'] as $tax){
            if (!taxonomy_exists($tax)) continue;
            $terms = get_terms(['taxonomy'=>$tax,'hide_empty'=>false,'search'=>'work']);
            if (!is_wp_error($terms)) {
                foreach($terms as $term){
                    if (stripos($term->slug, 'work') !== false || stripos($term->name, 'work') !== false) $work_term_ids[$tax][] = (int)$term->term_id;
                }
            }
        }

        $queries = [];
        if (!empty($work_term_ids['category'])) $queries[] = ['category__in' => array_values(array_unique($work_term_ids['category']))];
        if (!empty($work_term_ids['post_tag'])) $queries[] = ['tag__in' => array_values(array_unique($work_term_ids['post_tag']))];
        $queries[] = ['s' => 'work'];
        $queries[] = ['name__in' => []]; // fallback below: recent/all public posts, then filter by URL/taxonomy/content.

        foreach($queries as $extra){
            $fallback_all = array_key_exists('name__in', $extra);
            if ($fallback_all) $extra = [];
            $args = array_merge([
                'post_type'=>$post_types,
                'post_status'=>['publish','future','private'],
                'posts_per_page'=>$fallback_all ? 1000 : 300,
                'orderby'=>'date',
                'order'=>'DESC',
                'suppress_filters'=>false,
            ], $extra);
            foreach(get_posts($args) as $p){
                if ($this->is_work_blog_post($p, $work_term_ids, $fallback_all)) $found[$p->ID] = $p;
            }
        }
        return array_values($found);
    }

    private function is_work_blog_post($post, $work_term_ids=[], $fallback_all=false){
        $url = (string)get_permalink($post);
        $slug = (string)$post->post_name;
        $title = (string)$post->post_title;
        if (stripos($url, '/blog/work/') !== false || stripos($url, '/work/') !== false) return true;
        if (stripos($slug, 'work') !== false || stripos($title, 'work blog') !== false || stripos($title, 'work blogs') !== false) return true;

        foreach(get_object_taxonomies($post->post_type, 'names') as $tax){
            $terms = wp_get_post_terms($post->ID, $tax);
            if (is_wp_error($terms)) continue;
            foreach($terms as $term){
                if (stripos($term->slug, 'work') !== false || stripos($term->name, 'work') !== false) return true;
            }
        }

        if ($fallback_all) {
            $txt = strtolower(wp_strip_all_tags(strip_shortcodes((string)$post->post_content)));
            // Monthly work blogs often have no word "work" in the title, but they do contain event date lists.
            if (preg_match('/\b(january|february|march|april|may|june|july|august|september|october|november|december)\s+20\d{2}\b/i', $title)
                && (strpos($txt, 'shift') !== false || strpos($txt, 'first direct arena') !== false || strpos($txt, 'arena') !== false)) return true;
        }
        return false;
    }

    private function estimate_work_event_count($content){
        $content = trim((string)$content);
        if ($content === '') return 1;
        $lines = preg_split('/\r\n|\r|\n/', $content);
        $count = 0;
        foreach($lines as $line){
            $line = trim(wp_strip_all_tags($line));
            if ($line === '') continue;
            if (preg_match('/\b([0-3]?\d)(st|nd|rd|th)?\b.*\b(january|february|march|april|may|june|july|august|september|october|november|december)\b/i', $line)) $count++;
            elseif (preg_match('/^\s*[-•*]?\s*([0-3]?\d)(\/|\-|\.)[01]?\d\b/', $line)) $count++;
        }
        if (!$count && preg_match_all('/<li\b/i', $content, $m)) $count = count($m[0]);
        return max(1, $count);
    }

    private function card_list_screen(){
        $card = sanitize_key($_GET['card'] ?? 'content');
        $labels = [
            'sites' => 'Sites',
            'content' => 'Content',
            'drafts' => 'Drafts',
            'plugins' => 'Plugins',
            'themes' => 'Themes',
            'updates' => 'Updates',
        ];
        if (!isset($labels[$card])) $card = 'content';
        $out = '<div class="cm-title"><h2>'.esc_html($labels[$card]).'</h2><p><a href="'.$this->url('home').'">← Back to dashboard</a> · Frontend/public view only. No backend edit links on this page.</p></div>';
        if ($card === 'sites') return $out.$this->card_sites_rows();
        if ($card === 'content') return $out.$this->card_content_rows(false);
        if ($card === 'drafts') return $out.$this->card_content_rows(true);
        if ($card === 'plugins') return $out.$this->card_plugins_rows();
        if ($card === 'themes') return $out.$this->card_themes_rows();
        if ($card === 'updates') return $out.$this->card_updates_rows();
        return $out;
    }

    private function card_sites_rows(){
        $out = '<div class="cm-list">';
        foreach($this->all_sites() as $site){
            $details = is_multisite() ? get_blog_details($site->blog_id) : (object)['blogname'=>get_bloginfo('name'), 'siteurl'=>home_url('/')];
            $url = is_multisite() ? get_home_url($site->blog_id, '/') : home_url('/');
            $out .= '<article class="cm-row"><div><strong>'.esc_html($details->blogname).'</strong><small>Site #'.esc_html($site->blog_id).' · '.esc_html($url).'</small></div><div class="cm-row-actions"><a class="cm-btn cm-pwa-popup" data-cm-pwa-popup="1" target="_blank" rel="noopener" href="'.esc_url($url).'">View Site</a></div></article>';
        }
        return $out.'</div>';
    }

    private function card_content_rows($drafts_only=false){
        $out = '<div class="cm-list">';
        $found = 0;
        foreach($this->all_sites() as $site){
            if (is_multisite()) switch_to_blog($site->blog_id);
            $site_name = $this->site_name($site->blog_id);
            foreach($this->public_types() as $pt=>$obj){
                $args = [
                    'post_type' => $pt,
                    'post_status' => $drafts_only ? ['draft','pending'] : ['publish','future','private'],
                    'posts_per_page' => 50,
                    'orderby' => 'modified',
                    'order' => 'DESC',
                    'suppress_filters' => false,
                ];
                if (!current_user_can('edit_others_posts')) $args['author'] = get_current_user_id();
                $posts = get_posts($args);
                foreach($posts as $p){
                    $found++;
                    $status = get_post_status_object($p->post_status);
                    $url = $drafts_only ? get_preview_post_link($p) : get_permalink($p);
                    if (!$url) $url = get_permalink($p);
                    $out .= '<article class="cm-row"><div><strong>'.esc_html(get_the_title($p) ?: '(no title)').'</strong><small>'.esc_html($site_name).' · '.esc_html($this->type_label($pt,$obj)).' · '.esc_html($status ? $status->label : $p->post_status).' · Modified '.esc_html(get_the_modified_date('', $p)).'</small></div><div class="cm-row-actions"><a class="cm-btn cm-pwa-popup" data-cm-pwa-popup="1" target="_blank" rel="noopener" href="'.esc_url($url).'">'.($drafts_only ? 'Preview' : 'View').'</a></div></article>';
                }
            }
            if (is_multisite()) restore_current_blog();
        }
        if (!$found) $out .= '<article class="cm-row"><div><strong>No items found</strong><small>Nothing is available for this card yet.</small></div></article>';
        return $out.'</div>';
    }

    private function card_plugins_rows(){
        if (!current_user_can('activate_plugins')) return '<p>Plugin list is restricted to administrators.</p>';
        if (!function_exists('get_plugins')) require_once ABSPATH.'wp-admin/includes/plugin.php';
        $active = (array)get_option('active_plugins', []);
        $network_active = is_multisite() ? array_keys((array)get_site_option('active_sitewide_plugins', [])) : [];
        $out = '<div class="cm-list">';
        foreach(get_plugins() as $file=>$p){
            $state = in_array($file, $active, true) || in_array($file, $network_active, true) ? 'Active' : 'Inactive';
            $out .= '<article class="cm-row"><div><strong>'.esc_html($p['Name']).'</strong><small>'.esc_html($file).' · v'.esc_html($p['Version']).' · '.esc_html($state).'</small></div></article>';
        }
        return $out.'</div>';
    }

    private function card_themes_rows(){
        if (!current_user_can('switch_themes')) return '<p>Theme list is restricted to administrators.</p>';
        $current = wp_get_theme();
        $out = '<div class="cm-list">';
        foreach(wp_get_themes() as $slug=>$theme){
            $state = ($theme->get_stylesheet() === $current->get_stylesheet()) ? 'Active on current site' : 'Installed';
            $out .= '<article class="cm-row"><div><strong>'.esc_html($theme->get('Name')).'</strong><small>'.esc_html($slug).' · v'.esc_html($theme->get('Version')).' · '.esc_html($state).'</small></div></article>';
        }
        return $out.'</div>';
    }

    private function card_updates_rows(){
        if (!current_user_can('update_plugins') && !current_user_can('update_themes')) return '<p>Updates list is restricted to administrators.</p>';
        $out = '<div class="cm-list">';
        $found = 0;
        $plugin_updates = get_site_transient('update_plugins');
        if (is_object($plugin_updates) && !empty($plugin_updates->response)) {
            if (!function_exists('get_plugins')) require_once ABSPATH.'wp-admin/includes/plugin.php';
            $plugins = get_plugins();
            foreach((array)$plugin_updates->response as $file=>$u){
                $found++;
                $name = $plugins[$file]['Name'] ?? $file;
                $out .= '<article class="cm-row"><div><strong>'.esc_html($name).'</strong><small>Plugin update · '.esc_html($file).' · New version '.esc_html($u->new_version ?? '').'</small></div></article>';
            }
        }
        $theme_updates = get_site_transient('update_themes');
        if (is_object($theme_updates) && !empty($theme_updates->response)) {
            foreach((array)$theme_updates->response as $slug=>$u){
                $found++;
                $out .= '<article class="cm-row"><div><strong>'.esc_html($slug).'</strong><small>Theme update · New version '.esc_html($u['new_version'] ?? '').'</small></div></article>';
            }
        }
        if (!$found) $out .= '<article class="cm-row"><div><strong>No updates found</strong><small>There are no plugin or theme updates showing right now.</small></div></article>';
        return $out.'</div>';
    }
    private function network_counts(){
        $r=['sites'=>1,'posts'=>0,'drafts'=>0,'plugins'=>0,'themes'=>0,'updates'=>0];
        $countable_statuses = ['publish','future','draft','pending','private'];
        $sites = is_multisite() ? get_sites(['number'=>500]) : [(object)['blog_id'=>get_current_blog_id()]];
        $r['sites'] = count($sites);
        foreach($sites as $s){
            if (is_multisite()) switch_to_blog($s->blog_id);
            foreach($this->public_types() as $slug=>$obj){
                $counts = wp_count_posts($slug);
                if (!$counts || is_wp_error($counts)) continue;
                foreach($countable_statuses as $status){
                    $r['posts'] += isset($counts->$status) ? (int)$counts->$status : 0;
                }
                $r['drafts'] += isset($counts->draft) ? (int)$counts->draft : 0;
            }
            if (is_multisite()) restore_current_blog();
        }
        if (current_user_can('activate_plugins')) {
            if (!function_exists('get_plugins')) require_once ABSPATH.'wp-admin/includes/plugin.php';
            $r['plugins']=count((array)get_plugins());
            $r['themes']=count((array)wp_get_themes());
            $plugin_updates=get_site_transient('update_plugins');
            $theme_updates=get_site_transient('update_themes');
            $r['updates']=(is_object($plugin_updates)&&isset($plugin_updates->response)?count((array)$plugin_updates->response):0)
                +(is_object($theme_updates)&&isset($theme_updates->response)?count((array)$theme_updates->response):0);
        }
        return $r;
    }
    private function site_select($selected=0){
        if (!is_multisite()) return '<input type="hidden" name="site_id" value="'.get_current_blog_id().'">';
        $out='<label>Site <select name="site_id" class="cm-input" onchange="this.form.submit()">';
        foreach(get_sites(['number'=>300]) as $s){ $name=get_blog_details($s->blog_id)->blogname; $out.='<option value="'.esc_attr($s->blog_id).'" '.selected($selected,$s->blog_id,false).'>'.esc_html($name).' (#'.$s->blog_id.')</option>'; }
        return $out.'</select></label>';
    }
    private function site_name($site_id){
        if (is_multisite()) {
            $details = get_blog_details($site_id);
            return $details && !empty($details->blogname) ? $details->blogname : ('Site #'.$site_id);
        }
        return get_bloginfo('name');
    }
    private function status_action_label($post){
        return 'Publish';
    }
    private function save_message($post_id, $site_id, $pt){
        if (!$post_id) return '';
        $permalink = get_permalink($post_id);
        if (!$permalink) return '';
        return '<div class="cm-notice updated"><p><strong>Content published.</strong> <a href="'.esc_url($permalink).'" target="_blank" rel="noopener">View content</a></p></div>';
    }
    private function permalink_line($post_id){
        if (!$post_id) return '';
        $permalink = get_permalink($post_id);
        if (!$permalink) return '';
        return '<div class="cm-permalink"><strong>Permalink:</strong> <a href="'.esc_url($permalink).'" target="_blank" rel="noopener">'.esc_html($permalink).'</a> <a class="cm-small-link cm-pwa-popup" data-cm-pwa-popup="1" href="'.esc_url($permalink).'" target="_blank" rel="noopener">View</a></div>';
    }
    private function as_type_object($slug, $label='', $singular='', $source='registered'){
        $slug = sanitize_key($slug);
        $label = $label ?: $slug;
        $singular = $singular ?: $label;
        return (object)[
            'name' => $slug,
            'label' => $label,
            'source' => $source,
            'show_ui' => true,
            'labels' => (object)[
                'name' => $label,
                'singular_name' => $singular,
            ],
        ];
    }
    private function cptui_stored_types(){
        $found = [];
        foreach (['cptui_post_types','cptui_registered_post_types'] as $opt) {
            $raw = get_option($opt, []);
            if (!is_array($raw)) continue;
            foreach ($raw as $key => $row) {
                $slug = '';
                $label = '';
                $singular = '';
                if (is_array($row)) {
                    $slug = $row['name'] ?? $row['post_type'] ?? $row['slug'] ?? $row['post_type_name'] ?? $key;
                    $label = $row['label'] ?? $row['plural_label'] ?? $row['labels']['name'] ?? $row['name'] ?? $slug;
                    $singular = $row['singular_label'] ?? $row['labels']['singular_name'] ?? $label;
                } elseif (is_string($row)) {
                    $slug = $row;
                    $label = $row;
                    $singular = $row;
                }
                $slug = sanitize_key($slug);
                if ($slug && !isset($found[$slug])) $found[$slug] = $this->as_type_object($slug, $label, $singular, 'cptui-option');
            }
        }
        return $found;
    }
    private function acf_field_groups_raw(){
        if (function_exists('acf_get_field_groups')) {
            $groups = acf_get_field_groups();
            if (is_array($groups)) return $groups;
        }
        $posts = get_posts([
            'post_type' => 'acf-field-group',
            'post_status' => ['publish','acf-disabled'],
            'posts_per_page' => -1,
            'suppress_filters' => false,
        ]);
        $groups = [];
        foreach ($posts as $p) {
            $data = maybe_unserialize($p->post_content);
            $groups[] = [
                'ID' => $p->ID,
                'key' => $p->post_name,
                'title' => $p->post_title,
                'location' => is_array($data) && isset($data['location']) ? $data['location'] : [],
            ];
        }
        return $groups;
    }
    private function acf_stored_post_type_slugs(){
        $found = [];
        foreach ((array)$this->acf_field_groups_raw() as $g) {
            foreach ((array)($g['location'] ?? []) as $or_group) {
                foreach ((array)$or_group as $rule) {
                    if (($rule['param'] ?? '') === 'post_type') {
                        $val = sanitize_key($rule['value'] ?? '');
                        if ($val && $val !== 'all') $found[$val] = true;
                    }
                }
            }
        }
        return array_keys($found);
    }
    private function cpt_matches_live_blog($slug, $obj=null){
        $hay = strtolower($slug.' '.(($obj->label ?? '') ?: '').' '.(($obj->labels->name ?? '') ?: '').' '.(($obj->labels->singular_name ?? '') ?: ''));
        return (strpos($hay, 'live') !== false && strpos($hay, 'blog') !== false) || in_array($slug, ['live_blog','liveblog','cm_live_blog','cm_liveblog','cm_live_blogs','live_blogs'], true);
    }
    private function live_blog_types(){
        $found = [];
        foreach ($this->public_types() as $slug=>$obj) {
            if ($this->cpt_matches_live_blog($slug, $obj)) $found[$slug] = $obj;
        }
        return $found;
    }
    private function public_types(){
        $types = get_post_types(['show_ui'=>true], 'objects');
        $skip = ['attachment','nav_menu_item','custom_css','customize_changeset','oembed_cache','user_request','wp_block','wp_template','wp_template_part','wp_global_styles','wp_navigation','acf-field','acf-field-group'];
        foreach ($skip as $k) unset($types[$k]);
        // Podcast has been removed from the dashboard. Keep the CPT available on the public site,
        // but hide it from Content/Add New/CPT listings here.
        foreach ($types as $k => $obj) {
            if ($this->cpt_matches_podcast($k, $obj)) unset($types[$k]);
        }
        foreach ($this->cptui_stored_types() as $slug=>$obj) {
            if (!isset($types[$slug])) $types[$slug] = $obj;
            else $types[$slug]->source = 'cptui-registered';
        }
        foreach ($this->acf_stored_post_type_slugs() as $slug) {
            if (!isset($types[$slug])) $types[$slug] = $this->as_type_object($slug, ucwords(str_replace(['_','-'],' ',$slug)), ucwords(str_replace(['_','-'],' ',$slug)), 'acf-location');
        }
        foreach ($types as $k => $obj) {
            if ($this->cpt_matches_podcast($k, $obj)) unset($types[$k]);
        }
        uasort($types, function($a,$b){ return strcasecmp($a->labels->singular_name ?? $a->name, $b->labels->singular_name ?? $b->name); });
        return $types;
    }
    private function type_source_suffix($slug){
        $obj = $this->public_types()[$slug] ?? null;
        $source = is_object($obj) && !empty($obj->source) ? $obj->source : '';
        if (strpos($source, 'cptui') !== false) return '-cptui';
        if ($source === 'acf-location') return '-acf';
        if (in_array($slug, ['live_blog','liveblog','cm_live_blog','cm_liveblog'], true)) return '-live';
        return post_type_exists($slug) ? '-plugin' : '';
    }
    private function type_label($slug, $obj){
        $label = $obj->labels->singular_name ?: $obj->label ?: $slug;
        return $label . ' (' . $slug . $this->type_source_suffix($slug) . ')';
    }
    private function all_sites(){
        return is_multisite() ? get_sites(['number'=>500]) : [(object)['blog_id'=>get_current_blog_id()]];
    }
    private function network_cpt_map(){
        $map=[];
        foreach($this->all_sites() as $site){
            if (is_multisite()) switch_to_blog($site->blog_id);
            foreach($this->public_types() as $slug=>$obj){
                if (!isset($map[$site->blog_id])) $map[$site->blog_id]=[];
                $map[$site->blog_id][$slug]=['label'=>$this->type_label($slug,$obj),'name'=>$obj->labels->singular_name ?: $slug, 'slug'=>$slug];
            }
            if (is_multisite()) restore_current_blog();
        }
        return $map;
    }
    private function acf_field_groups_for_type($post_id, $pt){
        $groups = function_exists('acf_get_field_groups') ? acf_get_field_groups(['post_id'=>$post_id ?: 0, 'post_type'=>$pt]) : [];
        if (!empty($groups)) return $groups;
        $all = $this->acf_field_groups_raw();
        $matched=[];
        foreach((array)$all as $g){
            $locations = $g['location'] ?? [];
            foreach((array)$locations as $or_group){
                foreach((array)$or_group as $rule){
                    if (($rule['param'] ?? '') === 'post_type') {
                        $op = $rule['operator'] ?? '=='; $val = $rule['value'] ?? '';
                        if (($op === '==' && ($val === $pt || $val === 'all')) || ($op === '!=' && $val !== $pt)) { $matched[]=$g; break 2; }
                    }
                }
            }
        }
        return $matched;
    }
    private function acf_box($post_id, $pt){
        if (!function_exists('acf_form')) return '<div class="cm-acf"><h3>ACF Fields</h3><p>Advanced Custom Fields is not active on this site.</p></div>';
        $groups = $this->acf_field_groups_for_type($post_id, $pt);
        ob_start();
        echo '<div class="cm-acf" data-cm-acf-saved="'.esc_attr(!empty($_GET['cm_saved']) ? '1' : '0').'"><div class="cm-acf-head"><h3>ACF Fields</h3><div class="cm-acf-tools"><button type="button" class="cm-btn ghost cm-acf-open-all">Open ACF</button><button type="button" class="cm-btn ghost cm-acf-close-all">Close ACF</button></div></div>';
        if ($groups) {
            $keys = array_filter(wp_list_pluck($groups,'key'));
            acf_form(['post_id'=>$post_id ?: 'new_post','form'=>false,'field_groups'=>$keys,'uploader'=>'wp']);
        } else {
            echo '<p>No ACF field groups were assigned to this CPT on this site.</p>';
        }
        echo '</div>';
        return ob_get_clean();
    }

    private function cpt_matches_podcast($slug, $obj=null){
        $hay = strtolower($slug.' '.(($obj->label ?? '') ?: '').' '.(($obj->labels->name ?? '') ?: '').' '.(($obj->labels->singular_name ?? '') ?: ''));
        return $slug === 'cm_podcast_app' || strpos($hay, 'podcast') !== false;
    }
    private function podcast_types(){
        $found = [];
        foreach ($this->public_types() as $slug=>$obj) {
            if ($this->cpt_matches_podcast($slug, $obj)) $found[$slug] = $obj;
        }
        // The uploaded CM Editorial Widgets podcast app uses this one CPT.
        // Add a fallback object so the dashboard can still show the section if
        // ACF location data exists before the CPT is registered on a switched site.
        if (isset($this->public_types()['cm_podcast_app']) && !isset($found['cm_podcast_app'])) {
            $found['cm_podcast_app'] = $this->public_types()['cm_podcast_app'];
        }
        return $found;
    }
    private function podcast_item_type($post_id){
        $type = get_post_meta($post_id, '_cm_podcast_item_type', true);
        return in_array($type, ['show','episode'], true) ? $type : 'episode';
    }
    private function podcast_screen(){
        $site_id = absint($_GET['site_id'] ?? get_current_blog_id());
        if (is_multisite()) switch_to_blog($site_id);
        $podcast_types = $this->podcast_types();
        $pt = sanitize_key($_GET['post_type'] ?? (isset($podcast_types['cm_podcast_app']) ? 'cm_podcast_app' : (array_key_first($podcast_types) ?: '')));
        if ($pt && !isset($podcast_types[$pt])) $pt = isset($podcast_types['cm_podcast_app']) ? 'cm_podcast_app' : (array_key_first($podcast_types) ?: '');
        $filter_type = sanitize_key($_GET['podcast_item_type'] ?? 'all');
        if (!in_array($filter_type, ['all','show','episode'], true)) $filter_type = 'all';
        $author = absint($_GET['author'] ?? 0);
        $out = '<div class="cm-title"><h2>Podcast</h2><p>Frontend manager for the CM Podcast CPT from your editorial widgets plugin. It uses the same add/edit/publish flow as Content and loads the podcast ACF fields through Advanced Custom Fields, including the playlist fallback fields from the latest podcast plugin.</p></div>';
        if (!empty($_GET['deleted'])) $out .= '<div class="cm-notice updated"><p><strong>Podcast item moved to Trash.</strong></p></div>';
        $out .= '<form class="cm-filter" method="get">'.$this->query_hidden('podcast').$this->site_select($site_id);
        $out .= '<label>Podcast CPT <select name="post_type" class="cm-input" onchange="this.form.submit()">';
        if ($podcast_types) {
            foreach($podcast_types as $k=>$obj) $out .= '<option value="'.esc_attr($k).'" '.selected($pt,$k,false).'>'.esc_html($this->type_label($k,$obj)).'</option>';
        } else {
            $out .= '<option value="">No Podcast CPT on this site</option>';
        }
        $out .= '</select></label><label>Type <select name="podcast_item_type" class="cm-input" onchange="this.form.submit()"><option value="all" '.selected($filter_type,'all',false).'>All</option><option value="show" '.selected($filter_type,'show',false).'>Shows</option><option value="episode" '.selected($filter_type,'episode',false).'>Episodes</option></select></label>';
        $out .= '<label>Author <select name="author" class="cm-input" onchange="this.form.submit()"><option value="0">All authors</option>';
        foreach(get_users(['fields'=>['ID','display_name','user_login']]) as $u){ $out .= '<option value="'.absint($u->ID).'" '.selected($author,$u->ID,false).'>'.esc_html($u->display_name ?: $u->user_login).'</option>'; }
        $out .= '</select></label><noscript><button class="cm-btn">Load</button></noscript></form>';
        if (!$pt) {
            $out .= '<div class="cm-list"><p>No Podcast CPT was detected. Make sure the uploaded CM Editorial Widgets podcast plugin is active on this site/network.</p></div>';
            if (is_multisite()) restore_current_blog();
            return $out;
        }
        $args = ['post_type'=>$pt,'post_status'=>['publish','draft','pending','private'],'posts_per_page'=>120,'orderby'=>'modified','order'=>'DESC'];
        if ($filter_type !== 'all') $args['meta_query'] = [['key'=>'_cm_podcast_item_type','value'=>$filter_type,'compare'=>'=']];
        if ($author) $args['author'] = $author;
        elseif (!current_user_can('edit_others_posts')) $args['author'] = get_current_user_id();
        $q = new WP_Query($args);
        $counts = ['show'=>0,'episode'=>0];
        $all = get_posts(['post_type'=>$pt,'post_status'=>['publish','draft','pending','private'],'posts_per_page'=>-1,'fields'=>'ids']);
        foreach($all as $id){ $t=$this->podcast_item_type($id); if(isset($counts[$t])) $counts[$t]++; }
        $out .= '<div class="cm-cards cm-mini-cards"><a class="cm-card cm-card-link" href="'.$this->url('podcast',['site_id'=>21,'post_type'=>$pt,'podcast_item_type'=>'show']).'"><span class="dashicons dashicons-microphone"></span><strong>'.esc_html($counts['show']).'</strong><p>Shows</p></a><a class="cm-card cm-card-link" href="'.$this->url('podcast',['site_id'=>21,'post_type'=>$pt,'podcast_item_type'=>'episode']).'"><span class="dashicons dashicons-format-audio"></span><strong>'.esc_html($counts['episode']).'</strong><p>Episodes</p></a></div>';
        $out .= '<p><a class="cm-btn" href="'.$this->url('add-new',['site_id'=>21,'post_type'=>$pt,'back'=>'podcast','podcast_item_type'=>'show']).'">Add New Show</a> <a class="cm-btn" href="'.$this->url('add-new',['site_id'=>21,'post_type'=>$pt,'back'=>'podcast','podcast_item_type'=>'episode']).'">Add New Episode</a></p>';
        $out .= '<div class="cm-list">';
        if ($q->have_posts()) {
            foreach($q->posts as $p){
                $item_type = $this->podcast_item_type($p->ID);
                $show_id = absint(get_post_meta($p->ID, '_cm_podcast_app_show', true));
                $show_title = $show_id ? get_the_title($show_id) : '';
                $number = get_post_meta($p->ID, '_cm_podcast_app_number', true);
                $duration = get_post_meta($p->ID, '_cm_podcast_app_duration', true);
                $bits = [ucfirst($item_type), $p->post_status];
                if ($show_title && $item_type === 'episode') $bits[] = 'Show: '.$show_title;
                if ($number) $bits[] = 'Episode: '.$number;
                if ($duration) $bits[] = 'Duration: '.$duration;
                if ($item_type === 'episode') { $pc = $this->podcast_playlist_count($p->ID); if ($pc) $bits[] = 'Playlist items: '.$pc; $info = $this->podcast_playlist_info_count($p->ID); if ($info) $bits[] = 'Info links: '.$info; }
                if ($item_type === 'show' && function_exists('cm_editorial_podcast_feed_url')) $bits[] = 'RSS available';
                $out .= '<article class="cm-row"><div><strong>'.esc_html(get_the_title($p) ?: '(no title)').'</strong><small>'.esc_html(implode(' · ', $bits)).'</small></div><div class="cm-row-actions"><a class="cm-btn" href="'.$this->url('edit',['post_id'=>$p->ID,'site_id'=>21,'post_type'=>$pt,'back'=>'podcast']).'">Edit</a><a class="cm-btn ghost cm-pwa-popup" data-cm-pwa-popup="1" target="_blank" rel="noopener" href="'.esc_url(get_permalink($p)).'">View</a>';
                if ($item_type === 'show' && function_exists('cm_editorial_podcast_feed_url')) $out .= '<a class="cm-btn ghost cm-pwa-popup" data-cm-pwa-popup="1" target="_blank" rel="noopener" href="'.esc_url(cm_editorial_podcast_feed_url($p->ID)).'">RSS</a>';
                $out .= $this->delete_button($p->ID,$site_id,$pt,'podcast').'</div></article>';
            }
        } else {
            $out .= '<p>No podcast items found for this filter.</p>';
        }
        $out .= '</div>';
        if (is_multisite()) restore_current_blog();
        return $out;
    }
    private function card_podcast_rows(){
        $out = '<div class="cm-list">';
        $found = 0;
        foreach($this->all_sites() as $site){
            if (is_multisite()) switch_to_blog($site->blog_id);
            foreach($this->podcast_types() as $pt=>$obj){
                $posts = get_posts(['post_type'=>$pt,'post_status'=>['publish','draft','pending','private'],'posts_per_page'=>50,'orderby'=>'modified','order'=>'DESC']);
                foreach($posts as $p){
                    $found++;
                    $item_type = $this->podcast_item_type($p->ID);
                    $out .= '<article class="cm-row"><div><strong>'.esc_html(get_the_title($p) ?: '(no title)').'</strong><small>'.esc_html($this->site_name($site->blog_id)).' · '.esc_html(ucfirst($item_type)).' · '.esc_html($p->post_status).'</small></div><div class="cm-row-actions"><a class="cm-btn" href="'.$this->url('podcast',['site_id'=>$site->blog_id,'post_type'=>$pt]).'">Open Podcast</a><a class="cm-btn ghost cm-pwa-popup" data-cm-pwa-popup="1" target="_blank" rel="noopener" href="'.esc_url(get_permalink($p)).'">View</a></div></article>';
                }
            }
            if (is_multisite()) restore_current_blog();
        }
        if (!$found) $out .= '<article class="cm-row"><div><strong>No podcast items found</strong><small>Activate the podcast plugin and create shows or episodes.</small></div></article>';
        return $out.'</div>';
    }
    private function podcast_playlist_count($post_id){
        $raw = (string) get_post_meta($post_id, '_cm_podcast_app_media_playlist', true);
        if ($raw === '') return 0;
        $count = 0;
        foreach (preg_split('/\r\n|\r|\n/', $raw) as $line) {
            if (trim($line) !== '') $count++;
        }
        return $count;
    }

    private function podcast_playlist_info_count($post_id){
        $raw = (string) get_post_meta($post_id, '_cm_podcast_app_media_playlist', true);
        if ($raw === '') return 0;
        $count = 0;
        foreach (preg_split('/\r\n|\r|\n/', $raw) as $line) {
            $line = trim($line);
            if ($line === '') continue;
            $parts = array_map('trim', explode('|', $line));
            $info = isset($parts[4]) ? $parts[4] : '';
            foreach ($parts as $part) {
                if (false === strpos($part, '=')) continue;
                list($k, $v) = array_map('trim', explode('=', $part, 2));
                $k = strtolower(str_replace(' ', '', $k));
                if (in_array($k, ['info','infourl','info_url','song','songurl','song_url','more','moreinfo','more_info'], true)) $info = $v;
            }
            if ($info !== '') $count++;
        }
        return $count;
    }

    private function podcast_media_playlist_builder($post_id=0){
        $raw = $post_id ? (string) get_post_meta($post_id, '_cm_podcast_app_media_playlist', true) : '';
        ob_start();
        ?>
        <div class="cm-acf cm-podcast-playlist-builder" data-cm-podcast-playlist-builder>
            <div class="cm-acf-head">
                <h3>Podcast Media Playlist</h3>
                <div class="cm-acf-tools"><button type="button" class="cm-btn ghost cm-podcast-playlist-add">Add Playlist Item</button></div>
            </div>
            <p class="cm-help">Add one row per item. The public podcast widget will show the playlist as FAQ/accordion rows and try <strong>YouTube first</strong>, then <strong>Spotify</strong>, then the <strong>WordPress uploaded media fallback</strong>. Add an optional official/song information URL for the View song information button.</p>
            <div class="cm-podcast-playlist-rows"></div>
            <textarea class="cm-input cm-podcast-playlist-raw" name="cm_podcast_media_playlist_dashboard" rows="5" style="display:none;"><?php echo esc_textarea($raw); ?></textarea>
            <template class="cm-podcast-playlist-template">
                <div class="cm-podcast-playlist-row">
                    <label>Title<input type="text" class="cm-input cm-podcast-pl-title" placeholder="Track title"></label>
                    <label>YouTube URL<input type="url" class="cm-input cm-podcast-pl-youtube" placeholder="https://youtube.com/watch?v=..."></label>
                    <label>Spotify URL<input type="url" class="cm-input cm-podcast-pl-spotify" placeholder="https://open.spotify.com/track/..."></label>
                    <label>WordPress media fallback<input type="text" class="cm-input cm-podcast-pl-media" placeholder="Media URL or attachment ID"></label>
                    <label>Official song/info URL<input type="url" class="cm-input cm-podcast-pl-info" placeholder="https://official-song-page.example"></label>
                    <div class="cm-row-actions"><button type="button" class="cm-btn ghost cm-podcast-pl-pick">Choose media</button><button type="button" class="cm-btn danger cm-podcast-pl-remove">Remove</button></div>
                </div>
            </template>
        </div>
        <script>
        (function(){
            var box = document.querySelector('[data-cm-podcast-playlist-builder]');
            if(!box) return;
            var rows = box.querySelector('.cm-podcast-playlist-rows');
            var raw = box.querySelector('.cm-podcast-playlist-raw');
            var tpl = box.querySelector('.cm-podcast-playlist-template');
            function splitLine(line){
                var parts = String(line || '').split('|').map(function(v){return v.trim();});
                var data = {title:parts[0]||'', youtube:parts[1]||'', spotify:parts[2]||'', media:parts[3]||'', info:parts[4]||''};
                parts.forEach(function(part){
                    var m = part.match(/^([a-z0-9_ -]+)\s*=\s*(.*)$/i);
                    if(!m) return;
                    var k = m[1].toLowerCase().replace(/\s+/g,'');
                    var v = m[2].trim();
                    if(k === 'title') data.title = v;
                    if(k === 'youtube' || k === 'yt') data.youtube = v;
                    if(k === 'spotify') data.spotify = v;
                    if(k === 'media' || k === 'upload' || k === 'wordpress' || k === 'file' || k === 'audio') data.media = v;
                    if(k === 'info' || k === 'infourl' || k === 'info_url' || k === 'song' || k === 'songurl' || k === 'song_url' || k === 'more' || k === 'moreinfo' || k === 'more_info') data.info = v;
                });
                return data;
            }
            function addRow(data){
                data = data || {};
                var node = tpl.content ? tpl.content.firstElementChild.cloneNode(true) : null;
                if(!node) return;
                node.querySelector('.cm-podcast-pl-title').value = data.title || '';
                node.querySelector('.cm-podcast-pl-youtube').value = data.youtube || '';
                node.querySelector('.cm-podcast-pl-spotify').value = data.spotify || '';
                node.querySelector('.cm-podcast-pl-media').value = data.media || '';
                node.querySelector('.cm-podcast-pl-info').value = data.info || '';
                rows.appendChild(node);
            }
            function sync(){
                var lines = [];
                rows.querySelectorAll('.cm-podcast-playlist-row').forEach(function(row){
                    var title = row.querySelector('.cm-podcast-pl-title').value.trim();
                    var youtube = row.querySelector('.cm-podcast-pl-youtube').value.trim();
                    var spotify = row.querySelector('.cm-podcast-pl-spotify').value.trim();
                    var media = row.querySelector('.cm-podcast-pl-media').value.trim();
                    var info = row.querySelector('.cm-podcast-pl-info').value.trim();
                    if(title || youtube || spotify || media || info){ lines.push([title,youtube,spotify,media,info].join(' | ')); }
                });
                raw.value = lines.join('\n');
                var acf = document.querySelector('textarea[name="acf[field_cm_podcast_app_media_playlist]"]');
                if(acf){ acf.value = raw.value; acf.dispatchEvent(new Event('change', {bubbles:true})); }
            }
            function init(){
                var acf = document.querySelector('textarea[name="acf[field_cm_podcast_app_media_playlist]"]');
                var initial = (acf && acf.value.trim()) ? acf.value : raw.value;
                var lines = initial.split(/\r\n|\r|\n/).filter(function(line){return line.trim() !== '';});
                if(lines.length){ lines.forEach(function(line){ addRow(splitLine(line)); }); } else { addRow({}); }
                sync();
            }
            box.addEventListener('input', sync);
            box.addEventListener('click', function(e){
                if(e.target.closest('.cm-podcast-playlist-add')){ e.preventDefault(); addRow({}); sync(); }
                if(e.target.closest('.cm-podcast-pl-remove')){ e.preventDefault(); var row=e.target.closest('.cm-podcast-playlist-row'); if(row){ row.remove(); sync(); } }
                if(e.target.closest('.cm-podcast-pl-pick')){
                    e.preventDefault();
                    var row=e.target.closest('.cm-podcast-playlist-row');
                    if(!row || !window.wp || !wp.media) return;
                    var frame = wp.media({title:'Choose podcast media fallback', button:{text:'Use this media'}, multiple:false, library:{type:['audio','video']}});
                    frame.on('select', function(){ var file=frame.state().get('selection').first().toJSON(); row.querySelector('.cm-podcast-pl-media').value = file.id || file.url || ''; sync(); });
                    frame.open();
                }
            });
            var form = box.closest('form'); if(form){ form.addEventListener('submit', sync); }
            init();
        })();
        </script>
        <?php
        return ob_get_clean();
    }

    private function cpts_screen(){
        $out='<div class="cm-title"><h2>All CPTs Network Wide</h2><p>Detected from WordPress, CPT UI, plugin registered CPTs, your Live Blog CPT, and every site on the network.</p></div><div class="cm-list">';
        foreach($this->network_cpt_map() as $blog_id=>$types){
            $details = is_multisite() ? get_blog_details($blog_id) : (object)['blogname'=>get_bloginfo('name')];
            $out.='<article class="cm-row"><div><strong>'.esc_html($details->blogname).' (#'.esc_html($blog_id).')</strong><small>';
            $bits=[]; foreach($types as $slug=>$t){ $bits[]='<a href="'.$this->url('content',['site_id'=>$blog_id,'post_type'=>$slug]).'">'.esc_html($t['label']).'</a>'; }
            $out.=implode(' · ', $bits).'</small></div></article>';
        }
        return $out.'</div>';
    }
    private function live_blog_screen(){
        $site_id = absint($_GET['site_id'] ?? get_current_blog_id());
        if (is_multisite()) switch_to_blog($site_id);
        $live_types = $this->live_blog_types();
        $pt = sanitize_key($_GET['post_type'] ?? (array_key_first($live_types) ?: ''));
        if ($pt && !isset($live_types[$pt])) $pt = array_key_first($live_types) ?: '';
        $out='<div class="cm-title"><h2>Live Blog</h2><p>Frontend Live Blog manager only. It uses the same Classic Editor add/edit/publish logic as Content, but filters the CPT list to Live Blog post types and loads ACF fields through the Advanced Custom Fields plugin when active.</p></div>';
        if (!empty($_GET['deleted'])) $out .= '<div class="cm-notice updated"><p><strong>Content moved to Trash.</strong></p></div>';
        if (!empty($_GET['service_menu_added'])) $out .= '<div class="cm-notice updated"><p><strong>Added to Service Header Menu.</strong></p></div>';
        $out.='<form class="cm-filter" method="get">'.$this->query_hidden('live-blog').$this->site_select($site_id);
        $out.='<div style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap;"><label style="flex:1;min-width:200px;">Live Blog CPT <select name="post_type" class="cm-input" onchange="this.form.submit()">';
        if ($live_types) {
            foreach($live_types as $k=>$obj) $out.='<option value="'.esc_attr($k).'" '.selected($pt,$k,false).'>'.esc_html($this->type_label($k,$obj)).'</option>';
        } else {
            $out.='<option value="">No Live Blog CPT on this site</option>';
        }
        $out.='</select></label>';
        if ($pt && isset($live_types[$pt])) {
            $out.='<a class="cm-btn" href="'.$this->url('add-new',['site_id'=>21,'post_type'=>$pt,'tab'=>'live-blog']).'">Add New</a>';
        }
        $out.='</div><noscript><button class="cm-btn">Load</button></noscript></form>';
        if (!$pt) {
            $out.='<div class="cm-list"><p>No Live Blog CPT was detected on this selected site. Pick another site above, or make sure the Live Blog/CPT UI plugin is active on that site.</p></div>';
            if (is_multisite()) restore_current_blog();
            return $out;
        }
        $q = new WP_Query(['post_type'=>$pt,'post_status'=>['publish','draft','pending','private'],'posts_per_page'=>80,'orderby'=>'modified','order'=>'DESC']);
        $out.='<div class="cm-list">';
        if ($q->have_posts()) {
            foreach($q->posts as $p){
                $acf_count=function_exists('get_field_objects') ? count((array)get_field_objects($p->ID)) : 0;
                $out.='<article class="cm-row"><div><strong>'.esc_html(get_the_title($p) ?: '(no title)').'</strong><small>'.esc_html($this->type_label($pt,$live_types[$pt])).' · '.esc_html($p->post_status).' · ACF fields: '.esc_html($acf_count).'</small></div><div class="cm-row-actions"><a class="cm-btn" href="'.$this->url('edit',['post_id'=>$p->ID,'site_id'=>21,'post_type'=>$pt,'back'=>'live-blog']).'">Edit</a><a class="cm-btn ghost" href="'.esc_url(get_permalink($p)).'">View</a>'.$this->delete_button($p->ID,$site_id,$pt,'live-blog').'</div></article>';
            }
        } else {
            $out.='<p>No live blog posts found for this CPT.</p>';
        }
        $out.='</div>';
        if (is_multisite()) restore_current_blog();
        return $out;
    }
    private function service_header_menu_button($post_id, $site_id, $pt, $back='content'){
        $post_id = absint($post_id);
        $site_id = absint($site_id);
        if (!$post_id || !$site_id) return '';
        $can = false;
        if (is_multisite()) switch_to_blog($site_id);
        $post = get_post($post_id);
        if ($post && current_user_can('edit_theme_options')) $can = true;
        if (is_multisite()) restore_current_blog();
        if (!$can) return '';
        return '<form class="cm-inline-service-menu" method="post" action="'.esc_url($this->dashboard_admin_post_url()).'">'
            .wp_nonce_field('cm_wlfd_add_to_service_menu','_wpnonce',true,false)
            .'<input type="hidden" name="action" value="cm_wlfd_add_to_service_menu">'
            .'<input type="hidden" name="post_id" value="'.esc_attr($post_id).'">'
            .'<input type="hidden" name="site_id" value="'.esc_attr($site_id).'">'
            .'<input type="hidden" name="post_type" value="'.esc_attr($pt).'">'
            .'<input type="hidden" name="back" value="'.esc_attr($back).'">'
            .'<button class="cm-btn ghost" type="submit">Add to Service Header Menu</button>'
            .'</form>';
    }

    public function add_to_service_menu(){
        check_admin_referer('cm_wlfd_add_to_service_menu');
        $site_id = absint($_POST['site_id'] ?? get_current_blog_id());
        $post_id = absint($_POST['post_id'] ?? 0);
        $pt = sanitize_key($_POST['post_type'] ?? 'post');
        $back = sanitize_key($_POST['back'] ?? 'content');
        if (is_multisite()) switch_to_blog($site_id);
        if (!current_user_can('edit_theme_options')) wp_die('No permission to edit menus on this site.');
        $post = $post_id ? get_post($post_id) : null;
        if (!$post) wp_die('Content item not found.');

        $locations = get_nav_menu_locations();
        $menu_id = isset($locations['service']) ? absint($locations['service']) : 0;
        if (!$menu_id) {
            $created = wp_create_nav_menu('Service Header Menu');
            if (!is_wp_error($created)) {
                $menu_id = absint($created);
                $locations['service'] = $menu_id;
                set_theme_mod('nav_menu_locations', $locations);
            }
        }
        if ($menu_id) {
            $existing = wp_get_nav_menu_items($menu_id, ['post_status' => 'publish']);
            $already = false;
            if (is_array($existing)) {
                foreach ($existing as $item) {
                    if ($item->type === 'post_type' && absint($item->object_id) === $post_id && $item->object === $post->post_type) { $already = true; break; }
                }
            }
            if (!$already) {
                wp_update_nav_menu_item($menu_id, 0, [
                    'menu-item-object-id' => $post_id,
                    'menu-item-object' => $post->post_type,
                    'menu-item-type' => 'post_type',
                    'menu-item-title' => $post->post_title,
                    'menu-item-status' => 'publish',
                ]);
            }
        }
        if (is_multisite()) restore_current_blog();
        $view = ($back === 'live-blog') ? 'live-blog' : 'content';
        wp_safe_redirect($this->url($view, ['site_id'=>21,'post_type'=>$pt,'service_menu_added'=>1]));
        exit;
    }

    private function delete_button($post_id, $site_id, $pt, $back='content', $return_to=''){
        if (!$post_id || !current_user_can('delete_post', $post_id)) return '';
        $return_to = $return_to ?: $this->current_dashboard_url();
        return '<form class="cm-inline-delete" method="post" action="'.esc_url($this->dashboard_admin_post_url()).'">'
            .wp_nonce_field('cm_wlfd_delete_post','_wpnonce',true,false)
            .'<input type="hidden" name="action" value="cm_wlfd_delete_post">'
            .'<input type="hidden" name="post_id" value="'.esc_attr($post_id).'">'
            .'<input type="hidden" name="site_id" value="'.esc_attr($site_id).'">'
            .'<input type="hidden" name="post_type" value="'.esc_attr($pt).'">'
            .'<input type="hidden" name="back" value="'.esc_attr($back).'">'
            .'<input type="hidden" name="return_to" value="'.esc_url($return_to).'">'
            .'<button class="cm-btn danger" type="submit" data-cm-delete-confirm="1">Delete</button>'
            .'</form>';
    }

    private function current_dashboard_url(){
        $request = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '';
        if (!$request) return $this->url('home');
        $base = is_multisite() ? network_home_url('/') : home_url('/');
        return esc_url_raw(add_query_arg([], $base.ltrim($request, '/')));
    }

    private function dashboard_safe_return_url($url, $fallback){
        $url = esc_url_raw($url);
        if (!$url) return $fallback;
        $fallback_host = wp_parse_url($fallback, PHP_URL_HOST);
        $url_host = wp_parse_url($url, PHP_URL_HOST);
        if ($fallback_host && $url_host && strtolower($fallback_host) !== strtolower($url_host)) return $fallback;
        $query = [];
        $parts = wp_parse_url($url);
        if (!empty($parts['query'])) parse_str($parts['query'], $query);
        $path = $parts['path'] ?? '';
        $is_dashboard = (!empty($query['cm_wlfd']) || strpos($path, '/dashboard') !== false);
        if (!$is_dashboard) return $fallback;
        unset($query['post_id'], $query['message'], $query['cm_saved']);
        $query['deleted'] = 1;
        $query['cm_deleted'] = time();
        $clean = (isset($parts['scheme']) ? $parts['scheme'].'://' : '').($parts['host'] ?? '').($path ?: '/');
        return add_query_arg($query, $clean);
    }


    private function corkboard_plugin_ready(){
        return post_type_exists('cm_corkboard');
    }

    private function corkboard_count(){
        if (!$this->corkboard_plugin_ready()) return 'Plugin required';
        $counts = wp_count_posts('cm_corkboard');
        return intval($counts->publish ?? 0) + intval($counts->draft ?? 0) + intval($counts->private ?? 0);
    }

    private function corkboards_screen(){
        if (!$this->corkboard_plugin_ready()) {
            return '<div class="cm-title"><h2>Cork Boards</h2><p>The private CM Corkboard plugin must be installed and activated.</p></div>';
        }

        $q = new WP_Query([
            'post_type'      => 'cm_corkboard',
            'post_status'    => ['publish','draft','private'],
            'posts_per_page' => 100,
            'orderby'        => 'modified',
            'order'          => 'DESC',
            'author'         => current_user_can('edit_others_posts') ? '' : get_current_user_id(),
        ]);

        $out = '<div class="cm-title"><h2>Cork Boards</h2><p>Private company boards displayed inside this dashboard.</p></div>';
        $out .= '<p><a class="cm-btn" href="'.$this->url('corkboard-edit').'">Add New Board</a></p>';
        $out .= '<div class="cm-list">';

        if ($q->have_posts()) {
            foreach ($q->posts as $board) {
                $notes = get_post_meta($board->ID, '_cm_corkboard_notes', true);
                $note_count = is_array($notes) ? count($notes) : 0;
                $out .= '<article class="cm-row"><div><strong>'.esc_html(get_the_title($board) ?: '(no title)').'</strong><small>'.esc_html($note_count).' tasks · Updated '.esc_html(get_the_modified_date('', $board)).'</small></div>';
                $out .= '<div class="cm-row-actions">';
                $out .= '<a class="cm-btn" href="'.$this->url('corkboard-edit',['post_id'=>$board->ID]).'">Edit</a>';
                $out .= '<a class="cm-btn ghost" href="'.$this->url('corkboard-view',['post_id'=>$board->ID]).'">View in Dashboard</a>';
                $out .= $this->delete_button($board->ID, get_current_blog_id(), 'cm_corkboard', 'corkboards', $this->url('corkboards'));
                $out .= '</div></article>';
            }
        } else {
            $out .= '<p>No private cork boards have been created yet.</p>';
        }

        return $out.'</div>';
    }

    private function corkboard_editor($post_id=0){
        if (!$this->corkboard_plugin_ready()) {
            return '<div class="cm-title"><h2>Cork Boards</h2><p>The private CM Corkboard plugin must be installed and activated.</p></div>';
        }

        $post = $post_id ? get_post($post_id) : null;
        if ($post && $post->post_type !== 'cm_corkboard') return '<p>That board could not be found.</p>';
        if ($post && !current_user_can('edit_post', $post_id)) return '<p>You do not have permission to edit this board.</p>';
        if (!$post && !current_user_can('edit_posts')) return '<p>You do not have permission to create a board.</p>';

        $notes = $post ? get_post_meta($post_id, '_cm_corkboard_notes', true) : [];
        if (!is_array($notes)) $notes = [];

        ob_start();
        echo '<div class="cm-title"><h2>'.($post ? 'Edit Board' : 'Add New Board').'</h2><p><a href="'.$this->url('corkboards').'">← Back to Cork Boards</a></p></div>';
        if (!empty($_GET['message'])) echo '<div class="cm-notice updated"><p><strong>Board saved.</strong></p></div>';
        echo '<form class="cm-editor cm-corkboard-dashboard-editor" method="post" action="'.esc_url($this->dashboard_admin_post_url()).'" data-cm-ajax-save="1">';
        wp_nonce_field('cm_wlfd_save_corkboard');
        echo '<input type="hidden" name="action" value="cm_wlfd_save_corkboard">';
        echo '<input type="hidden" name="post_id" value="'.esc_attr($post_id).'">';
        echo '<label>Job site / board title<input class="cm-input big" name="post_title" required value="'.esc_attr($post ? $post->post_title : '').'"></label>';
        echo '<label>Board description';
        wp_editor($post ? $post->post_content : '', 'cm_corkboard_dashboard_content', ['textarea_name'=>'post_content','media_buttons'=>true,'textarea_rows'=>7,'teeny'=>false,'quicktags'=>true]);
        echo '</label>';
        echo '<div class="cm-corkboard-toolbar"><h3>Tasks / Sticky Notes</h3><button type="button" class="cm-btn" id="cm-dashboard-add-note">Add Task</button></div>';
        echo '<div id="cm-dashboard-note-list">';
        foreach ($notes as $i => $note) echo $this->corkboard_note_row($i, $note);
        echo '</div>';
        echo '<template id="cm-dashboard-note-template">'.$this->corkboard_note_row('__INDEX__', [], true).'</template>';
        echo '<p class="cm-editor-actions"><button class="cm-btn" type="submit">'.($post ? 'Update Board' : 'Publish Board').'</button>';
        if ($post) echo '<a class="cm-btn ghost" href="'.$this->url('corkboard-view',['post_id'=>$post_id]).'">View in Dashboard</a>';
        echo '</p></form>';
        return ob_get_clean();
    }

    private function corkboard_note_row($index, $note=[], $return=false){
        $note = wp_parse_args((array)$note, [
            'title'=>'','content'=>'','url'=>'','image'=>'','colour'=>'yellow',
            'x'=>'','y'=>'','width'=>'230','rotation'=>'0','fastener'=>'none','pinned'=>'0',
            'note_id'=>'','author_id'=>'','author_name'=>'','created_at'=>''
        ]);
        ob_start();
        echo '<article class="cm-dashboard-note-row">';
        echo '<div class="cm-dashboard-note-head"><span class="dashicons dashicons-move cm-dashboard-note-handle"></span><strong>Task / Sticky Note</strong><button type="button" class="button-link-delete cm-dashboard-remove-note">Remove</button></div>';
        echo '<div class="cm-dashboard-note-fields">';
        echo '<input type="hidden" name="cm_corkboard_notes['.esc_attr($index).'][note_id]" value="'.esc_attr($note['note_id']).'">';
        echo '<input type="hidden" name="cm_corkboard_notes['.esc_attr($index).'][author_id]" value="'.esc_attr($note['author_id']).'">';
        echo '<input type="hidden" name="cm_corkboard_notes['.esc_attr($index).'][author_name]" value="'.esc_attr($note['author_name']).'">';
        echo '<input type="hidden" name="cm_corkboard_notes['.esc_attr($index).'][created_at]" value="'.esc_attr($note['created_at']).'">';
        echo '<label>Task title<input class="cm-input" name="cm_corkboard_notes['.esc_attr($index).'][title]" value="'.esc_attr($note['title']).'"></label>';
        echo '<label class="cm-dashboard-pinned-option"><input type="checkbox" name="cm_corkboard_notes['.esc_attr($index).'][pinned]" value="1" '.checked(!empty($note['pinned']), true, false).'> 📌 Pinned to this board</label>';
        echo '<label>Task details<textarea class="cm-input" rows="4" name="cm_corkboard_notes['.esc_attr($index).'][content]">'.esc_textarea($note['content']).'</textarea></label>';
        echo '<div class="cm-dashboard-note-grid">';
        echo '<label>Colour<select class="cm-input" name="cm_corkboard_notes['.esc_attr($index).'][colour]">';
        foreach (['yellow'=>'Yellow','pink'=>'Pink','blue'=>'Blue','green'=>'Green','white'=>'White'] as $value=>$label) echo '<option value="'.esc_attr($value).'" '.selected($note['colour'],$value,false).'>'.esc_html($label).'</option>';
        echo '</select></label>';
        echo '<label>Fastener<select class="cm-input" name="cm_corkboard_notes['.esc_attr($index).'][fastener]">';
        foreach (['pin'=>'📌 Push Pin','drawing-pin'=>'📍 Drawing Pin','clip'=>'📎 Paper Clip','magnet'=>'🧲 Magnet','none'=>'None'] as $value=>$label) echo '<option value="'.esc_attr($value).'" '.selected($note['fastener'],$value,false).'>'.esc_html($label).'</option>';
        echo '</select></label>';
        echo '<label>Link URL<input class="cm-input" type="url" name="cm_corkboard_notes['.esc_attr($index).'][url]" value="'.esc_attr($note['url']).'"></label>';
        echo '<label>Image URL<span class="cm-dashboard-image-line"><input class="cm-input cm-dashboard-note-image" type="url" name="cm_corkboard_notes['.esc_attr($index).'][image]" value="'.esc_attr($note['image']).'"><button type="button" class="cm-btn ghost cm-dashboard-pick-note-image">Choose</button></span></label>';
        echo '<label>Left %<input class="cm-input" type="number" min="0" max="90" name="cm_corkboard_notes['.esc_attr($index).'][x]" value="'.esc_attr($note['x']).'" placeholder="Auto"></label>';
        echo '<label>Top px<input class="cm-input" type="number" min="0" name="cm_corkboard_notes['.esc_attr($index).'][y]" value="'.esc_attr($note['y']).'" placeholder="Auto"></label>';
        echo '<label>Width px<input class="cm-input" type="number" min="160" max="420" name="cm_corkboard_notes['.esc_attr($index).'][width]" value="'.esc_attr($note['width']).'"></label>';
        echo '<label>Rotation °<input class="cm-input" type="number" min="-12" max="12" name="cm_corkboard_notes['.esc_attr($index).'][rotation]" value="'.esc_attr($note['rotation']).'"></label>';
        echo '</div></div></article>';
        $html = ob_get_clean();
        if ($return) return $html;
        echo $html;
    }

    private function save_corkboard_notes_meta($post_id, $raw_notes){
        $clean = [];
        if (!is_array($raw_notes)) $raw_notes = [];

        $existing_notes = get_post_meta($post_id, '_cm_corkboard_notes', true);
        if (!is_array($existing_notes)) $existing_notes = [];

        $existing_by_id = [];
        foreach ($existing_notes as $existing_note) {
            if (!is_array($existing_note) || empty($existing_note['note_id'])) continue;
            $existing_by_id[(string)$existing_note['note_id']] = $existing_note;
        }

        $current_user = wp_get_current_user();
        $posted_time = current_time('mysql');

        foreach ($raw_notes as $note) {
            if (!is_array($note)) continue;

            $title = sanitize_text_field(wp_unslash($note['title'] ?? ''));
            $content = sanitize_textarea_field(wp_unslash($note['content'] ?? ''));
            $image = esc_url_raw(wp_unslash($note['image'] ?? ''));

            if ($title === '' && $content === '' && $image === '') continue;

            $colour = sanitize_key($note['colour'] ?? 'yellow');
            if (!in_array($colour, ['yellow','pink','blue','green','white'], true)) {
                $colour = 'yellow';
            }

            $fastener = sanitize_key($note['fastener'] ?? 'none');
            if (!in_array($fastener, ['pin','drawing-pin','clip','magnet','none'], true)) {
                $fastener = 'none';
            }

            $pinned = !empty($note['pinned']) ? 1 : 0;

            $note_id = sanitize_text_field(wp_unslash($note['note_id'] ?? ''));
            $original = ($note_id !== '' && isset($existing_by_id[$note_id]))
                ? $existing_by_id[$note_id]
                : null;

            if ($original) {
                // Preserve the original posting identity and timestamp permanently.
                $author_id = absint($original['author_id'] ?? 0);
                $author_name = sanitize_text_field($original['author_name'] ?? '');
                $created_at = sanitize_text_field($original['created_at'] ?? '');

                if (!$author_id) $author_id = (int)$current_user->ID;
                if ($author_name === '') $author_name = $current_user->display_name;
                if ($created_at === '' || strtotime($created_at) === false) $created_at = $posted_time;
            } else {
                $note_id = wp_generate_uuid4();
                $author_id = (int)$current_user->ID;
                $author_name = $current_user->display_name;
                $created_at = $posted_time;
            }

            $clean[] = [
                'note_id'     => $note_id,
                'author_id'   => $author_id,
                'author_name' => $author_name,
                'created_at'  => $created_at,
                'title'       => $title,
                'content'     => $content,
                'url'         => esc_url_raw(wp_unslash($note['url'] ?? '')),
                'image'       => $image,
                'colour'      => $colour,
                'fastener'    => $fastener,
                'pinned'      => $pinned,
                'x'           => ($note['x'] ?? '') === '' ? '' : min(90, max(0, intval($note['x']))),
                'y'           => ($note['y'] ?? '') === '' ? '' : max(0, intval($note['y'])),
                'width'       => min(420, max(160, intval($note['width'] ?? 230))),
                'rotation'    => min(12, max(-12, intval($note['rotation'] ?? 0))),
            ];
        }

        update_post_meta($post_id, '_cm_corkboard_notes', $clean);
    }

    private function persist_corkboard_from_request(){
        $post_id = absint($_POST['post_id'] ?? 0);
        if ($post_id && !current_user_can('edit_post',$post_id)) return new WP_Error('forbidden','No permission.');
        if (!$post_id && !current_user_can('edit_posts')) return new WP_Error('forbidden','No permission.');

        $data = [
            'post_title'=>sanitize_text_field(wp_unslash($_POST['post_title'] ?? '')),
            'post_content'=>wp_kses_post(wp_unslash($_POST['post_content'] ?? '')),
            'post_status'=>'publish',
            'post_type'=>'cm_corkboard',
        ];
        if ($post_id) {
            $data['ID']=$post_id;
            $saved = wp_update_post(wp_slash($data), true);
        } else {
            $data['post_author']=get_current_user_id();
            $saved = wp_insert_post(wp_slash($data), true);
        }
        if (is_wp_error($saved)) return $saved;
        $post_id = absint($saved);
        $this->save_corkboard_notes_meta($post_id, $_POST['cm_corkboard_notes'] ?? []);
        clean_post_cache($post_id);
        return $post_id;
    }

    public function save_corkboard(){
        check_admin_referer('cm_wlfd_save_corkboard');
        $post_id = $this->persist_corkboard_from_request();
        if (is_wp_error($post_id)) wp_die($post_id->get_error_message());
        wp_safe_redirect($this->url('corkboard-edit',['post_id'=>$post_id,'message'=>1,'cm_saved'=>time()]));
        exit;
    }

    public function ajax_save_corkboard(){
        check_ajax_referer('cm_wlfd_save_corkboard', '_wpnonce');
        $post_id = $this->persist_corkboard_from_request();
        if (is_wp_error($post_id)) wp_send_json_error(['message'=>$post_id->get_error_message()], 403);
        $post = get_post($post_id);
        wp_send_json_success([
            'post_id'=>$post_id,
            'modified'=>get_post_modified_time('c', false, $post),
            'edit_url'=>$this->url('corkboard-edit',['post_id'=>$post_id]),
            'view_url'=>$this->url('corkboard-view',['post_id'=>$post_id]),
            'message'=>'Board saved.',
        ]);
    }

    private function corkboard_live_content($post){
        $post_id = (int)$post->ID;
        $notes = get_post_meta($post_id, '_cm_corkboard_notes', true);
        if (!is_array($notes)) $notes = [];
        $positions = [[4,35],[34,55],[65,40],[10,335],[39,380],[73,320],[23,635],[57,650]];
        $icons = ['pin'=>'','drawing-pin'=>'📍','clip'=>'📎','magnet'=>'🧲','none'=>''];

        // Stable pinned-first ordering: preserve the saved order inside both groups.
        $pinned_notes = [];
        $unpinned_notes = [];
        foreach ($notes as $note) {
            if (!empty($note['pinned'])) $pinned_notes[] = $note;
            else $unpinned_notes[] = $note;
        }
        $notes = array_merge($pinned_notes, $unpinned_notes);

        $board_author = get_userdata((int)$post->post_author);
        $board_author_name = $board_author ? $board_author->display_name : 'Unknown user';

        $out = '<div class="cm-corkboard-live-content">';
        if (trim($post->post_content)) $out .= '<div class="cm-dashboard-board-intro">'.wpautop(wp_kses_post($post->post_content)).'</div>';
        $out .= '<section class="cm-dashboard-corkboard"><div class="cm-dashboard-stack-columns">';
        foreach ($notes as $i=>$note) {
            if ($i % 5 === 0) $out .= '<div class="cm-dashboard-stack-column">';
            $width = intval($note['width'] ?? 230);
            $rotation = intval($note['rotation'] ?? 0);
            $colour = sanitize_html_class($note['colour'] ?? 'yellow');
            $fastener = $icons[$note['fastener'] ?? 'none'] ?? '';
            $out .= '<article class="cm-dashboard-sticky cm-dashboard-sticky--'.esc_attr($colour).'" style="--note-width:'.esc_attr($width).'px;--rotation:'.esc_attr($rotation).'deg">';
            if ($fastener !== '') $out .= '<span class="cm-dashboard-fastener" aria-hidden="true">'.esc_html($fastener).'</span>';
            if (!empty($note['pinned'])) $out .= '<span class="cm-dashboard-pinned-icon" aria-hidden="true">📌</span>';
            if (!empty($note['title'])) $out .= '<h3>'.esc_html($note['title']).'</h3>';
            $note_author = !empty($note['author_name']) ? $note['author_name'] : $board_author_name;
            $note_time_raw = !empty($note['created_at']) ? $note['created_at'] : $post->post_date;
            $note_timestamp = strtotime($note_time_raw);
            $note_time = $note_timestamp ? wp_date(get_option('date_format').' | '.get_option('time_format'), $note_timestamp, wp_timezone()) : '';
            $out .= '<div class="cm-dashboard-sticky-meta">'.esc_html($note_author).($note_time !== '' ? ' | '.esc_html($note_time) : '').'</div>';
            if (!empty($note['content'])) $out .= '<div>'.nl2br(esc_html($note['content'])).'</div>';
            if (!empty($note['image'])) $out .= '<img src="'.esc_url($note['image']).'" alt="">';
            if (!empty($note['url'])) $out .= '<a class="cm-dashboard-sticky-link" href="'.esc_url($note['url']).'" aria-label="Open task link"></a>';
            $out .= '</article>';
            if ($i % 5 === 4 || $i === count($notes) - 1) $out .= '</div>';
        }
        $out .= '</div>';
        if (!$notes) $out .= '<p class="cm-dashboard-board-empty">No tasks have been added to this board yet.</p>';
        return $out.'</section></div>';
    }

    private function corkboard_view($post_id){
        if (!$this->corkboard_plugin_ready()) return '<p>The private CM Corkboard plugin must be activated.</p>';
        $post = get_post($post_id);
        if (!$post || $post->post_type !== 'cm_corkboard') return '<p>Board not found.</p>';
        if (!current_user_can('read_post',$post_id) && !current_user_can('edit_post',$post_id)) return '<p>You do not have permission to view this board.</p>';

        $board_modified_iso = get_post_modified_time('c', false, $post);
        $out = '<div class="cm-title cm-corkboard-view-header" data-cm-corkboard-id="'.esc_attr($post_id).'" data-cm-corkboard-modified="'.esc_attr($board_modified_iso).'"><h2>'.esc_html(get_the_title($post)).'</h2><p><a href="'.$this->url('corkboards').'">← All boards</a> · <a href="'.$this->url('corkboard-edit',['post_id'=>$post_id]).'">Edit board</a></p></div>';
        $out .= '<div class="cm-corkboard-presentation" id="cm-corkboard-presentation">';
        $out .= '<button type="button" class="cm-btn cm-corkboard-fullscreen-button" aria-controls="cm-corkboard-presentation" aria-pressed="false"><span class="dashicons dashicons-fullscreen-alt" aria-hidden="true"></span><span class="cm-corkboard-fullscreen-label">Full Screen</span></button>';
        $out .= $this->corkboard_live_content($post);
        return $out.'</div>';
    }

    public function ajax_corkboard_content(){
        check_ajax_referer('cm_wlfd_corkboard_refresh', 'nonce');
        $post_id = absint($_GET['post_id'] ?? 0);
        $post = get_post($post_id);
        if (!$post || $post->post_type !== 'cm_corkboard') wp_send_json_error(['message'=>'Board not found.'], 404);
        if (!current_user_can('read_post',$post_id) && !current_user_can('edit_post',$post_id)) wp_send_json_error(['message'=>'No permission.'], 403);
        wp_send_json_success([
            'modified'=>get_post_modified_time('c', false, $post),
            'title'=>get_the_title($post),
            'html'=>$this->corkboard_live_content($post),
        ]);
    }

    public function ajax_corkboard_modified(){
        check_ajax_referer('cm_wlfd_corkboard_refresh', 'nonce');
        $post_id = absint($_GET['post_id'] ?? 0);
        $post = get_post($post_id);

        if (!$post || $post->post_type !== 'cm_corkboard') {
            wp_send_json_error(['message'=>'Board not found.'], 404);
        }

        if (!current_user_can('read_post', $post_id) && !current_user_can('edit_post', $post_id)) {
            wp_send_json_error(['message'=>'No permission.'], 403);
        }

        wp_send_json_success([
            'modified'=>get_post_modified_time('c', false, $post),
        ]);
    }

    private function content_tabs(){
        $current_tab = sanitize_key($_GET['tab'] ?? 'blog');
        $allowed_tabs = ['blog','other-content','elementor','live-blog'];
        if (current_user_can('manage_options')) $allowed_tabs[] = 'github';
        if (!in_array($current_tab, $allowed_tabs, true)) $current_tab = 'blog';
        ob_start();
        ?>
        <style>
.cm-tabs-wrapper {
    background: #fff;
    border-bottom: 1px solid #e5e7eb;
    margin-bottom: 18px;
}
.cm-tabs {
    display: flex;
    gap: 0;
    margin: 0;
    padding: 0;
    overflow-x: auto;
    overflow-y: hidden;
    -webkit-overflow-scrolling: touch;
    scroll-behavior: smooth;
}
.cm-tabs::-webkit-scrollbar { height: 3px; }
.cm-tabs::-webkit-scrollbar-track { background: #f0f0f0; }
.cm-tabs::-webkit-scrollbar-thumb { background: #ccc; border-radius: 3px; }
.cm-tab {
    padding: 14px 20px;
    border: none;
    background: none;
    cursor: pointer;
    font-size: 14px;
    font-weight: 600;
    color: #64748b;
    white-space: nowrap;
    border-bottom: 3px solid transparent;
    transition: color 0.2s, border-color 0.2s;
    font-family: inherit;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
}
.cm-tab:hover { color: #2563eb; }
.cm-tab.is-active { color: #2563eb; border-bottom-color: #2563eb; }
.cm-wlfd-tab-panel { min-height: 220px; }
.cm-wlfd-tab-panel.is-loading { opacity: .72; pointer-events: none; }
@media(max-width: 768px) {
    .cm-tab { padding: 12px 16px; font-size: 13px; }
}
</style>
        <div class="cm-tabs-wrapper" data-cm-tabs-wrapper="1">
            <div class="cm-tabs" role="tablist" aria-label="Content tabs">
                <a class="cm-tab <?php echo $current_tab === 'blog' ? 'is-active' : ''; ?>" role="tab" data-cm-tab="blog" href="<?php echo esc_url($this->url('content', ['tab' => 'blog'])); ?>">Blog</a>
                <a class="cm-tab <?php echo $current_tab === 'other-content' ? 'is-active' : ''; ?>" role="tab" data-cm-tab="other-content" href="<?php echo esc_url($this->url('content', ['tab' => 'other-content'])); ?>">Other Content</a>
                <a class="cm-tab <?php echo $current_tab === 'elementor' ? 'is-active' : ''; ?>" role="tab" data-cm-tab="elementor" href="<?php echo esc_url($this->url('content', ['tab' => 'elementor'])); ?>">Elementor</a>
                <a class="cm-tab <?php echo $current_tab === 'live-blog' ? 'is-active' : ''; ?>" role="tab" data-cm-tab="live-blog" href="<?php echo esc_url($this->url('content', ['tab' => 'live-blog'])); ?>">Live Blog</a>
                <?php if ( current_user_can( 'manage_options' ) ) : ?>
                    <a class="cm-tab <?php echo $current_tab === 'github' ? 'is-active' : ''; ?>" role="tab" data-cm-tab="github" href="<?php echo esc_url($this->url('content', ['tab' => 'github'])); ?>">GitHub</a>
                <?php endif; ?>
            </div>
        </div>
        <div id="cm-wlfd-tab-panel" class="cm-wlfd-tab-panel" aria-live="polite">
            <?php echo $this->render_content_tab_panel($current_tab); ?>
        </div>
        <?php
        return ob_get_clean();
    }

    private function render_content_tab_panel($current_tab){
        $current_tab = sanitize_key($current_tab ?: 'blog');
        if ($current_tab === 'blog') return $this->blog_post_screen();
        if ($current_tab === 'other-content') return $this->other_content_screen();
        if ($current_tab === 'elementor') return $this->elementor_screen();
        if ($current_tab === 'live-blog') return $this->live_blog_screen();
        if ($current_tab === 'github') return $this->github_content_screen();
        return $this->blog_post_screen();
    }

    public function ajax_content_tab(){
        check_ajax_referer('cm_wlfd_content_tab', 'nonce');
        if (!is_user_logged_in()) wp_send_json_error(['message'=>'Login required.'], 401);
        $tab = sanitize_key(wp_unslash($_POST['tab'] ?? 'blog'));
        $allowed_tabs = ['blog','other-content','elementor','live-blog'];
        if (current_user_can('manage_options')) $allowed_tabs[] = 'github';
        if (!in_array($tab, $allowed_tabs, true)) $tab = 'blog';
        $html = $this->render_content_tab_panel($tab);
        wp_send_json_success(['tab'=>$tab, 'html'=>$html]);
    }
    
    private function content_browser(){
        $site_id = absint($_GET['site_id'] ?? get_current_blog_id());
        if (is_multisite()) switch_to_blog($site_id);
        $types = $this->public_types();
        $pt = sanitize_key($_GET['post_type'] ?? (array_key_first($types) ?: 'post'));
        if (!isset($types[$pt])) $pt = array_key_first($types) ?: 'post';
        $args = ['post_type'=>$pt,'post_status'=>['publish','draft','pending','private'],'posts_per_page'=>80,'orderby'=>'modified','order'=>'DESC'];
        if (!current_user_can('edit_others_posts')) $args['author']=get_current_user_id();
        $q = new WP_Query($args);
        $out='<div class="cm-title"><h2>Content</h2><p>Network-wide picker: site → CPT/plugin CPT/CPT UI CPT/Live Blog → frontend editor with ACF.</p></div>';
        if (!empty($_GET['deleted'])) $out .= '<div class="cm-notice updated"><p><strong>Content moved to Trash.</strong></p></div>';
        if (!empty($_GET['service_menu_added'])) $out .= '<div class="cm-notice updated"><p><strong>Added to Service Header Menu.</strong></p></div>';
        $out.='<form class="cm-filter" method="get">'.$this->query_hidden('content').'<input type="hidden" name="tab" value="other-content">';
        if ($site_id === 21) $site_id = get_current_blog_id();
        $out.=$this->site_select($site_id).'<div style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap;"><label style="flex:1;min-width:200px;">CPT <select name="post_type" class="cm-input" onchange="this.form.submit()">';
        foreach($types as $k=>$obj) $out.='<option value="'.esc_attr($k).'" '.selected($pt,$k,false).'>'.esc_html($this->type_label($k,$obj)).'</option>';
        $out.='</select></label><a class="cm-btn" href="'.$this->url('add-new',['site_id'=>21,'post_type'=>$pt,'tab'=>'blog']).'">Add New '.esc_html($types[$pt]->labels->singular_name ?? $pt).'</a></div><noscript><button class="cm-btn">Load</button></noscript></form><div class="cm-list">';
        if ($q->have_posts()) {
            foreach($q->posts as $p){
                $perma=get_permalink($p); $acf_count=function_exists('get_field_objects') ? count((array)get_field_objects($p->ID)) : 0;
                $out.='<article class="cm-row"><div><strong>'.esc_html(get_the_title($p) ?: '(no title)').'</strong><small>'.esc_html($this->type_label($pt,$types[$pt])).' · '.esc_html($p->post_status).' · ACF fields: '.esc_html($acf_count).' · '.esc_html($perma).'</small></div><div class="cm-row-actions"><a class="cm-btn" href="'.$this->url('edit',['post_id'=>$p->ID,'site_id'=>21,'post_type'=>$pt]).'">Edit</a>'.$this->elementor_editor_button($p->ID,$site_id,$pt).'<a class="cm-btn ghost" href="'.esc_url($perma).'">View</a>'.$this->service_header_menu_button($p->ID,$site_id,$pt,'content').$this->delete_button($p->ID,$site_id,$pt,'content').'</div></article>';
            }
        } else $out.='<p>No content found for this CPT.</p>';
        $out.='</div>';
        if (is_multisite()) restore_current_blog(); return $out;
    }
    private function editor_screen($post_id=0){
        $site_id=absint($_GET['site_id'] ?? get_current_blog_id()); $pt=sanitize_key($_GET['post_type'] ?? 'post');
        if (is_multisite()) switch_to_blog($site_id);
        $types=$this->public_types();
        $post=$post_id?get_post($post_id):null; if ($post) $pt=$post->post_type;
        if (!isset($types[$pt]) && !$post) { if (is_multisite()) restore_current_blog(); return '<p>This CPT is not registered on this site.</p>'; }
        $can = $post ? current_user_can('edit_post',$post_id) : current_user_can('edit_posts');
        if (!$can) { if (is_multisite()) restore_current_blog(); return '<p>You do not have permission to edit this content.</p>'; }
        ob_start();
        
        $back = sanitize_key($_GET['back'] ?? 'content');
        $tab = sanitize_key($_GET['tab'] ?? 'blog');
        $back_url = $this->url('content',['site_id'=>21,'post_type'=>$pt,'tab'=>$tab]);
        $site_name = $this->site_name($site_id);
        echo '<div class="cm-title"><h2>'.($post?'Edit ':'Add New ').esc_html($types[$pt]->labels->singular_name ?? $pt).' <small>('.esc_html($pt.$this->type_source_suffix($pt)).')</small></h2><p>Site: <strong>'.esc_html($site_name).'</strong> (#'.esc_html($site_id).') · <a href="'.$back_url.'">← Back</a></p></div>';
        if (!empty($_GET['message'])) echo $this->save_message($post ? $post->ID : $post_id, $site_id, $pt);
        echo '<form class="cm-editor" method="post" action="'.esc_url($this->dashboard_admin_post_url()).'">'; wp_nonce_field('cm_wlfd_save_post');
        echo '<input type="hidden" name="action" value="cm_wlfd_save_post"><input type="hidden" name="post_id" value="'.esc_attr($post ? $post->ID : $post_id).'"><input type="hidden" name="site_id" value="'.esc_attr($site_id).'"><input type="hidden" name="post_type" value="'.esc_attr($pt).'"><input type="hidden" name="back" value="'.esc_attr($_GET['back'] ?? 'content').'">';
        if ($pt === 'cm_podcast_app' && !$post && !empty($_GET['podcast_item_type'])) echo '<input type="hidden" name="cm_podcast_dashboard_item_type" value="'.esc_attr(sanitize_key($_GET['podcast_item_type'])).'">';
        echo '<label>Title<input class="cm-input big" name="post_title" value="'.esc_attr($post ? $post->post_title : '').'"></label>';
        if ($post) echo $this->permalink_line($post->ID);
        echo '<input type="hidden" name="post_status" value="publish">';
        wp_editor($post ? $post->post_content : '', 'cm_wlfd_content', ['textarea_name'=>'post_content','media_buttons'=>true,'textarea_rows'=>16,'teeny'=>false,'quicktags'=>true]);
        echo '<div class="cm-featured"><strong>Featured image</strong><input type="hidden" id="cm_featured_id" name="featured_id" value="'.esc_attr($post_id ? get_post_thumbnail_id($post ? $post->ID : $post_id) : 0).'"><button type="button" class="cm-btn ghost" id="cm_pick_featured">Choose image</button><span id="cm_featured_label">'.($post&&has_post_thumbnail($post->ID)?'Image selected':'No image selected').'</span></div>';
        echo $this->acf_box($post ? $post->ID : 0, $pt);
        echo '<p class="cm-editor-actions">';
        echo '<button class="cm-btn" type="submit" name="cm_save_submit" value="1">'.esc_html($this->status_action_label($post)).'</button>';
        if ($this->elementor_is_available_for_post_type($pt)) {
            if ($post) echo $this->elementor_editor_button($post->ID, $site_id, $pt);
            echo '<button class="cm-btn ghost elementor" type="submit" name="cm_open_elementor" value="1">'.esc_html($post ? 'Update & Open Elementor' : 'Publish & Open Elementor').'</button>';
        }
        echo '</p></form>';
        if ($post) {
            echo '<div class="cm-editor-menu-row">'.$this->service_header_menu_button($post->ID,$site_id,$pt,$back).'</div>';
        }
        // Keep delete outside the publish/update form. Nested forms make some browsers
        // submit the delete action when the user clicks Publish after a new post has
        // been created and reloaded into edit mode.
        if ($post) {
            echo '<div class="cm-editor-delete-row">'.$this->delete_button($post->ID,$site_id,$pt,$back,$back_url).'</div>';
        }
        $html=ob_get_clean(); if (is_multisite()) restore_current_blog(); return $html;
    }
    public function save_post(){
        check_admin_referer('cm_wlfd_save_post');
        $site_id = absint($_POST['site_id'] ?? get_current_blog_id());
        if (is_multisite()) switch_to_blog($site_id);

        $post_id = absint($_POST['post_id'] ?? 0);
        $pt = sanitize_key($_POST['post_type'] ?? 'post');
        $back = sanitize_key($_POST['back'] ?? 'content');

        if ($post_id && !current_user_can('edit_post', $post_id)) wp_die('No permission.');
        if (!$post_id && !current_user_can('edit_posts')) wp_die('No permission.');

        $data = [
            'post_title'   => sanitize_text_field($_POST['post_title'] ?? ''),
            'post_content' => wp_kses_post($_POST['post_content'] ?? ''),
            'post_status'  => 'publish',
            'post_type'    => $pt,
        ];

        if ($post_id) {
            $data['ID'] = $post_id;
            $saved_id = wp_update_post(wp_slash($data), true);
        } else {
            $data['post_author'] = get_current_user_id();
            $saved_id = wp_insert_post(wp_slash($data), true);
        }

        if (is_wp_error($saved_id)) {
            if (is_multisite()) restore_current_blog();
            wp_die($saved_id->get_error_message());
        }

        $post_id = absint($saved_id);

        if (!empty($_POST['featured_id'])) {
            set_post_thumbnail($post_id, absint($_POST['featured_id']));
        } else {
            delete_post_thumbnail($post_id);
        }

        if (function_exists('acf_save_post')) {
            acf_save_post($post_id);
        }

        if ($pt === 'cm_corkboard') {
            $this->save_corkboard_notes_meta($post_id, $_POST['cm_corkboard_notes'] ?? []);
        }



        clean_post_cache($post_id);

        // Match the default Classic Editor flow exactly enough for the frontend:
        // save first, keep the saved post ID, restore the original blog context, then
        // redirect straight back to the frontend EDIT route with post_id in the URL.
        // That means Add New becomes Edit after first publish, and every later Publish
        // reloads the same editor with title/content/ACF still on screen.
        $saved_pt = get_post_type($post_id) ?: $pt;
        $open_elementor = !empty($_POST['cm_open_elementor']) && $this->elementor_is_available_for_post_type($saved_pt);
        $redirect = $open_elementor ? $this->elementor_edit_url($post_id, $site_id) : $this->edit_url_after_save($site_id, $post_id, $saved_pt, $back);
        if (is_multisite()) restore_current_blog();
        nocache_headers();
        wp_safe_redirect($redirect);
        exit;
    }
    public function delete_post(){
        check_admin_referer('cm_wlfd_delete_post');
        $site_id = absint($_POST['site_id'] ?? get_current_blog_id());
        $pt = sanitize_key($_POST['post_type'] ?? 'post');
        $back = sanitize_key($_POST['back'] ?? 'content');
        $id = absint($_POST['post_id'] ?? 0);
        if (is_multisite()) switch_to_blog($site_id);
        if (!$id || !current_user_can('delete_post', $id)) {
            if (is_multisite()) restore_current_blog();
            wp_die('No permission to delete this content.');
        }
        wp_trash_post($id);
        if (is_multisite()) restore_current_blog();
        $view = $back === 'live-blog' ? 'live-blog' : 'content';
        $fallback = $this->url($view, ['site_id'=>$site_id, 'post_type'=>$pt, 'deleted'=>1, 'cm_deleted'=>time()]);
        $return_to = isset($_POST['return_to']) ? wp_unslash($_POST['return_to']) : '';
        wp_safe_redirect($this->dashboard_safe_return_url($return_to, $fallback));
        exit;
    }

    private function elementor_is_available_for_post_type($post_type){
        $post_type = sanitize_key($post_type);
        if (!$post_type) return false;
        if (!(defined('ELEMENTOR_VERSION') || did_action('elementor/loaded') || class_exists('\\Elementor\\Plugin'))) return false;
        if (!post_type_exists($post_type)) return false;
        $support = get_option('elementor_cpt_support');
        if (is_array($support)) return in_array($post_type, $support, true);
        return in_array($post_type, ['post','page'], true);
    }

    private function elementor_editor_button($post_id, $site_id, $post_type, $label = 'Edit in Elementor'){
        $post_id = absint($post_id);
        if (!$post_id || !$this->elementor_is_available_for_post_type($post_type)) return '';
        return '<a class="cm-btn elementor cm-pwa-popup" data-cm-pwa-popup="1" target="_blank" rel="noopener" href="'.esc_url($this->elementor_edit_url($post_id, $site_id)).'">'.esc_html($label).'</a>';
    }

    private function elementor_edit_url($post_id, $site_id = 0){
        $post_id = absint($post_id);
        $site_id = absint($site_id ?: get_current_blog_id());
        if (is_multisite()) {
            return get_admin_url($site_id, 'post.php?post='.$post_id.'&action=elementor');
        }
        return admin_url('post.php?post='.$post_id.'&action=elementor');
    }

    private function elementor_screen(){
        $site_id = absint($_GET['site_id'] ?? get_current_blog_id());
        $site_name = $this->site_name($site_id);

        $pages = [];
        $templates = [];

        if (is_multisite()) switch_to_blog($site_id);

        if (post_type_exists('page')) {
            $pages = get_posts([
                'post_type'      => 'page',
                'post_status'    => ['publish','draft','pending','private','future'],
                'posts_per_page' => 50,
                'orderby'        => 'modified',
                'order'          => 'DESC',
                'suppress_filters' => false,
            ]);
        }

        if (post_type_exists('elementor_library')) {
            $templates = get_posts([
                'post_type'      => 'elementor_library',
                'post_status'    => ['publish','draft','pending','private','future'],
                'posts_per_page' => 50,
                'orderby'        => 'modified',
                'order'          => 'DESC',
                'suppress_filters' => false,
            ]);
        }

        if (is_multisite()) restore_current_blog();

        $out = '<div class="cm-title"><h2>Elementor</h2><p>Select a site, create pages/templates from the frontend dashboard, then open the direct Elementor editor in a new tab.</p></div>';
        $out .= '<form class="cm-filter" method="get">'.$this->query_hidden('elementor').$this->site_select($site_id).'<noscript><button class="cm-btn">Load Site</button></noscript></form>';
        $out .= '<div class="cm-title"><h2>'.esc_html($site_name).'</h2><p>Selected site #'.esc_html($site_id).' · Add and edit without loading the backend template manager.</p></div>';
        $out .= $this->elementor_create_forms($site_id);

        $out .= '<div class="cm-title"><h2>Pages</h2><p>Edit site pages straight in Elementor.</p></div><div class="cm-list">';
        if ($pages) {
            foreach ($pages as $p) {
                $url = $this->elementor_edit_url($p->ID, $site_id);
                $status = get_post_status_object($p->post_status);
                $out .= '<article class="cm-row"><div><strong>'.esc_html(get_the_title($p) ?: '(no title)').'</strong><small>Page #'.esc_html($p->ID).' · '.esc_html($status ? $status->label : $p->post_status).' · Last edited '.esc_html(get_the_modified_date('', $p)).'</small></div><div class="cm-row-actions"><a class="cm-btn cm-pwa-popup" data-cm-pwa-popup="1" target="_blank" rel="noopener" href="'.esc_url($url).'">Edit in Elementor</a></div></article>';
            }
        } else {
            $out .= '<article class="cm-row"><div><strong>No pages found</strong><small>Create a page first, then it will appear here.</small></div></article>';
        }
        $out .= '</div>';

        $out .= '<div class="cm-title" style="margin-top:18px"><h2>Templates</h2><p>Edit Elementor templates straight in Elementor.</p></div><div class="cm-list">';
        if ($templates) {
            foreach ($templates as $t) {
                $url = $this->elementor_edit_url($t->ID, $site_id);
                $type = get_post_meta($t->ID, '_elementor_template_type', true) ?: 'template';
                $status = get_post_status_object($t->post_status);
                $popup_id = 'cm-cond-'.$site_id.'-'.$t->ID;
                $out .= '<article class="cm-row cm-template-row"><div><strong>'.esc_html(get_the_title($t) ?: '(no title)').'</strong><small>'.esc_html(ucwords(str_replace('-', ' ', $type))).' #'.esc_html($t->ID).' · '.esc_html($status ? $status->label : $t->post_status).' · Last edited '.esc_html(get_the_modified_date('', $t)).'</small></div><div class="cm-row-actions"><button class="cm-btn ghost cm-condition-toggle" data-condition-target="'.esc_attr($popup_id).'">Conditions</button><a class="cm-btn cm-pwa-popup" data-cm-pwa-popup="1" target="_blank" rel="noopener" href="'.esc_url($url).'">Edit in Elementor</a></div><form id="'.esc_attr($popup_id).'" class="cm-condition-popup" method="post" action="'.esc_url($this->dashboard_admin_post_url()).'">'.wp_nonce_field('cm_wlfd_elementor_condition','_wpnonce',true,false).'<input type="hidden" name="action" value="cm_wlfd_elementor_condition"><input type="hidden" name="site_id" value="'.esc_attr($site_id).'"><input type="hidden" name="template_id" value="'.esc_attr($t->ID).'"><input type="hidden" name="template_type" value="'.esc_attr($type).'"><label>Condition<select class="cm-input" name="condition_kind"><option value="entire_site">Entire site</option><option value="single_cpt">Single CPT</option><option value="archive_cpt">CPT archive</option></select></label><label>CPT / content type<select class="cm-input" name="condition_post_type">'.$this->elementor_post_type_options($site_id, 'post').'</select></label><button class="cm-btn">Save Condition</button><button class="cm-btn ghost cm-condition-close">Close</button></form></article>';
            }
        } else {
            $out .= '<article class="cm-row"><div><strong>No Elementor templates found</strong><small>Templates will appear here once they exist on this site.</small></div></article>';
        }
        $out .= '</div>';

        return $out;
    }


    private function elementor_post_type_options($site_id, $selected='post'){
        $site_id = absint($site_id ?: get_current_blog_id());
        $types = [];
        if (is_multisite()) switch_to_blog($site_id);
        $objects = get_post_types(['public'=>true], 'objects');
        foreach ($objects as $name => $obj) {
            if (in_array($name, ['attachment','elementor_library'], true)) continue;
            $types[$name] = $obj->labels->singular_name ?: $obj->label ?: $name;
        }
        if (is_multisite()) restore_current_blog();
        if (!$types) $types = ['page'=>'Page','post'=>'Post'];
        $out = '';
        foreach ($types as $name => $label) {
            $out .= '<option value="'.esc_attr($name).'" '.selected($selected, $name, false).'>'.esc_html($label).' ('.esc_html($name).')</option>';
        }
        return $out;
    }

    private function elementor_create_forms($site_id){
        $site_id = absint($site_id ?: get_current_blog_id());
        $out = '<div class="cm-elementor-grid">';
        $out .= '<form class="cm-editor" method="post" target="cmWlfdPwaPopup" data-cm-pwa-popup-form="1" data-cm-refresh-origin="1" action="'.esc_url($this->dashboard_admin_post_url()).'">';
        $out .= wp_nonce_field('cm_wlfd_elementor_create_page','_wpnonce',true,false);
        $out .= '<input type="hidden" name="action" value="cm_wlfd_elementor_create_page"><input type="hidden" name="site_id" value="'.esc_attr($site_id).'">';
        $out .= '<h2>Add Page</h2><p>Create a draft page, then open it straight in Elementor.</p>';
        $out .= '<label>Page name<input class="cm-input" name="title" required placeholder="New page name"></label>';
        $out .= '<button class="cm-btn">Create & Open Elementor</button></form>';

        $out .= '<form class="cm-editor" method="post" target="cmWlfdPwaPopup" data-cm-pwa-popup-form="1" data-cm-refresh-origin="1" action="'.esc_url($this->dashboard_admin_post_url()).'">';
        $out .= wp_nonce_field('cm_wlfd_elementor_create_template','_wpnonce',true,false);
        $out .= '<input type="hidden" name="action" value="cm_wlfd_elementor_create_template"><input type="hidden" name="site_id" value="'.esc_attr($site_id).'">';
        $out .= '<h2>Add Template</h2><p>Create the Elementor template, save the display condition, then open the editor.</p>';
        $out .= '<label>Template name<input class="cm-input" name="title" required placeholder="New template name"></label>';
        $out .= '<label>Template type<select class="cm-input" name="template_type"><option value="single">Single</option><option value="archive">Archive</option><option value="page">Page</option><option value="section">Section</option><option value="header">Header</option><option value="footer">Footer</option></select></label>';
        $out .= '<label>Condition<select class="cm-input" name="condition_kind"><option value="entire_site">Entire site</option><option value="single_cpt">Single CPT</option><option value="archive_cpt">CPT archive</option></select></label>';
        $out .= '<label>CPT / content type<select class="cm-input" name="condition_post_type">'.$this->elementor_post_type_options($site_id, 'post').'</select></label>';
        $out .= '<button class="cm-btn">Create, Save Condition & Open Elementor</button></form>';
        $out .= '</div>';
        return $out;
    }

    private function elementor_seed_meta($post_id, $template_type=''){
        $post_id = absint($post_id);
        if (!$post_id) return;
        update_post_meta($post_id, '_elementor_edit_mode', 'builder');
        if (!metadata_exists('post', $post_id, '_elementor_data')) update_post_meta($post_id, '_elementor_data', '[]');
        if (defined('ELEMENTOR_VERSION')) update_post_meta($post_id, '_elementor_version', ELEMENTOR_VERSION);
        if ($template_type) update_post_meta($post_id, '_elementor_template_type', sanitize_key($template_type));
    }

    private function elementor_build_conditions($template_type, $kind, $post_type){
        $template_type = sanitize_key($template_type ?: 'single');
        $kind = sanitize_key($kind ?: 'entire_site');
        $post_type = sanitize_key($post_type ?: 'post');
        if ($kind === 'single_cpt') return ['include/singular/'.$post_type];
        if ($kind === 'archive_cpt') return ['include/archive/'.$post_type];
        if ($template_type === 'single') return ['include/singular'];
        if ($template_type === 'archive') return ['include/archive'];
        return ['include/general'];
    }

    public function elementor_create_page(){
        check_admin_referer('cm_wlfd_elementor_create_page');
        $site_id = absint($_POST['site_id'] ?? get_current_blog_id());
        $title = sanitize_text_field($_POST['title'] ?? 'New Elementor Page');
        if (is_multisite()) switch_to_blog($site_id);
        if (!current_user_can('edit_pages')) { if (is_multisite()) restore_current_blog(); wp_die('No permission to create pages.'); }
        $post_id = wp_insert_post(['post_type'=>'page','post_title'=>$title,'post_status'=>'draft','post_author'=>get_current_user_id()], true);
        if (is_wp_error($post_id)) { if (is_multisite()) restore_current_blog(); wp_die($post_id->get_error_message()); }
        $this->elementor_seed_meta($post_id, 'page');
        $url = $this->elementor_edit_url($post_id, $site_id);
        if (is_multisite()) restore_current_blog();
        wp_safe_redirect($url);
        exit;
    }

    public function elementor_create_template(){
        check_admin_referer('cm_wlfd_elementor_create_template');
        $site_id = absint($_POST['site_id'] ?? get_current_blog_id());
        $title = sanitize_text_field($_POST['title'] ?? 'New Elementor Template');
        $template_type = sanitize_key($_POST['template_type'] ?? 'single');
        $condition_kind = sanitize_key($_POST['condition_kind'] ?? 'entire_site');
        $condition_post_type = sanitize_key($_POST['condition_post_type'] ?? 'post');
        if (is_multisite()) switch_to_blog($site_id);
        if (!post_type_exists('elementor_library')) { if (is_multisite()) restore_current_blog(); wp_die('Elementor template post type is not available on this site.'); }
        if (!current_user_can('edit_posts')) { if (is_multisite()) restore_current_blog(); wp_die('No permission to create templates.'); }
        $post_id = wp_insert_post(['post_type'=>'elementor_library','post_title'=>$title,'post_status'=>'publish','post_author'=>get_current_user_id()], true);
        if (is_wp_error($post_id)) { if (is_multisite()) restore_current_blog(); wp_die($post_id->get_error_message()); }
        $this->elementor_seed_meta($post_id, $template_type);
        $conditions = $this->elementor_build_conditions($template_type, $condition_kind, $condition_post_type);
        update_post_meta($post_id, '_elementor_conditions', $conditions);
        update_post_meta($post_id, '_elementor_pro_conditions', $conditions);
        do_action('elementor/theme/register_conditions', $post_id, $conditions);
        $url = $this->elementor_edit_url($post_id, $site_id);
        if (is_multisite()) restore_current_blog();
        wp_safe_redirect($url);
        exit;
    }

    public function elementor_save_condition(){
        check_admin_referer('cm_wlfd_elementor_condition');
        $site_id = absint($_POST['site_id'] ?? get_current_blog_id());
        $template_id = absint($_POST['template_id'] ?? 0);
        $template_type = sanitize_key($_POST['template_type'] ?? 'single');
        $condition_kind = sanitize_key($_POST['condition_kind'] ?? 'entire_site');
        $condition_post_type = sanitize_key($_POST['condition_post_type'] ?? 'post');
        if (is_multisite()) switch_to_blog($site_id);
        if (!$template_id || !current_user_can('edit_post', $template_id)) { if (is_multisite()) restore_current_blog(); wp_die('No permission to update template conditions.'); }
        $conditions = $this->elementor_build_conditions($template_type, $condition_kind, $condition_post_type);
        update_post_meta($template_id, '_elementor_conditions', $conditions);
        update_post_meta($template_id, '_elementor_pro_conditions', $conditions);
        if (is_multisite()) restore_current_blog();
        wp_safe_redirect($this->url('elementor', ['site_id'=>$site_id, 'condition_saved'=>1]));
        exit;
    }



    public function register_rest_routes(){
        $ns = 'cm-wlfd/v1';
        register_rest_route($ns, '/settings', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_settings'],
            'permission_callback' => [$this, 'rest_can_read'],
        ]);
        register_rest_route($ns, '/sites', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_sites'],
            'permission_callback' => [$this, 'rest_can_read'],
        ]);
        register_rest_route($ns, '/types', [
            'methods' => 'GET',
            'callback' => [$this, 'rest_types'],
            'permission_callback' => [$this, 'rest_can_read'],
            'args' => ['site_id' => ['sanitize_callback' => 'absint']],
        ]);
        register_rest_route($ns, '/content', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'rest_content_list'],
                'permission_callback' => [$this, 'rest_can_read'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$this, 'rest_content_save'],
                'permission_callback' => [$this, 'rest_can_edit'],
            ],
        ]);
        register_rest_route($ns, '/content/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'rest_content_get'],
                'permission_callback' => [$this, 'rest_can_read'],
            ],
            [
                'methods' => 'DELETE',
                'callback' => [$this, 'rest_content_delete'],
                'permission_callback' => [$this, 'rest_can_edit'],
            ],
        ]);
    }

    public function rest_can_read(){
        return is_user_logged_in() && current_user_can('read');
    }

    public function rest_can_edit(){
        return is_user_logged_in() && current_user_can('edit_posts');
    }

    private function rest_switch_site($request){
        $site_id = absint($request->get_param('site_id') ?: get_current_blog_id());
        if (is_multisite()) switch_to_blog($site_id);
        return $site_id;
    }

    private function rest_restore_site(){
        if (is_multisite()) restore_current_blog();
    }

    public function rest_settings($request){
        return rest_ensure_response([
            'name' => 'CM Frontend Dashboard',
            'version' => self::VERSION,
            'mode' => 'self_hosted_rest_api',
            'login_url' => $this->url('login'),
            'dashboard_url' => $this->url('home'),
            'rest_base' => rest_url('cm-wlfd/v1/'),
            'current_user' => [
                'id' => get_current_user_id(),
                'name' => wp_get_current_user()->display_name,
                'can_edit' => current_user_can('edit_posts'),
            ],
            'notes' => 'This endpoint lets a standalone app or PWA talk to this self-hosted WordPress site while WordPress remains the content engine.',
        ]);
    }

    public function rest_sites($request){
        $sites = [];
        if (is_multisite()) {
            foreach (get_sites(['number' => 0]) as $site) {
                $details = get_blog_details($site->blog_id);
                $sites[] = [
                    'id' => (int)$site->blog_id,
                    'name' => $details ? $details->blogname : ('Site '.$site->blog_id),
                    'url' => $details ? $details->siteurl : get_home_url($site->blog_id),
                ];
            }
        } else {
            $sites[] = ['id' => get_current_blog_id(), 'name' => get_bloginfo('name'), 'url' => home_url('/')];
        }
        return rest_ensure_response($sites);
    }

    public function rest_types($request){
        $site_id = $this->rest_switch_site($request);
        $types = [];
        foreach ($this->public_types() as $slug => $obj) {
            $types[] = [
                'slug' => $slug,
                'label' => $obj->labels->name ?? $slug,
                'singular' => $obj->labels->singular_name ?? $slug,
                'source' => $obj->cm_source ?? 'registered',
            ];
        }
        $this->rest_restore_site();
        return rest_ensure_response(['site_id' => $site_id, 'types' => $types]);
    }

    public function rest_content_list($request){
        $site_id = $this->rest_switch_site($request);
        $post_type = sanitize_key($request->get_param('post_type') ?: 'post');
        $status = sanitize_key($request->get_param('status') ?: 'any');
        $author = absint($request->get_param('author'));
        $search = sanitize_text_field($request->get_param('search') ?: '');
        $args = [
            'post_type' => $post_type,
            'post_status' => $status === 'any' ? ['publish','draft','pending','private','future'] : $status,
            'posts_per_page' => min(100, max(1, absint($request->get_param('per_page') ?: 50))),
            'orderby' => 'modified',
            'order' => 'DESC',
        ];
        if ($author) $args['author'] = $author;
        if ($search !== '') $args['s'] = $search;
        $posts = get_posts($args);
        $rows = [];
        foreach ($posts as $post) {
            if (!current_user_can('edit_post', $post->ID) && !current_user_can('read_post', $post->ID)) continue;
            $rows[] = $this->rest_post_payload($post, $site_id, false);
        }
        $this->rest_restore_site();
        return rest_ensure_response(['site_id' => $site_id, 'post_type' => $post_type, 'items' => $rows]);
    }

    public function rest_content_get($request){
        $site_id = $this->rest_switch_site($request);
        $post_id = absint($request['id']);
        $post = get_post($post_id);
        if (!$post || (!current_user_can('edit_post', $post_id) && !current_user_can('read_post', $post_id))) {
            $this->rest_restore_site();
            return new WP_Error('cm_wlfd_not_found', 'Content not found or not allowed.', ['status' => 404]);
        }
        $payload = $this->rest_post_payload($post, $site_id, true);
        $this->rest_restore_site();
        return rest_ensure_response($payload);
    }

    public function rest_content_save($request){
        $site_id = $this->rest_switch_site($request);
        $post_id = absint($request->get_param('id'));
        $post_type = sanitize_key($request->get_param('post_type') ?: 'post');
        $status = sanitize_key($request->get_param('status') ?: 'draft');
        if (!in_array($status, ['draft','pending','publish','private'], true)) $status = 'draft';
        $data = [
            'post_type' => $post_type,
            'post_title' => sanitize_text_field($request->get_param('title') ?: 'Untitled'),
            'post_content' => wp_kses_post($request->get_param('content') ?: ''),
            'post_excerpt' => wp_kses_post($request->get_param('excerpt') ?: ''),
            'post_status' => $status,
        ];
        if ($post_id) {
            if (!current_user_can('edit_post', $post_id)) { $this->rest_restore_site(); return new WP_Error('cm_wlfd_forbidden', 'No permission to edit this item.', ['status' => 403]); }
            $data['ID'] = $post_id;
            $saved = wp_update_post($data, true);
        } else {
            if (!current_user_can('edit_posts')) { $this->rest_restore_site(); return new WP_Error('cm_wlfd_forbidden', 'No permission to create content.', ['status' => 403]); }
            $saved = wp_insert_post($data, true);
        }
        if (is_wp_error($saved)) { $this->rest_restore_site(); return $saved; }
        $acf = $request->get_param('acf');
        if (is_array($acf) && function_exists('update_field')) {
            foreach ($acf as $key => $value) update_field(sanitize_key($key), $value, $saved);
        }
        $post = get_post($saved);
        $payload = $this->rest_post_payload($post, $site_id, true);
        $this->rest_restore_site();
        return rest_ensure_response($payload);
    }

    public function rest_content_delete($request){
        $site_id = $this->rest_switch_site($request);
        $post_id = absint($request['id']);
        if (!$post_id || !current_user_can('delete_post', $post_id)) {
            $this->rest_restore_site();
            return new WP_Error('cm_wlfd_forbidden', 'No permission to delete this item.', ['status' => 403]);
        }
        $trashed = wp_trash_post($post_id);
        $this->rest_restore_site();
        return rest_ensure_response(['site_id' => $site_id, 'id' => $post_id, 'trashed' => (bool)$trashed]);
    }

    private function rest_post_payload($post, $site_id, $full=false){
        $payload = [
            'site_id' => (int)$site_id,
            'id' => (int)$post->ID,
            'post_type' => $post->post_type,
            'title' => get_the_title($post),
            'status' => $post->post_status,
            'author' => (int)$post->post_author,
            'author_name' => get_the_author_meta('display_name', $post->post_author),
            'modified' => get_post_modified_time('c', true, $post),
            'date' => get_post_time('c', true, $post),
            'permalink' => get_permalink($post),
            'edit_url' => $this->url('edit', ['site_id' => $site_id, 'post_id' => $post->ID, 'post_type' => $post->post_type, 'back' => 'content']),
        ];
        if ($full) {
            $payload['content'] = $post->post_content;
            $payload['excerpt'] = $post->post_excerpt;
            if (function_exists('get_fields')) $payload['acf'] = get_fields($post->ID) ?: [];
        }
        return $payload;
    }


    /**
     * Dashboard > View.
     * View All embeds every globally-visible repository using the newer CM GitHub
     * Connector browser. GitHub lets the user open one repository at a time.
     */
    private function view_tabs(){
        if (!current_user_can('manage_options')) {
            return '<div class="cm-title"><h2>View</h2></div><div class="cm-notice"><strong>Administrator access required.</strong> The GitHub repository viewer is restricted to administrators because connected tokens can include private repositories.</div>';
        }

        $tab = sanitize_key($_GET['view_tab'] ?? 'all');
        if (!in_array($tab, ['all','github'], true)) $tab = 'all';
        $all_url = $this->url('view', ['view_tab'=>'all']);
        $github_url = $this->url('view', ['view_tab'=>'github']);
        $out = '<div class="cm-title"><h2>View</h2><p>Read GitHub repositories inside the dashboard without opening GitHub for normal repository navigation.</p></div>';
        $out .= '<div class="cm-tabs-wrapper cm-view-tabs-wrapper"><div class="cm-tabs" role="tablist" aria-label="View tabs">';
        $out .= '<a class="cm-tab '.($tab === 'all' ? 'is-active' : '').'" href="'.$all_url.'">View All</a>';
        $out .= '<a class="cm-tab '.($tab === 'github' ? 'is-active' : '').'" href="'.$github_url.'">GitHub</a>';
        $out .= '</div></div>';
        $out .= $tab === 'github' ? $this->github_view_single_screen() : $this->github_view_all_screen();
        return $out;
    }

    private function github_view_settings(){
        $enabled = get_option('cm_wlfd_github_view_show_all', null);
        if (null === $enabled) $enabled = '1';
        $excluded = get_option('cm_wlfd_github_view_excluded_repos', []);
        return [
            'enabled' => (string)$enabled !== '0',
            'excluded' => is_array($excluded) ? array_values(array_filter(array_map('sanitize_text_field', $excluded))) : [],
        ];
    }

    private function github_view_catalog(){
        $catalog = [];
        if (class_exists('CM_WL_CMGC_Admin')) {
            $catalog = CM_WL_CMGC_Admin::get_repository_catalog();
        }
        if (!empty($catalog) && is_array($catalog)) return $catalog;

        // Fallback to the write-module cache so View still works immediately
        // after Update Repositories & Branches even if CMGC catalog data is absent.
        if (!class_exists('\\CM_WL_GitHub\\Settings') || !class_exists('\\CM_WL_GitHub\\GitHub_API')) return [];
        $repos = \CM_WL_GitHub\Settings::get_saved_repo_options();
        $api = new \CM_WL_GitHub\GitHub_API();
        $owner = $api->get_authenticated_username();
        if (!$owner || !is_array($repos)) return [];
        foreach ($repos as $name => $label) {
            $name = sanitize_text_field($name);
            if (!$name) continue;
            $catalog[] = [
                'full_name' => $owner.'/'.$name,
                'owner' => $owner,
                'name' => $name,
                'default_branch' => 'main',
                'private' => false,
                'description' => '',
            ];
        }
        return $catalog;
    }

    private function github_view_visible_catalog(){
        $settings = $this->github_view_settings();
        if (!$settings['enabled']) return [];
        $excluded = array_map('strtolower', $settings['excluded']);
        $visible = [];
        foreach ($this->github_view_catalog() as $repo) {
            if (empty($repo['full_name']) || empty($repo['owner']) || empty($repo['name'])) continue;
            if (in_array(strtolower((string)$repo['full_name']), $excluded, true)) continue;
            $visible[] = $repo;
        }
        return $visible;
    }

    private function github_view_all_screen(){
        $settings = $this->github_view_settings();
        if (!$settings['enabled']) {
            return '<div class="cm-notice"><strong>View All is disabled.</strong> Turn on <em>Show All GitHub repositories</em> under Settings → GitHub.</div>';
        }
        if (!class_exists('CM_WL_CMGC_Renderer')) {
            return '<div class="cm-notice"><strong>The embedded GitHub viewer could not be loaded.</strong> Reinstall this dashboard ZIP so modules/cm-github-connector is present.</div>';
        }
        $repos = $this->github_view_visible_catalog();
        if (empty($repos)) {
            return '<div class="cm-notice"><strong>No repositories are available for View All.</strong> Update the GitHub cache under Settings → GitHub, or check that you have not excluded every repository.</div>';
        }
        $out = '<div class="cm-github-view-heading"><div><h3>GitHub repositories</h3><p>'.esc_html(count($repos)).' repositories shown. Exclusions are controlled under Settings → GitHub.</p></div><a class="cm-btn ghost" href="'.$this->url('github').'">GitHub Settings</a></div>';
        $out .= '<div class="cm-github-view-all" data-repo-count="'.esc_attr(count($repos)).'">';
        foreach ($repos as $repo) {
            $out .= '<article class="cm-github-view-repo">';
            $out .= CM_WL_CMGC_Renderer::render_browser(
                sanitize_text_field($repo['owner']),
                sanitize_text_field($repo['name']),
                '',
                '',
                'dashboard',
                true
            );
            $out .= '</article>';
        }
        $out .= '</div>';
        return $out;
    }

    private function github_view_single_screen(){
        if (!class_exists('CM_WL_CMGC_Renderer')) {
            return '<div class="cm-notice"><strong>The embedded GitHub viewer could not be loaded.</strong></div>';
        }
        $repos = $this->github_view_visible_catalog();
        if (empty($repos)) return '<div class="cm-notice"><strong>No visible GitHub repositories.</strong> Check Settings → GitHub.</div>';
        $requested = sanitize_text_field(wp_unslash($_GET['repo'] ?? ''));
        $selected = null;
        foreach ($repos as $repo) {
            if ($requested && 0 === strcasecmp($requested, (string)$repo['full_name'])) { $selected = $repo; break; }
        }
        if (!$selected) $selected = $repos[0];
        $out = '<form class="cm-filter cm-github-view-picker" method="get">'.$this->query_hidden('view').'<input type="hidden" name="view_tab" value="github"><label>Repository<select class="cm-input" name="repo" onchange="this.form.submit()">';
        foreach ($repos as $repo) {
            $full = (string)$repo['full_name'];
            $out .= '<option value="'.esc_attr($full).'" '.selected($full, $selected['full_name'], false).'>'.esc_html($full).(!empty($repo['private']) ? ' — Private' : '').'</option>';
        }
        $out .= '</select></label><noscript><button class="cm-btn">View repository</button></noscript><a class="cm-btn ghost" href="'.$this->url('view',['view_tab'=>'all']).'">View All</a></form>';
        $out .= '<div class="cm-github-view-single">'.CM_WL_CMGC_Renderer::render_browser(
            sanitize_text_field($selected['owner']),
            sanitize_text_field($selected['name']),
            '',
            '',
            'dashboard',
            true
        ).'</div>';
        return $out;
    }



    private function settings_screen(){
        $cards = [
            ['add-new','Add New','Create new posts and content.','plus-alt2'],
            ['cpts','All CPTs','Browse all custom post types.','screenoptions'],
            ['corkboards','Cork Boards','View and manage cork board notes.','sticky'],
            ['network-nav','Header/Footer Menus','Edit the global main-site header and footer menus.','menu-alt3'],
            ['media','Media','Upload and browse media from the frontend dashboard.','format-image'],
            ['plugins','Plugins','View installed plugins from the frontend dashboard.','admin-plugins'],
        ];
        if (current_user_can('manage_options')) {
            $cards[] = ['github','GitHub','Connect GitHub, manage the token and refresh repository/branch settings.','admin-links'];
        }
        $out = '<div class="cm-title"><h2>Settings</h2><p>Dashboard tools for menus, media, plugins and GitHub.</p></div><div class="cm-cards">';
        foreach ($cards as $card) {
            $out .= '<a class="cm-card cm-card-link" href="'.$this->url($card[0]).'"><span class="dashicons dashicons-'.$card[3].'"></span><strong>'.esc_html($card[1]).'</strong><p>'.esc_html($card[2]).'</p></a>';
        }
        return $out.'</div>';
    }



    private function github_screen(){
        if (!current_user_can('manage_options')) {
            return '<div class="cm-title"><h2>GitHub Settings</h2></div><div class="cm-notice"><strong>Administrator access required.</strong> GitHub connection settings are restricted to WordPress administrators.</div>';
        }

        if (!class_exists('\CM_WL_GitHub\Frontend_Dashboard')) {
            return '<div class="cm-title"><h2>GitHub Settings</h2><p><a href="'.$this->url('settings').'">← Back to Settings</a></p></div><div class="cm-notice"><strong>The built-in GitHub module could not be loaded.</strong> Reinstall this dashboard ZIP so its modules/github-repo-selector folder is present.</div>';
        }

        $out = '<p style="margin:0 0 14px;"><a href="'.$this->url('settings').'">← Back to Settings</a></p>';
        $out .= \CM_WL_GitHub\Frontend_Dashboard::render_settings();
        return $out;
    }

    private function github_content_screen(){
        if (!current_user_can('manage_options')) {
            return '<div class="cm-title"><h2>GitHub</h2></div><div class="cm-notice"><strong>Administrator access required.</strong> GitHub repository changes are restricted to WordPress administrators.</div>';
        }

        if (!class_exists('\CM_WL_GitHub\Frontend_Dashboard')) {
            return '<div class="cm-title"><h2>GitHub</h2></div><div class="cm-notice"><strong>The built-in GitHub module could not be loaded.</strong> Reinstall this dashboard ZIP so its modules/github-repo-selector folder is present.</div>';
        }

        return \CM_WL_GitHub\Frontend_Dashboard::render_tools();
    }

    private function network_nav_capability(){
        return is_multisite() ? current_user_can('manage_network_options') : current_user_can('manage_options');
    }

    private function network_main_blog_id(){
        if (!is_multisite()) return get_current_blog_id();
        if (function_exists('get_main_site_id')) return absint(get_main_site_id());
        return 1;
    }

    private function network_nav_screen(){
        if (!$this->network_nav_capability()) return '<p>Network header/footer setup is restricted to network administrators.</p>';
        $main_id = $this->network_main_blog_id();
        if (is_multisite()) switch_to_blog($main_id);

        $menus = wp_get_nav_menus(['hide_empty' => false]);
        $locations = get_nav_menu_locations();
        $registered = get_registered_nav_menus();
        $primary_id = isset($locations['primary']) ? absint($locations['primary']) : 0;
        $footer_id = isset($locations['footer']) ? absint($locations['footer']) : 0;
        $selected_menu_id = absint($_GET['menu_id'] ?? 0);
        if (!$selected_menu_id) $selected_menu_id = $primary_id ?: ($footer_id ?: (!empty($menus[0]->term_id) ? absint($menus[0]->term_id) : 0));
        $selected_menu = $selected_menu_id ? wp_get_nav_menu_object($selected_menu_id) : null;

        $menu_options = '<option value="0">— Select a menu —</option>';
        foreach ($menus as $menu) {
            $sel = selected($selected_menu_id, $menu->term_id, false);
            $menu_options .= '<option value="'.esc_attr($menu->term_id).'" '.$sel.'>'.esc_html($menu->name).'</option>';
        }
        $primary_options = '<option value="0">— No menu assigned —</option>';
        $footer_options = '<option value="0">— No menu assigned —</option>';
        foreach ($menus as $menu) {
            $primary_options .= '<option value="'.esc_attr($menu->term_id).'" '.selected($primary_id, $menu->term_id, false).'>'.esc_html($menu->name).'</option>';
            $footer_options .= '<option value="'.esc_attr($menu->term_id).'" '.selected($footer_id, $menu->term_id, false).'>'.esc_html($menu->name).'</option>';
        }

        $message = '';
        if (!empty($_GET['updated'])) $message = '<div class="cm-notice"><strong>Saved.</strong> The network header/footer setup now reads from the main site menu locations.</div>';
        if (!empty($_GET['menu_updated'])) $message = '<div class="cm-notice"><strong>Menu saved.</strong> The main-site menu items have been updated.</div>';

        $out = '<div class="cm-title"><h2>Menus</h2><p>WordPress-style menu management for the main site global header and footer. The service menu is still local per child site.</p></div>';
        $out .= $message;

        $out .= '<div class="cm-menu-tabs">';
        $out .= '<form class="cm-menu-select" method="get" action="'.esc_url(network_home_url('/')).'">';
        $out .= '<input type="hidden" name="cm_wlfd" value="1"><input type="hidden" name="view" value="network-nav">';
        $out .= '<label>Select a menu to edit: <select class="cm-input" name="menu_id">'.$menu_options.'</select></label> <button class="cm-btn">Select</button>';
        $out .= '</form>';
        $out .= '<form class="cm-menu-create" method="post" action="'.esc_url($this->dashboard_admin_post_url()).'">'.wp_nonce_field('cm_wlfd_network_nav_setup','_wpnonce',true,false).'<input type="hidden" name="action" value="cm_wlfd_network_nav_setup"><input type="hidden" name="primary_menu_id" value="'.esc_attr($primary_id).'"><input type="hidden" name="footer_menu_id" value="'.esc_attr($footer_id).'"><label>Create new menu <input class="cm-input" name="primary_menu_name" placeholder="Menu name"></label><button class="cm-btn ghost">Create Menu</button></form>';
        $out .= '</div>';

        $out .= '<form class="cm-editor cm-menu-locations" method="post" action="'.esc_url($this->dashboard_admin_post_url()).'">';
        $out .= wp_nonce_field('cm_wlfd_network_nav_setup','_wpnonce',true,false).'<input type="hidden" name="action" value="cm_wlfd_network_nav_setup">';
        $out .= '<h3>Menu locations</h3><p><small>Global header uses the main site <code>primary</code> menu. Global footer uses the main site <code>footer</code> menu. Local service menus are not changed here.</small></p>';
        $out .= '<div class="cm-menu-location-grid"><label>Global header / primary <select class="cm-input" name="primary_menu_id">'.$primary_options.'</select></label><label>Global footer <select class="cm-input" name="footer_menu_id">'.$footer_options.'</select></label></div>';
        $out .= '<button class="cm-btn">Save Locations</button>';
        $out .= '</form>';

        if ($selected_menu && $selected_menu_id) {
            $out .= $this->wordpress_style_menu_editor($selected_menu_id, $selected_menu->name);
        } else {
            $out .= '<div class="cm-notice"><strong>No menu selected.</strong> Create or select a menu first.</div>';
        }

        if (!isset($registered['primary']) || !isset($registered['footer'])) {
            $out .= '<div class="cm-notice"><strong>Theme note:</strong> This works best with the Orbital Service Theme locations: <code>primary</code>, <code>service</code>, and <code>footer</code>.</div>';
        }
        if (is_multisite()) restore_current_blog();
        return $out;
    }

    public function save_network_nav_setup(){
        if (!$this->network_nav_capability()) wp_die('Permission denied.');
        check_admin_referer('cm_wlfd_network_nav_setup');
        $main_id = $this->network_main_blog_id();
        if (is_multisite()) switch_to_blog($main_id);

        $locations = get_nav_menu_locations();
        $primary_menu_id = absint($_POST['primary_menu_id'] ?? 0);
        $footer_menu_id = absint($_POST['footer_menu_id'] ?? 0);
        $primary_name = sanitize_text_field($_POST['primary_menu_name'] ?? '');
        $footer_name = sanitize_text_field($_POST['footer_menu_name'] ?? '');

        $created_menu_id = 0;
        if ($primary_name !== '') {
            $created = wp_create_nav_menu($primary_name);
            if (!is_wp_error($created)) { $primary_menu_id = absint($created); $created_menu_id = $primary_menu_id; }
        }
        if ($footer_name !== '') {
            $created = wp_create_nav_menu($footer_name);
            if (!is_wp_error($created)) { $footer_menu_id = absint($created); $created_menu_id = $footer_menu_id; }
        }

        if ($primary_menu_id) $locations['primary'] = $primary_menu_id; else unset($locations['primary']);
        if ($footer_menu_id) $locations['footer'] = $footer_menu_id; else unset($locations['footer']);
        set_theme_mod('nav_menu_locations', $locations);

        if (is_multisite()) restore_current_blog();
        $args = ['updated' => 1];
        if ($created_menu_id) $args['menu_id'] = $created_menu_id;
        wp_safe_redirect($this->url('network-nav', $args));
        exit;
    }

    private function wordpress_style_menu_editor($menu_id, $menu_name){
        $menu_id = absint($menu_id);
        $items = wp_get_nav_menu_items($menu_id, ['post_status' => 'publish']);
        if (!is_array($items)) $items = [];
        usort($items, function($a,$b){ return intval($a->menu_order) <=> intval($b->menu_order); });
        $pages = get_pages(['sort_column'=>'menu_order,post_title','post_status'=>'publish']);
        $categories = get_categories(['hide_empty' => false, 'orderby' => 'name']);

        $out = '<div class="cm-wp-menu-screen">';
        $out .= '<div class="cm-wp-menu-left">';
        $out .= '<h3>Add menu items</h3>';

        $out .= '<details class="cm-menu-box" open><summary>Pages</summary><form method="post" action="'.esc_url($this->dashboard_admin_post_url()).'">'.wp_nonce_field('cm_wlfd_menu_item_add','_wpnonce',true,false).'<input type="hidden" name="action" value="cm_wlfd_menu_item_add"><input type="hidden" name="menu_id" value="'.esc_attr($menu_id).'"><input type="hidden" name="item_kind" value="pages"><div class="cm-menu-checklist">';
        if ($pages) { foreach ($pages as $page) $out .= '<label><input type="checkbox" name="page_ids[]" value="'.esc_attr($page->ID).'"> '.esc_html($page->post_title).'</label>'; }
        else $out .= '<p><small>No published pages.</small></p>';
        $out .= '</div><button class="cm-btn">Add to Menu</button></form></details>';

        $out .= '<details class="cm-menu-box"><summary>Custom Links</summary><form method="post" action="'.esc_url($this->dashboard_admin_post_url()).'">'.wp_nonce_field('cm_wlfd_menu_item_add','_wpnonce',true,false).'<input type="hidden" name="action" value="cm_wlfd_menu_item_add"><input type="hidden" name="menu_id" value="'.esc_attr($menu_id).'"><input type="hidden" name="item_kind" value="custom"><label>URL<input class="cm-input" name="link_url" value="https://"></label><label>Link Text<input class="cm-input" name="link_text"></label><button class="cm-btn">Add to Menu</button></form></details>';

        $out .= '<details class="cm-menu-box"><summary>Categories</summary><form method="post" action="'.esc_url($this->dashboard_admin_post_url()).'">'.wp_nonce_field('cm_wlfd_menu_item_add','_wpnonce',true,false).'<input type="hidden" name="action" value="cm_wlfd_menu_item_add"><input type="hidden" name="menu_id" value="'.esc_attr($menu_id).'"><input type="hidden" name="item_kind" value="categories"><div class="cm-menu-checklist">';
        if ($categories) { foreach ($categories as $cat) $out .= '<label><input type="checkbox" name="cat_ids[]" value="'.esc_attr($cat->term_id).'"> '.esc_html($cat->name).'</label>'; }
        else $out .= '<p><small>No categories.</small></p>';
        $out .= '</div><button class="cm-btn">Add to Menu</button></form></details>';

        $out .= '</div>';
        $out .= '<div class="cm-wp-menu-right"><form class="cm-menu-structure" method="post" action="'.esc_url($this->dashboard_admin_post_url()).'">'.wp_nonce_field('cm_wlfd_menu_editor_save','_wpnonce',true,false).'<input type="hidden" name="action" value="cm_wlfd_menu_editor_save"><input type="hidden" name="menu_id" value="'.esc_attr($menu_id).'">';
        $out .= '<div class="cm-menu-name-row"><label>Menu Name<input class="cm-input" name="menu_name" value="'.esc_attr($menu_name).'"></label><button class="cm-btn">Save Menu</button></div>';
        $out .= '<h3>Menu structure</h3><p><small>Use the same fields as WordPress menus. Change order numbers to reorder items; choose a parent to nest an item.</small></p>';

        if ($items) {
            $parent_options_base = '<option value="0">No parent</option>';
            foreach ($items as $opt) $parent_options_base .= '<option value="'.esc_attr($opt->ID).'">'.esc_html($opt->title).'</option>';
            $n = 1;
            foreach ($items as $item) {
                $type_label = $item->type_label ?: $item->type;
                $parent_options = str_replace('value="'.esc_attr($item->menu_item_parent).'"', 'value="'.esc_attr($item->menu_item_parent).'" selected', $parent_options_base);
                $parent_options = str_replace('value="'.esc_attr($item->ID).'"', 'value="'.esc_attr($item->ID).'" disabled', $parent_options);
                $target_checked = ($item->target === '_blank') ? ' checked' : '';
                $out .= '<details class="cm-menu-item-box"><summary><strong>'.esc_html($item->title).'</strong><span>'.esc_html($type_label).'</span></summary>';
                $out .= '<input type="hidden" name="item_ids[]" value="'.esc_attr($item->ID).'">';
                $out .= '<div class="cm-menu-item-fields">';
                $out .= '<label>Navigation Label<input class="cm-input" name="item_title['.esc_attr($item->ID).']" value="'.esc_attr($item->title).'"></label>';
                $out .= '<label>Title Attribute<input class="cm-input" name="item_attr_title['.esc_attr($item->ID).']" value="'.esc_attr($item->attr_title).'"></label>';
                if ($item->type === 'custom') $out .= '<label>URL<input class="cm-input" name="item_url['.esc_attr($item->ID).']" value="'.esc_attr($item->url).'"></label>';
                else $out .= '<p><small>Original: '.esc_html($item->url).'</small></p>';
                $out .= '<label>Parent<select class="cm-input" name="item_parent['.esc_attr($item->ID).']">'.$parent_options.'</select></label>';
                $out .= '<label>Order<input class="cm-input" type="number" min="1" name="item_order['.esc_attr($item->ID).']" value="'.esc_attr($n).'" style="max-width:120px"></label>';
                $out .= '<label class="cm-checkbox"><input type="checkbox" name="item_target['.esc_attr($item->ID).']" value="_blank"'.$target_checked.'> Open link in a new tab</label>';
                $out .= '<label>CSS Classes<input class="cm-input" name="item_classes['.esc_attr($item->ID).']" value="'.esc_attr(is_array($item->classes) ? implode(' ', array_filter($item->classes)) : '').'"></label>';
                $out .= '<label class="cm-checkbox danger-text"><input type="checkbox" name="item_delete['.esc_attr($item->ID).']" value="1"> Remove this item</label>';
                $out .= '</div></details>';
                $n++;
            }
        } else {
            $out .= '<div class="cm-notice">Add pages, custom links or categories from the left column.</div>';
        }

        $out .= '<div class="cm-menu-save-bottom"><button class="cm-btn">Save Menu</button></div>';
        $out .= '</form></div></div>';
        return $out;
    }

    public function menu_item_add(){
        if (!$this->network_nav_capability()) wp_die('Permission denied.');
        check_admin_referer('cm_wlfd_menu_item_add');
        $main_id = $this->network_main_blog_id();
        if (is_multisite()) switch_to_blog($main_id);
        $menu_id = absint($_POST['menu_id'] ?? 0);
        $kind = sanitize_key($_POST['item_kind'] ?? 'custom');
        if ($menu_id && $kind === 'pages') {
            $ids = array_map('absint', (array)($_POST['page_ids'] ?? []));
            foreach ($ids as $page_id) {
                if ($page_id) wp_update_nav_menu_item($menu_id, 0, [
                    'menu-item-object-id' => $page_id,
                    'menu-item-object' => 'page',
                    'menu-item-type' => 'post_type',
                    'menu-item-status' => 'publish',
                ]);
            }
        } elseif ($menu_id && $kind === 'categories') {
            $ids = array_map('absint', (array)($_POST['cat_ids'] ?? []));
            foreach ($ids as $cat_id) {
                if ($cat_id) wp_update_nav_menu_item($menu_id, 0, [
                    'menu-item-object-id' => $cat_id,
                    'menu-item-object' => 'category',
                    'menu-item-type' => 'taxonomy',
                    'menu-item-status' => 'publish',
                ]);
            }
        } elseif ($menu_id && $kind === 'page') {
            $page_id = absint($_POST['page_id'] ?? 0);
            if ($page_id) wp_update_nav_menu_item($menu_id, 0, [
                'menu-item-object-id' => $page_id,
                'menu-item-object' => 'page',
                'menu-item-type' => 'post_type',
                'menu-item-status' => 'publish',
            ]);
        } elseif ($menu_id) {
            $title = sanitize_text_field($_POST['link_text'] ?? '');
            $url = esc_url_raw($_POST['link_url'] ?? '');
            if ($title !== '' && $url !== '') wp_update_nav_menu_item($menu_id, 0, [
                'menu-item-title' => $title,
                'menu-item-url' => $url,
                'menu-item-type' => 'custom',
                'menu-item-status' => 'publish',
            ]);
        }
        if (is_multisite()) restore_current_blog();
        wp_safe_redirect($this->url('network-nav', ['menu_id' => $menu_id, 'menu_updated' => 1]));
        exit;
    }

    public function menu_editor_save(){
        if (!$this->network_nav_capability()) wp_die('Permission denied.');
        check_admin_referer('cm_wlfd_menu_editor_save');
        $main_id = $this->network_main_blog_id();
        if (is_multisite()) switch_to_blog($main_id);
        $menu_id = absint($_POST['menu_id'] ?? 0);
        $menu_name = sanitize_text_field($_POST['menu_name'] ?? '');
        if ($menu_id && $menu_name !== '') wp_update_term($menu_id, 'nav_menu', ['name' => $menu_name]);
        $ids = array_map('absint', (array)($_POST['item_ids'] ?? []));
        $orders = [];
        foreach ($ids as $item_id) {
            $orders[$item_id] = max(1, absint($_POST['item_order'][$item_id] ?? 999));
        }
        asort($orders);
        $position = 1;
        foreach (array_keys($orders) as $item_id) {
            if (!empty($_POST['item_delete'][$item_id])) { wp_delete_post($item_id, true); continue; }
            $item = wp_setup_nav_menu_item(get_post($item_id));
            if (!$item || empty($item->ID)) continue;
            $args = [
                'menu-item-db-id' => $item_id,
                'menu-item-title' => sanitize_text_field($_POST['item_title'][$item_id] ?? $item->title),
                'menu-item-attr-title' => sanitize_text_field($_POST['item_attr_title'][$item_id] ?? ''),
                'menu-item-classes' => sanitize_text_field($_POST['item_classes'][$item_id] ?? ''),
                'menu-item-target' => !empty($_POST['item_target'][$item_id]) ? '_blank' : '',
                'menu-item-parent-id' => absint($_POST['item_parent'][$item_id] ?? 0),
                'menu-item-position' => $position,
                'menu-item-status' => 'publish',
                'menu-item-type' => $item->type,
                'menu-item-object' => $item->object,
                'menu-item-object-id' => $item->object_id,
            ];
            if ($item->type === 'custom') $args['menu-item-url'] = esc_url_raw($_POST['item_url'][$item_id] ?? $item->url);
            wp_update_nav_menu_item($menu_id, $item_id, $args);
            $position++;
        }
        if (is_multisite()) restore_current_blog();
        wp_safe_redirect($this->url('network-nav', ['menu_id' => $menu_id, 'menu_updated' => 1]));
        exit;
    }

    public function menu_item_remove(){
        if (!$this->network_nav_capability()) wp_die('Permission denied.');
        check_admin_referer('cm_wlfd_menu_item_remove');
        $main_id = $this->network_main_blog_id();
        if (is_multisite()) switch_to_blog($main_id);
        $item_id = absint($_POST['menu_item_id'] ?? 0);
        $menu_id = absint($_POST['menu_id'] ?? 0);
        if ($item_id) wp_delete_post($item_id, true);
        if (is_multisite()) restore_current_blog();
        wp_safe_redirect($this->url('network-nav', ['menu_id' => $menu_id, 'menu_updated' => 1]));
        exit;
    }

    private function media_screen(){
        if (!current_user_can('upload_files')) return '<p>Media tools are restricted to users who can upload files.</p>';
        $attachments = get_posts([
            'post_type'=>'attachment',
            'post_status'=>'inherit',
            'posts_per_page'=>60,
            'orderby'=>'date',
            'order'=>'DESC',
        ]);
        $out='<div class="cm-title"><h2>Media</h2><p>Upload media, select an item, then edit its title, caption, alt text and description without opening wp-admin.</p></div>';
        if (!empty($_GET['media_updated'])) $out.='<div class="cm-notice"><p>Media details saved.</p></div>';
        if (!empty($_GET['media_uploaded'])) $out.='<div class="cm-notice"><p>Media uploaded.</p></div>';
        $out.='<form class="cm-uploader cm-media-upload-bar" method="post" enctype="multipart/form-data" action="'.esc_url($this->dashboard_admin_post_url()).'">';
        $out.=wp_nonce_field('cm_wlfd_media_upload','_wpnonce',true,false).'<input type="hidden" name="action" value="cm_wlfd_media_upload"><input type="file" name="media_file" required><button class="cm-btn">Upload</button></form>';
        $out.='<div class="cm-media-browser" data-cm-media-browser><div class="cm-media-toolbar"><strong>Media Library</strong><input type="search" class="cm-input cm-media-search" placeholder="Search media"></div><div class="cm-media-main"><div class="cm-media-grid" role="list">';
        foreach($attachments as $index=>$a){
            $id=(int)$a->ID;
            $thumb=wp_get_attachment_image($id,'thumbnail',false,['class'=>'cm-media-thumb']);
            if (!$thumb) $thumb='<span class="dashicons dashicons-media-default cm-media-file-icon"></span>';
            $title=get_the_title($id);
            $caption=$a->post_excerpt;
            $description=$a->post_content;
            $alt=(string)get_post_meta($id,'_wp_attachment_image_alt',true);
            $url=wp_get_attachment_url($id);
            $mime=get_post_mime_type($id);
            $date=get_the_date('', $id);
            $file=basename((string)get_attached_file($id));
            $out.='<button type="button" class="cm-media-card'.($index===0?' is-selected':'').'" role="listitem" data-id="'.esc_attr($id).'" data-title="'.esc_attr($title).'" data-caption="'.esc_attr($caption).'" data-alt="'.esc_attr($alt).'" data-description="'.esc_attr($description).'" data-url="'.esc_url($url).'" data-filename="'.esc_attr($file).'" data-date="'.esc_attr($date).'" data-mime="'.esc_attr($mime).'" data-search="'.esc_attr(strtolower($title.' '.$caption.' '.$alt.' '.$description.' '.$file)).'">'.$thumb.'<span>'.esc_html($title ?: $file ?: ('Media #'.$id)).'</span></button>';
        }
        if (!$attachments) $out.='<p class="cm-muted">No media found yet. Upload your first item above.</p>';
        $first=$attachments ? $attachments[0] : null;
        $first_id=$first ? (int)$first->ID : 0;
        $first_title=$first ? get_the_title($first_id) : '';
        $first_caption=$first ? $first->post_excerpt : '';
        $first_desc=$first ? $first->post_content : '';
        $first_alt=$first ? (string)get_post_meta($first_id,'_wp_attachment_image_alt',true) : '';
        $first_url=$first ? wp_get_attachment_url($first_id) : '';
        $first_file=$first ? basename((string)get_attached_file($first_id)) : '';
        $first_date=$first ? get_the_date('', $first_id) : '';
        $first_mime=$first ? get_post_mime_type($first_id) : '';
        $out.='</div><aside class="cm-media-details" aria-live="polite"><h3>Attachment Details</h3>';
        $out.='<div class="cm-media-preview" data-cm-media-preview>'.($first_id ? wp_get_attachment_image($first_id,'medium') : '<span class="dashicons dashicons-format-image"></span>').'</div>';
        $out.='<p class="cm-media-meta"><strong data-cm-media-filename>'.esc_html($first_file).'</strong><br><span data-cm-media-date>'.esc_html($first_date).'</span><br><span data-cm-media-mime>'.esc_html($first_mime).'</span></p>';
        $out.='<p><a data-cm-media-url href="'.esc_url($first_url).'" target="_blank" rel="noopener">View file</a></p>';
        $out.='<form class="cm-media-edit-form" method="post" action="'.esc_url($this->dashboard_admin_post_url()).'">';
        $out.=wp_nonce_field('cm_wlfd_media_update','_wpnonce',true,false).'<input type="hidden" name="action" value="cm_wlfd_media_update"><input type="hidden" name="attachment_id" value="'.esc_attr($first_id).'" data-cm-media-id>';
        $out.='<label>Title<input class="cm-input" name="attachment_title" value="'.esc_attr($first_title).'" data-cm-media-title></label>';
        $out.='<label>Caption<textarea class="cm-input" name="attachment_caption" rows="4" data-cm-media-caption>'.esc_textarea($first_caption).'</textarea></label>';
        $out.='<label>Alt Text<input class="cm-input" name="attachment_alt" value="'.esc_attr($first_alt).'" data-cm-media-alt></label>';
        $out.='<label>Description<textarea class="cm-input" name="attachment_description" rows="5" data-cm-media-description>'.esc_textarea($first_desc).'</textarea></label>';
        $out.='<button class="cm-btn" type="submit"'.($first_id?'':' disabled').'>Save Media Details</button></form></aside></div></div>';
        return $out;
    }
    public function media_upload(){ check_admin_referer('cm_wlfd_media_upload'); if (!current_user_can('upload_files')) wp_die('Permission denied.'); require_once ABSPATH.'wp-admin/includes/file.php'; require_once ABSPATH.'wp-admin/includes/media.php'; require_once ABSPATH.'wp-admin/includes/image.php'; media_handle_upload('media_file',0); wp_safe_redirect($this->url('media', ['media_uploaded'=>1])); exit; }
    public function button_styles(){
        echo '<style>
body.cm-wlfd-body .cm-btn {
    background: #2563eb !important;
    color: #fff !important;
    border: 0 !important;
    border-radius: 9px !important;
    padding: 10px 14px !important;
    text-decoration: none !important;
    font-weight: 700 !important;
    cursor: pointer !important;
    display: inline-flex !important;
    align-items: center !important;
    gap: 6px !important;
}
body.cm-wlfd-body .cm-btn:hover, body.cm-wlfd-body .cm-btn:focus {
    background: #2563eb !important;
    color: #fff !important;
    text-decoration: none !important;
    opacity: 1 !important;
}
body.cm-wlfd-body .cm-btn.ghost {
    background: #eef2ff !important;
    color: #1d4ed8 !important;
}
body.cm-wlfd-body .cm-btn.ghost:hover, body.cm-wlfd-body .cm-btn.ghost:focus {
    background: #eef2ff !important;
    color: #1d4ed8 !important;
}
.cm-toplinks a {
    background: #2563eb !important;
    color: #fff !important;
}
body.cm-wlfd-body .cm-editor-actions button,
body.cm-wlfd-body .cm-row-actions button,
body.cm-wlfd-body .cm-featured button {
    background: #2563eb !important;
    color: #fff !important;
    border: 0 !important;
    border-radius: 9px !important;
    padding: 10px 14px !important;
    font-weight: 700 !important;
    cursor: pointer !important;
}
</style>';
    }
    
    public function media_update(){
        check_admin_referer('cm_wlfd_media_update');
        $id=absint($_POST['attachment_id'] ?? 0);
        if (!$id || get_post_type($id) !== 'attachment') wp_die('Invalid attachment.');
        if (!current_user_can('edit_post', $id)) wp_die('Permission denied.');
        wp_update_post([
            'ID'=>$id,
            'post_title'=>sanitize_text_field(wp_unslash($_POST['attachment_title'] ?? '')),
            'post_excerpt'=>wp_kses_post(wp_unslash($_POST['attachment_caption'] ?? '')),
            'post_content'=>wp_kses_post(wp_unslash($_POST['attachment_description'] ?? '')),
        ]);
        update_post_meta($id, '_wp_attachment_image_alt', sanitize_text_field(wp_unslash($_POST['attachment_alt'] ?? '')));
        wp_safe_redirect($this->url('media', ['media_updated'=>1]));
        exit;
    }
    private function profile_screen(){ $u=wp_get_current_user(); return '<div class="cm-title"><h2>Profile</h2></div><form class="cm-editor" method="post" action="'.esc_url($this->dashboard_admin_post_url()).'">'.wp_nonce_field('cm_wlfd_profile','_wpnonce',true,false).'<input type="hidden" name="action" value="cm_wlfd_profile"><label>Display name<input class="cm-input" name="display_name" value="'.esc_attr($u->display_name).'"></label><label>Email<input class="cm-input" name="user_email" value="'.esc_attr($u->user_email).'"></label><button class="cm-btn">Save Profile</button></form>'; }
    public function save_profile(){ check_admin_referer('cm_wlfd_profile'); wp_update_user(['ID'=>get_current_user_id(),'display_name'=>sanitize_text_field($_POST['display_name']),'user_email'=>sanitize_email($_POST['user_email'])]); wp_safe_redirect($this->url('profile')); exit; }
    private function blog_types($all_types){
        $wanted_labels = ['work','reviews','testimonials','leeds united'];
        $wanted_keys = ['work','reviews','review','testimonials','testimonial','leeds_united_','leeds_united__cptui','leeds_united'];
        $blog_types = [];
        foreach ((array)$all_types as $key => $obj) {
            $label = strtolower(trim($obj->labels->singular_name ?? $obj->label ?? $key));
            $plural = strtolower(trim($obj->labels->name ?? $obj->label ?? $key));
            if (in_array($key, $wanted_keys, true) || in_array($label, $wanted_labels, true) || in_array($plural, $wanted_labels, true)) {
                $blog_types[$key] = $obj;
            }
        }
        return $blog_types;
    }

    private function blog_post_screen(){
        $site_id = 21;
        if (is_multisite()) switch_to_blog($site_id);
        $all_types = $this->public_types();
        $types = $this->blog_types($all_types);
        if (!$types) $types = $all_types;
        $default_pt = isset($types['work']) ? 'work' : (isset($types['leeds_united_']) ? 'leeds_united_' : array_key_first($types));
        $pt = sanitize_key($_GET['post_type'] ?? get_user_meta(get_current_user_id(), 'cm_wlfd_blog_post_type', true));
        if (!$pt || !isset($types[$pt])) $pt = $default_pt ?: 'post';
        update_user_meta(get_current_user_id(), 'cm_wlfd_blog_post_type', $pt);
        $args = ['post_type'=>$pt,'post_status'=>['publish','draft','pending','private'],'posts_per_page'=>80,'orderby'=>'modified','order'=>'DESC'];
        if (!current_user_can('edit_others_posts')) $args['author']=get_current_user_id();
        $q = new WP_Query($args);
        $out='<div class="cm-title"><h2>Blog</h2><p>Choose the blog CPT to manage. This tab stays on the same page and only this content area changes.</p></div>';
        if (!empty($_GET['deleted'])) $out .= '<div class="cm-notice updated"><p><strong>Content moved to Trash.</strong></p></div>';
        $out.='<form class="cm-filter" method="get">'.$this->query_hidden('content').'<input type="hidden" name="tab" value="blog"><div style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap;"><label style="flex:1;min-width:220px;">Blog CPT <select name="post_type" class="cm-input" onchange="this.form.submit()">';
        foreach($types as $k=>$obj) $out.='<option value="'.esc_attr($k).'" '.selected($pt,$k,false).'>'.esc_html($this->type_label($k,$obj)).'</option>';
        $out.='</select></label><a class="cm-btn" href="'.$this->url('add-new',['site_id'=>$site_id,'post_type'=>$pt,'tab'=>'blog']).'">Add New '.esc_html($this->type_label($pt,$types[$pt] ?? null)).'</a></div><noscript><button class="cm-btn">Load</button></noscript></form><div class="cm-list">';
        if ($q->have_posts()) {
            foreach($q->posts as $p){
                $perma=get_permalink($p); $acf_count=function_exists('get_field_objects') ? count((array)get_field_objects($p->ID)) : 0;
                $type_label = $this->type_label($pt,$types[$pt] ?? null);
                $out.='<article class="cm-row"><div><strong>'.esc_html(get_the_title($p) ?: '(no title)').'</strong><small>'.esc_html($type_label).' · '.esc_html($p->post_status).' · ACF fields: '.esc_html($acf_count).' · '.esc_html($perma).'</small></div><div class="cm-row-actions"><a class="cm-btn" href="'.$this->url('edit',['post_id'=>$p->ID,'site_id'=>$site_id,'post_type'=>$pt,'tab'=>'blog']).'" >Edit</a><a class="cm-btn ghost" href="'.esc_url($perma).'">View</a>'.$this->delete_button($p->ID,$site_id,$pt,'content').'</div></article>';
            }
        } else $out.='<p>No blog posts found for this CPT.</p>';
        $out.='</div>';
        if (is_multisite()) restore_current_blog(); return $out;
    }
    private function other_content_screen(){
        $site_id = absint($_GET['site_id'] ?? get_current_blog_id());
        if (is_multisite()) switch_to_blog($site_id);
        $types = $this->public_types();
        // Filter out blog post type
        $types = array_filter($types, fn($k)=>$k !== 'blog', ARRAY_FILTER_USE_KEY);
        $pt = sanitize_key($_GET['post_type'] ?? (array_key_first($types) ?: 'post'));
        if (!isset($types[$pt])) $pt = array_key_first($types) ?: 'post';
        $args = ['post_type'=>$pt,'post_status'=>['publish','draft','pending','private'],'posts_per_page'=>80,'orderby'=>'modified','order'=>'DESC'];
        if (!current_user_can('edit_others_posts')) $args['author']=get_current_user_id();
        $q = new WP_Query($args);
        $out='<div class="cm-title"><h2>Other Content</h2><p>Manage all other content types.</p></div>';
        if (!empty($_GET['deleted'])) $out .= '<div class="cm-notice updated"><p><strong>Content moved to Trash.</strong></p></div>';
        $out.='<form class="cm-filter" method="get">'.$this->query_hidden('content').'<input type="hidden" name="tab" value="other-content">';
        if ($site_id === 21) $site_id = get_current_blog_id();
        $out.=$this->site_select($site_id).'<div style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap;"><label style="flex:1;min-width:200px;">CPT <select name="post_type" class="cm-input" onchange="this.form.submit()">';
        foreach($types as $k=>$obj) $out.='<option value="'.esc_attr($k).'" '.selected($pt,$k,false).'>'.esc_html($this->type_label($k,$obj)).'</option>';
        $out.='</select></label><a class="cm-btn" href="'.$this->url('add-new',['site_id'=>21,'post_type'=>$pt,'tab'=>'other-content']).'">Add New '.$this->type_label($pt,$types[$pt]).'</a></div><noscript><button class="cm-btn">Load</button></noscript></form><div class="cm-list">';
        if ($q->have_posts()) {
            foreach($q->posts as $p){
                $perma=get_permalink($p); $acf_count=function_exists('get_field_objects') ? count((array)get_field_objects($p->ID)) : 0;
                $out.='<article class="cm-row"><div><strong>'.esc_html(get_the_title($p) ?: '(no title)').'</strong><small>'.esc_html($this->type_label($pt,$types[$pt])).' · '.esc_html($p->post_status).' · ACF fields: '.esc_html($acf_count).' · '.esc_html($perma).'</small></div><div class="cm-row-actions"><a class="cm-btn" href="'.$this->url('edit',['post_id'=>$p->ID,'site_id'=>21,'post_type'=>$pt]).'">Edit</a><a class="cm-btn ghost" href="'.esc_url($perma).'">View</a>'.$this->delete_button($p->ID,$site_id,$pt,'content').'</div></article>';
            }
        } else $out.='<p>No content found for this CPT.</p>';
        $out.='</div>';
        if (is_multisite()) restore_current_blog(); return $out;
    }
        private function plugins_screen(){ if (!current_user_can('activate_plugins')) return '<p>Plugin tools are restricted to administrators.</p>'; require_once ABSPATH.'wp-admin/includes/plugin.php'; $out='<div class="cm-title"><h2>Plugins</h2><p>Installed plugin overview. Activation/deactivation stays in wp-admin for safety.</p></div><div class="cm-list">'; foreach(get_plugins() as $file=>$p){ $out.='<article class="cm-row"><div><strong>'.esc_html($p['Name']).'</strong><small>'.esc_html($file).' · v'.esc_html($p['Version']).'</small></div></article>'; } return $out.'</div>'; }
}
CM_WL_Frontend_Dashboard::instance();