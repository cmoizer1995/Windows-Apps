<?php
/**
 * GitHub Repo Selector Elementor Widget
 */

namespace GitHub_Repo_Selector\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use GitHub_Repo_Selector\GitHub_API;
use GitHub_Repo_Selector\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GitHub_Repo_Widget extends Widget_Base {
	private $github_api;

	public function __construct( $data = [], $args = null ) {
		parent::__construct( $data, $args );
		$this->github_api = new GitHub_API();
	}

	public function get_name() {
		return 'github_repo_selector';
	}

	public function get_title() {
		return esc_html__( 'GitHub Repos', 'github-repo-selector' );
	}

	public function get_icon() {
		return 'eicon-code';
	}

	public function get_categories() {
		return [ 'general' ];
	}

	public function get_keywords() {
		return [ 'github', 'repository', 'repos', 'code' ];
	}

	protected function register_controls() {
		// GitHub Settings Section
		$this->start_controls_section(
			'section_github_settings',
			[
				'label' => esc_html__( 'GitHub Settings', 'github-repo-selector' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$settings_url = Settings::get_settings_url();

		$this->add_control(
			'github_token_account_notice',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => '<div style="background: #f0f6fc; border-left: 4px solid #0969da; padding: 12px; margin: 12px 0; border-radius: 4px; color: #24292f; font-size: 12px;">' .
					'<strong>GitHub account:</strong> This widget now uses the account connected to your saved GitHub token. ' .
					'<a href="' . esc_url( $settings_url ) . '" target="_blank" rel="noopener noreferrer">Open GitHub Repo Selector settings</a> to change the token.' .
				'</div>',
			]
		);

		$this->add_control(
			'fetch_repos_notice',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => '<div style="background: #f0f6fc; border-left: 4px solid #0969da; padding: 12px; margin: 12px 0; border-radius: 4px; color: #24292f; font-size: 12px;">
					<strong>Info:</strong> Click "Update Repositories & Branches" to fetch repositories from the GitHub account connected to the saved token.
				</div>',
			]
		);

		$this->add_control(
			'update_repos_button',
			[
				'type'  => Controls_Manager::RAW_HTML,
				'raw'   => '<button type="button" id="update-github-repos" class="elementor-button elementor-button-default github-repo-selector-update" style="margin: 10px 0;">Update Repositories & Branches</button><div class="github-repo-selector-mobile-note" style="font-size:11px;opacity:.8;margin-top:6px;">Updates the saved repo and branch cache, then refreshes the Elementor controls.</div>',
				'label' => '',
			]
		);

		$repo_options = Settings::get_saved_repo_options();

		$this->add_control(
			'repo_cache_status',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => '<div style="font-size:12px; padding:8px 10px; background:#f6f7f7; border:1px solid #dcdcde; border-radius:4px; margin-bottom:10px;"><strong>Repo cache:</strong> ' . esc_html( count( $repo_options ) ) . ' repositories loaded.</div>',
			]
		);


		$this->add_control(
			'frontend_dashboard_mode',
			[
				'label' => esc_html__( 'Front-End Dashboard Mode', 'github-repo-selector' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'github-repo-selector' ),
				'label_off' => esc_html__( 'No', 'github-repo-selector' ),
				'return_value' => 'yes',
				'default' => '',
				'description' => esc_html__( 'Turn this on when placing the widget on your custom front-end dashboard. It shows GitHub Tools and all cached repository cards underneath.', 'github-repo-selector' ),
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'repo_selection_mode',
			[
				'label'       => esc_html__( 'Repo Display Mode', 'github-repo-selector' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'multiple',
				'options'     => [
					'all'      => esc_html__( 'Add all repositories', 'github-repo-selector' ),
					'single'   => esc_html__( 'Add one repo', 'github-repo-selector' ),
					'multiple' => esc_html__( 'Add multiple repos as a list', 'github-repo-selector' ),
				],
				'description' => esc_html__( 'Choose all repositories at once, one repository, or build a custom list of repositories.', 'github-repo-selector' ),
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);



		$this->add_control(
			'all_repos_notice',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => '<div style="font-size:12px; padding:8px 10px; background:#f6f7f7; border:1px solid #dcdcde; border-radius:4px; margin-bottom:10px;"><strong>All repositories:</strong> This will render every repository currently saved in the repo cache. Use Update Repositories & Branches in settings/editor to refresh the list.</div>',
				'condition' => [
					'repo_selection_mode' => 'all',
				],
			]
		);

		$this->add_control(
			'selected_repo_single',
			[
				'label'       => esc_html__( 'Repository', 'github-repo-selector' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => '',
				'options'     => array_merge( [ '' => esc_html__( 'Select a repository', 'github-repo-selector' ) ], $repo_options ),
				'label_block' => true,
				'description' => empty( $repo_options ) ? esc_html__( 'Click Update Repositories & Branches first. The dropdown will fill with repos from your saved GitHub token.', 'github-repo-selector' ) : esc_html__( 'Select one repository from the dropdown connected to your GitHub token.', 'github-repo-selector' ),
				'condition'   => [
					'repo_selection_mode' => 'single',
				],
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);

		$repo_repeater = new Repeater();
		$repo_repeater->add_control(
			'repo_name',
			[
				'label'       => esc_html__( 'Repository', 'github-repo-selector' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => '',
				'options'     => array_merge( [ '' => esc_html__( 'Select a repository', 'github-repo-selector' ) ], $repo_options ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'selected_repos_list',
			[
				'label'       => esc_html__( 'Repositories List', 'github-repo-selector' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repo_repeater->get_controls(),
				'title_field' => '{{{ repo_name || "Repository" }}}',
				'description' => empty( $repo_options ) ? esc_html__( 'Click Update Repositories & Branches first. Then add rows and choose repositories from the dropdowns.', 'github-repo-selector' ) : esc_html__( 'Add one row per repository. Each row uses the same dropdown style as version v1.0.', 'github-repo-selector' ),
				'condition'   => [
					'repo_selection_mode' => 'multiple',
				],
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);

		$this->end_controls_section();

		// Repository Branch Settings
		$this->start_controls_section(
			'section_branch_settings',
			[
				'label' => esc_html__( 'Branch Settings', 'github-repo-selector' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'default_branch',
			[
				'label'       => esc_html__( 'Selected Branch', 'github-repo-selector' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'main',
				'placeholder' => 'main',
				'description' => esc_html__( 'This branch is used first when it exists on the selected repository. The frontend branch dropdown then updates links and README content live.', 'github-repo-selector' ),
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'show_branches',
			[
				'label'       => esc_html__( 'Show Branch Selector', 'github-repo-selector' ),
				'type'        => Controls_Manager::SWITCHER,
				'default'     => 'yes',
				'description' => esc_html__( 'Allow users to select branches from dropdown', 'github-repo-selector' ),
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);

		$this->end_controls_section();

		// Content Display Settings
		$this->start_controls_section(
			'section_display_settings',
			[
				'label' => esc_html__( 'Display Options', 'github-repo-selector' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_readme',
			[
				'label'   => esc_html__( 'Show README Content', 'github-repo-selector' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'show_repo_description',
			[
				'label'   => esc_html__( 'Show Repository Description', 'github-repo-selector' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'show_repo_stats',
			[
				'label'   => esc_html__( 'Show Repository Stats', 'github-repo-selector' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'show_repo_link',
			[
				'label'   => esc_html__( 'Show GitHub Link Button', 'github-repo-selector' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'show_download_button',
			[
				'label'   => esc_html__( 'Show Download ZIP Button', 'github-repo-selector' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'description' => esc_html__( 'Adds a Download button next to View on GitHub. It downloads the selected branch as a ZIP, or the main/default branch if that is selected.', 'github-repo-selector' ),
				'render_type' => 'template',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'readme_max_height',
			[
				'label'     => esc_html__( 'README Max Height (px)', 'github-repo-selector' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 400,
				'render_type' => 'template',
				'frontend_available' => true,
				'condition' => [
					'show_readme' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		// Styling
		$this->start_controls_section(
			'section_style_container',
			[
				'label' => esc_html__( 'Container Style', 'github-repo-selector' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'container_background',
			[
				'label'     => esc_html__( 'Background Color', 'github-repo-selector' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .github-repo-container' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'container_border',
				'label'    => esc_html__( 'Border', 'github-repo-selector' ),
				'selector' => '{{WRAPPER}} .github-repo-container',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'container_shadow',
				'label'    => esc_html__( 'Box Shadow', 'github-repo-selector' ),
				'selector' => '{{WRAPPER}} .github-repo-container',
			]
		);

		$this->add_control(
			'container_padding',
			[
				'label'      => esc_html__( 'Padding', 'github-repo-selector' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => 20,
					'right'  => 20,
					'bottom' => 20,
					'left'   => 20,
				],
				'selectors'  => [
					'{{WRAPPER}} .github-repo-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Repo Card Styling
		$this->start_controls_section(
			'section_style_repo_card',
			[
				'label' => esc_html__( 'Repository Card Style', 'github-repo-selector' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'repo_card_background',
			[
				'label'     => esc_html__( 'Background Color', 'github-repo-selector' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f6f8fa',
				'selectors' => [
					'{{WRAPPER}} .repo-card' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'repo_card_border',
				'label'    => esc_html__( 'Border', 'github-repo-selector' ),
				'selector' => '{{WRAPPER}} .repo-card',
			]
		);

		$this->add_control(
			'repo_card_padding',
			[
				'label'      => esc_html__( 'Padding', 'github-repo-selector' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => 15,
					'right'  => 15,
					'bottom' => 15,
					'left'   => 15,
				],
				'selectors'  => [
					'{{WRAPPER}} .repo-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'repo_card_margin',
			[
				'label'      => esc_html__( 'Margin', 'github-repo-selector' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => 15,
					'right'  => 0,
					'bottom' => 15,
					'left'   => 0,
				],
				'selectors'  => [
					'{{WRAPPER}} .repo-card' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Title Styling
		$this->start_controls_section(
			'section_style_title',
			[
				'label' => esc_html__( 'Title Style', 'github-repo-selector' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'github-repo-selector' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#0969da',
				'selectors' => [
					'{{WRAPPER}} .repo-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'label'    => esc_html__( 'Typography', 'github-repo-selector' ),
				'selector' => '{{WRAPPER}} .repo-title',
				'fields_options' => [
					'typography' => [ 'default' => 'yes' ],
					'font_size' => [ 'default' => [ 'size' => 20 ] ],
					'font_weight' => [ 'default' => 600 ],
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$dashboard_mode = ! empty( $settings['frontend_dashboard_mode'] ) && 'yes' === $settings['frontend_dashboard_mode'];

		if ( $dashboard_mode ) {
			echo '<div class="github-repo-dashboard-mode-active">';
			$this->render_frontend_dashboard_tools( $settings );
		}

		$username = $this->github_api->get_authenticated_username();
		$selected_repos = [];
		$repo_selection_mode = ! empty( $settings['repo_selection_mode'] ) ? sanitize_text_field( $settings['repo_selection_mode'] ) : 'multiple';

		if ( $dashboard_mode || 'all' === $repo_selection_mode ) {
			// Dashboard mode always shows all cached repositories under the GitHub Tools panel.
			// Normal all-repositories mode also uses the saved dropdown cache.
			$cached_repo_options = Settings::get_saved_repo_options();
			$selected_repos = array_keys( $cached_repo_options );
		} elseif ( 'single' === $repo_selection_mode ) {
			if ( ! empty( $settings['selected_repo_single'] ) ) {
				$selected_repos = [ sanitize_text_field( $settings['selected_repo_single'] ) ];
			}
		} else {
			if ( ! empty( $settings['selected_repos_list'] ) && is_array( $settings['selected_repos_list'] ) ) {
				foreach ( $settings['selected_repos_list'] as $repo_row ) {
					if ( ! empty( $repo_row['repo_name'] ) ) {
						$selected_repos[] = sanitize_text_field( $repo_row['repo_name'] );
					}
				}
			} elseif ( ! empty( $settings['selected_repos'] ) ) {
				// Backwards compatibility for older v1.0/v1.0 widgets that used a SELECT2 multiple field.
				$selected_repos = array_map( 'sanitize_text_field', (array) $settings['selected_repos'] );
			}
		}
		$selected_repos = array_values( array_unique( array_filter( $selected_repos ) ) );

		if ( empty( $username ) ) {
			echo '<div class="elementor-alert elementor-alert-danger">' .
				sprintf(
					esc_html__( 'No GitHub account is connected. Add a valid token in %s.', 'github-repo-selector' ),
					'<a href="' . esc_url( Settings::get_settings_url() ) . '">' . esc_html__( 'GitHub Repo Selector settings', 'github-repo-selector' ) . '</a>'
				) .
			'</div>';
			return;
		}

		if ( empty( $selected_repos ) ) {
			$repos = $this->github_api->get_user_repos( $username );
			Settings::save_repo_options_from_repos( $repos );
			$selected_repos = wp_list_pluck( $repos, 'name' );
		}

		if ( empty( $selected_repos ) ) {
			echo '<div class="elementor-alert elementor-alert-info">' .
				esc_html__( 'No repositories found for the GitHub account connected to this token.', 'github-repo-selector' ) .
			'</div>';
			return;
		}

		?>
		<?php if ( $dashboard_mode ) : ?>
			<div class="github-repo-dashboard-repositories-box">
				<div class="github-repo-dashboard-repo-heading">
					<h3><?php esc_html_e( 'All GitHub Repositories', 'github-repo-selector' ); ?></h3>
					<p><?php esc_html_e( 'Showing all repositories currently saved in the GitHub cache.', 'github-repo-selector' ); ?></p>
				</div>
		<?php endif; ?>
		<div class="github-repo-container">
			<?php
			foreach ( $selected_repos as $repo_name ) {
				$this->render_repo_card( $username, $repo_name, $settings );
			}
			?>
		</div>
		<?php
		if ( $dashboard_mode ) {
			echo '</div></div>';
		}
	}


	private function render_frontend_dashboard_tools( $settings ) {
		$repo_options = Settings::get_saved_repo_options();
		$branch_options = Settings::get_saved_branch_options();

		$repo_count = is_array( $repo_options ) ? count( $repo_options ) : 0;
		$branch_count = 0;

		if ( is_array( $branch_options ) ) {
			foreach ( $branch_options as $branch_list ) {
				if ( is_array( $branch_list ) ) {
					$branch_count += count( $branch_list );
				}
			}
		}

		$last_repo_updated = get_option( 'github_repo_selector_repo_cache_updated', '' );
		$last_branch_updated = get_option( 'github_repo_selector_branch_cache_updated', '' );
		$last_updated = ! empty( $last_branch_updated ) ? $last_branch_updated : $last_repo_updated;

		if ( empty( $last_updated ) ) {
			$last_updated = __( 'Never', 'github-repo-selector' );
		}

		$can_update = current_user_can( 'manage_options' ) || current_user_can( 'edit_posts' );
		?>
		<div class="github-repo-dashboard-tools" data-github-repo-dashboard-tools="yes">
			<div class="github-repo-dashboard-tools-header">
				<h3><?php esc_html_e( 'GitHub Tools', 'github-repo-selector' ); ?></h3>
				<p><?php esc_html_e( 'Update the repository and branch cache used by the GitHub Repo Selector widget.', 'github-repo-selector' ); ?></p>
			</div>


			<?php $github_user = $this->github_api->get_authenticated_user(); ?>
			<?php if ( ! empty( $github_user['login'] ) ) : ?>
				<div class="github-repo-dashboard-account">
					<?php if ( ! empty( $github_user['avatar_url'] ) ) : ?>
						<img src="<?php echo esc_url( $github_user['avatar_url'] ); ?>" alt="<?php echo esc_attr( $github_user['login'] ); ?>">
					<?php endif; ?>
					<div>
						<span><?php esc_html_e( 'Connected GitHub account', 'github-repo-selector' ); ?></span>
						<strong>@<?php echo esc_html( $github_user['login'] ); ?></strong>
						<?php if ( ! empty( $github_user['html_url'] ) ) : ?>
							<a href="<?php echo esc_url( $github_user['html_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'View profile', 'github-repo-selector' ); ?></a>
						<?php endif; ?>
					</div>
				</div>
			<?php endif; ?>


			<div class="github-repo-dashboard-tools-actions">
				<?php if ( $can_update ) : ?>
					<button type="button" class="github-repo-dashboard-update-button repo-button repo-view-button" data-github-cache-update="yes">
						<?php esc_html_e( 'Update Repositories & Branches', 'github-repo-selector' ); ?>
					</button>
				<?php else : ?>
					<div class="github-repo-dashboard-message github-repo-dashboard-message-warning">
						<?php esc_html_e( 'You need permission to update the GitHub cache.', 'github-repo-selector' ); ?>
					</div>
				<?php endif; ?>
			</div>

			<div class="github-repo-dashboard-cache-grid">
				<div class="github-repo-dashboard-cache-card">
					<span class="github-repo-dashboard-cache-label"><?php esc_html_e( 'Repos cached', 'github-repo-selector' ); ?></span>
					<strong class="github-repo-dashboard-repo-count"><?php echo esc_html( $repo_count ); ?></strong>
				</div>
				<div class="github-repo-dashboard-cache-card">
					<span class="github-repo-dashboard-cache-label"><?php esc_html_e( 'Branches cached', 'github-repo-selector' ); ?></span>
					<strong class="github-repo-dashboard-branch-count"><?php echo esc_html( $branch_count ); ?></strong>
				</div>
				<div class="github-repo-dashboard-cache-card github-repo-dashboard-cache-card-wide">
					<span class="github-repo-dashboard-cache-label"><?php esc_html_e( 'Last updated', 'github-repo-selector' ); ?></span>
					<strong class="github-repo-dashboard-last-updated"><?php echo esc_html( $last_updated ); ?></strong>
				</div>
				<div class="github-repo-dashboard-cache-card github-repo-dashboard-cache-card-wide github-repo-dashboard-latest-url-card">
					<span class="github-repo-dashboard-cache-label"><?php esc_html_e( 'Latest GitHub edit URL', 'github-repo-selector' ); ?></span>
					<strong class="github-repo-dashboard-latest-url">
						<?php $latest_github_url = get_option( 'github_repo_selector_latest_edit_url', '' ); ?>
						<?php if ( ! empty( $latest_github_url ) ) : ?>
							<a href="<?php echo esc_url( $latest_github_url ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $latest_github_url ); ?></a>
						<?php else : ?>
							<?php esc_html_e( 'No GitHub repository or branch edits yet', 'github-repo-selector' ); ?>
						<?php endif; ?>
					</strong>
				</div>
			</div>

			<?php $dashboard_repos = Settings::get_content_repo_options(); ?>
			<?php
			$dashboard_repos = Settings::get_content_repo_options();
			$dashboard_branches = Settings::get_saved_branch_options();
			?>
			<div class="github-repo-dashboard-management" data-branches='<?php echo esc_attr( wp_json_encode( $dashboard_branches ) ); ?>'>
				<h4><?php esc_html_e( 'GitHub Management', 'github-repo-selector' ); ?></h4>
				<p><?php esc_html_e( 'These actions sync directly with GitHub and only show in Front-End Dashboard Mode.', 'github-repo-selector' ); ?></p>

				<div class="github-repo-dashboard-action-grid">
					<div class="github-repo-dashboard-action-card github-repo-dashboard-wide-card github-repo-dashboard-add-card" data-add-type="create_repo">
						<h5><?php esc_html_e( 'Add repository or branch', 'github-repo-selector' ); ?></h5>
						<select class="github-dashboard-add-type">
							<option value="create_repo"><?php esc_html_e( 'Add repository', 'github-repo-selector' ); ?></option>
							<option value="create_branch"><?php esc_html_e( 'Add branch', 'github-repo-selector' ); ?></option>
						</select>

						<div class="github-dashboard-add-repo-fields">
							<input type="text" class="github-dashboard-repo-name" placeholder="<?php esc_attr_e( 'new-repo-name', 'github-repo-selector' ); ?>">
							<input type="text" class="github-dashboard-repo-description" placeholder="<?php esc_attr_e( 'Optional GitHub repo description', 'github-repo-selector' ); ?>">
						</div>

						<div class="github-dashboard-add-branch-fields">
							<label class="github-dashboard-field-label"><?php esc_html_e( 'Select repository to add branch into', 'github-repo-selector' ); ?></label>
							<select class="github-dashboard-repo-select">
								<option value=""><?php esc_html_e( 'Select repo', 'github-repo-selector' ); ?></option>
								<?php foreach ( $dashboard_repos as $repo_key => $repo_label ) : ?>
									<option value="<?php echo esc_attr( $repo_key ); ?>"><?php echo esc_html( $repo_label ); ?></option>
								<?php endforeach; ?>
							</select>
							<select class="github-dashboard-source-branch-select">
								<option value=""><?php esc_html_e( 'Source branch / default', 'github-repo-selector' ); ?></option>
							</select>
							<input type="text" class="github-dashboard-branch-name" placeholder="<?php esc_attr_e( 'new-branch-name', 'github-repo-selector' ); ?>">
						</div>

						<button type="button" class="github-repo-dashboard-github-action repo-button repo-view-button" data-github-action-from-add-select="yes">
							<?php esc_html_e( 'Add Selected', 'github-repo-selector' ); ?>
						</button>
					</div>


					<div class="github-repo-dashboard-action-card github-repo-dashboard-danger-card github-repo-dashboard-wide-card">
						<h5><?php esc_html_e( 'Delete repository or branch', 'github-repo-selector' ); ?></h5>
						<select class="github-dashboard-delete-type">
							<option value="delete_branch"><?php esc_html_e( 'Delete branch', 'github-repo-selector' ); ?></option>
							<option value="delete_repo"><?php esc_html_e( 'Delete repository', 'github-repo-selector' ); ?></option>
							<option value="delete_file"><?php esc_html_e( 'Delete file', 'github-repo-selector' ); ?></option>
						</select>
						<select class="github-dashboard-repo-select">
							<option value=""><?php esc_html_e( 'Select repo', 'github-repo-selector' ); ?></option>
							<?php foreach ( $dashboard_repos as $repo_key => $repo_label ) : ?>
								<option value="<?php echo esc_attr( $repo_key ); ?>"><?php echo esc_html( $repo_label ); ?></option>
							<?php endforeach; ?>
						</select>
						<select class="github-dashboard-branch-select">
							<option value=""><?php esc_html_e( 'Select branch', 'github-repo-selector' ); ?></option>
						</select>
						<select class="github-dashboard-file-delete-select">
							<option value=""><?php esc_html_e( 'Select file', 'github-repo-selector' ); ?></option>
						</select>
						<button type="button" class="github-repo-dashboard-github-action github-repo-dashboard-danger-button" data-github-action-from-select="yes">
							<?php esc_html_e( 'Delete Selected', 'github-repo-selector' ); ?>
						</button>
					</div>

					<div class="github-repo-dashboard-action-card github-repo-dashboard-wide-card">
						<h5><?php esc_html_e( 'Create / edit README.md', 'github-repo-selector' ); ?></h5>
						<select class="github-dashboard-repo-select">
							<option value=""><?php esc_html_e( 'Select repo', 'github-repo-selector' ); ?></option>
							<?php foreach ( $dashboard_repos as $repo_key => $repo_label ) : ?>
								<option value="<?php echo esc_attr( $repo_key ); ?>"><?php echo esc_html( $repo_label ); ?></option>
							<?php endforeach; ?>
						</select>
						<select class="github-dashboard-branch-select">
							<option value=""><?php esc_html_e( 'Select branch', 'github-repo-selector' ); ?></option>
						</select>
						<input type="text" class="github-dashboard-file-title" placeholder="<?php esc_attr_e( 'README title, e.g. My Plugin', 'github-repo-selector' ); ?>">
						<button type="button" class="github-dashboard-load-readme repo-button repo-view-button">
							<?php esc_html_e( 'Load README for editing', 'github-repo-selector' ); ?>
						</button>
						<div class="github-dashboard-readme-status" style="display:none;"></div>
						<div class="github-dashboard-wysiwyg-toolbar">
							<button type="button" data-md="h1">H1</button>
							<button type="button" data-md="h2">H2</button>
							<button type="button" data-md="bold">Bold</button>
							<button type="button" data-md="list">List</button>
							<button type="button" data-md="link">Link</button>
						</div>
						<textarea class="github-dashboard-file-content github-dashboard-readme-editor" rows="12" placeholder="<?php esc_attr_e( 'README description/content goes here...', 'github-repo-selector' ); ?>"></textarea>
						<input type="text" class="github-dashboard-commit-message" placeholder="<?php esc_attr_e( 'Commit message, optional', 'github-repo-selector' ); ?>">
						<button type="button" class="github-repo-dashboard-github-action repo-button repo-view-button" data-github-action="create_readme">
							<?php esc_html_e( 'Create / Edit README', 'github-repo-selector' ); ?>
						</button>

						<div class="github-dashboard-readme-modal" aria-hidden="true">
							<div class="github-dashboard-readme-modal-backdrop"></div>
							<div class="github-dashboard-readme-modal-panel" role="dialog" aria-modal="true">
								<div class="github-dashboard-readme-modal-header">
									<h4><?php esc_html_e( 'README editor', 'github-repo-selector' ); ?></h4>
									<button type="button" class="github-dashboard-readme-modal-close" aria-label="<?php esc_attr_e( 'Close README editor', 'github-repo-selector' ); ?>">×</button>
								</div>
								<p class="github-dashboard-readme-modal-note"><?php esc_html_e( 'README loaded from GitHub. Edit the content, then use Create / Edit README to commit it.', 'github-repo-selector' ); ?></p>
								<div class="github-dashboard-readme-modal-toolbar github-dashboard-wysiwyg-toolbar">
									<button type="button" data-md="h1">H1</button>
									<button type="button" data-md="h2">H2</button>
									<button type="button" data-md="bold">Bold</button>
									<button type="button" data-md="list">List</button>
									<button type="button" data-md="link">Link</button>
								</div>
								<textarea class="github-dashboard-readme-modal-editor github-dashboard-readme-editor"></textarea>
								<div class="github-dashboard-readme-modal-actions">
									<button type="button" class="github-dashboard-readme-modal-apply repo-button repo-view-button"><?php esc_html_e( 'Use this README content', 'github-repo-selector' ); ?></button>
									<button type="button" class="github-dashboard-readme-modal-close-button"><?php esc_html_e( 'Close', 'github-repo-selector' ); ?></button>
								</div>
							</div>
						</div>
					</div>

					<div class="github-repo-dashboard-action-card github-repo-dashboard-wide-card">
						<h5><?php esc_html_e( 'Create / update custom file', 'github-repo-selector' ); ?></h5>
						<select class="github-dashboard-repo-select">
							<option value=""><?php esc_html_e( 'Select repo', 'github-repo-selector' ); ?></option>
							<?php foreach ( $dashboard_repos as $repo_key => $repo_label ) : ?>
								<option value="<?php echo esc_attr( $repo_key ); ?>"><?php echo esc_html( $repo_label ); ?></option>
							<?php endforeach; ?>
						</select>
						<select class="github-dashboard-branch-select">
							<option value=""><?php esc_html_e( 'Select branch', 'github-repo-selector' ); ?></option>
						</select>
						<input type="text" class="github-dashboard-file-path" placeholder="<?php esc_attr_e( 'File path, e.g. docs/notes.md', 'github-repo-selector' ); ?>">
						<textarea class="github-dashboard-file-content" rows="6" placeholder="<?php esc_attr_e( 'File text/content', 'github-repo-selector' ); ?>"></textarea>
						<input type="text" class="github-dashboard-commit-message" placeholder="<?php esc_attr_e( 'Commit message, optional', 'github-repo-selector' ); ?>">
						<button type="button" class="github-repo-dashboard-github-action repo-button repo-view-button" data-github-action="create_file">
							<?php esc_html_e( 'Create / Update File', 'github-repo-selector' ); ?>
						</button>
					</div>

					<div class="github-repo-dashboard-action-card github-repo-dashboard-wide-card">
						<h5><?php esc_html_e( 'Upload file / ZIP', 'github-repo-selector' ); ?></h5>
						<select class="github-dashboard-repo-select">
							<option value=""><?php esc_html_e( 'Select repo', 'github-repo-selector' ); ?></option>
							<?php foreach ( $dashboard_repos as $repo_key => $repo_label ) : ?>
								<option value="<?php echo esc_attr( $repo_key ); ?>"><?php echo esc_html( $repo_label ); ?></option>
							<?php endforeach; ?>
						</select>
						<select class="github-dashboard-branch-select">
							<option value=""><?php esc_html_e( 'Select branch', 'github-repo-selector' ); ?></option>
						</select>
						<input type="text" class="github-dashboard-file-path" placeholder="<?php esc_attr_e( 'Destination folder optional, e.g. releases or builds/v4', 'github-repo-selector' ); ?>">
						<input type="file" class="github-dashboard-file-upload">
						<input type="text" class="github-dashboard-commit-message" placeholder="<?php esc_attr_e( 'Commit message, optional', 'github-repo-selector' ); ?>">
						<button type="button" class="github-repo-dashboard-github-action repo-button repo-view-button" data-github-action="upload_file">
							<?php esc_html_e( 'Upload to GitHub', 'github-repo-selector' ); ?>
						</button>
					</div>
				</div>
			</div>
			<div class="github-repo-dashboard-message" style="display:none;"></div>
		</div>
		<?php
	}


	private function render_repo_card( $username, $repo_name, $settings ) {
		$repo_details = $this->github_api->get_repo_details( $username, $repo_name );
		$branches = [];

		if ( 'yes' === $settings['show_branches'] ) {
			$branches = $this->github_api->get_repo_branches( $username, $repo_name );
		}

		if ( empty( $repo_details ) ) {
			return;
		}

		$requested_branch = ! empty( $settings['default_branch'] ) ? sanitize_text_field( $settings['default_branch'] ) : '';
		$repo_default_branch = ! empty( $repo_details['default_branch'] ) ? $repo_details['default_branch'] : 'main';
		$branch_names = ! empty( $branches ) ? wp_list_pluck( $branches, 'name' ) : [];

		// Important: use the branch selected/typed in Elementor first when that branch exists.
		// The old version always preferred GitHub's default branch, so selecting a branch still opened main/default.
		if ( ! empty( $requested_branch ) && ( empty( $branch_names ) || in_array( $requested_branch, $branch_names, true ) ) ) {
			$initial_branch = $requested_branch;
		} else {
			$initial_branch = $repo_default_branch;
		}

		$branch_url = $this->build_github_branch_url( $repo_details['html_url'], $initial_branch );
		$download_url = $this->build_github_branch_zip_url( $repo_details['html_url'], $initial_branch );

		?>
		<div class="repo-card">
			<div class="repo-header">
				<h3 class="repo-title">
					<a class="repo-title-link" href="<?php echo esc_url( $branch_url ); ?>" target="_blank" rel="noopener noreferrer">
						<?php echo esc_html( $repo_details['name'] ); ?>
					</a>
				</h3>
				<?php if ( ! empty( $repo_details['language'] ) ) : ?>
					<span class="repo-language"><?php echo esc_html( $repo_details['language'] ); ?></span>
				<?php endif; ?>
			</div>

			<?php if ( 'yes' === $settings['show_repo_description'] && ! empty( $repo_details['description'] ) ) : ?>
				<p class="repo-description"><?php echo esc_html( $repo_details['description'] ); ?></p>
			<?php endif; ?>

			<?php if ( 'yes' === $settings['show_branches'] && ! empty( $branches ) ) : ?>
				<div class="repo-branches">
					<label for="branch-<?php echo esc_attr( $repo_name ); ?>">
						<?php esc_html_e( 'Branch:', 'github-repo-selector' ); ?>
					</label>
					<select id="branch-<?php echo esc_attr( $repo_name ); ?>" class="branch-selector" data-owner="<?php echo esc_attr( $username ); ?>" data-repo="<?php echo esc_attr( $repo_name ); ?>" data-base-url="<?php echo esc_url( $repo_details['html_url'] ); ?>" data-current-branch="<?php echo esc_attr( $initial_branch ); ?>">
						<?php foreach ( $branches as $branch ) : ?>
							<option value="<?php echo esc_attr( $branch['name'] ); ?>" <?php selected( $branch['name'], $initial_branch ); ?>>
								<?php echo esc_html( $branch['name'] ); ?>
								<?php if ( $branch['name'] === $repo_default_branch ) : ?>
									(default)
								<?php endif; ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>
			<?php endif; ?>

			<?php if ( 'yes' === $settings['show_repo_stats'] ) : ?>
				<div class="repo-stats">
					<span class="stat">
						<span class="stat-label"><?php esc_html_e( 'Stars:', 'github-repo-selector' ); ?></span>
						<span class="stat-value"><?php echo number_format( $repo_details['stargazers_count'] ); ?></span>
					</span>
					<span class="stat">
						<span class="stat-label"><?php esc_html_e( 'Forks:', 'github-repo-selector' ); ?></span>
						<span class="stat-value"><?php echo number_format( $repo_details['forks_count'] ); ?></span>
					</span>
					<?php if ( ! $repo_details['private'] ) : ?>
						<span class="stat">
							<span class="stat-label"><?php esc_html_e( 'Watchers:', 'github-repo-selector' ); ?></span>
							<span class="stat-value"><?php echo number_format( $repo_details['watchers_count'] ); ?></span>
						</span>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<?php if ( 'yes' === $settings['show_readme'] ) : ?>
				<div class="repo-readme-container" style="max-height: <?php echo intval( $settings['readme_max_height'] ); ?>px; overflow-y: auto;">
					<?php
					$readme = $this->github_api->get_repo_readme( $username, $repo_name, $initial_branch );
					
					if ( ! empty( $readme ) ) {
						// Convert markdown to HTML (basic)
						$readme = $this->markdown_to_html( $readme );
						echo wp_kses_post( $readme );
					} else {
						echo '<p class="repo-no-readme">' . esc_html__( 'No README available', 'github-repo-selector' ) . '</p>';
					}
					?>
				</div>
			<?php endif; ?>

			<?php if ( 'yes' === $settings['show_repo_link'] || ( isset( $settings['show_download_button'] ) && 'yes' === $settings['show_download_button'] ) ) : ?>
				<div class="repo-footer">
					<?php if ( 'yes' === $settings['show_repo_link'] ) : ?>
						<a href="<?php echo esc_url( $branch_url ); ?>" class="repo-button repo-view-button" target="_blank" rel="noopener noreferrer">
							<?php esc_html_e( 'View on GitHub', 'github-repo-selector' ); ?>
						</a>
					<?php endif; ?>
					<?php if ( isset( $settings['show_download_button'] ) && 'yes' === $settings['show_download_button'] ) : ?>
						<a href="<?php echo esc_url( $download_url ); ?>" class="repo-button repo-download-button" target="_blank" rel="noopener noreferrer" download>
							<?php esc_html_e( 'Download ZIP', 'github-repo-selector' ); ?>
						</a>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}


	private function build_github_branch_url( $base_url, $branch ) {
		$base_url = untrailingslashit( $base_url );
		$branch_parts = array_map( 'rawurlencode', explode( '/', (string) $branch ) );
		return $base_url . '/tree/' . implode( '/', $branch_parts );
	}

	private function build_github_branch_zip_url( $base_url, $branch ) {
		$base_url = untrailingslashit( $base_url );
		$branch_parts = array_map( 'rawurlencode', explode( '/', (string) $branch ) );
		return $base_url . '/archive/refs/heads/' . implode( '/', $branch_parts ) . '.zip';
	}

	/**
	 * Basic markdown to HTML conversion
	 */
	private function markdown_to_html( $markdown ) {
		// Convert headers
		$markdown = preg_replace( '/^### (.*?)$/m', '<h3>$1</h3>', $markdown );
		$markdown = preg_replace( '/^## (.*?)$/m', '<h2>$1</h2>', $markdown );
		$markdown = preg_replace( '/^# (.*?)$/m', '<h1>$1</h1>', $markdown );

		// Convert bold
		$markdown = preg_replace( '/\*\*(.*?)\*\*/', '<strong>$1</strong>', $markdown );
		$markdown = preg_replace( '/__(.+?)__/', '<strong>$1</strong>', $markdown );

		// Convert italic
		$markdown = preg_replace( '/\*(.*?)\*/', '<em>$1</em>', $markdown );
		$markdown = preg_replace( '/_(.+?)_/', '<em>$1</em>', $markdown );

		// Convert line breaks
		$markdown = nl2br( $markdown );

		// Convert links
		$markdown = preg_replace( '/\[(.*?)\]\((.*?)\)/', '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>', $markdown );

		// Convert code blocks
		$markdown = preg_replace( '/`([^`]+)`/', '<code>$1</code>', $markdown );

		// Convert lists
		$markdown = preg_replace( '/^\- (.*?)$/m', '<li>$1</li>', $markdown );
		$markdown = preg_replace( '/(<li>.*<\/li>)/s', '<ul>$1</ul>', $markdown );

		return $markdown;
	}

	protected function content_template() {
		$repo_options = Settings::get_saved_repo_options();
		$repo_names = array_values( array_keys( $repo_options ) );
		?>
		<#
		var dashboardMode = settings.frontend_dashboard_mode === 'yes';
		var repoMode = dashboardMode ? 'all' : ( settings.repo_selection_mode || 'multiple' );
		var selectedRepos = [];
		var cachedRepos = <?php echo wp_json_encode( $repo_names ); ?> || [];
		var branch = settings.default_branch || 'main';
		var maxHeight = settings.readme_max_height || 400;
		var showDescription = settings.show_repo_description !== 'yes' ? false : true;
		var showStats = settings.show_repo_stats !== 'yes' ? false : true;
		var showReadme = settings.show_readme !== 'yes' ? false : true;
		var showBranches = settings.show_branches !== 'yes' ? false : true;
		var showGithub = settings.show_repo_link !== 'yes' ? false : true;
		var showDownload = settings.show_download_button !== 'yes' ? false : true;

		function cleanRepoName( value ) {
			return value ? String( value ) : '';
		}

		function repoBranchUrl( repo, selectedBranch ) {
			var owner = '<?php echo esc_js( $this->github_api->get_authenticated_username() ?: 'your-github-account' ); ?>';
			var encodedBranch = String( selectedBranch || 'main' ).split( '/' ).map( encodeURIComponent ).join( '/' );
			return 'https://github.com/' + owner + '/' + encodeURIComponent( repo ) + '/tree/' + encodedBranch;
		}

		function repoZipUrl( repo, selectedBranch ) {
			var owner = '<?php echo esc_js( $this->github_api->get_authenticated_username() ?: 'your-github-account' ); ?>';
			var encodedBranch = String( selectedBranch || 'main' ).split( '/' ).map( encodeURIComponent ).join( '/' );
			return 'https://github.com/' + owner + '/' + encodeURIComponent( repo ) + '/archive/refs/heads/' + encodedBranch + '.zip';
		}

		if ( repoMode === 'all' ) {
			selectedRepos = cachedRepos.slice( 0 );
		} else if ( repoMode === 'single' ) {
			if ( settings.selected_repo_single ) {
				selectedRepos = [ cleanRepoName( settings.selected_repo_single ) ];
			}
		} else if ( settings.selected_repos_list && settings.selected_repos_list.length ) {
			_.each( settings.selected_repos_list, function( row ) {
				if ( row && row.repo_name ) {
					selectedRepos.push( cleanRepoName( row.repo_name ) );
				}
			} );
		}

		selectedRepos = _.uniq( _.filter( selectedRepos ) );
		if ( ! selectedRepos.length ) {
			selectedRepos = [ 'Select a repository' ];
		}
		#>
		<# if ( dashboardMode ) { #>
			<div class="github-repo-dashboard-tools github-repo-selector-live-preview-tools">
				<div class="github-repo-dashboard-tools-header">
					<h3>GitHub Tools</h3>
					<p>Update the repository and branch cache used by the GitHub Repo Selector widget.</p>
				</div>
				<div class="github-repo-dashboard-account github-repo-dashboard-account-preview">
					<div class="github-repo-dashboard-avatar-placeholder"></div>
					<div>
						<span>Connected GitHub account</span>
						<strong>@<?php echo esc_js( $this->github_api->get_authenticated_username() ?: 'your-github-account' ); ?></strong>
						<a href="#">View profile</a>
					</div>
				</div>
				<div class="github-repo-dashboard-tools-actions">
					<button type="button" class="github-repo-dashboard-update-button repo-button repo-view-button">Update Repositories & Branches</button>
				</div>
				<div class="github-repo-dashboard-cache-grid">
					<div class="github-repo-dashboard-cache-card">
						<span class="github-repo-dashboard-cache-label">Repos cached</span>
						<strong class="github-repo-dashboard-repo-count"><?php echo esc_js( count( $repo_names ) ); ?></strong>
						<div class="github-repo-dashboard-management">
					<h4>GitHub Management</h4>
					<p>Dashboard-only controls for adding or deleting repos and branches.</p>
					<div class="github-repo-dashboard-action-grid">
						<div class="github-repo-dashboard-action-card"><h5>Add repository</h5><input placeholder="new-repo-name"><button class="repo-button repo-view-button">Add Repo</button></div>
						<div class="github-repo-dashboard-action-card"><h5>Add branch</h5>
							<div style="margin-bottom: 10px;">
								<label style="display: block; font-size: 12px; font-weight: 600; margin-bottom: 6px; color: #24292f;">Select Repository:</label>
								<select class="github-add-branch-repo-select" style="width: 100%; padding: 8px; border: 1px solid #d0d7de; border-radius: 4px; font-size: 13px;">
									<option value="">-- Choose a repository --</option>
								</select>
							</div>
							<input class="github-add-branch-name" placeholder="new-branch-name" style="width: 100%; padding: 8px; border: 1px solid #d0d7de; border-radius: 4px; margin-bottom: 10px;">
							<button class="repo-button repo-view-button github-add-branch-btn" style="width: 100%;">Add Branch</button>
						</div>
						<div class="github-repo-dashboard-action-card github-repo-dashboard-danger-card"><h5>Delete branch</h5><input placeholder="branch-to-delete"><button class="github-repo-dashboard-danger-button">Delete Branch</button></div>
						<div class="github-repo-dashboard-action-card github-repo-dashboard-danger-card"><h5>Delete repository</h5><button class="github-repo-dashboard-danger-button">Delete Repo</button></div>
						<div class="github-repo-dashboard-action-card github-repo-dashboard-wide-card"><h5>Create / update file</h5><input placeholder="README.md"><textarea placeholder="# README.md content"></textarea><button class="repo-button repo-view-button">Create / Update File</button></div>
						<div class="github-repo-dashboard-action-card github-repo-dashboard-wide-card"><h5>Upload file / ZIP</h5><input placeholder="releases/"><input type="file"><button class="repo-button repo-view-button">Upload to GitHub</button></div>
					</div>
				</div>
			</div>
					<div class="github-repo-dashboard-cache-card">
						<span class="github-repo-dashboard-cache-label">Branches cached</span>
						<strong class="github-repo-dashboard-branch-count">Live count</strong>
					</div>

					<div class="github-repo-dashboard-cache-card github-repo-dashboard-cache-card-wide">
						<span class="github-repo-dashboard-cache-label"><?php esc_html_e( 'Latest GitHub edit URL', 'github-repo-selector' ); ?></span>
						<strong class="github-repo-dashboard-latest-url">
							<?php echo esc_html( get_option( 'github_repo_selector_latest_edit_url', 'No GitHub repository or branch edits yet' ) ); ?>
						</strong>
					</div>


					<div class="github-repo-dashboard-cache-card github-repo-dashboard-cache-card-wide">
						<span class="github-repo-dashboard-cache-label">Latest GitHub edit URL</span>
						<strong class="github-repo-dashboard-latest-url">https://github.com/username/repo/tree/branch</strong>
					</div>

					<div class="github-repo-dashboard-cache-card github-repo-dashboard-cache-card-wide">
						<span class="github-repo-dashboard-cache-label">Last updated</span>
						<strong class="github-repo-dashboard-last-updated">Saved cache time</strong>
					</div>
				</div>
			</div>
			<div class="github-repo-dashboard-repo-heading">
				<h3>All GitHub Repositories</h3>
				<p>Showing all repositories currently saved in the GitHub cache.</p>
			</div>
		<# } #>
		<div class="github-repo-container github-repo-selector-live-preview" data-preview-mode="{{ repoMode }}">
			<# _.each( selectedRepos, function( repoName ) { 
				var isPlaceholder = repoName === 'Select a repository';
				var viewUrl = isPlaceholder ? '#' : repoBranchUrl( repoName, branch );
				var zipUrl = isPlaceholder ? '#' : repoZipUrl( repoName, branch );
			#>
				<div class="repo-card">
					<div class="repo-header">
						<h3 class="repo-title">
							<# if ( isPlaceholder ) { #>
								{{{ repoName }}}
							<# } else { #>
								<a class="repo-title-link" href="{{ viewUrl }}" target="_blank" rel="noopener noreferrer">{{{ repoName }}}</a>
							<# } #>
						</h3>
						<span class="repo-language">Live preview</span>
					</div>

					<# if ( showDescription ) { #>
						<p class="repo-description">Repository description will show here from GitHub on the live page.</p>
					<# } #>

					<# if ( showBranches ) { #>
						<div class="repo-branches">
							<label>Branch:</label>
							<select class="branch-selector">
								<option selected>{{{ branch }}}</option>
							</select>
						</div>
					<# } #>

					<# if ( showStats ) { #>
						<div class="repo-stats">
							<span class="stat"><span class="stat-label">Stars:</span> <span class="stat-value">0</span></span>
							<span class="stat"><span class="stat-label">Forks:</span> <span class="stat-value">0</span></span>
						</div>
					<# } #>

					<# if ( showReadme ) { #>
						<div class="repo-readme-container" style="max-height: {{ maxHeight }}px; overflow-y: auto;">
							<p><strong>README preview</strong></p>
							<p>The real README loads from GitHub on the frontend. This preview updates live while you change repository mode, repo selection, branch, buttons and display options.</p>
						</div>
					<# } #>

					<# if ( showGithub || showDownload ) { #>
						<div class="repo-footer">
							<# if ( showGithub ) { #>
								<a href="{{ viewUrl }}" class="repo-button repo-view-button" target="_blank" rel="noopener noreferrer">View on GitHub</a>
							<# } #>
							<# if ( showDownload ) { #>
								<a href="{{ zipUrl }}" class="repo-button repo-download-button" target="_blank" rel="noopener noreferrer" download>Download ZIP</a>
							<# } #>
						</div>
					<# } #>
				</div>
			<# } ); #>
		</div>
		<?php
	}
}
