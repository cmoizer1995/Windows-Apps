( function( $ ) {
	'use strict';

	function markdownFallback( text ) {
		return String( text || '' )
			.replace( /^### (.*?)$/gm, '<h3>$1</h3>' )
			.replace( /^## (.*?)$/gm, '<h2>$1</h2>' )
			.replace( /^# (.*?)$/gm, '<h1>$1</h1>' )
			.replace( /\*\*(.*?)\*\*/g, '<strong>$1</strong>' )
			.replace( /`([^`]+)`/g, '<code>$1</code>' )
			.replace( /\[(.*?)\]\((.*?)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>' )
			.replace( /\n/g, '<br>' );
	}

	function encodeBranchForGitHubUrl( branch ) {
		// GitHub branch names can contain slashes. Encoding the whole branch turns / into %2F,
		// which can make GitHub fall back or fail. Encode each path part instead.
		return String( branch || '' ).split( '/' ).map( encodeURIComponent ).join( '/' );
	}

	function getBranchUrl( baseUrl, branch ) {
		return String( baseUrl || '' ).replace( /\/$/, '' ) + '/tree/' + encodeBranchForGitHubUrl( branch );
	}

	function getBranchZipUrl( baseUrl, branch ) {
		return String( baseUrl || '' ).replace( /\/$/, '' ) + '/archive/refs/heads/' + encodeBranchForGitHubUrl( branch ) + '.zip';
	}

	function updateCardBranchLinks( select ) {
		const $card = $( select ).closest( '.repo-card' );
		const branch = select.value || select.dataset.currentBranch || '';
		const baseUrl = select.dataset.baseUrl || '';
		const branchUrl = getBranchUrl( baseUrl, branch );
		const zipUrl = getBranchZipUrl( baseUrl, branch );

		select.dataset.currentBranch = branch;
		$card.attr( 'data-selected-branch', branch );
		$card.find( '.repo-title-link, .repo-view-button' ).attr( 'href', branchUrl ).attr( 'data-selected-branch', branch );
		$card.find( '.repo-download-button' ).attr( 'href', zipUrl ).attr( 'data-selected-branch', branch );

		return branchUrl;
	}

	$( document ).on( 'change', '.github-repo-container .branch-selector', function() {
		const select = this;
		const $card = $( select ).closest( '.repo-card' );
		const owner = select.dataset.owner || '';
		const repo = select.dataset.repo || '';
		const branch = select.value || select.dataset.currentBranch || '';
		const branchUrl = updateCardBranchLinks( select );

		const $readme = $card.find( '.repo-readme-container' );
		if ( ! $readme.length || ! owner || ! repo || ! branch ) {
			return;
		}

		$readme.addClass( 'is-loading' ).html( '<p class="repo-loading-readme">Loading README for ' + branch + '...</p>' );

		$.ajax( {
			url: ( window.cmWlfdGithubFrontend && window.cmWlfdGithubFrontend.ajaxurl ) || '/wp-admin/admin-ajax.php',
			method: 'POST',
			data: {
				action: 'cm_wlfd_github_fetch_readme',
				nonce: ( window.cmWlfdGithubFrontend && window.cmWlfdGithubFrontend.nonce ) || '',
				owner: owner,
				repo: repo,
				branch: branch
			}
		} ).done( function( response ) {
			if ( response && response.success && response.data && response.data.readme ) {
				$readme.html( response.data.readme );
			} else {
				$readme.html( '<p class="repo-no-readme">No README available for this branch.</p>' );
			}
		} ).fail( function() {
			$readme.html( '<p class="repo-no-readme">Could not load README for this branch.</p>' );
		} ).always( function() {
			$readme.removeClass( 'is-loading' );
		} );
	} );

	$( document ).on( 'click', '.github-repo-container .repo-title-link, .github-repo-container .repo-view-button, .github-repo-container .repo-download-button', function() {
		const $card = $( this ).closest( '.repo-card' );
		const select = $card.find( '.branch-selector' ).get( 0 );
		if ( select ) {
			updateCardBranchLinks( select );
		}
	} );


	function updateDashboardCounts( $tools, data ) {
		if ( data && typeof data.count !== 'undefined' ) {
			$tools.find( '.github-repo-dashboard-repo-count' ).text( data.count );
		}
		if ( data && typeof data.branch_count !== 'undefined' ) {
			$tools.find( '.github-repo-dashboard-branch-count' ).text( data.branch_count );
		}
		$tools.find( '.github-repo-dashboard-last-updated' ).text( 'Just now' );
	}

	$( document ).on( 'click', '.github-repo-dashboard-update-button', function( e ) {
		e.preventDefault();

		const button = this;
		const $button = $( button );
		var $tools = $button.closest( '.github-repo-dashboard-tools' );
		if ( ! $tools.length ) {
			$tools = $button.closest( '.github-repo-dashboard-settings-panel' );
		}
		const $message = $tools.find( '.github-repo-dashboard-message' ).last();

		$button.prop( 'disabled', true ).text( 'Updating repos and branches...' );
		$message.removeClass( 'github-repo-dashboard-message-success github-repo-dashboard-message-error' ).show().text( 'Connecting to GitHub and refreshing cache...' );

		$.ajax( {
			url: ( window.cmWlfdGithubFrontend && window.cmWlfdGithubFrontend.ajaxurl ) || '/wp-admin/admin-ajax.php',
			method: 'POST',
			data: {
				action: 'cm_wlfd_github_update_cache',
				nonce: ( window.cmWlfdGithubFrontend && window.cmWlfdGithubFrontend.nonce ) || ''
			}
		} ).done( function( response ) {
			if ( response && response.success && response.data ) {
				updateDashboardCounts( $tools, response.data );
				$message.addClass( 'github-repo-dashboard-message-success' ).text(
					'Updated ' + response.data.count + ' repositories and ' + ( response.data.branch_count || 0 ) + ' branches from @' + response.data.username + '. Refreshing page...'
				);

				setTimeout( function() {
					var url = window.location.href.split( '#' )[0];
					var separator = url.indexOf( '?' ) === -1 ? '?' : '&';
					window.location.href = url + separator + 'github_cache_updated=' + Date.now();
				}, 1200 );
			} else {
				$message.addClass( 'github-repo-dashboard-message-error' ).text(
					( response && response.data && response.data.message ) ? response.data.message : 'Could not update GitHub cache.'
				);
			}
		} ).fail( function() {
			$message.addClass( 'github-repo-dashboard-message-error' ).text( 'Could not connect to WordPress AJAX. Check login/session permissions.' );
		} ).always( function() {
			$button.prop( 'disabled', false ).text( 'Update Repositories & Branches' );
		} );
	} );




	function getDashboardBranches( $scope ) {
		var raw = $scope.closest( '.github-repo-dashboard-management' ).attr( 'data-branches' ) || '{}';
		try {
			return JSON.parse( raw );
		} catch ( e ) {
			return {};
		}
	}

	function populateDashboardBranchSelects( card ) {
		var $card = $( card );
		var repo = $card.find( '.github-dashboard-repo-select' ).val() || '';
		var branchesByRepo = getDashboardBranches( $card );
		var branches = branchesByRepo[ repo ] || [];

		$card.find( '.github-dashboard-branch-select, .github-dashboard-source-branch-select' ).each( function() {
			var $select = $( this );
			var current = $select.val() || '';
			var firstText = $select.hasClass( 'github-dashboard-source-branch-select' ) ? 'Source branch / default' : 'Select branch';

			$select.empty().append( $( '<option>', { value: '', text: firstText } ) );

			branches.forEach( function( branchName ) {
				$select.append( $( '<option>', { value: branchName, text: branchName } ) );
			} );

			if ( current && branches.indexOf( current ) !== -1 ) {
				$select.val( current );
			}
		} );
	}

	// Populate Add Branch repo selector with cached repos
	$( function() {
		var raw = $( '.github-repo-dashboard-management' ).attr( 'data-branches' ) || '{}';
		var branchesByRepo = {};
		try {
			branchesByRepo = JSON.parse( raw );
		} catch ( e ) {
			branchesByRepo = {};
		}
		
		var repos = Object.keys( branchesByRepo );
		var $repoSelect = $( '.github-add-branch-repo-select' );
		
		repos.forEach( function( repo ) {
			$repoSelect.append( $( '<option>', { value: repo, text: repo } ) );
		} );
	} );

	// Handle repo selection in Add Branch
	$( document ).on( 'change', '.github-add-branch-repo-select', function() {
		var $card = $( this ).closest( '.github-repo-dashboard-action-card' );
		var repo = $( this ).val();
		var $branchInput = $card.find( '.github-add-branch-name' );
		
		// Store selected repo for use when creating branch
		$branchInput.attr( 'data-repo', repo );
		
		if ( repo ) {
			$branchInput.prop( 'disabled', false ).placeholder = 'new-branch-name';
		} else {
			$branchInput.prop( 'disabled', true ).placeholder = 'Please select a repository first';
		}
	} );

	// Handle Add Branch button click
	$( document ).on( 'click', '.github-add-branch-btn', function( e ) {
		e.preventDefault();
		
		var $card = $( this ).closest( '.github-repo-dashboard-action-card' );
		var $repoSelect = $card.find( '.github-add-branch-repo-select' );
		var $branchInput = $card.find( '.github-add-branch-name' );
		
		var repo = $repoSelect.val();
		var branchName = $branchInput.val();
		
		if ( ! repo ) {
			alert( 'Please select a repository first.' );
			return;
		}
		
		if ( ! branchName ) {
			alert( 'Please enter a branch name.' );
			return;
		}
		
		// Change button text to indicate loading
		var $btn = $( this );
		var originalText = $btn.text();
		$btn.prop( 'disabled', true ).text( 'Creating...' );
		
		// Call the GitHub action with repo
		$.ajax( {
			url: ( window.cmWlfdGithubFrontend && window.cmWlfdGithubFrontend.ajaxurl ) || '/wp-admin/admin-ajax.php',
			method: 'POST',
			data: {
				action: 'cm_wlfd_github_dashboard_action',
				nonce: ( window.cmWlfdGithubFrontend && window.cmWlfdGithubFrontend.nonce ) || '',
				github_action: 'create_branch',
				repo: repo,
				branch: branchName,
				source_branch: 'main'
			}
		} ).done( function( response ) {
			if ( response && response.success ) {
				alert( 'Branch created successfully!' );
				$repoSelect.val( '' );
				$branchInput.val( '' ).removeAttr( 'data-repo' ).prop( 'disabled', true );
				// Refresh the page to update cache
				setTimeout( function() {
					location.reload();
				}, 1000 );
			} else {
				alert( 'Error: ' + ( response && response.data && response.data.message ? response.data.message : 'Could not create branch.' ) );
			}
		} ).fail( function() {
			alert( 'Error connecting to server.' );
		} ).always( function() {
			$btn.prop( 'disabled', false ).text( originalText );
		} );
	} );

	$( document ).on( 'change', '.github-repo-dashboard-management .github-dashboard-repo-select', function() {
		populateDashboardBranchSelects( $( this ).closest( '.github-repo-dashboard-action-card' ) );
	} );

	function buildReadmeContentFromCard( $card ) {
		var title = $card.find( '.github-dashboard-file-title' ).val() || '';
		var body = $card.find( '.github-dashboard-file-content' ).val() || '';

		if ( title && body ) {
			return '# ' + title + "\n\n" + body;
		}

		if ( title ) {
			return '# ' + title + "\n";
		}

		return body;
	}




	function loadFilesForDelete( card ) {
		var $card = $( card );
		if ( ( $card.find( '.github-dashboard-delete-type' ).val() || '' ) !== 'delete_file' ) {
			return;
		}

		var repo = $card.find( '.github-dashboard-repo-select' ).val() || '';
		var branch = $card.find( '.github-dashboard-branch-select' ).val() || '';
		var $fileSelect = $card.find( '.github-dashboard-file-delete-select' );

		$fileSelect.empty().append( $( '<option>', { value: '', text: 'Select file' } ) );

		if ( ! repo || ! branch ) {
			return;
		}

		$fileSelect.append( $( '<option>', { value: '', text: 'Loading files...' } ) );

		$.ajax( {
			url: ( window.cmWlfdGithubFrontend && window.cmWlfdGithubFrontend.ajaxurl ) || '/wp-admin/admin-ajax.php',
			method: 'POST',
			data: {
				action: 'cm_wlfd_github_load_files_for_delete',
				nonce: ( window.cmWlfdGithubFrontend && window.cmWlfdGithubFrontend.nonce ) || '',
				repo: repo,
				branch: branch
			}
		} ).done( function( response ) {
			$fileSelect.empty().append( $( '<option>', { value: '', text: 'Select file' } ) );

			if ( response && response.success && response.data && response.data.files && response.data.files.length ) {
				response.data.files.forEach( function( file ) {
					$fileSelect.append( $( '<option>', { value: file.path, text: file.path } ) );
				} );
			} else {
				$fileSelect.append( $( '<option>', { value: '', text: 'No root files found' } ) );
			}
		} ).fail( function() {
			$fileSelect.empty().append( $( '<option>', { value: '', text: 'Could not load files' } ) );
		} );
	}

	$( document ).on( 'change', '.github-dashboard-delete-type, .github-repo-dashboard-action-card .github-dashboard-repo-select, .github-repo-dashboard-action-card .github-dashboard-branch-select', function() {
		var $card = $( this ).closest( '.github-repo-dashboard-action-card' );
		if ( $card.find( '.github-dashboard-file-delete-select' ).length ) {
			setTimeout( function() {
				loadFilesForDelete( $card );
			}, 120 );
		}
	} );



	function openReadmeModal( $card, content ) {
		var $modal = $card.find( '.github-dashboard-readme-modal' );

		if ( ! $modal.length ) {
			// Fallback: if modal markup is missing, still make it obvious the editor is editable.
			$card.find( '.github-dashboard-file-content' ).focus();
			return;
		}

		$modal.find( '.github-dashboard-readme-modal-editor' ).val( content || $card.find( '.github-dashboard-file-content' ).val() || '' );
		$modal.addClass( 'is-open' ).attr( 'aria-hidden', 'false' );
		$( 'body' ).addClass( 'github-readme-modal-open' );
	}

	function closeReadmeModal( $modal ) {
		$modal.removeClass( 'is-open' ).attr( 'aria-hidden', 'true' );
		$( 'body' ).removeClass( 'github-readme-modal-open' );
	}

	function applyReadmeModalContent( $modal ) {
		var content = $modal.find( '.github-dashboard-readme-modal-editor' ).val() || '';
		var $card = $modal.closest( '.github-repo-dashboard-action-card' );
		$card.find( '.github-dashboard-file-content' ).val( content );
		closeReadmeModal( $modal );
	}

	$( document ).on( 'click', '.github-dashboard-readme-modal-close, .github-dashboard-readme-modal-close-button, .github-dashboard-readme-modal-backdrop', function( e ) {
		e.preventDefault();
		closeReadmeModal( $( this ).closest( '.github-dashboard-readme-modal' ) );
	} );

	$( document ).on( 'click', '.github-dashboard-readme-modal-apply', function( e ) {
		e.preventDefault();
		applyReadmeModalContent( $( this ).closest( '.github-dashboard-readme-modal' ) );
	} );

	$( document ).on( 'keydown', function( e ) {
		if ( e.key === 'Escape' ) {
			$( '.github-dashboard-readme-modal.is-open' ).each( function() {
				closeReadmeModal( $( this ) );
			} );
		}
	} );


	function loadReadmeIntoDashboardEditor( card ) {
		var $card = $( card );
		if ( ! $card.find( '.github-dashboard-file-title' ).length ) {
			return;
		}

		var repo = $card.find( '.github-dashboard-repo-select' ).val() || '';
		var branch = $card.find( '.github-dashboard-branch-select' ).val() || '';
		var $status = $card.find( '.github-dashboard-readme-status' );

		if ( ! repo || ! branch ) {
			return;
		}

		$status.removeClass( 'github-repo-dashboard-message-error github-repo-dashboard-message-success' ).show().text( 'Loading README from GitHub...' );

		$.ajax( {
			url: ( window.cmWlfdGithubFrontend && window.cmWlfdGithubFrontend.ajaxurl ) || '/wp-admin/admin-ajax.php',
			method: 'POST',
			data: {
				action: 'cm_wlfd_github_load_readme_for_edit',
				nonce: ( window.cmWlfdGithubFrontend && window.cmWlfdGithubFrontend.nonce ) || '',
				repo: repo,
				branch: branch
			}
		} ).done( function( response ) {
			if ( response && response.success && response.data ) {
				$card.find( '.github-dashboard-file-title' ).val( response.data.title || repo );
				$card.find( '.github-dashboard-file-content' ).val( response.data.readme || '' );
				$status.addClass( 'github-repo-dashboard-message-success' ).text(
					response.data.readme ? 'README loaded for editing.' : 'No README exists yet. You can create one here.'
				);

				openReadmeModal( $card, response.data.readme || '' );

				if ( response.data.github_url ) {
					setLatestInternalLink( $card.closest( '.github-repo-dashboard-tools' ), response.data.viewer || {}, response.data.github_url );
				}
				if ( response.data.viewer ) {
					showInternalViewer( $card.closest( '.github-repo-dashboard-tools' ), response.data.viewer );
				}
			} else {
				$status.addClass( 'github-repo-dashboard-message-error' ).text(
					( response && response.data && response.data.message ) ? response.data.message : 'Could not load README.'
				);
			}
		} ).fail( function() {
			$status.addClass( 'github-repo-dashboard-message-error' ).text( 'Could not connect to WordPress AJAX.' );
		} );
	}

	$( document ).on( 'click', '.github-dashboard-load-readme', function( e ) {
		e.preventDefault();
		loadReadmeIntoDashboardEditor( $( this ).closest( '.github-repo-dashboard-action-card' ) );
	} );


	function setLatestInternalLink( $tools, viewer, displayUrl ) {
		if ( ! $tools || ! $tools.length || ! viewer || ! viewer.repo ) return;
		var label = displayUrl || viewer.github_url || ( ( viewer.owner ? viewer.owner + '/' : '' ) + viewer.repo );
		var $latest = $tools.find( '.github-repo-dashboard-latest-url' ).first();
		var $button = $( '<button>', {
			type: 'button',
			'class': 'github-dashboard-open-internal-view github-dashboard-internal-url',
			text: label
		} );
		$button.attr( 'data-repo', viewer.repo || '' );
		$button.attr( 'data-branch', viewer.branch || '' );
		$button.attr( 'data-path', viewer.path || '' );
		$latest.empty().append( $button );
	}

	function showInternalViewer( $tools, viewer ) {
		if ( ! $tools || ! $tools.length ) return;
		var $panel = $tools.find( '.github-dashboard-internal-view' ).first();
		var $content = $panel.find( '.github-dashboard-internal-view-content' );
		var $title = $panel.find( '.github-dashboard-internal-view-title' );
		if ( ! $panel.length || ! $content.length ) return;

		if ( viewer && viewer.deleted_repo ) {
			$title.text( 'Repository deleted' );
			$content.html( '<div class="github-dashboard-internal-result-note"><strong>Repository deleted from GitHub.</strong><p>The repository no longer exists to preview. Use View → View All to see the repositories that remain.</p></div>' );
		} else if ( viewer && viewer.html ) {
			$title.text( ( viewer.owner ? viewer.owner + '/' : '' ) + ( viewer.repo || 'GitHub repository' ) + ( viewer.branch ? ' · ' + viewer.branch : '' ) );
			$content.html( viewer.html );
			if ( window.CMWLInitGithubBrowsers ) window.CMWLInitGithubBrowsers( $content.get( 0 ) );
		} else {
			$title.text( 'GitHub repository' );
			$content.html( '<div class="github-dashboard-internal-result-note">The GitHub action completed, but there is no repository preview for this action.</div>' );
		}

		$panel.prop( 'hidden', false ).attr( 'hidden', false );
		setTimeout( function() { $panel.get( 0 ).scrollIntoView( { behavior: 'smooth', block: 'start' } ); }, 80 );
	}

	function updateDashboardRepoChoices( $tools, responseData ) {
		if ( ! responseData ) return;
		var options = responseData.options || {};
		var branches = responseData.branches_by_repo || {};
		var $management = $tools.find( '.github-repo-dashboard-management' );
		$management.attr( 'data-branches', JSON.stringify( branches ) );

		$management.find( '.github-dashboard-repo-select' ).each( function() {
			var $select = $( this );
			var current = $select.val() || '';
			$select.empty().append( $( '<option>', { value: '', text: 'Select repo' } ) );
			Object.keys( options ).forEach( function( key ) {
				$select.append( $( '<option>', { value: key, text: options[key] } ) );
			} );
			if ( current && Object.prototype.hasOwnProperty.call( options, current ) ) $select.val( current );
			populateDashboardBranchSelects( $select.closest( '.github-repo-dashboard-action-card' ) );
		} );
	}

	function refreshDashboardAfterGitHubAction( $tools, responseData, messagePrefix ) {
		if ( responseData ) {
			updateDashboardCounts( $tools, responseData );
			updateDashboardRepoChoices( $tools, responseData );
		}

		var $message = $tools.find( '.github-repo-dashboard-message' ).last();
		$message.removeClass( 'github-repo-dashboard-message-error' ).addClass( 'github-repo-dashboard-message-success' ).show().text(
			( responseData && responseData.message ? responseData.message : messagePrefix ) + ' The result is shown below.'
		);

		if ( responseData && responseData.viewer ) {
			showInternalViewer( $tools, responseData.viewer );
			if ( responseData.viewer.repo ) {
				setLatestInternalLink( $tools, responseData.viewer );
			} else if ( responseData.viewer.deleted_repo ) {
				$tools.find( '.github-repo-dashboard-latest-url' ).first().text( 'No GitHub repository or branch edits yet' );
			}
		}
	}


	$( document ).on( 'change', '.github-dashboard-delete-type', function() {
		var $card = $( this ).closest( '.github-repo-dashboard-action-card' );
		$card.attr( 'data-delete-type', $( this ).val() || 'delete_branch' );
	} );


	$( document ).on( 'click', '.cm-wlfd-github-dashboard-action', function( e ) {
		e.preventDefault();

		var button = this;
		var $button = $( button );
		var $tools = $button.closest( '.github-repo-dashboard-tools' );
		var $card = $button.closest( '.github-repo-dashboard-action-card' );
		var $message = $tools.find( '.github-repo-dashboard-message' ).last();
		var action = $button.data( 'github-action' ) || '';
		if ( $button.data( 'github-action-from-select' ) ) {
			action = $card.find( '.github-dashboard-delete-type' ).val() || 'delete_branch';
		}
		if ( $button.data( 'github-action-from-add-select' ) ) {
			action = $card.find( '.github-dashboard-add-type' ).val() || 'create_repo';
		}

		var repo = $card.find( '.github-dashboard-repo-select' ).val() || $card.find( '.github-dashboard-repo-name' ).val() || '';
		var branch = $card.find( '.github-dashboard-branch-select' ).val() || $card.find( '.github-dashboard-branch-name' ).val() || '';
		var sourceBranch = $card.find( '.github-dashboard-source-branch-select' ).val() || $card.find( '.github-dashboard-source-branch' ).val() || '';
		var description = $card.find( '.github-dashboard-repo-description' ).val() || '';

		if ( action === 'create_readme' ) {
			action = 'create_file';
			if ( ! $card.find( '.github-dashboard-file-path' ).length ) {
				$card.append( '<input type="hidden" class="github-dashboard-file-path" value="README.md">' );
			}
		}

		if ( ( action === 'delete_branch' || action === 'delete_repo' || action === 'delete_file' ) && ! window.confirm( 'This will delete from GitHub. Are you sure?' ) ) {
			return;
		}

		$button.prop( 'disabled', true );
		$message.removeClass( 'github-repo-dashboard-message-success github-repo-dashboard-message-error' ).show().text( 'Sending request to GitHub...' );

		var ajaxData;
		var ajaxOptions = {
			url: ( window.cmWlfdGithubFrontend && window.cmWlfdGithubFrontend.ajaxurl ) || '/wp-admin/admin-ajax.php',
			method: 'POST'
		};

		if ( action === 'upload_file' ) {
			if ( ! repo ) {
				$message.addClass( 'github-repo-dashboard-message-error' ).text( 'Select the repository you want to upload to.' );
				$button.prop( 'disabled', false );
				return;
			}
			if ( ! branch ) {
				$message.addClass( 'github-repo-dashboard-message-error' ).text( 'Select the branch you want to upload to.' );
				$button.prop( 'disabled', false );
				return;
			}

			var fileInput = $card.find( '.github-dashboard-file-upload' ).get( 0 );
			if ( ! fileInput || ! fileInput.files || ! fileInput.files.length ) {
				$message.addClass( 'github-repo-dashboard-message-error' ).text( 'Choose a file to upload first.' );
				$button.prop( 'disabled', false );
				return;
			}

			ajaxData = new FormData();
			ajaxData.append( 'action', 'cm_wlfd_github_dashboard_action' );
			ajaxData.append( 'nonce', ( window.cmWlfdGithubFrontend && window.cmWlfdGithubFrontend.nonce ) || '' );
			ajaxData.append( 'github_action', action );
			ajaxData.append( 'repo', repo );
			ajaxData.append( 'branch', branch );
			ajaxData.append( 'source_branch', sourceBranch );
			ajaxData.append( 'description', description );
			ajaxData.append( 'file_path', $card.find( '.github-dashboard-file-path' ).val() || '' );
			ajaxData.append( 'commit_message', $card.find( '.github-dashboard-commit-message' ).val() || '' );
			ajaxData.append( 'github_file_upload', fileInput.files[0] );

			ajaxOptions.data = ajaxData;
			ajaxOptions.processData = false;
			ajaxOptions.contentType = false;
		} else {
			ajaxOptions.data = {
				action: 'cm_wlfd_github_dashboard_action',
				nonce: ( window.cmWlfdGithubFrontend && window.cmWlfdGithubFrontend.nonce ) || '',
				github_action: action,
				repo: repo,
				branch: branch,
				source_branch: sourceBranch,
				description: description,
				file_path: $card.find( '.github-dashboard-file-path' ).val() || ( $card.find( '.github-dashboard-file-title' ).length ? 'README.md' : '' ),
				file_content: $card.find( '.github-dashboard-file-title' ).length ? buildReadmeContentFromCard( $card ) : ( $card.find( '.github-dashboard-file-content' ).val() || '' ),
				commit_message: $card.find( '.github-dashboard-commit-message' ).val() || '',
				file_to_delete: $card.find( '.github-dashboard-file-delete-select' ).val() || ''
			};
		}

		$.ajax( ajaxOptions ).done( function( response ) {
			if ( response && response.success && response.data ) {
				refreshDashboardAfterGitHubAction( $tools, response.data, 'GitHub action complete.' );
				if ( action === 'create_branch' ) {
					var selectedRepo = $card.find( '.github-dashboard-repo-select' ).val() || '';
					if ( ! selectedRepo ) {
						window.alert( 'Please select a repository before creating a branch.' );
						return;
					}
				}

			} else {
				$message.addClass( 'github-repo-dashboard-message-error' ).text(
					( response && response.data && response.data.message ) ? response.data.message : 'GitHub action failed.'
				);
			}
		} ).fail( function() {
			$message.addClass( 'github-repo-dashboard-message-error' ).text( 'Could not connect to WordPress AJAX.' );
		} ).always( function() {
			$button.prop( 'disabled', false );
		} );
	} );


	$( document ).on( 'click', '.github-content-subtab', function( e ) {
		e.preventDefault();
		var $button = $( this );
		var tab = $button.attr( 'data-github-content-tool-tab' ) || 'add';
		var $tools = $button.closest( '.github-repo-dashboard-tools' );
		$tools.find( '.github-content-subtab' ).removeClass( 'is-active' ).attr( 'aria-selected', 'false' );
		$button.addClass( 'is-active' ).attr( 'aria-selected', 'true' );
		$tools.find( '.github-content-tool-panel' ).removeClass( 'is-active' ).prop( 'hidden', true ).attr( 'hidden', true );
		$tools.find( '.github-content-tool-panel[data-github-content-tool-panel="' + tab + '"]' ).addClass( 'is-active' ).prop( 'hidden', false ).removeAttr( 'hidden' );
	} );

	$( document ).on( 'click', '.github-dashboard-open-internal-view', function( e ) {
		e.preventDefault();
		var $button = $( this );
		var $tools = $button.closest( '.github-repo-dashboard-tools' );
		var repo = $button.attr( 'data-repo' ) || '';
		if ( ! repo ) return;
		var $panel = $tools.find( '.github-dashboard-internal-view' );
		$panel.prop( 'hidden', false ).removeAttr( 'hidden' );
		$panel.find( '.github-dashboard-internal-view-content' ).html( '<div class="github-dashboard-internal-loading">Loading repository inside the dashboard…</div>' );

		$.ajax( {
			url: ( window.cmWlfdGithubFrontend && window.cmWlfdGithubFrontend.ajaxurl ) || '/wp-admin/admin-ajax.php',
			method: 'POST',
			data: {
				action: 'cm_wlfd_github_render_internal_view',
				nonce: ( window.cmWlfdGithubFrontend && window.cmWlfdGithubFrontend.nonce ) || '',
				repo: repo,
				branch: $button.attr( 'data-branch' ) || '',
				path: $button.attr( 'data-path' ) || ''
			}
		} ).done( function( response ) {
			if ( response && response.success && response.data && response.data.viewer ) {
				showInternalViewer( $tools, response.data.viewer );
			} else {
				$panel.find( '.github-dashboard-internal-view-content' ).text( ( response && response.data && response.data.message ) ? response.data.message : 'Could not load repository.' );
			}
		} ).fail( function() {
			$panel.find( '.github-dashboard-internal-view-content' ).text( 'Could not connect to the dashboard GitHub viewer.' );
		} );
	} );

	$( document ).on( 'click', '.github-dashboard-internal-view-close', function( e ) {
		e.preventDefault();
		$( this ).closest( '.github-dashboard-internal-view' ).prop( 'hidden', true ).attr( 'hidden', true );
	} );


	$( function() {
		$( '.github-repo-container .branch-selector' ).each( function() {
			updateCardBranchLinks( this );
		} );

		$( '.github-repo-dashboard-management .github-repo-dashboard-action-card' ).each( function() {
			populateDashboardBranchSelects( this );
		} );

		$( '.github-dashboard-delete-type' ).each( function() {
			$( this ).closest( '.github-repo-dashboard-action-card' ).attr( 'data-delete-type', $( this ).val() || 'delete_branch' );
		} );

		$( '.github-dashboard-add-type' ).each( function() {
			$( this ).closest( '.github-repo-dashboard-add-card' ).attr( 'data-add-type', $( this ).val() || 'create_repo' );
			$( this ).trigger( 'change' );
		} );
	} );
} )( jQuery );
