<?php
/**
 * Front-end dashboard integration.
 *
 * Provides a standalone GitHub settings + management screen which can be
 * embedded by other front-end dashboard plugins without depending on Elementor.
 */

namespace CM_WL_GitHub;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Frontend_Dashboard {
	/**
	 * Render the full settings + GitHub management screen.
	 *
	 * @return string
	 */
	public static function render() {
		if ( ! is_user_logged_in() ) {
			return '<div class="github-repo-dashboard-integration"><div class="github-repo-dashboard-message github-repo-dashboard-message-error">' . esc_html__( 'You must be logged in to manage GitHub.', 'github-repo-selector' ) . '</div></div>';
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return '<div class="github-repo-dashboard-integration"><div class="github-repo-dashboard-message github-repo-dashboard-message-error">' . esc_html__( 'GitHub settings and repository management are restricted to WordPress administrators.', 'github-repo-selector' ) . '</div></div>';
		}

		$notice = self::handle_settings_post();

		ob_start();
		?>
		<div class="github-repo-dashboard-integration">
			<div class="github-repo-dashboard-integration-title">
				<h2><?php esc_html_e( 'GitHub', 'github-repo-selector' ); ?></h2>
				<p><?php esc_html_e( 'Manage the GitHub connection and update GitHub without leaving WordPress.', 'github-repo-selector' ); ?></p>
			</div>

			<?php echo $notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php self::render_settings_panel(); ?>
			<?php self::render_tools_panel(); ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Render only the connection/settings area used under Dashboard > Settings > GitHub.
	 *
	 * @return string
	 */
	public static function render_settings() {
		if ( ! is_user_logged_in() ) {
			return '<div class="github-repo-dashboard-integration"><div class="github-repo-dashboard-message github-repo-dashboard-message-error">' . esc_html__( 'You must be logged in to manage GitHub settings.', 'github-repo-selector' ) . '</div></div>';
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return '<div class="github-repo-dashboard-integration"><div class="github-repo-dashboard-message github-repo-dashboard-message-error">' . esc_html__( 'GitHub settings are restricted to WordPress administrators.', 'github-repo-selector' ) . '</div></div>';
		}

		$notice = self::handle_settings_post();

		ob_start();
		?>
		<div class="github-repo-dashboard-integration github-repo-dashboard-settings-only">
			<div class="github-repo-dashboard-integration-title">
				<h2><?php esc_html_e( 'GitHub Settings', 'github-repo-selector' ); ?></h2>
				<p><?php esc_html_e( 'Connect your GitHub account, save the token and refresh the repository and branch lists used by the dashboard and Elementor.', 'github-repo-selector' ); ?></p>
			</div>

			<?php echo $notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php self::render_settings_panel(); ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Render only day-to-day GitHub content tools used by Dashboard > Content > GitHub.
	 *
	 * @return string
	 */
	public static function render_tools() {
		if ( ! is_user_logged_in() ) {
			return '<div class="github-repo-dashboard-integration"><div class="github-repo-dashboard-message github-repo-dashboard-message-error">' . esc_html__( 'You must be logged in to manage GitHub content.', 'github-repo-selector' ) . '</div></div>';
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return '<div class="github-repo-dashboard-integration"><div class="github-repo-dashboard-message github-repo-dashboard-message-error">' . esc_html__( 'GitHub repository changes are restricted to WordPress administrators.', 'github-repo-selector' ) . '</div></div>';
		}

		ob_start();
		?>
		<div class="github-repo-dashboard-integration github-repo-dashboard-tools-only">
			<div class="github-repo-dashboard-integration-title">
				<h2><?php esc_html_e( 'GitHub Content', 'github-repo-selector' ); ?></h2>
				<p><?php esc_html_e( 'Choose a repository and branch, then create or edit README/files, upload releases and manage repository content from the dashboard.', 'github-repo-selector' ); ?></p>
			</div>

			<?php if ( empty( Settings::get_github_token() ) ) : ?>
				<div class="github-repo-dashboard-message github-repo-dashboard-message-error" style="display:block;"><?php esc_html_e( 'GitHub is not connected yet. Open Settings → GitHub first and save your token.', 'github-repo-selector' ); ?></div>
			<?php endif; ?>
			<?php self::render_tools_panel(); ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Handle the token form submitted on the front-end dashboard screen.
	 *
	 * @return string
	 */
	private static function handle_settings_post() {
		if ( empty( $_POST['github_repo_selector_frontend_save'] ) ) {
			return '';
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return self::notice( __( 'You do not have permission to change GitHub settings.', 'github-repo-selector' ), 'error' );
		}

		$nonce = isset( $_POST['github_repo_selector_frontend_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['github_repo_selector_frontend_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'github_repo_selector_frontend_save' ) ) {
			return self::notice( __( 'Security check failed. GitHub settings were not changed.', 'github-repo-selector' ), 'error' );
		}

		$clear_token = ! empty( $_POST['github_repo_selector_clear_token'] );
		$new_token   = isset( $_POST['github_token'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['github_token'] ) ) ) : '';

		if ( $clear_token ) {
			delete_option( 'github_repo_selector_token' );
		} elseif ( '' !== $new_token ) {
			update_option( 'github_repo_selector_token', $new_token, false );
		}

		// Global Show All settings are shared by Dashboard → View All and the
		// Elementor CM GitHub Browser when Repository Source = All repositories.
		$show_all = ! empty( $_POST['cm_wlfd_github_view_show_all'] ) ? '1' : '0';
		$excluded = isset( $_POST['cm_wlfd_github_view_excluded_repos'] ) && is_array( $_POST['cm_wlfd_github_view_excluded_repos'] )
			? array_values( array_unique( array_filter( array_map( 'sanitize_text_field', wp_unslash( $_POST['cm_wlfd_github_view_excluded_repos'] ) ) ) ) )
			: [];
		update_option( 'cm_wlfd_github_view_show_all', $show_all, false );
		update_option( 'cm_wlfd_github_view_excluded_repos', $excluded, false );

		// Keep the bundled CMGC viewer on the same PAT so there is only one token
		// setting in the front-end dashboard.
		if ( class_exists( '\CM_WL_CMGC_Admin' ) ) {
			$cmgc_options = \CM_WL_CMGC_Admin::get_options();
			if ( $clear_token ) {
				$cmgc_options['token'] = '';
			} elseif ( '' !== $new_token ) {
				$cmgc_options['token'] = $new_token;
			}
			update_option( \CM_WL_CMGC_Admin::OPTION_SETTINGS, $cmgc_options, false );
			if ( class_exists( '\CM_WL_CMGC_API' ) ) \CM_WL_CMGC_API::flush_cache();
		}

		// Elementor's normal CMGC layer shares this same PAT when available.
		if ( class_exists( '\CMGC_Admin' ) ) {
			$elementor_options = \CMGC_Admin::get_options();
			if ( $clear_token ) {
				$elementor_options['token'] = '';
			} elseif ( '' !== $new_token ) {
				$elementor_options['token'] = $new_token;
			}
			update_option( \CMGC_Admin::OPTION_SETTINGS, $elementor_options, false );
			if ( class_exists( '\CMGC_API' ) ) \CMGC_API::flush_cache();
		}

		$api = new GitHub_API();
		$api->clear_cache( '', '', false );

		if ( $clear_token ) {
			return self::notice( __( 'Saved GitHub token removed.', 'github-repo-selector' ), 'success' );
		}

		if ( '' === $new_token ) {
			return self::notice( __( 'GitHub settings saved. The existing token was kept.', 'github-repo-selector' ), 'success' );
		}

		$username = $api->get_authenticated_username();
		if ( empty( $username ) ) {
			return self::notice( __( 'Token saved, but GitHub could not identify the account. Check the token permissions.', 'github-repo-selector' ), 'error' );
		}

		return self::notice(
			sprintf( __( 'GitHub settings saved. Connected as @%s.', 'github-repo-selector' ), esc_html( $username ) ),
			'success'
		);
	}

	private static function notice( $message, $type = 'success' ) {
		$class = 'success' === $type ? 'github-repo-dashboard-message-success' : 'github-repo-dashboard-message-error';
		return '<div class="github-repo-dashboard-message ' . esc_attr( $class ) . '" style="display:block;">' . wp_kses_post( $message ) . '</div>';
	}

	/**
	 * Render the front-end equivalent of Settings > GitHub Repo Selector.
	 */
	private static function render_settings_panel() {
		$token      = Settings::get_github_token();
		$has_token  = ! empty( $token );
		$api        = new GitHub_API();
		$github_user = $api->get_authenticated_user();
		$repo_options = Settings::get_saved_repo_options();
		$branch_options = Settings::get_saved_branch_options();
		$branch_count = self::branch_count( $branch_options );
		$last_updated = get_option( 'github_repo_selector_branch_cache_updated', '' );
		if ( empty( $last_updated ) ) {
			$last_updated = get_option( 'github_repo_selector_repo_cache_updated', '' );
		}
		$show_all_setting = get_option( 'cm_wlfd_github_view_show_all', null );
		$show_all_setting = null === $show_all_setting ? true : (string) $show_all_setting !== '0';
		$excluded_repos = get_option( 'cm_wlfd_github_view_excluded_repos', [] );
		$excluded_repos = is_array( $excluded_repos ) ? array_map( 'strtolower', $excluded_repos ) : [];
		$viewer_catalog = class_exists( '\CM_WL_CMGC_Admin' ) ? \CM_WL_CMGC_Admin::get_repository_catalog() : [];
		if ( empty( $viewer_catalog ) && ! empty( $repo_options ) ) {
			$owner = ! empty( $github_user['login'] ) ? $github_user['login'] : get_option( 'github_repo_selector_connected_username', '' );
			foreach ( $repo_options as $repo_name => $repo_label ) {
				$viewer_catalog[] = [ 'full_name' => $owner ? $owner . '/' . $repo_name : $repo_name, 'name' => $repo_name, 'private' => false ];
			}
		}
		?>
		<section class="github-repo-dashboard-settings-panel">
			<div class="github-repo-dashboard-tools-header">
				<h3><?php esc_html_e( 'GitHub Repo Selector Settings', 'github-repo-selector' ); ?></h3>
				<p><?php esc_html_e( 'This connection is used by the Elementor GitHub Repo Selector widget and by Content → GitHub. GitHub editing tools are kept out of Settings.', 'github-repo-selector' ); ?></p>
			</div>

			<?php if ( ! empty( $github_user['login'] ) ) : ?>
				<div class="github-repo-dashboard-account">
					<?php if ( ! empty( $github_user['avatar_url'] ) ) : ?>
						<img src="<?php echo esc_url( $github_user['avatar_url'] ); ?>" alt="<?php echo esc_attr( $github_user['login'] ); ?>">
					<?php endif; ?>
					<div>
						<span><?php esc_html_e( 'Connected GitHub account', 'github-repo-selector' ); ?></span>
						<strong>@<?php echo esc_html( $github_user['login'] ); ?></strong>
						<?php if ( ! empty( $github_user['html_url'] ) ) : ?>
							<a href="<?php echo esc_url( $github_user['html_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'View profile', 'github-repo-selector' ); ?></a>
						<?php endif; ?>
					</div>
				</div>
			<?php elseif ( $has_token ) : ?>
				<div class="github-repo-dashboard-message github-repo-dashboard-message-error" style="display:block;"><?php esc_html_e( 'A token is saved, but GitHub could not identify the account. Check or replace the token.', 'github-repo-selector' ); ?></div>
			<?php else : ?>
				<div class="github-repo-dashboard-message github-repo-dashboard-message-warning" style="display:block;"><?php esc_html_e( 'No GitHub token is saved yet.', 'github-repo-selector' ); ?></div>
			<?php endif; ?>

			<form method="post" class="github-repo-dashboard-settings-form">
				<?php wp_nonce_field( 'github_repo_selector_frontend_save', 'github_repo_selector_frontend_nonce' ); ?>
				<input type="hidden" name="github_repo_selector_frontend_save" value="1">
				<label class="github-dashboard-field-label" for="github_repo_selector_frontend_token"><?php esc_html_e( 'GitHub Personal Access Token', 'github-repo-selector' ); ?></label>
				<input type="password" id="github_repo_selector_frontend_token" name="github_token" value="" autocomplete="new-password" placeholder="<?php echo esc_attr( $has_token ? __( 'Token saved – leave blank to keep it', 'github-repo-selector' ) : __( 'Paste GitHub token', 'github-repo-selector' ) ); ?>">
				<p class="github-repo-dashboard-help"><?php esc_html_e( 'Leave the token field blank to keep the currently saved token. Enter a new token only when you want to replace it.', 'github-repo-selector' ); ?></p>
				<?php if ( $has_token ) : ?>
					<label class="github-repo-dashboard-clear-token"><input type="checkbox" name="github_repo_selector_clear_token" value="1"> <?php esc_html_e( 'Remove the saved GitHub token', 'github-repo-selector' ); ?></label>
				<?php endif; ?>

				<div class="github-repo-dashboard-view-settings">
					<h4><?php esc_html_e( 'Show All GitHub — Dashboard + Elementor', 'github-repo-selector' ); ?></h4>
					<label class="github-repo-dashboard-show-all-toggle"><input type="checkbox" name="cm_wlfd_github_view_show_all" value="1" <?php checked( $show_all_setting ); ?>> <strong><?php esc_html_e( 'Show All GitHub repositories', 'github-repo-selector' ); ?></strong></label>
					<p class="github-repo-dashboard-help"><?php esc_html_e( 'This controls Dashboard → View → View All and is also applied to the Elementor GitHub Repository Browser when Repository Source is All repositories.', 'github-repo-selector' ); ?></p>
					<?php if ( ! empty( $viewer_catalog ) ) : ?>
						<div class="github-repo-dashboard-exclusions">
							<strong><?php esc_html_e( 'Exclude repositories from Show All', 'github-repo-selector' ); ?></strong>
							<p class="github-repo-dashboard-help"><?php esc_html_e( 'Tick any repository you do not want in View All or Elementor All repositories.', 'github-repo-selector' ); ?></p>
							<div class="github-repo-dashboard-exclusion-grid">
							<?php foreach ( $viewer_catalog as $viewer_repo ) : if ( empty( $viewer_repo['full_name'] ) ) continue; $full_name = (string) $viewer_repo['full_name']; ?>
								<label><input type="checkbox" name="cm_wlfd_github_view_excluded_repos[]" value="<?php echo esc_attr( $full_name ); ?>" <?php checked( in_array( strtolower( $full_name ), $excluded_repos, true ) ); ?>> <span><?php echo esc_html( $full_name . ( ! empty( $viewer_repo['private'] ) ? ' — Private' : '' ) ); ?></span></label>
							<?php endforeach; ?>
							</div>
						</div>
					<?php else : ?>
						<p class="github-repo-dashboard-help"><strong><?php esc_html_e( 'No repositories loaded yet.', 'github-repo-selector' ); ?></strong> <?php esc_html_e( 'Press Update Repositories & Branches below, then return here to choose exclusions.', 'github-repo-selector' ); ?></p>
					<?php endif; ?>
				</div>

				<div class="github-repo-dashboard-settings-actions">
					<button type="submit" class="repo-button repo-view-button"><?php esc_html_e( 'Save GitHub Settings', 'github-repo-selector' ); ?></button>
					<a class="repo-button repo-secondary-button" href="https://github.com/settings/tokens" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Open GitHub Token Settings', 'github-repo-selector' ); ?></a>
				</div>
			</form>

			<div class="github-repo-dashboard-cache-grid github-repo-dashboard-settings-cache">
				<div class="github-repo-dashboard-cache-card">
					<span class="github-repo-dashboard-cache-label"><?php esc_html_e( 'Repos cached', 'github-repo-selector' ); ?></span>
					<strong class="github-repo-dashboard-repo-count"><?php echo esc_html( count( $repo_options ) ); ?></strong>
				</div>
				<div class="github-repo-dashboard-cache-card">
					<span class="github-repo-dashboard-cache-label"><?php esc_html_e( 'Branches cached', 'github-repo-selector' ); ?></span>
					<strong class="github-repo-dashboard-branch-count"><?php echo esc_html( $branch_count ); ?></strong>
				</div>
				<div class="github-repo-dashboard-cache-card github-repo-dashboard-cache-card-wide">
					<span class="github-repo-dashboard-cache-label"><?php esc_html_e( 'Last updated', 'github-repo-selector' ); ?></span>
					<strong class="github-repo-dashboard-last-updated"><?php echo esc_html( $last_updated ?: __( 'Never', 'github-repo-selector' ) ); ?></strong>
				</div>
			</div>
			<button type="button" class="github-repo-dashboard-update-button repo-button repo-view-button" data-github-cache-update="yes"><?php esc_html_e( 'Update Repositories & Branches', 'github-repo-selector' ); ?></button>
			<div class="github-repo-dashboard-message" style="display:none;"></div>
		</section>
		<?php
	}

	/**
	 * Render standalone GitHub management tools. Markup intentionally matches the
	 * Elementor dashboard-mode tools so the existing frontend.js can power both.
	 */
	private static function render_tools_panel() {
		$repo_options   = Settings::get_content_repo_options();
		$branch_options = Settings::get_saved_branch_options();
		$repo_count     = count( $repo_options );
		$branch_count   = self::branch_count( $branch_options );
		$last_updated   = get_option( 'github_repo_selector_branch_cache_updated', '' );
		if ( empty( $last_updated ) ) $last_updated = get_option( 'github_repo_selector_repo_cache_updated', '' );
		$latest_github_url = get_option( 'github_repo_selector_latest_edit_url', '' );
		$latest_internal = get_option( 'cm_wlfd_github_latest_internal_view', [] );
		if ( ! is_array( $latest_internal ) ) $latest_internal = [];

		// Migrate the v1.0.30.74 external latest URL into the new internal-view
		// state so upgrading does not make the existing Latest GitHub edit URL disappear.
		if ( empty( $latest_internal['repo'] ) && ! empty( $latest_github_url ) ) {
			$parts = wp_parse_url( $latest_github_url );
			$path_parts = ! empty( $parts['path'] ) ? array_values( array_filter( explode( '/', trim( $parts['path'], '/' ) ) ) ) : [];
			if ( count( $path_parts ) >= 2 ) {
				$latest_internal = [
					'owner'  => sanitize_text_field( rawurldecode( $path_parts[0] ) ),
					'repo'   => sanitize_text_field( rawurldecode( $path_parts[1] ) ),
					'branch' => '',
					'path'   => '',
				];
				if ( isset( $path_parts[2] ) && 'tree' === $path_parts[2] && count( $path_parts ) > 3 ) {
					$latest_internal['branch'] = sanitize_text_field( implode( '/', array_map( 'rawurldecode', array_slice( $path_parts, 3 ) ) ) );
				}
			}
		}
		?>
		<section class="github-repo-dashboard-tools" data-github-repo-dashboard-tools="yes">
			<div class="github-repo-dashboard-tools-header">
				<h3><?php esc_html_e( 'GitHub Content Tools', 'github-repo-selector' ); ?></h3>
				<p><?php esc_html_e( 'Use the tabs below to add, upload, edit or delete GitHub content. All actions stay inside this dashboard.', 'github-repo-selector' ); ?></p>
			</div>

			<div class="github-repo-dashboard-cache-grid">
				<div class="github-repo-dashboard-cache-card"><span class="github-repo-dashboard-cache-label"><?php esc_html_e( 'Repos cached', 'github-repo-selector' ); ?></span><strong class="github-repo-dashboard-repo-count"><?php echo esc_html( $repo_count ); ?></strong></div>
				<div class="github-repo-dashboard-cache-card"><span class="github-repo-dashboard-cache-label"><?php esc_html_e( 'Branches cached', 'github-repo-selector' ); ?></span><strong class="github-repo-dashboard-branch-count"><?php echo esc_html( $branch_count ); ?></strong></div>
				<div class="github-repo-dashboard-cache-card github-repo-dashboard-cache-card-wide"><span class="github-repo-dashboard-cache-label"><?php esc_html_e( 'Last updated', 'github-repo-selector' ); ?></span><strong class="github-repo-dashboard-last-updated"><?php echo esc_html( $last_updated ?: __( 'Never', 'github-repo-selector' ) ); ?></strong></div>
				<div class="github-repo-dashboard-cache-card github-repo-dashboard-cache-card-wide github-repo-dashboard-latest-url-card">
					<span class="github-repo-dashboard-cache-label"><?php esc_html_e( 'Latest GitHub edit URL', 'github-repo-selector' ); ?></span>
					<strong class="github-repo-dashboard-latest-url">
					<?php if ( ! empty( $latest_internal['repo'] ) ) : ?>
						<button type="button" class="github-dashboard-open-internal-view github-dashboard-internal-url" data-repo="<?php echo esc_attr( $latest_internal['repo'] ); ?>" data-branch="<?php echo esc_attr( $latest_internal['branch'] ?? '' ); ?>" data-path="<?php echo esc_attr( $latest_internal['path'] ?? '' ); ?>"><?php echo esc_html( $latest_github_url ?: ( ( $latest_internal['owner'] ?? '' ) . '/' . $latest_internal['repo'] ) ); ?></button>
					<?php else : esc_html_e( 'No GitHub repository or branch edits yet', 'github-repo-selector' ); endif; ?>
					</strong>
				</div>
			</div>

			<div class="github-repo-dashboard-management" data-branches='<?php echo esc_attr( wp_json_encode( $branch_options ) ); ?>'>
				<div class="github-content-subtabs" role="tablist" aria-label="GitHub content tools">
					<button type="button" class="github-content-subtab is-active" data-github-content-tool-tab="add" aria-selected="true">Add</button>
					<button type="button" class="github-content-subtab" data-github-content-tool-tab="upload" aria-selected="false">Upload</button>
					<button type="button" class="github-content-subtab" data-github-content-tool-tab="edit" aria-selected="false">Edit</button>
					<button type="button" class="github-content-subtab" data-github-content-tool-tab="delete" aria-selected="false">Delete</button>
				</div>

				<div class="github-content-tool-panels">
					<section class="github-content-tool-panel is-active" data-github-content-tool-panel="add">
						<div class="github-repo-dashboard-action-card github-repo-dashboard-wide-card github-repo-dashboard-add-card" data-add-type="create_repo">
							<h5><?php esc_html_e( 'Add repository or branch', 'github-repo-selector' ); ?></h5>
							<select class="github-dashboard-add-type"><option value="create_repo"><?php esc_html_e( 'Add repository', 'github-repo-selector' ); ?></option><option value="create_branch"><?php esc_html_e( 'Add branch', 'github-repo-selector' ); ?></option></select>
							<div class="github-dashboard-add-repo-fields"><input type="text" class="github-dashboard-repo-name" placeholder="<?php esc_attr_e( 'new-repo-name', 'github-repo-selector' ); ?>"><input type="text" class="github-dashboard-repo-description" placeholder="<?php esc_attr_e( 'Optional GitHub repo description', 'github-repo-selector' ); ?>"></div>
							<div class="github-dashboard-add-branch-fields"><label class="github-dashboard-field-label"><?php esc_html_e( 'Select repository to add branch into', 'github-repo-selector' ); ?></label><?php self::repo_select( $repo_options ); ?><select class="github-dashboard-source-branch-select"><option value=""><?php esc_html_e( 'Source branch / default', 'github-repo-selector' ); ?></option></select><input type="text" class="github-dashboard-branch-name" placeholder="<?php esc_attr_e( 'new-branch-name', 'github-repo-selector' ); ?>"></div>
							<button type="button" class="cm-wlfd-github-dashboard-action repo-button repo-view-button" data-github-action-from-add-select="yes"><?php esc_html_e( 'Add Selected', 'github-repo-selector' ); ?></button>
						</div>
					</section>

					<section class="github-content-tool-panel" data-github-content-tool-panel="upload" hidden>
						<div class="github-repo-dashboard-action-card github-repo-dashboard-wide-card">
							<h5><?php esc_html_e( 'Upload file / ZIP', 'github-repo-selector' ); ?></h5><?php self::repo_select( $repo_options ); ?><select class="github-dashboard-branch-select"><option value=""><?php esc_html_e( 'Select branch', 'github-repo-selector' ); ?></option></select><input type="text" class="github-dashboard-file-path" placeholder="<?php esc_attr_e( 'Destination folder optional, e.g. releases or builds/v4', 'github-repo-selector' ); ?>"><input type="file" class="github-dashboard-file-upload"><input type="text" class="github-dashboard-commit-message" placeholder="<?php esc_attr_e( 'Commit message, optional', 'github-repo-selector' ); ?>"><button type="button" class="cm-wlfd-github-dashboard-action repo-button repo-view-button" data-github-action="upload_file"><?php esc_html_e( 'Upload to GitHub', 'github-repo-selector' ); ?></button>
						</div>
					</section>

					<section class="github-content-tool-panel" data-github-content-tool-panel="edit" hidden>
						<div class="github-repo-dashboard-action-grid">
							<div class="github-repo-dashboard-action-card github-repo-dashboard-wide-card">
								<h5><?php esc_html_e( 'Create / edit README.md', 'github-repo-selector' ); ?></h5><?php self::repo_select( $repo_options ); ?><select class="github-dashboard-branch-select"><option value=""><?php esc_html_e( 'Select branch', 'github-repo-selector' ); ?></option></select><input type="text" class="github-dashboard-file-title" placeholder="<?php esc_attr_e( 'README title, e.g. My Plugin', 'github-repo-selector' ); ?>"><button type="button" class="github-dashboard-load-readme repo-button repo-view-button"><?php esc_html_e( 'Load README for editing', 'github-repo-selector' ); ?></button><div class="github-dashboard-readme-status" style="display:none;"></div>
								<div class="github-dashboard-wysiwyg-toolbar"><button type="button" data-md="h1">H1</button><button type="button" data-md="h2">H2</button><button type="button" data-md="bold">Bold</button><button type="button" data-md="list">List</button><button type="button" data-md="link">Link</button></div><textarea class="github-dashboard-file-content github-dashboard-readme-editor" rows="12" placeholder="<?php esc_attr_e( 'README description/content goes here...', 'github-repo-selector' ); ?>"></textarea><input type="text" class="github-dashboard-commit-message" placeholder="<?php esc_attr_e( 'Commit message, optional', 'github-repo-selector' ); ?>"><button type="button" class="cm-wlfd-github-dashboard-action repo-button repo-view-button" data-github-action="create_readme"><?php esc_html_e( 'Create / Edit README', 'github-repo-selector' ); ?></button>
								<div class="github-dashboard-readme-modal" aria-hidden="true"><div class="github-dashboard-readme-modal-backdrop"></div><div class="github-dashboard-readme-modal-panel" role="dialog" aria-modal="true"><div class="github-dashboard-readme-modal-header"><h4><?php esc_html_e( 'README editor', 'github-repo-selector' ); ?></h4><button type="button" class="github-dashboard-readme-modal-close" aria-label="<?php esc_attr_e( 'Close README editor', 'github-repo-selector' ); ?>">×</button></div><p class="github-dashboard-readme-modal-note"><?php esc_html_e( 'README loaded from GitHub. Edit the content, then use Create / Edit README to commit it.', 'github-repo-selector' ); ?></p><div class="github-dashboard-readme-modal-toolbar github-dashboard-wysiwyg-toolbar"><button type="button" data-md="h1">H1</button><button type="button" data-md="h2">H2</button><button type="button" data-md="bold">Bold</button><button type="button" data-md="list">List</button><button type="button" data-md="link">Link</button></div><textarea class="github-dashboard-readme-modal-editor github-dashboard-readme-editor"></textarea><div class="github-dashboard-readme-modal-actions"><button type="button" class="github-dashboard-readme-modal-apply repo-button repo-view-button"><?php esc_html_e( 'Use this README content', 'github-repo-selector' ); ?></button><button type="button" class="github-dashboard-readme-modal-close-button"><?php esc_html_e( 'Close', 'github-repo-selector' ); ?></button></div></div></div>
							</div>
							<div class="github-repo-dashboard-action-card github-repo-dashboard-wide-card">
								<h5><?php esc_html_e( 'Create / update custom file', 'github-repo-selector' ); ?></h5><?php self::repo_select( $repo_options ); ?><select class="github-dashboard-branch-select"><option value=""><?php esc_html_e( 'Select branch', 'github-repo-selector' ); ?></option></select><input type="text" class="github-dashboard-file-path" placeholder="<?php esc_attr_e( 'File path, e.g. docs/notes.md', 'github-repo-selector' ); ?>"><textarea class="github-dashboard-file-content" rows="6" placeholder="<?php esc_attr_e( 'File text/content', 'github-repo-selector' ); ?>"></textarea><input type="text" class="github-dashboard-commit-message" placeholder="<?php esc_attr_e( 'Commit message, optional', 'github-repo-selector' ); ?>"><button type="button" class="cm-wlfd-github-dashboard-action repo-button repo-view-button" data-github-action="create_file"><?php esc_html_e( 'Create / Update File', 'github-repo-selector' ); ?></button>
							</div>
						</div>
					</section>

					<section class="github-content-tool-panel" data-github-content-tool-panel="delete" hidden>
						<div class="github-repo-dashboard-action-card github-repo-dashboard-danger-card github-repo-dashboard-wide-card">
							<h5><?php esc_html_e( 'Delete repository, branch or file', 'github-repo-selector' ); ?></h5><select class="github-dashboard-delete-type"><option value="delete_branch"><?php esc_html_e( 'Delete branch', 'github-repo-selector' ); ?></option><option value="delete_repo"><?php esc_html_e( 'Delete repository', 'github-repo-selector' ); ?></option><option value="delete_file"><?php esc_html_e( 'Delete file', 'github-repo-selector' ); ?></option></select><?php self::repo_select( $repo_options ); ?><select class="github-dashboard-branch-select"><option value=""><?php esc_html_e( 'Select branch', 'github-repo-selector' ); ?></option></select><select class="github-dashboard-file-delete-select"><option value=""><?php esc_html_e( 'Select file', 'github-repo-selector' ); ?></option></select><button type="button" class="cm-wlfd-github-dashboard-action github-repo-dashboard-danger-button" data-github-action-from-select="yes"><?php esc_html_e( 'Delete Selected', 'github-repo-selector' ); ?></button>
						</div>
					</section>
				</div>
			</div>

			<div class="github-repo-dashboard-message" style="display:none;"></div>
			<section class="github-dashboard-internal-view" hidden aria-live="polite">
				<div class="github-dashboard-internal-view-header"><div><span class="github-repo-dashboard-cache-label"><?php esc_html_e( 'Internal dashboard view', 'github-repo-selector' ); ?></span><strong class="github-dashboard-internal-view-title"><?php esc_html_e( 'GitHub repository', 'github-repo-selector' ); ?></strong></div><button type="button" class="github-dashboard-internal-view-close"><?php esc_html_e( 'Close view', 'github-repo-selector' ); ?></button></div>
				<div class="github-dashboard-internal-view-content"></div>
			</section>
		</section>
		<?php
	}

	private static function repo_select( $repo_options ) {
		?>
		<select class="github-dashboard-repo-select">
			<option value=""><?php esc_html_e( 'Select repo', 'github-repo-selector' ); ?></option>
			<?php foreach ( $repo_options as $repo_key => $repo_label ) : ?>
				<option value="<?php echo esc_attr( $repo_key ); ?>"><?php echo esc_html( $repo_label ); ?></option>
			<?php endforeach; ?>
		</select>
		<?php
	}

	private static function branch_count( $branch_options ) {
		$count = 0;
		if ( is_array( $branch_options ) ) {
			foreach ( $branch_options as $branches ) {
				if ( is_array( $branches ) ) {
					$count += count( $branches );
				}
			}
		}
		return $count;
	}
}
