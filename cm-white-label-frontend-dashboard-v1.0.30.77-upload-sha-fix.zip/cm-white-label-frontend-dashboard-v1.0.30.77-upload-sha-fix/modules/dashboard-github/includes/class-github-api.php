<?php
/**
 * GitHub API Handler
 */

namespace CM_WL_GitHub;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GitHub_API {
	private $token = '';
	private $base_url = 'https://api.github.com';
	private $cache_duration = 3600; // 1 hour

	public function __construct() {
		$this->token = get_option( 'github_repo_selector_token', '' );
	}

	/**
	 * Get the GitHub account connected to the saved token.
	 */
	public function get_authenticated_user() {
		$cache_key = 'github_authenticated_user';
		$cached = get_transient( $cache_key );

		if ( $cached ) {
			if ( ! empty( $cached['login'] ) ) {
				update_option( 'github_repo_selector_connected_username', sanitize_text_field( $cached['login'] ), false );
			}
			return $cached;
		}

		if ( empty( $this->token ) ) {
			return [];
		}

		$response = $this->make_request( $this->base_url . '/user' );

		if ( is_wp_error( $response ) || empty( $response['login'] ) ) {
			return [];
		}

		update_option( 'github_repo_selector_connected_username', sanitize_text_field( $response['login'] ), false );
		set_transient( $cache_key, $response, $this->cache_duration );

		return $response;
	}

	/**
	 * Get the GitHub username/login connected to the saved token.
	 */
	public function get_authenticated_username() {
		$user = $this->get_authenticated_user();
		return ! empty( $user['login'] ) ? $user['login'] : '';
	}

	/**
	 * Get user repositories
	 */
	public function get_user_repos( $username = '', $force_refresh = false ) {
		$authenticated_username = $this->get_authenticated_username();
		$username = ! empty( $username ) ? sanitize_text_field( $username ) : $authenticated_username;

		if ( empty( $username ) ) {
			return [];
		}

		$cache_key = 'github_repos_' . $username;
		$cached = get_transient( $cache_key );

		if ( $cached && ! $force_refresh ) {
			return $cached;
		}

		if ( ! empty( $authenticated_username ) && strtolower( $username ) === strtolower( $authenticated_username ) ) {
			$url = $this->base_url . '/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator,organization_member';
		} else {
			$url = $this->base_url . '/users/' . rawurlencode( $username ) . '/repos?per_page=100&sort=updated';
		}

		$response = $this->make_paginated_request( $url );

		if ( is_wp_error( $response ) ) {
			return [];
		}

		set_transient( $cache_key, $response, $this->cache_duration );

		return $response;
	}

	/**
	 * Get repository branches
	 */
	public function get_repo_branches( $owner, $repo, $force_refresh = false ) {
		$owner = sanitize_text_field( $owner );
		$repo  = sanitize_text_field( $repo );

		$cache_key = 'github_branches_' . $owner . '_' . $repo;
		$cached = get_transient( $cache_key );

		if ( $cached && ! $force_refresh ) {
			return $cached;
		}

		$url = $this->base_url . '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/branches?per_page=100';
		$response = $this->make_paginated_request( $url );

		if ( is_wp_error( $response ) ) {
			return [];
		}

		set_transient( $cache_key, $response, $this->cache_duration );

		return $response;
	}

	/**
	 * Refresh repositories and branch caches together.
	 *
	 * This is used by the Update Repositories button so new GitHub branches
	 * appear on the website without needing to wait for old transients to expire.
	 */
	public function refresh_repositories_and_branches( $username = '' ) {
		$username = ! empty( $username ) ? sanitize_text_field( $username ) : $this->get_authenticated_username();

		if ( empty( $username ) ) {
			return [
				'username' => '',
				'repos' => [],
				'repo_count' => 0,
				'branch_count' => 0,
				'branches_by_repo' => [],
			];
		}

		delete_transient( 'github_repos_' . $username );

		$repos = $this->get_user_repos( $username, true );
		$branches_by_repo = [];
		$total_branches = 0;

		if ( is_array( $repos ) ) {
			foreach ( $repos as $repo ) {
				if ( empty( $repo['name'] ) ) {
					continue;
				}

				$owner = ! empty( $repo['owner']['login'] ) ? $repo['owner']['login'] : $username;
				$repo_name = $repo['name'];

				delete_transient( 'github_branches_' . $owner . '_' . $repo_name );
				delete_transient( 'github_repo_details_' . $owner . '_' . $repo_name );

				$branches = $this->get_repo_branches( $owner, $repo_name, true );
				$branch_names = [];

				if ( is_array( $branches ) ) {
					foreach ( $branches as $branch ) {
						if ( ! empty( $branch['name'] ) ) {
							$branch_names[] = $branch['name'];
						}
					}
				}

				$branches_by_repo[ $repo_name ] = $branch_names;
				$total_branches += count( $branch_names );
			}
		}

		update_option( 'github_repo_selector_branch_options', $branches_by_repo, false );
		update_option( 'github_repo_selector_branch_cache_updated', current_time( 'mysql' ), false );

		return [
			'username' => $username,
			'repos' => is_array( $repos ) ? $repos : [],
			'repo_count' => is_array( $repos ) ? count( $repos ) : 0,
			'branch_count' => $total_branches,
			'branches_by_repo' => $branches_by_repo,
		];
	}

	/**
	 * Get repository details
	 */
	public function get_repo_details( $owner, $repo, $force_refresh = false ) {
		$cache_key = 'github_repo_details_' . $owner . '_' . $repo;
		$cached = get_transient( $cache_key );

		if ( $cached && ! $force_refresh ) {
			return $cached;
		}

		$url = $this->base_url . '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo );
		$response = $this->make_request( $url );

		if ( is_wp_error( $response ) ) {
			return [];
		}

		set_transient( $cache_key, $response, $this->cache_duration );

		return $response;
	}

	/**
	 * Get repository README
	 */
	public function get_repo_readme( $owner, $repo, $branch = 'main', $force_refresh = false ) {
		$owner = sanitize_text_field( $owner );
		$repo = sanitize_text_field( $repo );
		$branch = sanitize_text_field( $branch );

		$cache_key = 'github_readme_' . $owner . '_' . $repo . '_' . $branch;
		$cached = get_transient( $cache_key );

		if ( $cached && ! $force_refresh ) {
			return $cached;
		}

		$possible_files = [ 'README.md', 'readme.md', 'README.MD', 'Readme.md', 'README', 'readme' ];

		$args = [
			'headers' => [
				'Accept' => 'application/vnd.github.v3.raw',
			],
		];

		if ( ! empty( $this->token ) ) {
			$args['headers']['Authorization'] = 'token ' . $this->token;
		}

		foreach ( $possible_files as $readme_file ) {
			$url = $this->base_url . '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/contents/' . rawurlencode( $readme_file ) . '?ref=' . rawurlencode( $branch );
			$response = wp_remote_get( $url, $args );

			if ( is_wp_error( $response ) ) {
				continue;
			}

			$status_code = wp_remote_retrieve_response_code( $response );
			if ( 200 === (int) $status_code ) {
				$body = wp_remote_retrieve_body( $response );
				set_transient( $cache_key, $body, $this->cache_duration );
				return $body;
			}
		}

		return '';
	}

	public function get_repo_files( $owner, $repo, $branch = 'main', $path = '' ) {
		$owner = sanitize_text_field( $owner );
		$repo = sanitize_text_field( $repo );
		$branch = sanitize_text_field( $branch );
		$path = trim( str_replace( '\\', '/', sanitize_text_field( $path ) ), '/' );

		$url = $this->base_url . '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/contents';
		if ( ! empty( $path ) ) {
			$url .= '/' . implode( '/', array_map( 'rawurlencode', explode( '/', $path ) ) );
		}
		$url .= '?ref=' . rawurlencode( $branch );

		$response = $this->make_request( $url );

		if ( is_wp_error( $response ) || ! is_array( $response ) ) {
			return [];
		}

		$files = [];
		foreach ( $response as $item ) {
			if ( empty( $item['path'] ) || empty( $item['type'] ) ) {
				continue;
			}

			if ( 'file' === $item['type'] ) {
				$files[] = [
					'path' => $item['path'],
					'name' => ! empty( $item['name'] ) ? $item['name'] : basename( $item['path'] ),
					'sha'  => ! empty( $item['sha'] ) ? $item['sha'] : '',
				];
			}
		}

		return $files;
	}

	public function delete_file( $owner, $repo, $path, $branch = 'main', $message = '' ) {
		$owner = sanitize_text_field( $owner );
		$repo = sanitize_text_field( $repo );
		$path = trim( str_replace( '\\', '/', sanitize_text_field( $path ) ), '/' );
		$branch = sanitize_text_field( $branch );

		if ( empty( $owner ) || empty( $repo ) || empty( $path ) || empty( $branch ) ) {
			return new \WP_Error( 'missing_file_delete_data', __( 'Repository, branch and file path are required.', 'github-repo-selector' ) );
		}

		$existing = $this->make_request(
			$this->base_url . '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/contents/' . implode( '/', array_map( 'rawurlencode', explode( '/', $path ) ) ) . '?ref=' . rawurlencode( $branch )
		);

		if ( is_wp_error( $existing ) || empty( $existing['sha'] ) ) {
			return new \WP_Error( 'file_not_found', __( 'Could not find that file on GitHub.', 'github-repo-selector' ) );
		}

		if ( empty( $message ) ) {
			$message = 'Delete ' . $path . ' from WordPress dashboard';
		}

		return $this->make_write_request(
			'DELETE',
			'/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/contents/' . implode( '/', array_map( 'rawurlencode', explode( '/', $path ) ) ),
			[
				'message' => sanitize_text_field( $message ),
				'sha'     => $existing['sha'],
				'branch'  => $branch,
			]
		);
	}

	/**
	 * Make authenticated GitHub write request.
	 */
	public function make_write_request( $method, $endpoint, $body = null ) {
		if ( empty( $this->token ) ) {
			return new \WP_Error( 'github_no_token', __( 'No GitHub token saved.', 'github-repo-selector' ) );
		}

		$args = [
			'method'  => strtoupper( $method ),
			'headers' => [
				'Accept'        => 'application/vnd.github.v3+json',
				'Content-Type'  => 'application/json',
				'Authorization' => 'token ' . $this->token,
			],
			'timeout' => 30,
		];

		if ( null !== $body ) {
			$args['body'] = wp_json_encode( $body );
		}

		$url = 0 === strpos( $endpoint, 'http' ) ? $endpoint : $this->base_url . $endpoint;
		$response = wp_remote_request( $url, $args );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		$decoded = json_decode( $response_body, true );

		if ( $status_code < 200 || $status_code >= 300 ) {
			$message = ! empty( $decoded['message'] ) ? $decoded['message'] : 'GitHub API Error: ' . $status_code;
			return new \WP_Error( 'github_write_api_error', $message, [ 'status' => $status_code, 'body' => $decoded ] );
		}

		return is_array( $decoded ) ? $decoded : [ 'success' => true, 'status' => $status_code ];
	}

	public function create_repository( $name, $description = '', $private = false ) {
		$name = sanitize_title( $name );
		if ( empty( $name ) ) {
			return new \WP_Error( 'missing_repo_name', __( 'Repository name is required.', 'github-repo-selector' ) );
		}

		return $this->make_write_request(
			'POST',
			'/user/repos',
			[
				'name'        => $name,
				'description' => sanitize_text_field( $description ),
				'private'     => (bool) $private,
				'auto_init'   => true,
			]
		);
	}

	public function delete_repository( $owner, $repo ) {
		$owner = sanitize_text_field( $owner );
		$repo  = sanitize_text_field( $repo );

		if ( empty( $owner ) || empty( $repo ) ) {
			return new \WP_Error( 'missing_repo', __( 'Owner and repository are required.', 'github-repo-selector' ) );
		}

		return $this->make_write_request( 'DELETE', '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) );
	}

	public function create_branch( $owner, $repo, $new_branch, $source_branch = '' ) {
		$owner = sanitize_text_field( $owner );
		$repo = sanitize_text_field( $repo );
		$new_branch = sanitize_text_field( $new_branch );
		$source_branch = sanitize_text_field( $source_branch );

		if ( empty( $owner ) || empty( $repo ) || empty( $new_branch ) ) {
			return new \WP_Error( 'missing_branch_data', __( 'Repository and branch name are required.', 'github-repo-selector' ) );
		}

		if ( empty( $source_branch ) ) {
			$details = $this->get_repo_details( $owner, $repo, true );
			$source_branch = ! empty( $details['default_branch'] ) ? $details['default_branch'] : 'main';
		}

		$source_ref = $this->make_request( $this->base_url . '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/git/ref/heads/' . implode( '/', array_map( 'rawurlencode', explode( '/', $source_branch ) ) ) );

		if ( is_wp_error( $source_ref ) || empty( $source_ref['object']['sha'] ) ) {
			return new \WP_Error( 'source_branch_not_found', __( 'Could not find the source branch SHA.', 'github-repo-selector' ) );
		}

		return $this->make_write_request(
			'POST',
			'/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/git/refs',
			[
				'ref' => 'refs/heads/' . $new_branch,
				'sha' => $source_ref['object']['sha'],
			]
		);
	}


	public function put_file_contents( $owner, $repo, $path, $content, $branch = '', $message = '' ) {
		$owner = sanitize_text_field( $owner );
		$repo = sanitize_text_field( $repo );
		$path = ltrim( str_replace( '\\', '/', sanitize_text_field( $path ) ), '/' );
		$branch = sanitize_text_field( $branch );
		$message = sanitize_text_field( $message );

		if ( empty( $owner ) || empty( $repo ) || empty( $path ) ) {
			return new \WP_Error( 'missing_file_data', __( 'Repository and file path are required.', 'github-repo-selector' ) );
		}

		if ( empty( $branch ) ) {
			$details = $this->get_repo_details( $owner, $repo, true );
			$branch = ! empty( $details['default_branch'] ) ? $details['default_branch'] : 'main';
		}

		if ( empty( $message ) ) {
			$message = 'Add ' . $path . ' from WordPress dashboard';
		}

		$existing_sha = '';
		$existing = $this->make_request(
			$this->base_url . '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/contents/' . implode( '/', array_map( 'rawurlencode', explode( '/', $path ) ) ) . '?ref=' . rawurlencode( $branch )
		);

		if ( is_array( $existing ) && ! empty( $existing['sha'] ) ) {
			$existing_sha = $existing['sha'];
		}

		$body = [
			'message' => $message,
			'content' => base64_encode( $content ),
			'branch'  => $branch,
		];

		if ( ! empty( $existing_sha ) ) {
			$body['sha'] = $existing_sha;
		}

		$endpoint = '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/contents/' . implode( '/', array_map( 'rawurlencode', explode( '/', $path ) ) );
		$result = $this->make_write_request( 'PUT', $endpoint, $body );

		// GitHub requires the current blob SHA when replacing an existing file.
		// A second request can race the first one (for example when an older
		// standalone GitHub plugin is also active), so retry a 422 SHA error by
		// re-reading the file metadata after the failed PUT and supplying its SHA.
		if ( is_wp_error( $result ) ) {
			$error_data = $result->get_error_data();
			$status = is_array( $error_data ) && isset( $error_data['status'] ) ? (int) $error_data['status'] : 0;
			$error_message = $result->get_error_message();
			if ( 422 === $status && false !== stripos( $error_message, 'sha' ) ) {
				$retry_existing = $this->make_request(
					$this->base_url . $endpoint . '?ref=' . rawurlencode( $branch )
				);
				if ( is_array( $retry_existing ) && ! empty( $retry_existing['sha'] ) ) {
					$body['sha'] = sanitize_text_field( $retry_existing['sha'] );
					$result = $this->make_write_request( 'PUT', $endpoint, $body );
				}
			}
		}

		return $result;
	}


	public function delete_branch( $owner, $repo, $branch ) {
		$owner = sanitize_text_field( $owner );
		$repo = sanitize_text_field( $repo );
		$branch = sanitize_text_field( $branch );

		if ( empty( $owner ) || empty( $repo ) || empty( $branch ) ) {
			return new \WP_Error( 'missing_branch', __( 'Repository and branch are required.', 'github-repo-selector' ) );
		}

		return $this->make_write_request( 'DELETE', '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/git/refs/heads/' . implode( '/', array_map( 'rawurlencode', explode( '/', $branch ) ) ) );
	}


	/**
	 * Make API request
	 */
	private function make_request( $url ) {
		$args = [
			'headers' => [
				'Accept' => 'application/vnd.github.v3+json',
			],
		];

		if ( ! empty( $this->token ) ) {
			$args['headers']['Authorization'] = 'token ' . $this->token;
		}

		$response = wp_remote_get( $url, $args );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$status_code = wp_remote_retrieve_response_code( $response );

		if ( $status_code !== 200 ) {
			return new \WP_Error( 'github_api_error', 'GitHub API Error: ' . $status_code );
		}

		$body = wp_remote_retrieve_body( $response );
		return json_decode( $body, true );
	}


	/**
	 * Make paginated API requests and merge array results.
	 */
	private function make_paginated_request( $url ) {
		$all = [];
		$page = 1;

		while ( $page <= 10 ) {
			$separator = strpos( $url, '?' ) === false ? '?' : '&';
			$page_url = $url . $separator . 'page=' . $page;
			$response = $this->make_request( $page_url );

			if ( is_wp_error( $response ) ) {
				return $response;
			}

			if ( empty( $response ) || ! is_array( $response ) ) {
				break;
			}

			$all = array_merge( $all, $response );

			if ( count( $response ) < 100 ) {
				break;
			}

			$page++;
		}

		return $all;
	}

	/**
	 * Clear cache
	 */
	public function clear_cache( $owner = '', $repo = '', $delete_saved_options = true ) {
		if ( ! empty( $owner ) && ! empty( $repo ) ) {
			delete_transient( 'github_branches_' . $owner . '_' . $repo );
			delete_transient( 'github_repo_details_' . $owner . '_' . $repo );
			delete_transient( 'github_readme_' . $owner . '_' . $repo . '_main' );
			delete_transient( 'github_readme_' . $owner . '_' . $repo . '_master' );
		} else {
			$old_username = $this->get_authenticated_username();
			delete_transient( 'github_authenticated_user' );
			if ( ! empty( $old_username ) ) {
				delete_transient( 'github_repos_' . $old_username );
			}
			if ( $delete_saved_options ) {
				delete_option( 'github_repo_selector_repo_options' );
			}
		}
	}
}
