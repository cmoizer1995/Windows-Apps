<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CMGC_Admin {
    const OPTION_SETTINGS = 'cmgc_options';
    const OPTION_CATALOG  = 'cmgc_repo_catalog';
    const OPTION_MAPPINGS = 'cmgc_repo_mappings';

    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
        add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
        add_action( 'admin_post_cmgc_refresh', array( __CLASS__, 'handle_refresh' ) );
        add_action( 'update_option_' . self::OPTION_SETTINGS, array( __CLASS__, 'options_updated' ), 10, 2 );
        add_action( 'add_meta_boxes', array( __CLASS__, 'add_repository_meta_boxes' ) );
        add_action( 'save_post', array( __CLASS__, 'save_repository_meta_box' ), 10, 2 );
    }

    public static function get_options() {
        $defaults = array(
            'token'              => '',
            'default_owner'      => '',
            'default_repo'       => '',
            'default_branch'     => 'main',
            'cache_minutes'      => 10,
        );
        $options = get_option( self::OPTION_SETTINGS, array() );
        $options = wp_parse_args( is_array( $options ) ? $options : array(), $defaults );
        if ( defined( 'CM_WL_DASHBOARD_BUNDLED_CMGC' ) && CM_WL_DASHBOARD_BUNDLED_CMGC ) {
            $dashboard_token = trim( (string) get_option( 'github_repo_selector_token', '' ) );
            if ( $dashboard_token ) $options['token'] = $dashboard_token;
        }
        return $options;
    }

    public static function get_repository_catalog() {
        $catalog = get_option( self::OPTION_CATALOG, array() );
        return is_array( $catalog ) ? $catalog : array();
    }

    public static function get_mappings() {
        $mappings = get_option( self::OPTION_MAPPINGS, array() );
        return is_array( $mappings ) ? $mappings : array();
    }

    public static function get_mapping_for_post( $post_id ) {
        $post_id = absint( $post_id );
        if ( ! $post_id ) {
            return null;
        }

        // v1.3+: the repository connection belongs to the individual WordPress
        // content item, just like an ACF/meta field. Nothing is assigned globally.
        $mapping = get_post_meta( $post_id, '_cmgc_repository_mapping', true );
        if ( is_array( $mapping ) && ! empty( $mapping['owner'] ) && ! empty( $mapping['repo'] ) ) {
            return $mapping;
        }

        // Backwards compatibility for connections made with v1.1/v1.2.
        $mappings = self::get_mappings();
        return isset( $mappings[ $post_id ] ) && is_array( $mappings[ $post_id ] ) ? $mappings[ $post_id ] : null;
    }

    public static function get_current_mapping() {
        $post_id = get_queried_object_id();
        if ( ! $post_id ) {
            $post_id = get_the_ID();
        }
        return self::get_mapping_for_post( $post_id );
    }

    public static function get_connectable_post_types() {
        $types = get_post_types( array( 'show_ui' => true ), 'objects' );
        if ( ! is_array( $types ) ) {
            return array();
        }

        unset( $types['attachment'] );

        uasort(
            $types,
            function ( $a, $b ) {
                $a_label = isset( $a->labels->name ) ? $a->labels->name : $a->name;
                $b_label = isset( $b->labels->name ) ? $b->labels->name : $b->name;
                return strcasecmp( $a_label, $b_label );
            }
        );
        return $types;
    }

    public static function admin_menu() {
        // The all-in-one dashboard owns the GitHub connection screen. Keep the
        // standalone wp-admin page only when CMGC is installed on its own.
        if ( defined( 'CM_WL_DASHBOARD_BUNDLED_CMGC' ) && CM_WL_DASHBOARD_BUNDLED_CMGC ) {
            return;
        }
        add_options_page(
            'GitHub Connector',
            'GitHub Connector',
            'manage_options',
            'cmgc-settings',
            array( __CLASS__, 'render_page' )
        );
    }

    public static function register_settings() {
        register_setting(
            'cmgc_settings_group',
            self::OPTION_SETTINGS,
            array(
                'type'              => 'array',
                'sanitize_callback' => array( __CLASS__, 'sanitize_options' ),
                'default'           => self::get_options(),
            )
        );
    }

    public static function sanitize_options( $input ) {
        $old = self::get_options();
        $input = is_array( $input ) ? $input : array();

        $token = isset( $input['token'] ) ? trim( (string) $input['token'] ) : '';
        $remove_token = ! empty( $input['remove_token'] );

        if ( defined( 'CMGC_GITHUB_TOKEN' ) && CMGC_GITHUB_TOKEN ) {
            $token = $old['token'];
        } elseif ( $remove_token ) {
            $token = '';
        } elseif ( '' === $token ) {
            $token = $old['token'];
        }

        return array(
            'token'          => sanitize_text_field( $token ),
            // Owner is intentionally not manually editable. Refresh / Update detects it from the PAT.
            'default_owner'  => sanitize_text_field( isset( $old['default_owner'] ) ? $old['default_owner'] : '' ),
            // Kept internally for backwards compatibility with existing manual widgets/shortcodes.
            'default_repo'   => isset( $old['default_repo'] ) ? sanitize_text_field( $old['default_repo'] ) : '',
            'default_branch' => isset( $old['default_branch'] ) ? sanitize_text_field( $old['default_branch'] ) : 'main',
            'cache_minutes'  => max( 1, min( 1440, isset( $input['cache_minutes'] ) ? absint( $input['cache_minutes'] ) : 10 ) ),
        );
    }

    public static function options_updated( $old_value, $value ) {
        if ( $old_value !== $value ) {
            CMGC_API::flush_cache();
        }
    }

    private static function redirect_notice( $status, $message ) {
        wp_safe_redirect(
            add_query_arg(
                array(
                    'page'        => 'cmgc-settings',
                    'cmgc_status' => sanitize_key( $status ),
                    'cmgc_msg'    => rawurlencode( $message ),
                ),
                admin_url( 'options-general.php' )
            )
        );
        exit;
    }

    public static function handle_refresh() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to do this.', 'cm-github-connector' ) );
        }

        check_admin_referer( 'cmgc_refresh_data' );
        CMGC_API::flush_cache();

        $options = self::get_options();
        $token = CMGC_API::get_token();
        $owner_message = '';

        if ( $token ) {
            $user = CMGC_API::get_authenticated_user( true );
            if ( is_wp_error( $user ) ) {
                self::redirect_notice( 'error', 'The GitHub token could not identify an account: ' . $user->get_error_message() );
            }

            if ( ! empty( $user['login'] ) ) {
                $options['default_owner'] = sanitize_text_field( $user['login'] );
                // Avoid update_option callback doing extra work after we already flushed the cache.
                remove_action( 'update_option_' . self::OPTION_SETTINGS, array( __CLASS__, 'options_updated' ), 10 );
                update_option( self::OPTION_SETTINGS, $options, false );
                add_action( 'update_option_' . self::OPTION_SETTINGS, array( __CLASS__, 'options_updated' ), 10, 2 );
                $owner_message = ' GitHub account detected: ' . $options['default_owner'] . '.';
            }
        }

        $catalog = CMGC_API::get_repository_catalog( true );
        if ( is_wp_error( $catalog ) ) {
            self::redirect_notice( 'error', $catalog->get_error_message() );
        }

        update_option( self::OPTION_CATALOG, $catalog, false );

        $rate = CMGC_API::get_rate_limit( true );
        $message = 'GitHub data refreshed.' . $owner_message . ' Found ' . count( $catalog ) . ' repositories for the repository dropdown.';
        if ( ! is_wp_error( $rate ) && isset( $rate['resources']['core']['remaining'] ) ) {
            $message .= ' API requests remaining: ' . absint( $rate['resources']['core']['remaining'] ) . '.';
        }

        self::redirect_notice( 'success', $message );
    }

    public static function add_repository_meta_boxes() {
        $available = self::get_connectable_post_types();

        foreach ( $available as $post_type => $object ) {
            add_meta_box(
                'cmgc_repository_connection',
                'GitHub Repository',
                array( __CLASS__, 'render_repository_meta_box' ),
                $post_type,
                'normal',
                'high'
            );
        }
    }

    public static function render_repository_meta_box( $post ) {
        $catalog = self::get_repository_catalog();
        $mapping = self::get_mapping_for_post( $post->ID );
        $selected = is_array( $mapping ) && ! empty( $mapping['full_name'] ) ? $mapping['full_name'] : '';

        wp_nonce_field( 'cmgc_save_post_repository_' . $post->ID, 'cmgc_repository_nonce' );
        ?>
        <div style="max-width:760px;padding:4px 0 8px;">
            <p style="margin-top:0;"><label for="cmgc_repo_for_post"><strong>Repository</strong></label></p>
            <select id="cmgc_repo_for_post" name="cmgc_repo_for_post" style="width:100%;max-width:760px;min-height:40px;">
                <option value="">— No GitHub repository —</option>
                <?php foreach ( $catalog as $repo ) :
                    if ( empty( $repo['full_name'] ) ) {
                        continue;
                    }
                    ?>
                    <option value="<?php echo esc_attr( $repo['full_name'] ); ?>" <?php selected( $selected, $repo['full_name'] ); ?>>
                        <?php echo esc_html( $repo['full_name'] . ( ! empty( $repo['private'] ) ? ' — Private' : '' ) ); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <?php if ( empty( $catalog ) ) : ?>
                <p class="description">No repositories are loaded yet. Save your token under <strong>Settings → GitHub Connector</strong>, then press <strong>Refresh / Update GitHub Data</strong>.</p>
            <?php else : ?>
                <p class="description">This field belongs to this individual <?php echo esc_html( get_post_type_object( $post->post_type )->labels->singular_name ?? 'content item' ); ?>. Choose the repository it represents, then press <strong>Publish</strong> or <strong>Update</strong>. An Elementor GitHub Repository Browser set to <strong>Connected repository for this Page / CPT</strong> will display this repository publicly.</p>
            <?php endif; ?>
            <?php if ( is_array( $mapping ) && ! empty( $mapping['branch'] ) ) : ?>
                <p class="description"><strong>Starting branch:</strong> <?php echo esc_html( $mapping['branch'] ); ?>. Visitors can switch branches from the GitHub-style branch dropdown on the public view.</p>
            <?php endif; ?>
        </div>
        <?php
    }

    public static function save_repository_meta_box( $post_id, $post ) {
        if ( ! $post || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
            return;
        }

        $available = self::get_connectable_post_types();
        if ( ! isset( $available[ $post->post_type ] ) ) {
            return;
        }

        if ( ! isset( $_POST['cmgc_repository_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['cmgc_repository_nonce'] ) ), 'cmgc_save_post_repository_' . $post_id ) ) {
            return;
        }

        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        $repo_full_name = isset( $_POST['cmgc_repo_for_post'] ) ? sanitize_text_field( wp_unslash( $_POST['cmgc_repo_for_post'] ) ) : '';

        if ( '' === $repo_full_name ) {
            delete_post_meta( $post_id, '_cmgc_repository_mapping' );
            self::remove_legacy_mapping( $post_id );
            return;
        }

        $selected_repo = null;
        foreach ( self::get_repository_catalog() as $repo ) {
            if ( isset( $repo['full_name'] ) && 0 === strcasecmp( $repo['full_name'], $repo_full_name ) ) {
                $selected_repo = $repo;
                break;
            }
        }

        if ( ! $selected_repo ) {
            return;
        }

        $mapping = array(
            'post_id'     => absint( $post_id ),
            'post_type'   => sanitize_key( $post->post_type ),
            'owner'       => sanitize_text_field( $selected_repo['owner'] ),
            'repo'        => sanitize_text_field( $selected_repo['name'] ),
            'full_name'   => sanitize_text_field( $selected_repo['full_name'] ),
            'branch'      => ! empty( $selected_repo['default_branch'] ) ? sanitize_text_field( $selected_repo['default_branch'] ) : 'main',
            'access'      => 'public',
            'show_header' => 'yes',
        );

        update_post_meta( $post_id, '_cmgc_repository_mapping', $mapping );
        self::remove_legacy_mapping( $post_id );
    }

    private static function remove_legacy_mapping( $post_id ) {
        $mappings = self::get_mappings();
        if ( isset( $mappings[ $post_id ] ) ) {
            unset( $mappings[ $post_id ] );
            update_option( self::OPTION_MAPPINGS, $mappings, false );
        }
    }

    public static function render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $options = self::get_options();
        $catalog = self::get_repository_catalog();
        $constant_token = defined( 'CMGC_GITHUB_TOKEN' ) && CMGC_GITHUB_TOKEN;
        ?>
        <div class="wrap">
            <h1>GitHub Connector</h1>
            <?php if ( isset( $_GET['cmgc_status'], $_GET['cmgc_msg'] ) ) : ?>
                <div class="notice notice-<?php echo 'success' === sanitize_key( wp_unslash( $_GET['cmgc_status'] ) ) ? 'success' : 'error'; ?> is-dismissible">
                    <p><?php echo esc_html( rawurldecode( sanitize_text_field( wp_unslash( $_GET['cmgc_msg'] ) ) ) ); ?></p>
                </div>
            <?php endif; ?>

            <p>This screen only manages the GitHub connection. Repository selection is done on each individual WordPress Page, Post or CPT Add/Edit screen.</p>

            <h2>GitHub connection</h2>
            <form method="post" action="options.php">
                <?php settings_fields( 'cmgc_settings_group' ); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="cmgc_token">Personal access token</label></th>
                        <td>
                            <?php if ( $constant_token ) : ?>
                                <input type="password" id="cmgc_token" class="regular-text" value="Token supplied by CMGC_GITHUB_TOKEN" disabled>
                                <p class="description">The token is defined in wp-config.php using <code>CMGC_GITHUB_TOKEN</code>.</p>
                            <?php else : ?>
                                <input type="password" id="cmgc_token" name="cmgc_options[token]" class="regular-text" value="" autocomplete="new-password" placeholder="<?php echo esc_attr( $options['token'] ? 'Saved token — enter a new token to replace it' : 'github_pat_…' ); ?>">
                                <p class="description">The token stays server-side and is never placed into the public page source.</p>
                                <?php if ( $options['token'] ) : ?><label><input type="checkbox" name="cmgc_options[remove_token]" value="1"> Remove the saved token when I save</label><?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">GitHub owner / account</th>
                        <td>
                            <input type="text" class="regular-text" value="<?php echo esc_attr( $options['default_owner'] ); ?>" readonly placeholder="Detected from token after Refresh / Update">
                            <p class="description">Detected automatically from the saved Personal Access Token.</p>
                        </td>
                    </tr>
                    <tr><th scope="row"><label for="cmgc_cache">Cache duration</label></th><td><input type="number" id="cmgc_cache" name="cmgc_options[cache_minutes]" min="1" max="1440" value="<?php echo esc_attr( $options['cache_minutes'] ); ?>"> minutes</td></tr>
                </table>
                <?php submit_button( 'Save GitHub Settings' ); ?>
            </form>

            <hr>
            <h2>Refresh / Update</h2>
            <p>Detects the GitHub account from the token, reloads the repository list used by the content-editor dropdowns, and clears cached GitHub data.</p>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="cmgc_refresh">
                <?php wp_nonce_field( 'cmgc_refresh_data' ); ?>
                <?php submit_button( 'Refresh / Update GitHub Data', 'secondary' ); ?>
            </form>
            <p><strong>Detected GitHub account:</strong> <?php echo $options['default_owner'] ? esc_html( $options['default_owner'] ) : 'Not detected yet'; ?><br>
            <strong>Repositories loaded for content editors:</strong> <?php echo absint( count( $catalog ) ); ?></p>

            <hr>
            <h2>Using it on content</h2>
            <p>Open any normal WordPress <strong>Page, Post or registered CPT</strong> and use its <strong>GitHub Repository</strong> field to choose the repository for that one item. CPT UI-created post types are included automatically because they are registered WordPress post types.</p>
            <p>After you press <strong>Publish</strong> or <strong>Update</strong>, an Elementor <strong>GitHub Repository Browser</strong> widget in <strong>Connected repository for this Page / CPT</strong> mode reads that saved repository. The public viewer starts on the repository's default branch and its GitHub-style branch button lets visitors switch to the other branches without leaving your WordPress page.</p>
        </div>
        <?php
    }

}
