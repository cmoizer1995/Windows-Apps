<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CMGC_REST {
    public static function init() {
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
    }

    public static function register_routes() {
        register_rest_route(
            'cmgc/v1',
            '/browse',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( __CLASS__, 'browse' ),
                'permission_callback' => '__return_true',
                'args'                => array(
                    'owner'     => array( 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
                    'repo'      => array( 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
                    'branch'    => array( 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ),
                    'path'      => array( 'required' => false, 'sanitize_callback' => array( __CLASS__, 'sanitize_path' ) ),
                    'access'    => array( 'required' => true, 'sanitize_callback' => 'sanitize_key' ),
                    'signature' => array( 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
                ),
            )
        );
    }

    public static function sanitize_path( $path ) {
        $path = str_replace( array( "\0", "\\" ), array( '', '/' ), (string) $path );
        $parts = array();
        foreach ( explode( '/', trim( $path, '/' ) ) as $part ) {
            if ( '' === $part || '.' === $part ) {
                continue;
            }
            if ( '..' === $part ) {
                array_pop( $parts );
                continue;
            }
            $parts[] = sanitize_text_field( rawurldecode( $part ) );
        }
        return implode( '/', $parts );
    }

    public static function browse( WP_REST_Request $request ) {
        $owner = $request->get_param( 'owner' );
        $repo = $request->get_param( 'repo' );
        $branch = $request->get_param( 'branch' );
        $path = $request->get_param( 'path' );
        $access = 'logged_in' === $request->get_param( 'access' ) ? 'logged_in' : 'public';
        $signature = $request->get_param( 'signature' );

        if ( ! CMGC_Renderer::verify_signature( $owner, $repo, $access, $signature ) ) {
            return new WP_Error( 'cmgc_invalid_instance', 'This repository browser instance is not valid.', array( 'status' => 403 ) );
        }

        if ( 'logged_in' === $access && ! is_user_logged_in() ) {
            return new WP_Error( 'cmgc_login_required', 'You must be logged in to view this repository.', array( 'status' => 401 ) );
        }

        $html = CMGC_Renderer::render_path( $owner, $repo, $branch, $path, false );

        $response = rest_ensure_response(
            array(
                'html'   => $html,
                'path'   => $path,
                'branch' => $branch,
            )
        );
        $response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0' );
        return $response;
    }
}
