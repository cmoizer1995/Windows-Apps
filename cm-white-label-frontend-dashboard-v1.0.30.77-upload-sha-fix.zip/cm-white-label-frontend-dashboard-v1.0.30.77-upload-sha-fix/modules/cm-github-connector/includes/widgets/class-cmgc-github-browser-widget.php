<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CMGC_GitHub_Browser_Widget extends \Elementor\Widget_Base {
    public function get_name(): string {
        return 'cmgc_github_browser';
    }

    public function get_title(): string {
        return 'GitHub Repository Browser';
    }

    public function get_icon(): string {
        return 'eicon-code';
    }

    public function get_categories(): array {
        return array( 'general' );
    }

    public function get_keywords(): array {
        return array( 'github', 'repository', 'repo', 'code', 'connector', 'cpt', 'all repositories' );
    }

    public function get_style_depends(): array {
        return array( 'cmgc-github-browser' );
    }

    public function get_script_depends(): array {
        return array( 'cmgc-github-browser' );
    }

    private function exclusion_control_id( $full_name ): string {
        return 'exclude_repo_' . substr( md5( strtolower( (string) $full_name ) ), 0, 16 );
    }

    protected function register_controls(): void {
        $defaults = CMGC_Admin::get_options();
        $catalog  = CMGC_Admin::get_repository_catalog();

        $this->start_controls_section(
            'repository_section',
            array( 'label' => 'GitHub Repository' )
        );

        $this->add_control(
            'repository_source',
            array(
                'label'   => 'Repository Source',
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'auto',
                'options' => array(
                    'auto'   => 'Connected repository for this Page / CPT',
                    'manual' => 'Manual repository',
                    'all'    => 'All repositories',
                ),
                'description' => 'Connected uses the repository selected on this Page/Post/CPT Add/Edit screen. All repositories displays every repository loaded from the saved GitHub token except the repositories you exclude below.',
            )
        );

        $this->add_control(
            'owner',
            array(
                'label'       => 'Owner / Organisation',
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => $defaults['default_owner'],
                'placeholder' => 'octocat',
                'label_block' => true,
                'condition'   => array( 'repository_source' => 'manual' ),
            )
        );

        $this->add_control(
            'repo',
            array(
                'label'       => 'Repository',
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => $defaults['default_repo'],
                'placeholder' => 'Hello-World',
                'label_block' => true,
                'condition'   => array( 'repository_source' => 'manual' ),
            )
        );

        if ( ! empty( $catalog ) ) {
            $this->add_control(
                'exclude_repositories_heading',
                array(
                    'label'     => 'Exclude repositories',
                    'type'      => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                    'condition' => array( 'repository_source' => 'all' ),
                )
            );

            $this->add_control(
                'exclude_repositories_help',
                array(
                    'type'      => \Elementor\Controls_Manager::RAW_HTML,
                    'raw'       => 'Turn on <strong>Exclude</strong> for any repository you do not want shown in this All Repositories widget.',
                    'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
                    'condition' => array( 'repository_source' => 'all' ),
                )
            );

            foreach ( $catalog as $catalog_repo ) {
                if ( empty( $catalog_repo['full_name'] ) ) {
                    continue;
                }

                $full_name = (string) $catalog_repo['full_name'];
                $label     = $full_name . ( ! empty( $catalog_repo['private'] ) ? ' — Private' : '' );

                $this->add_control(
                    $this->exclusion_control_id( $full_name ),
                    array(
                        'label'        => $label,
                        'type'         => \Elementor\Controls_Manager::SWITCHER,
                        'label_on'     => 'Exclude',
                        'label_off'    => 'Show',
                        'return_value' => 'yes',
                        'default'      => '',
                        'condition'    => array( 'repository_source' => 'all' ),
                    )
                );
            }
        } else {
            $this->add_control(
                'all_repositories_empty_notice',
                array(
                    'type'      => \Elementor\Controls_Manager::RAW_HTML,
                    'raw'       => 'No repositories are loaded yet. Go to <strong>Dashboard → Settings → GitHub</strong> and press <strong>Update Repositories & Branches</strong>, then reopen Elementor.',
                    'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
                    'condition' => array( 'repository_source' => 'all' ),
                )
            );
        }

        $this->add_control(
            'branch',
            array(
                'label'       => 'Starting Branch Override',
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => '',
                'placeholder' => 'Leave blank to use the connected/default branch',
                'label_block' => true,
                'condition'   => array( 'repository_source!' => 'all' ),
            )
        );

        $this->add_control(
            'path',
            array(
                'label'       => 'Starting Path',
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => '',
                'placeholder' => 'docs or src/plugin.php',
                'label_block' => true,
                'condition'   => array( 'repository_source!' => 'all' ),
            )
        );

        $this->add_control(
            'manual_access',
            array(
                'label'   => 'Frontend Access',
                'type'    => \Elementor\Controls_Manager::SELECT,
                'default' => 'public',
                'options' => array(
                    'public'    => 'Public visitors',
                    'logged_in' => 'Logged-in WordPress users only',
                ),
                'condition' => array( 'repository_source' => 'manual' ),
            )
        );

        $this->add_control(
            'manual_show_header',
            array(
                'label'        => 'Show Repository Header',
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => 'Show',
                'label_off'    => 'Hide',
                'return_value' => 'yes',
                'default'      => 'yes',
                'condition'    => array( 'repository_source' => 'manual' ),
            )
        );

        $this->end_controls_section();
    }

    private function render_all_repositories( $settings ): void {
        $catalog = CMGC_Admin::get_repository_catalog();
        $global_show_all = get_option( 'cm_wlfd_github_view_show_all', null );
        if ( null !== $global_show_all && '0' === (string) $global_show_all ) {
            echo '<div class="cmgc-all-empty">Show All GitHub is disabled under Dashboard → Settings → GitHub.</div>';
            return;
        }
        $global_excluded = get_option( 'cm_wlfd_github_view_excluded_repos', array() );
        $global_excluded = is_array( $global_excluded ) ? array_map( 'strtolower', $global_excluded ) : array();

        if ( empty( $catalog ) ) {
            echo '<div class="cmgc-error">No GitHub repositories are loaded. Open Dashboard → Settings → GitHub and press Update Repositories & Branches.</div>';
            return;
        }

        $visible = array();
        foreach ( $catalog as $catalog_repo ) {
            if ( empty( $catalog_repo['full_name'] ) || empty( $catalog_repo['owner'] ) || empty( $catalog_repo['name'] ) ) {
                continue;
            }

            if ( in_array( strtolower( (string) $catalog_repo['full_name'] ), $global_excluded, true ) ) {
                continue;
            }

            $control_id = $this->exclusion_control_id( $catalog_repo['full_name'] );
            if ( isset( $settings[ $control_id ] ) && 'yes' === $settings[ $control_id ] ) {
                continue;
            }

            $visible[] = $catalog_repo;
        }

        if ( empty( $visible ) ) {
            echo '<div class="cmgc-all-empty">All loaded repositories are excluded in this Elementor widget.</div>';
            return;
        }

        echo '<div class="cmgc-all-repositories" data-cmgc-repository-count="' . esc_attr( count( $visible ) ) . '">';
        foreach ( $visible as $catalog_repo ) {
            echo '<div class="cmgc-all-repository-item">';
            echo CMGC_Renderer::render_browser(
                sanitize_text_field( $catalog_repo['owner'] ),
                sanitize_text_field( $catalog_repo['name'] ),
                ! empty( $catalog_repo['default_branch'] ) ? sanitize_text_field( $catalog_repo['default_branch'] ) : '',
                '',
                'public',
                true
            ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            echo '</div>';
        }
        echo '</div>';
    }

    protected function render(): void {
        $settings = $this->get_settings_for_display();
        $source = isset( $settings['repository_source'] ) ? $settings['repository_source'] : 'auto';

        if ( 'all' === $source ) {
            $this->render_all_repositories( $settings );
            return;
        }

        $mapping = 'manual' !== $source ? CMGC_Admin::get_current_mapping() : null;

        if ( is_array( $mapping ) ) {
            $owner = isset( $mapping['owner'] ) ? $mapping['owner'] : '';
            $repo = isset( $mapping['repo'] ) ? $mapping['repo'] : '';
            $branch = ! empty( $settings['branch'] ) ? $settings['branch'] : ( isset( $mapping['branch'] ) ? $mapping['branch'] : '' );
            $access = isset( $mapping['access'] ) && 'logged_in' === $mapping['access'] ? 'logged_in' : 'public';
            $show_header = ! isset( $mapping['show_header'] ) || 'no' !== $mapping['show_header'];
        } else {
            // Backwards-compatible fallback: old widgets with owner/repo values still render manually.
            $owner = isset( $settings['owner'] ) ? $settings['owner'] : '';
            $repo = isset( $settings['repo'] ) ? $settings['repo'] : '';
            $defaults = CMGC_Admin::get_options();
            if ( ! $owner ) {
                $owner = $defaults['default_owner'];
            }
            if ( ! $repo ) {
                $repo = $defaults['default_repo'];
            }
            $branch = ! empty( $settings['branch'] ) ? $settings['branch'] : $defaults['default_branch'];
            $access = isset( $settings['manual_access'] ) && 'logged_in' === $settings['manual_access'] ? 'logged_in' : 'public';
            $show_header = ! isset( $settings['manual_show_header'] ) || ! empty( $settings['manual_show_header'] );
        }

        echo CMGC_Renderer::render_browser(
            sanitize_text_field( $owner ),
            sanitize_text_field( $repo ),
            sanitize_text_field( $branch ),
            isset( $settings['path'] ) ? sanitize_text_field( $settings['path'] ) : '',
            $access,
            $show_header
        ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }
}
