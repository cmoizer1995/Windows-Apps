<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CMGC_Renderer {
    public static function signature( $owner, $repo, $access ) {
        $payload = strtolower( trim( $owner ) ) . '/' . strtolower( trim( $repo ) ) . '|' . ( 'logged_in' === $access ? 'logged_in' : 'public' );
        return hash_hmac( 'sha256', $payload, wp_salt( 'auth' ) );
    }

    public static function verify_signature( $owner, $repo, $access, $signature ) {
        return hash_equals( self::signature( $owner, $repo, $access ), (string) $signature );
    }

    public static function render_browser( $owner, $repo, $branch = '', $path = '', $access = 'public', $show_header = true ) {
        if ( ! $owner || ! $repo ) {
            return '<div class="cmgc-error">Set a GitHub owner and repository in the Elementor widget or GitHub Connector settings.</div>';
        }

        if ( 'logged_in' === $access && ! is_user_logged_in() ) {
            return '<div class="cmgc-auth-required">You must be logged in to view this repository.</div>';
        }

        $repo_data = CMGC_API::get_repo( $owner, $repo );
        if ( is_wp_error( $repo_data ) ) {
            return '<div class="cmgc-error">' . esc_html( $repo_data->get_error_message() ) . '</div>';
        }

        if ( ! $branch ) {
            $branch = ! empty( $repo_data['default_branch'] ) ? $repo_data['default_branch'] : 'main';
        }

        wp_enqueue_style( 'cmgc-github-browser' );
        wp_enqueue_script( 'cmgc-github-browser' );

        $branches = CMGC_API::get_branches( $owner, $repo );
        if ( is_wp_error( $branches ) ) {
            $branches = array();
        }

        $content_html = self::render_path( $owner, $repo, $branch, $path );
        $signature = self::signature( $owner, $repo, $access );
        $instance = 'cmgc-' . wp_generate_uuid4();

        ob_start();
        ?>
        <section
            id="<?php echo esc_attr( $instance ); ?>"
            class="cmgc-browser"
            data-owner="<?php echo esc_attr( $owner ); ?>"
            data-repo="<?php echo esc_attr( $repo ); ?>"
            data-branch="<?php echo esc_attr( $branch ); ?>"
            data-path="<?php echo esc_attr( trim( $path, '/' ) ); ?>"
            data-access="<?php echo esc_attr( $access ); ?>"
            data-signature="<?php echo esc_attr( $signature ); ?>"
            data-endpoint="<?php echo esc_url( rest_url( 'cmgc/v1/browse' ) ); ?>"
            data-rest-nonce="<?php echo esc_attr( wp_create_nonce( 'wp_rest' ) ); ?>"
        >
            <?php if ( $show_header ) : ?>
                <div class="cmgc-repo-header">
                    <div class="cmgc-repo-title-row">
                        <div class="cmgc-repo-title">
                            <span class="cmgc-repo-icon" aria-hidden="true">◉</span>
                            <strong><?php echo esc_html( $owner ); ?></strong><span class="cmgc-slash">/</span><strong><?php echo esc_html( $repo ); ?></strong>
                            <?php if ( isset( $repo_data['private'] ) ) : ?>
                                <span class="cmgc-badge"><?php echo $repo_data['private'] ? 'Private' : 'Public'; ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="cmgc-repo-actions">
                            <?php if ( isset( $repo_data['stargazers_count'] ) ) : ?><span class="cmgc-counter">☆ <?php echo esc_html( number_format_i18n( (int) $repo_data['stargazers_count'] ) ); ?></span><?php endif; ?>
                            <?php if ( isset( $repo_data['forks_count'] ) ) : ?><span class="cmgc-counter">⑂ <?php echo esc_html( number_format_i18n( (int) $repo_data['forks_count'] ) ); ?></span><?php endif; ?>
                            <?php if ( ! empty( $repo_data['html_url'] ) ) : ?>
                                <a class="cmgc-external-button" href="<?php echo esc_url( $repo_data['html_url'] ); ?>" target="_blank" rel="noopener noreferrer">Open on GitHub ↗</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if ( ! empty( $repo_data['description'] ) ) : ?>
                        <p class="cmgc-description"><?php echo esc_html( $repo_data['description'] ); ?></p>
                    <?php endif; ?>
                    <?php
                    $repo_updated_raw = ! empty( $repo_data['pushed_at'] ) ? $repo_data['pushed_at'] : ( ! empty( $repo_data['updated_at'] ) ? $repo_data['updated_at'] : '' );
                    $repo_updated     = $repo_updated_raw ? wp_date( 'd/m/Y', strtotime( $repo_updated_raw ) ) : '';
                    if ( $repo_updated ) :
                        ?>
                        <div class="cmgc-repo-updated">
                            <span>Last updated repo: <?php echo esc_html( $repo_updated ); ?></span>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="cmgc-toolbar">
                <details class="cmgc-branch-menu">
                    <summary class="cmgc-branch-summary" aria-label="Select GitHub branch">
                        <span class="cmgc-branch-icon" aria-hidden="true">⑂</span>
                        <span class="cmgc-current-branch"><?php echo esc_html( $branch ); ?></span>
                        <span class="cmgc-branch-caret" aria-hidden="true">▼</span>
                    </summary>
                    <div class="cmgc-branch-popover" role="menu" aria-label="Branches">
                        <div class="cmgc-branch-popover-title">Switch branches</div>
                        <div class="cmgc-branch-list">
                            <?php
                            $seen_branch = false;
                            foreach ( $branches as $branch_item ) :
                                if ( empty( $branch_item['name'] ) ) {
                                    continue;
                                }
                                $is_current = $branch_item['name'] === $branch;
                                $seen_branch = $seen_branch || $is_current;
                                ?>
                                <button type="button" class="cmgc-branch-option<?php echo $is_current ? ' is-current' : ''; ?>" data-cmgc-branch="<?php echo esc_attr( $branch_item['name'] ); ?>" role="menuitem">
                                    <span class="cmgc-branch-check" aria-hidden="true"><?php echo $is_current ? '✓' : ''; ?></span>
                                    <span><?php echo esc_html( $branch_item['name'] ); ?></span>
                                </button>
                            <?php endforeach; ?>
                            <?php if ( ! $seen_branch ) : ?>
                                <button type="button" class="cmgc-branch-option is-current" data-cmgc-branch="<?php echo esc_attr( $branch ); ?>" role="menuitem">
                                    <span class="cmgc-branch-check" aria-hidden="true">✓</span>
                                    <span><?php echo esc_html( $branch ); ?></span>
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </details>
                <button type="button" class="cmgc-refresh-button" title="Refresh this view">↻ Refresh</button><span class="cmgc-code-view-label">Code</span>
                <span class="cmgc-loading" hidden>Loading…</span>
            </div>

            <div class="cmgc-live-region screen-reader-text" aria-live="polite"></div>
            <div class="cmgc-content"><?php echo $content_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
        </section>
        <?php
        return ob_get_clean();
    }

    public static function render_path( $owner, $repo, $branch, $path = '', $force = false ) {
        $path = trim( (string) $path, '/' );
        $contents = CMGC_API::get_contents( $owner, $repo, $path, $branch, $force );
        if ( is_wp_error( $contents ) ) {
            return '<div class="cmgc-error">' . esc_html( $contents->get_error_message() ) . '</div>';
        }

        if ( isset( $contents['type'] ) && 'file' === $contents['type'] ) {
            return self::render_file( $owner, $repo, $branch, $contents );
        }

        if ( ! is_array( $contents ) ) {
            return '<div class="cmgc-error">GitHub returned an unexpected directory response.</div>';
        }

        return self::render_directory( $owner, $repo, $branch, $path, $contents );
    }

    private static function render_directory( $owner, $repo, $branch, $path, $items ) {
        usort(
            $items,
            function ( $a, $b ) {
                $a_dir = isset( $a['type'] ) && 'dir' === $a['type'];
                $b_dir = isset( $b['type'] ) && 'dir' === $b['type'];
                if ( $a_dir !== $b_dir ) {
                    return $a_dir ? -1 : 1;
                }
                return strcasecmp( isset( $a['name'] ) ? $a['name'] : '', isset( $b['name'] ) ? $b['name'] : '' );
            }
        );

        $readme = null;
        foreach ( $items as $item ) {
            if ( isset( $item['type'], $item['name'] ) && 'file' === $item['type'] && preg_match( '/^readme(?:\.[a-z0-9._-]+)?$/i', $item['name'] ) ) {
                $readme = $item;
                break;
            }
        }

        ob_start();
        echo self::render_breadcrumbs( $path ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        ?>
        <div class="cmgc-file-list" role="table" aria-label="Repository files">
            <?php if ( '' !== $path ) :
                $parent = dirname( $path );
                if ( '.' === $parent ) {
                    $parent = '';
                }
                ?>
                <button type="button" class="cmgc-file-row cmgc-nav-link" data-cmgc-path="<?php echo esc_attr( $parent ); ?>" role="row">
                    <span class="cmgc-file-icon" aria-hidden="true">↩</span>
                    <span class="cmgc-file-name">..</span>
                    <span class="cmgc-file-meta">Parent directory</span>
                </button>
            <?php endif; ?>
            <?php foreach ( $items as $item ) :
                if ( empty( $item['name'] ) || empty( $item['path'] ) || empty( $item['type'] ) ) {
                    continue;
                }
                $is_dir = 'dir' === $item['type'];
                ?>
                <button type="button" class="cmgc-file-row cmgc-nav-link" data-cmgc-path="<?php echo esc_attr( $item['path'] ); ?>" role="row">
                    <span class="cmgc-file-icon" aria-hidden="true"><?php echo $is_dir ? '▰' : '▤'; ?></span>
                    <span class="cmgc-file-name"><?php echo esc_html( $item['name'] ); ?></span>
                    <span class="cmgc-file-meta"><?php echo $is_dir ? 'Directory' : esc_html( size_format( isset( $item['size'] ) ? (int) $item['size'] : 0 ) ); ?></span>
                </button>
            <?php endforeach; ?>
        </div>
        <?php
        if ( $readme ) {
            $html = CMGC_API::get_rendered_markdown( $owner, $repo, $readme['path'], $branch );
            if ( ! is_wp_error( $html ) ) {
                $html = self::rewrite_markdown_links( $html, $owner, $repo, $branch, $readme['path'] );
                ?>
                <article class="cmgc-readme">
                    <div class="cmgc-readme-title">README</div>
                    <div class="cmgc-markdown-body"><?php echo self::sanitize_markdown_html( $html ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
                </article>
                <?php
            }
        }
        return ob_get_clean();
    }

    private static function render_file( $owner, $repo, $branch, $file ) {
        $path = isset( $file['path'] ) ? $file['path'] : '';
        $name = isset( $file['name'] ) ? $file['name'] : basename( $path );
        $size = isset( $file['size'] ) ? (int) $file['size'] : 0;
        $extension = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );

        ob_start();
        echo self::render_breadcrumbs( $path, true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        ?>
        <div class="cmgc-file-header">
            <strong><?php echo esc_html( $name ); ?></strong>
            <span><?php echo esc_html( size_format( $size ) ); ?></span>
            <?php if ( ! empty( $file['html_url'] ) ) : ?>
                <a href="<?php echo esc_url( $file['html_url'] ); ?>" target="_blank" rel="noopener noreferrer">View on GitHub ↗</a>
            <?php endif; ?>
        </div>
        <?php

        if ( in_array( $extension, array( 'md', 'markdown', 'mdown', 'mkdn' ), true ) ) {
            $html = CMGC_API::get_rendered_markdown( $owner, $repo, $path, $branch );
            if ( is_wp_error( $html ) ) {
                echo '<div class="cmgc-error">' . esc_html( $html->get_error_message() ) . '</div>';
            } else {
                $html = self::rewrite_markdown_links( $html, $owner, $repo, $branch, $path );
                echo '<article class="cmgc-markdown-body cmgc-file-markdown">' . self::sanitize_markdown_html( $html ) . '</article>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            }
            return ob_get_clean();
        }

        if ( self::is_text_file( $extension, $name ) && $size <= 1024 * 1024 && ! empty( $file['content'] ) && 'base64' === ( isset( $file['encoding'] ) ? $file['encoding'] : '' ) ) {
            $decoded = base64_decode( preg_replace( '/\s+/', '', $file['content'] ), true );
            if ( false !== $decoded ) {
                self::render_code( $decoded );
                return ob_get_clean();
            }
        }

        echo '<div class="cmgc-binary-message">Preview is not available for this file type inside the repository browser. Use “View on GitHub” above.</div>';
        return ob_get_clean();
    }

    private static function render_code( $text ) {
        $lines = preg_split( '/\R/', (string) $text );
        echo '<div class="cmgc-code-wrap"><table class="cmgc-code-table"><tbody>';
        foreach ( $lines as $index => $line ) {
            echo '<tr><td class="cmgc-line-no">' . esc_html( $index + 1 ) . '</td><td class="cmgc-code-line"><code>' . esc_html( $line ) . '</code></td></tr>';
        }
        echo '</tbody></table></div>';
    }

    private static function is_text_file( $extension, $name ) {
        $text_extensions = array(
            'txt','php','js','jsx','ts','tsx','css','scss','sass','less','html','htm','xml','json','yml','yaml','ini','conf','config','env','example','sh','bash','zsh','bat','cmd','ps1','py','rb','java','c','h','cpp','hpp','cs','go','rs','sql','csv','tsv','log','svg','gitignore','gitattributes','editorconfig','lock','toml','vue','svelte'
        );
        if ( in_array( $extension, $text_extensions, true ) ) {
            return true;
        }
        return in_array( strtolower( $name ), array( 'license', 'copying', 'dockerfile', 'makefile', 'readme' ), true );
    }

    private static function render_breadcrumbs( $path, $file_last = false ) {
        $path = trim( (string) $path, '/' );
        $segments = '' === $path ? array() : explode( '/', $path );
        $built = '';

        ob_start();
        ?>
        <nav class="cmgc-breadcrumbs" aria-label="Repository path">
            <button type="button" class="cmgc-crumb cmgc-nav-link" data-cmgc-path="">root</button>
            <?php foreach ( $segments as $index => $segment ) :
                $built = '' === $built ? $segment : $built . '/' . $segment;
                $is_last = $index === count( $segments ) - 1;
                ?>
                <span class="cmgc-crumb-sep">/</span>
                <?php if ( $is_last && $file_last ) : ?>
                    <span class="cmgc-crumb-current"><?php echo esc_html( $segment ); ?></span>
                <?php else : ?>
                    <button type="button" class="cmgc-crumb cmgc-nav-link" data-cmgc-path="<?php echo esc_attr( $built ); ?>"><?php echo esc_html( $segment ); ?></button>
                <?php endif; ?>
            <?php endforeach; ?>
        </nav>
        <?php
        return ob_get_clean();
    }


    private static function sanitize_markdown_html( $html ) {
        $allowed = wp_kses_allowed_html( 'post' );
        if ( ! isset( $allowed['a'] ) ) {
            $allowed['a'] = array();
        }
        $allowed['a']['data-cmgc-path'] = true;
        $allowed['a']['data-cmgc-branch'] = true;
        $allowed['a']['class'] = true;
        $allowed['a']['target'] = true;
        $allowed['a']['rel'] = true;
        $allowed['a']['href'] = true;
        return wp_kses( $html, $allowed );
    }

    private static function normalize_relative_path( $base_file, $relative ) {
        $relative = preg_replace( '/[?#].*$/', '', (string) $relative );
        $base_dir = dirname( $base_file );
        if ( '.' === $base_dir ) {
            $base_dir = '';
        }
        $combined = ( $base_dir ? $base_dir . '/' : '' ) . $relative;
        $parts = array();
        foreach ( explode( '/', $combined ) as $part ) {
            if ( '' === $part || '.' === $part ) {
                continue;
            }
            if ( '..' === $part ) {
                array_pop( $parts );
            } else {
                $parts[] = $part;
            }
        }
        return implode( '/', $parts );
    }

    private static function get_internal_markdown_target( $href, $owner, $repo, $branch, $current_file, $branch_names ) {
        $href = html_entity_decode( (string) $href );
        if ( '' === $href || 0 === strpos( $href, '#' ) || 0 === strpos( $href, 'mailto:' ) || 0 === strpos( $href, 'tel:' ) ) {
            return null;
        }

        $path          = null;
        $target_branch = (string) $branch;
        $parsed        = wp_parse_url( $href );

        // Keep links to this same GitHub repository inside the WordPress viewer.
        if ( is_array( $parsed ) && ! empty( $parsed['host'] ) && in_array( strtolower( $parsed['host'] ), array( 'github.com', 'www.github.com' ), true ) ) {
            $url_path = isset( $parsed['path'] ) ? trim( rawurldecode( $parsed['path'] ), '/' ) : '';
            $segments = '' === $url_path ? array() : explode( '/', $url_path );

            if (
                count( $segments ) >= 2 &&
                0 === strcasecmp( $segments[0], $owner ) &&
                0 === strcasecmp( $segments[1], $repo )
            ) {
                if ( 2 === count( $segments ) ) {
                    return array(
                        'branch' => $target_branch,
                        'path'   => '',
                    );
                }

                if ( isset( $segments[2] ) && in_array( $segments[2], array( 'blob', 'tree' ), true ) ) {
                    $rest = implode( '/', array_slice( $segments, 3 ) );

                    foreach ( $branch_names as $known_branch ) {
                        if ( $rest === $known_branch ) {
                            return array(
                                'branch' => $known_branch,
                                'path'   => '',
                            );
                        }

                        $prefix = $known_branch . '/';
                        if ( 0 === strpos( $rest, $prefix ) ) {
                            return array(
                                'branch' => $known_branch,
                                'path'   => substr( $rest, strlen( $prefix ) ),
                            );
                        }
                    }

                    // Fallback for ordinary one-segment branch names if GitHub's branch list is unavailable.
                    if ( '' !== $rest ) {
                        $rest_parts = explode( '/', $rest, 2 );
                        return array(
                            'branch' => $rest_parts[0],
                            'path'   => isset( $rest_parts[1] ) ? $rest_parts[1] : '',
                        );
                    }
                }
            }

            return null;
        }

        // Relative links in a README/file belong to the current repository and branch.
        if ( ! preg_match( '#^[a-z][a-z0-9+.-]*://#i', $href ) && 0 !== strpos( $href, '//' ) ) {
            $path = self::normalize_relative_path( $current_file, $href );
            return array(
                'branch' => $target_branch,
                'path'   => $path,
            );
        }

        return null;
    }

    private static function rewrite_markdown_links_without_dom( $html, $owner, $repo, $branch, $current_file, $branch_names ) {
        return preg_replace_callback(
            '/<a\b[^>]*\bhref\s*=\s*(?:"([^"]*)"|\'([^\']*)\')[^>]*>/i',
            function ( $matches ) use ( $owner, $repo, $branch, $current_file, $branch_names ) {
                $tag  = $matches[0];
                $href = isset( $matches[1] ) && '' !== $matches[1] ? $matches[1] : ( isset( $matches[2] ) ? $matches[2] : '' );
                $target = self::get_internal_markdown_target( $href, $owner, $repo, $branch, $current_file, $branch_names );

                if ( is_array( $target ) ) {
                    $tag = preg_replace( '/\s+(?:target|rel|data-cmgc-path|data-cmgc-branch)\s*=\s*(?:"[^"]*"|\'[^\']*\')/i', '', $tag );
                    $tag = preg_replace( '/\bhref\s*=\s*(?:"[^"]*"|\'[^\']*\')/i', 'href="#"', $tag, 1 );

                    if ( preg_match( '/\bclass\s*=\s*"([^"]*)"/i', $tag, $class_match ) ) {
                        $classes = trim( $class_match[1] . ' cmgc-nav-link' );
                        $tag = preg_replace( '/\bclass\s*=\s*"[^"]*"/i', 'class="' . esc_attr( $classes ) . '"', $tag, 1 );
                    } elseif ( preg_match( '/\bclass\s*=\s*\'([^\']*)\'/i', $tag, $class_match ) ) {
                        $classes = trim( $class_match[1] . ' cmgc-nav-link' );
                        $tag = preg_replace( '/\bclass\s*=\s*\'[^\']*\'/i', 'class="' . esc_attr( $classes ) . '"', $tag, 1 );
                    } else {
                        $tag = preg_replace( '/>$/', ' class="cmgc-nav-link">', $tag, 1 );
                    }

                    $attrs = ' data-cmgc-path="' . esc_attr( trim( $target['path'], '/' ) ) . '" data-cmgc-branch="' . esc_attr( $target['branch'] ) . '"';
                    $tag = preg_replace( '/>$/', $attrs . '>', $tag, 1 );
                    return $tag;
                }

                // Preserve the existing external-link behaviour.
                $tag = preg_replace( '/\s+(?:target|rel)\s*=\s*(?:"[^"]*"|\'[^\']*\')/i', '', $tag );
                $tag = preg_replace( '/>$/', ' target="_blank" rel="noopener noreferrer">', $tag, 1 );
                return $tag;
            },
            $html
        );
    }

    private static function rewrite_markdown_links( $html, $owner, $repo, $branch, $current_file ) {
        $branch_names = array( (string) $branch );
        $branch_items = CMGC_API::get_branches( $owner, $repo );
        if ( ! is_wp_error( $branch_items ) && is_array( $branch_items ) ) {
            foreach ( $branch_items as $branch_item ) {
                if ( ! empty( $branch_item['name'] ) ) {
                    $branch_names[] = (string) $branch_item['name'];
                }
            }
        }
        $branch_names = array_values( array_unique( array_filter( $branch_names ) ) );
        usort(
            $branch_names,
            function ( $a, $b ) {
                return strlen( $b ) - strlen( $a );
            }
        );

        // Some WordPress hosts do not have the PHP DOM extension enabled.
        // Use a safe anchor-tag fallback so internal repository links still work.
        if ( ! class_exists( 'DOMDocument' ) ) {
            return self::rewrite_markdown_links_without_dom( $html, $owner, $repo, $branch, $current_file, $branch_names );
        }

        $previous = libxml_use_internal_errors( true );
        $dom = new DOMDocument( '1.0', 'UTF-8' );
        $wrapped = '<!doctype html><html><body><div id="cmgc-root">' . $html . '</div></body></html>';
        $dom->loadHTML( '<?xml encoding="utf-8" ?>' . $wrapped, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
        $xpath = new DOMXPath( $dom );
        $links = $xpath->query( '//div[@id="cmgc-root"]//a[@href]' );

        if ( $links ) {
            foreach ( $links as $link ) {
                $href   = html_entity_decode( $link->getAttribute( 'href' ) );
                $target = self::get_internal_markdown_target( $href, $owner, $repo, $branch, $current_file, $branch_names );

                if ( is_array( $target ) ) {
                    $link->setAttribute( 'href', '#' );
                    $link->setAttribute( 'data-cmgc-path', trim( $target['path'], '/' ) );
                    $link->setAttribute( 'data-cmgc-branch', $target['branch'] );
                    $link->setAttribute( 'class', trim( $link->getAttribute( 'class' ) . ' cmgc-nav-link' ) );
                    $link->removeAttribute( 'target' );
                    $link->removeAttribute( 'rel' );
                } elseif ( '' !== $href && 0 !== strpos( $href, '#' ) && 0 !== strpos( $href, 'mailto:' ) && 0 !== strpos( $href, 'tel:' ) ) {
                    $link->setAttribute( 'target', '_blank' );
                    $link->setAttribute( 'rel', 'noopener noreferrer' );
                }
            }
        }

        $root = $dom->getElementById( 'cmgc-root' );
        $output = '';
        if ( $root ) {
            foreach ( $root->childNodes as $child ) {
                $output .= $dom->saveHTML( $child );
            }
        } else {
            $output = $html;
        }

        libxml_clear_errors();
        libxml_use_internal_errors( $previous );
        return $output;
    }

}
