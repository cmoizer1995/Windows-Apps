<?php
/**
 * AJAX Handlers
 */

namespace GitHub_Repo_Selector;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AJAX_Handler {
	public static function init() {
		add_action( 'wp_ajax_fetch_github_repos', [ __CLASS__, 'fetch_github_repos' ] );
		add_action( 'wp_ajax_github_repo_selector_update_cache', [ __CLASS__, 'fetch_github_repos' ] );
		add_action( 'wp_ajax_github_repo_selector_dashboard_action', [ __CLASS__, 'dashboard_action' ] );
		add_action( 'wp_ajax_fetch_github_repo_readme', [ __CLASS__, 'fetch_github_repo_readme' ] );
		add_action( 'wp_ajax_github_repo_selector_load_readme_for_edit', [ __CLASS__, 'load_readme_for_edit' ] );
		add_action( 'wp_ajax_github_repo_selector_load_files_for_delete', [ __CLASS__, 'load_files_for_delete' ] );
		add_action( 'wp_ajax_nopriv_fetch_github_repo_readme', [ __CLASS__, 'fetch_github_repo_readme' ] );
	}

	public static function fetch_github_repos() {
		// Security check
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				[
					'message' => __( 'Insufficient permissions', 'github-repo-selector' ),
				],
				403
			);
		}

		// Verify nonce
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
		if ( ! wp_verify_nonce( $nonce, 'github_repo_selector_nonce' ) ) {
			wp_send_json_error(
				[
					'message' => __( 'Security check failed', 'github-repo-selector' ),
				],
				403
			);
		}

		// Fetch repositories for the GitHub account connected to the saved token.
		$api = new GitHub_API();
		$username = $api->get_authenticated_username();

		if ( empty( $username ) ) {
			wp_send_json_error(
				[
					'message' => __( 'No GitHub account found from the saved token. Add a valid token in Settings > GitHub Repo Selector.', 'github-repo-selector' ),
				]
			);
		}

		$api->clear_cache( '', '', false );
		$refresh = $api->refresh_repositories_and_branches( $username );
		$repos = $refresh['repos'];

		if ( empty( $repos ) || ! is_array( $repos ) ) {
			wp_send_json_error(
				[
					'message' => __( 'No repositories found or error fetching repositories. Check that the token has repository Contents read access.', 'github-repo-selector' ),
				]
			);
		}

		// Save repo names so dashboard write tools have current options.
		$repo_options = Settings::save_repo_options_from_repos( $repos );

		// v1.0.30.72: the same refresh also feeds the newer CM GitHub Connector
		// used by View → GitHub and Elementor.
		if ( class_exists( '\CMGC_Admin' ) ) {
			$cmgc_catalog = [];
			foreach ( $repos as $repo_item ) {
				if ( empty( $repo_item['name'] ) ) continue;
				$owner = ! empty( $repo_item['owner']['login'] ) ? $repo_item['owner']['login'] : $username;
				$cmgc_catalog[] = [
					'full_name'      => $owner . '/' . $repo_item['name'],
					'owner'          => $owner,
					'name'           => $repo_item['name'],
					'default_branch' => ! empty( $repo_item['default_branch'] ) ? $repo_item['default_branch'] : 'main',
					'private'        => ! empty( $repo_item['private'] ),
					'description'    => isset( $repo_item['description'] ) ? (string) $repo_item['description'] : '',
				];
			}
			update_option( \CMGC_Admin::OPTION_CATALOG, $cmgc_catalog, false );
			$cmgc_options = \CMGC_Admin::get_options();
			$cmgc_options['default_owner'] = $username;
			update_option( \CMGC_Admin::OPTION_SETTINGS, $cmgc_options, false );
			if ( class_exists( '\CMGC_API' ) ) \CMGC_API::flush_cache();
		}

		// Format response
		$formatted_repos = [];
		foreach ( $repos as $repo ) {
			$formatted_repos[] = [
				'name' => $repo['name'],
				'description' => $repo['description'] ?? '',
				'url' => $repo['html_url'],
				'stars' => $repo['stargazers_count'],
				'language' => $repo['language'] ?? 'Unknown',
			];
		}


		wp_send_json_success(
			[
				'repos' => $formatted_repos,
				'count' => count( $formatted_repos ),
				'branch_count' => isset( $refresh['branch_count'] ) ? (int) $refresh['branch_count'] : 0,
				'branches_by_repo' => isset( $refresh['branches_by_repo'] ) ? $refresh['branches_by_repo'] : [],
				'username' => $username,
				'options'  => $repo_options,
			]
		);
	}


	public static function dashboard_action() {
		if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'GitHub management is restricted to WordPress administrators.', 'github-repo-selector' ) ], 403 );
		}

		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
		if ( ! wp_verify_nonce( $nonce, 'github_repo_selector_nonce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Security check failed.', 'github-repo-selector' ) ], 403 );
		}

		$api = new GitHub_API();
		$username = $api->get_authenticated_username();

		if ( empty( $username ) ) {
			wp_send_json_error( [ 'message' => __( 'No GitHub account found from the saved token.', 'github-repo-selector' ) ] );
		}

		$github_action = isset( $_POST['github_action'] ) ? sanitize_text_field( wp_unslash( $_POST['github_action'] ) ) : '';
		$repo = isset( $_POST['repo'] ) ? sanitize_text_field( wp_unslash( $_POST['repo'] ) ) : '';
		$branch = isset( $_POST['branch'] ) ? sanitize_text_field( wp_unslash( $_POST['branch'] ) ) : '';
		$source_branch = isset( $_POST['source_branch'] ) ? sanitize_text_field( wp_unslash( $_POST['source_branch'] ) ) : '';
		$description = isset( $_POST['description'] ) ? sanitize_text_field( wp_unslash( $_POST['description'] ) ) : '';
		$file_path = isset( $_POST['file_path'] ) ? sanitize_text_field( wp_unslash( $_POST['file_path'] ) ) : '';
		$file_content = isset( $_POST['file_content'] ) ? sanitize_textarea_field( wp_unslash( $_POST['file_content'] ) ) : '';
		$commit_message = isset( $_POST['commit_message'] ) ? sanitize_text_field( wp_unslash( $_POST['commit_message'] ) ) : '';
		$file_to_delete = isset( $_POST['file_to_delete'] ) ? sanitize_text_field( wp_unslash( $_POST['file_to_delete'] ) ) : '';

		switch ( $github_action ) {
			case 'create_repo':
				$result = $api->create_repository( $repo, $description, false );
				$success_message = __( 'Repository created on GitHub.', 'github-repo-selector' );
				break;

			case 'create_branch':
				$result = $api->create_branch( $username, $repo, $branch, $source_branch );
				$success_message = __( 'Branch created on GitHub.', 'github-repo-selector' );
				break;

			case 'delete_branch':
				$result = $api->delete_branch( $username, $repo, $branch );
				$success_message = __( 'Branch deleted from GitHub.', 'github-repo-selector' );
				break;

			case 'delete_repo':
				$result = $api->delete_repository( $username, $repo );
				$success_message = __( 'Repository deleted from GitHub.', 'github-repo-selector' );
				break;

			case 'delete_file':
				$result = $api->delete_file( $username, $repo, $file_to_delete, $branch, $commit_message );
				$success_message = __( 'File deleted from GitHub.', 'github-repo-selector' );
				break;

			case 'create_file':
				$result = $api->put_file_contents( $username, $repo, $file_path, $file_content, $branch, $commit_message );
				$success_message = __( 'File created or updated on GitHub.', 'github-repo-selector' );
				break;

			case 'upload_file':
				if ( empty( $_FILES['github_file_upload'] ) || ! is_uploaded_file( $_FILES['github_file_upload']['tmp_name'] ) ) {
					wp_send_json_error( [ 'message' => __( 'No file was uploaded.', 'github-repo-selector' ) ] );
				}

				$uploaded_file = $_FILES['github_file_upload'];
				$max_size = 10 * 1024 * 1024;

				if ( ! empty( $uploaded_file['size'] ) && $uploaded_file['size'] > $max_size ) {
					wp_send_json_error( [ 'message' => __( 'File is too large. Maximum size is 10MB.', 'github-repo-selector' ) ] );
				}

				$filename = sanitize_file_name( $uploaded_file['name'] );
				$target_path = ! empty( $file_path ) ? $file_path : $filename;
				if ( substr( $target_path, -1 ) === '/' ) {
					$target_path .= $filename;
				}

				$file_body = file_get_contents( $uploaded_file['tmp_name'] );
				$result = $api->put_file_contents( $username, $repo, $target_path, $file_body, $branch, $commit_message );
				$success_message = __( 'File uploaded to GitHub.', 'github-repo-selector' );
				break;

			default:
				wp_send_json_error( [ 'message' => __( 'Unknown GitHub dashboard action.', 'github-repo-selector' ) ] );
		}

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( [ 'message' => $result->get_error_message() ] );
		}

		if ( in_array( $github_action, [ 'delete_repo', 'delete_branch', 'delete_file' ], true ) ) {
			delete_option( 'github_repo_selector_latest_edit_url' );
		} elseif ( ! empty( $repo ) ) {
			$github_latest_url = 'https://github.com/' . rawurlencode( $username ) . '/' . rawurlencode( $repo );
			if ( ! empty( $branch ) ) {
				$github_latest_url .= '/tree/' . implode( '/', array_map( 'rawurlencode', explode( '/', $branch ) ) );
			}
			update_option( 'github_repo_selector_latest_edit_url', esc_url_raw( $github_latest_url ), false );
		}

		$refresh = $api->refresh_repositories_and_branches( $username );
		Settings::save_repo_options_from_repos( $refresh['repos'] );

		wp_send_json_success(
			[
				'message' => $success_message,
				'count' => isset( $refresh['repo_count'] ) ? (int) $refresh['repo_count'] : 0,
				'branch_count' => isset( $refresh['branch_count'] ) ? (int) $refresh['branch_count'] : 0,
				'username' => $username,
			]
		);
	}




	public static function load_files_for_delete() {
		if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'GitHub management is restricted to WordPress administrators.', 'github-repo-selector' ) ], 403 );
		}

		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
		if ( ! wp_verify_nonce( $nonce, 'github_repo_selector_nonce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Security check failed.', 'github-repo-selector' ) ], 403 );
		}

		$api = new GitHub_API();
		$username = $api->get_authenticated_username();
		$repo = isset( $_POST['repo'] ) ? sanitize_text_field( wp_unslash( $_POST['repo'] ) ) : '';
		$branch = isset( $_POST['branch'] ) ? sanitize_text_field( wp_unslash( $_POST['branch'] ) ) : '';

		if ( empty( $username ) || empty( $repo ) || empty( $branch ) ) {
			wp_send_json_error( [ 'message' => __( 'Select a repository and branch first.', 'github-repo-selector' ) ] );
		}

		$files = $api->get_repo_files( $username, $repo, $branch );

		wp_send_json_success( [ 'files' => $files ] );
	}


	public static function load_readme_for_edit() {
		if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'GitHub management is restricted to WordPress administrators.', 'github-repo-selector' ) ], 403 );
		}

		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
		if ( ! wp_verify_nonce( $nonce, 'github_repo_selector_nonce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Security check failed.', 'github-repo-selector' ) ], 403 );
		}

		$api = new GitHub_API();
		$username = $api->get_authenticated_username();
		$repo = isset( $_POST['repo'] ) ? sanitize_text_field( wp_unslash( $_POST['repo'] ) ) : '';
		$branch = isset( $_POST['branch'] ) ? sanitize_text_field( wp_unslash( $_POST['branch'] ) ) : '';

		if ( empty( $username ) || empty( $repo ) || empty( $branch ) ) {
			wp_send_json_error( [ 'message' => __( 'Select a repository and branch first.', 'github-repo-selector' ) ] );
		}

		$readme = $api->get_repo_readme( $username, $repo, $branch, true );

		$github_url = 'https://github.com/' . rawurlencode( $username ) . '/' . rawurlencode( $repo ) . '/tree/' . implode( '/', array_map( 'rawurlencode', explode( '/', $branch ) ) );
		update_option( 'github_repo_selector_latest_edit_url', esc_url_raw( $github_url ), false );

		wp_send_json_success(
			[
				'readme' => $readme,
				'title' => $repo,
				'github_url' => $github_url,
			]
		);
	}


	public static function fetch_github_repo_readme() {
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
		if ( ! empty( $nonce ) && ! wp_verify_nonce( $nonce, 'github_repo_selector_nonce' ) ) {
			wp_send_json_error( [ 'message' => __( 'Security check failed', 'github-repo-selector' ) ], 403 );
		}

		$owner  = isset( $_POST['owner'] ) ? sanitize_text_field( wp_unslash( $_POST['owner'] ) ) : '';
		$repo   = isset( $_POST['repo'] ) ? sanitize_text_field( wp_unslash( $_POST['repo'] ) ) : '';
		$branch = isset( $_POST['branch'] ) ? sanitize_text_field( wp_unslash( $_POST['branch'] ) ) : '';

		if ( empty( $owner ) || empty( $repo ) || empty( $branch ) ) {
			wp_send_json_error( [ 'message' => __( 'Missing repository or branch.', 'github-repo-selector' ) ] );
		}

		$api = new GitHub_API();
		$readme = $api->get_repo_readme( $owner, $repo, $branch );

		if ( '' === $readme ) {
			wp_send_json_error( [ 'message' => __( 'No README available for this branch.', 'github-repo-selector' ) ] );
		}

		wp_send_json_success( [ 'readme' => wp_kses_post( self::markdown_to_html( $readme ) ) ] );
	}

	private static function markdown_to_html( $markdown ) {
		$markdown = preg_replace( '/^### (.*?)$/m', '<h3>$1</h3>', $markdown );
		$markdown = preg_replace( '/^## (.*?)$/m', '<h2>$1</h2>', $markdown );
		$markdown = preg_replace( '/^# (.*?)$/m', '<h1>$1</h1>', $markdown );
		$markdown = preg_replace( '/\*\*(.*?)\*\*/', '<strong>$1</strong>', $markdown );
		$markdown = preg_replace( '/__(.+?)__/', '<strong>$1</strong>', $markdown );
		$markdown = preg_replace( '/`([^`]+)`/', '<code>$1</code>', $markdown );
		$markdown = preg_replace( '/\[(.*?)\]\((.*?)\)/', '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>', $markdown );
		return nl2br( $markdown );
	}
}

// Initialize AJAX handlers
AJAX_Handler::init();
