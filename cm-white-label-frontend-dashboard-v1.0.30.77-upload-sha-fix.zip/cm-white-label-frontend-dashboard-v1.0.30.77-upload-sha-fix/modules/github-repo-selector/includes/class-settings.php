<?php
/**
 * Settings Handler
 */

namespace GitHub_Repo_Selector;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Settings {
	public static function get_github_token() {
		return get_option( 'github_repo_selector_token', '' );
	}

	public static function has_github_token() {
		return ! empty( self::get_github_token() );
	}

	public static function get_settings_url() {
		if ( defined( 'CM_WL_DASHBOARD_BUNDLED_GITHUB' ) && CM_WL_DASHBOARD_BUNDLED_GITHUB ) {
			$root = is_multisite() ? network_home_url( '/' ) : home_url( '/' );
			return add_query_arg(
				[
					'cm_wlfd' => 1,
					'view'    => 'github',
				],
				$root
			);
		}

		return admin_url( 'options-general.php?page=github-repo-selector' );
	}

	public static function get_saved_repo_options() {
		$options = get_option( 'github_repo_selector_repo_options', [] );
		return is_array( $options ) ? $options : [];
	}

	/**
	 * Repository options available to Content -> GitHub.
	 *
	 * The dashboard exclusion list is intentionally applied here rather than
	 * deleting repositories from the cache. Unticking an exclusion therefore
	 * makes the repository available again immediately.
	 */
	public static function get_content_repo_options() {
		$options = self::get_saved_repo_options();
		$excluded = get_option( 'cm_wlfd_github_view_excluded_repos', [] );

		if ( empty( $options ) || ! is_array( $excluded ) || empty( $excluded ) ) {
			return $options;
		}

		$excluded_full  = [];
		$excluded_short = [];
		foreach ( $excluded as $excluded_repo ) {
			$excluded_repo = strtolower( trim( (string) $excluded_repo ) );
			if ( '' === $excluded_repo ) {
				continue;
			}
			$excluded_full[ $excluded_repo ] = true;
			$parts = explode( '/', $excluded_repo );
			$short = strtolower( trim( (string) end( $parts ) ) );
			if ( '' !== $short ) {
				$excluded_short[ $short ] = true;
			}
		}

		$username = strtolower( trim( (string) get_option( 'github_repo_selector_connected_username', '' ) ) );
		$visible  = [];

		foreach ( $options as $repo_key => $repo_label ) {
			$key   = strtolower( trim( (string) $repo_key ) );
			$label = strtolower( trim( (string) $repo_label ) );
			$parts = explode( '/', $key );
			$short = strtolower( trim( (string) end( $parts ) ) );
			$owner_key = ( '' !== $username && '' !== $short ) ? $username . '/' . $short : '';

			if ( isset( $excluded_full[ $key ] ) || isset( $excluded_full[ $label ] ) ||
				( '' !== $owner_key && isset( $excluded_full[ $owner_key ] ) ) ||
				( '' !== $short && isset( $excluded_short[ $short ] ) ) ) {
				continue;
			}

			$visible[ $repo_key ] = $repo_label;
		}

		return $visible;
	}

	public static function save_repo_options_from_repos( $repos ) {
		$options = [];

		if ( is_array( $repos ) ) {
			foreach ( $repos as $repo ) {
				if ( empty( $repo['name'] ) ) {
					continue;
				}

				$options[ $repo['name'] ] = $repo['name'];
			}
		}

		update_option( 'github_repo_selector_repo_options', $options, false );
		update_option( 'github_repo_selector_repo_cache_updated', current_time( 'mysql' ), false );
		return $options;
	}

	public static function get_saved_branch_options() {
		$options = get_option( 'github_repo_selector_branch_options', [] );
		return is_array( $options ) ? $options : [];
	}
}
