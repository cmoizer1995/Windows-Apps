<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CM_WL_CMGC_API {
    const API_ROOT = 'https://api.github.com';
    const API_VERSION = '2026-03-10';

    public static function get_token() {
        if ( defined( 'CMGC_GITHUB_TOKEN' ) && CMGC_GITHUB_TOKEN ) {
            return trim( (string) CMGC_GITHUB_TOKEN );
        }

        $options = CM_WL_CMGC_Admin::get_options();
        $token = isset( $options['token'] ) ? trim( (string) $options['token'] ) : '';
        if ( ! $token && defined( 'CM_WL_DASHBOARD_BUNDLED_CMGC' ) && CM_WL_DASHBOARD_BUNDLED_CMGC ) {
            $token = trim( (string) get_option( 'github_repo_selector_token', '' ) );
        }
        return $token;
    }

    public static function cache_ttl() {
        $options = CM_WL_CMGC_Admin::get_options();
        $minutes = isset( $options['cache_minutes'] ) ? absint( $options['cache_minutes'] ) : 10;
        return max( 1, min( 1440, $minutes ) ) * MINUTE_IN_SECONDS;
    }

    private static function headers( $accept = 'application/vnd.github+json' ) {
        $headers = array(
            'Accept'               => $accept,
            'X-GitHub-Api-Version' => self::API_VERSION,
            'User-Agent'           => 'CM-GitHub-Connector/' . CM_WL_CMGC_VERSION . '; ' . home_url( '/' ),
        );

        $token = self::get_token();
        if ( $token ) {
            $headers['Authorization'] = 'Bearer ' . $token;
        }

        return $headers;
    }

    private static function cache_key( $url, $accept ) {
        $token_fingerprint = self::get_token() ? substr( hash( 'sha256', self::get_token() ), 0, 12 ) : 'anon';
        return 'cmgc_' . md5( $url . '|' . $accept . '|' . $token_fingerprint );
    }

    private static function remember_cache_key( $key ) {
        $keys = get_option( 'cmgc_cache_keys', array() );
        if ( ! is_array( $keys ) ) {
            $keys = array();
        }
        if ( ! in_array( $key, $keys, true ) ) {
            $keys[] = $key;
            if ( count( $keys ) > 1000 ) {
                $keys = array_slice( $keys, -1000 );
            }
            update_option( 'cmgc_cache_keys', $keys, false );
        }
    }

    public static function flush_cache() {
        $keys = get_option( 'cmgc_cache_keys', array() );
        if ( is_array( $keys ) ) {
            foreach ( $keys as $key ) {
                delete_transient( $key );
            }
        }
        delete_option( 'cmgc_cache_keys' );
    }

    private static function request( $endpoint, $accept = 'application/vnd.github+json', $force = false ) {
        $url = self::API_ROOT . $endpoint;
        $key = self::cache_key( $url, $accept );

        if ( ! $force ) {
            $cached = get_transient( $key );
            if ( false !== $cached ) {
                return $cached;
            }
        }

        $response = wp_remote_get(
            $url,
            array(
                'headers'     => self::headers( $accept ),
                'timeout'     => 20,
                'redirection' => 3,
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $status = (int) wp_remote_retrieve_response_code( $response );
        $body   = (string) wp_remote_retrieve_body( $response );
        $result = array(
            'status'  => $status,
            'body'    => $body,
            'headers' => wp_remote_retrieve_headers( $response ),
        );

        if ( $status >= 200 && $status < 300 ) {
            set_transient( $key, $result, self::cache_ttl() );
            self::remember_cache_key( $key );
        }

        return $result;
    }

    private static function decode_json_result( $result ) {
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        $data = json_decode( $result['body'], true );
        if ( $result['status'] < 200 || $result['status'] >= 300 ) {
            $message = is_array( $data ) && ! empty( $data['message'] ) ? $data['message'] : 'GitHub API request failed.';
            return new WP_Error( 'cmgc_github_api', $message, array( 'status' => $result['status'] ) );
        }

        if ( null === $data && JSON_ERROR_NONE !== json_last_error() ) {
            return new WP_Error( 'cmgc_invalid_json', 'GitHub returned an unexpected response.' );
        }

        return $data;
    }

    public static function get_authenticated_user( $force = false ) {
        if ( ! self::get_token() ) {
            return new WP_Error( 'cmgc_no_token', 'Save a GitHub Personal Access Token first.' );
        }
        return self::decode_json_result( self::request( '/user', 'application/vnd.github+json', $force ) );
    }

    public static function get_repo( $owner, $repo, $force = false ) {
        $endpoint = '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo );
        return self::decode_json_result( self::request( $endpoint, 'application/vnd.github+json', $force ) );
    }

    public static function get_branches( $owner, $repo, $force = false ) {
        $endpoint = '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/branches?per_page=100';
        return self::decode_json_result( self::request( $endpoint, 'application/vnd.github+json', $force ) );
    }

    public static function get_contents( $owner, $repo, $path = '', $branch = '', $force = false ) {
        $path = trim( (string) $path, '/' );
        $endpoint = '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/contents';
        if ( '' !== $path ) {
            $segments = array_map( 'rawurlencode', explode( '/', $path ) );
            $endpoint .= '/' . implode( '/', $segments );
        }
        if ( $branch ) {
            $endpoint .= '?ref=' . rawurlencode( $branch );
        }
        return self::decode_json_result( self::request( $endpoint, 'application/vnd.github+json', $force ) );
    }

    public static function get_rendered_markdown( $owner, $repo, $path, $branch = '', $force = false ) {
        $path = trim( (string) $path, '/' );
        $endpoint = '/repos/' . rawurlencode( $owner ) . '/' . rawurlencode( $repo ) . '/contents';
        if ( '' !== $path ) {
            $segments = array_map( 'rawurlencode', explode( '/', $path ) );
            $endpoint .= '/' . implode( '/', $segments );
        }
        if ( $branch ) {
            $endpoint .= '?ref=' . rawurlencode( $branch );
        }

        $result = self::request( $endpoint, 'application/vnd.github.html+json', $force );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        if ( $result['status'] < 200 || $result['status'] >= 300 ) {
            $decoded = json_decode( $result['body'], true );
            $message = is_array( $decoded ) && ! empty( $decoded['message'] ) ? $decoded['message'] : 'Unable to render Markdown.';
            return new WP_Error( 'cmgc_markdown', $message );
        }

        $decoded = json_decode( $result['body'], true );
        return is_string( $decoded ) ? $decoded : $result['body'];
    }

    /**
     * Returns repositories visible to the saved token. If no token exists, it
     * returns public repositories for the configured default owner.
     */
    public static function get_repository_catalog( $force = false ) {
        $repos = array();
        $token = self::get_token();
        $options = CM_WL_CMGC_Admin::get_options();

        if ( $token ) {
            for ( $page = 1; $page <= 10; $page++ ) {
                $endpoint = '/user/repos?per_page=100&page=' . $page . '&sort=full_name&direction=asc';
                $batch = self::decode_json_result( self::request( $endpoint, 'application/vnd.github+json', $force ) );
                if ( is_wp_error( $batch ) ) {
                    return $batch;
                }
                if ( ! is_array( $batch ) || empty( $batch ) ) {
                    break;
                }
                $repos = array_merge( $repos, $batch );
                if ( count( $batch ) < 100 ) {
                    break;
                }
            }
        } elseif ( ! empty( $options['default_owner'] ) ) {
            for ( $page = 1; $page <= 10; $page++ ) {
                $endpoint = '/users/' . rawurlencode( $options['default_owner'] ) . '/repos?per_page=100&page=' . $page . '&sort=full_name&direction=asc&type=owner';
                $batch = self::decode_json_result( self::request( $endpoint, 'application/vnd.github+json', $force ) );
                if ( is_wp_error( $batch ) ) {
                    return $batch;
                }
                if ( ! is_array( $batch ) || empty( $batch ) ) {
                    break;
                }
                $repos = array_merge( $repos, $batch );
                if ( count( $batch ) < 100 ) {
                    break;
                }
            }
        }

        $catalog = array();
        foreach ( $repos as $repo ) {
            if ( empty( $repo['name'] ) || empty( $repo['owner']['login'] ) ) {
                continue;
            }
            $full_name = $repo['owner']['login'] . '/' . $repo['name'];
            $catalog[ strtolower( $full_name ) ] = array(
                'full_name'      => $full_name,
                'owner'          => $repo['owner']['login'],
                'name'           => $repo['name'],
                'default_branch' => ! empty( $repo['default_branch'] ) ? $repo['default_branch'] : 'main',
                'private'        => ! empty( $repo['private'] ),
                'description'    => isset( $repo['description'] ) ? (string) $repo['description'] : '',
            );
        }

        uasort(
            $catalog,
            function ( $a, $b ) {
                return strcasecmp( $a['full_name'], $b['full_name'] );
            }
        );

        return array_values( $catalog );
    }

    public static function get_rate_limit( $force = false ) {
        return self::decode_json_result( self::request( '/rate_limit', 'application/vnd.github+json', $force ) );
    }
}
