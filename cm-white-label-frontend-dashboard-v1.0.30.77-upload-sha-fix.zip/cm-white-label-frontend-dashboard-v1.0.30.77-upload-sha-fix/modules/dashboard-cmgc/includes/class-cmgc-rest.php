<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CM_WL_CMGC_REST {
    public static function init() {
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
    }

    public static function register_routes() {
        register_rest_route(
            'cm-wlfd-github/v1',
            '/browse',
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( __CLASS__, 'browse' ),
                'permission_callback' => '__return_true',
                'args'                => array(
                    'owner'     => array( 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
                    'repo'      => array( 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
                    'branch'    => array( 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ),
                    'path'      => array( 'required' => false, 'sanitize_callback' => array( __CLASS__, 'sanitize_path' ) ),
                    'access'    => array( 'required' => true, 'sanitize_callback' => 'sanitize_key' ),
                    'signature' => array( 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
                ),
            )
        );
    }

    public static function sanitize_path( $path ) {
        $path = str_replace( array( "\0", "\\" ), array( '', '/' ), (string) $path );
        $parts = array();
        foreach ( explode( '/', trim( $path, '/' ) ) as $part ) {
            if ( '' === $part || '.' === $part ) {
                continue;
            }
            if ( '..' === $part ) {
                array_pop( $parts );
                continue;
            }
            $parts[] = sanitize_text_field( rawurldecode( $part ) );
        }
        return implode( '/', $parts );
    }

    public static function browse( WP_REST_Request $request ) {
        $owner = $request->get_param( 'owner' );
        $repo = $request->get_param( 'repo' );
        $branch = $request->get_param( 'branch' );
        $path = $request->get_param( 'path' );
        $requested_access = $request->get_param( 'access' );
        $access = in_array( $requested_access, array( 'logged_in', 'dashboard' ), true ) ? $requested_access : 'public';
        $signature = $request->get_param( 'signature' );

        if ( ! CM_WL_CMGC_Renderer::verify_signature( $owner, $repo, $access, $signature ) ) {
            return new WP_Error( 'cmgc_invalid_instance', 'This repository browser instance is not valid.', array( 'status' => 403 ) );
        }

        // Normal embeds can still require a live WordPress login. Dashboard embeds
        // use a separate HMAC-signed access mode because some mobile/Safari REST
        // requests do not reliably restore the WP auth cookie even though the
        // dashboard page itself was rendered for an authenticated administrator.
        if ( 'logged_in' === $access && ! is_user_logged_in() ) {
            return new WP_Error( 'cmgc_login_required', 'You must be logged in to view this repository.', array( 'status' => 401 ) );
        }

        $html = CM_WL_CMGC_Renderer::render_path( $owner, $repo, $branch, $path, false );

        $response = rest_ensure_response(
            array(
                'html'   => $html,
                'path'   => $path,
                'branch' => $branch,
            )
        );
        $response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0' );
        return $response;
    }
}
