(function () {
    'use strict';

    function initBrowser(browser) {
        if (!browser || browser.dataset.cmgcReady === '1') return;
        browser.dataset.cmgcReady = '1';

        const content = browser.querySelector('.cmgc-content');
        const loading = browser.querySelector('.cmgc-loading');
        const live = browser.querySelector('.cmgc-live-region');
        const branchMenu = browser.querySelector('.cmgc-branch-menu');
        const currentBranch = browser.querySelector('.cmgc-current-branch');
        const endpoint = browser.dataset.endpoint || '';

        if (!content || !endpoint) return;

        async function browse(path) {
            const params = new URLSearchParams({
                owner: browser.dataset.owner || '',
                repo: browser.dataset.repo || '',
                branch: browser.dataset.branch || '',
                path: path || '',
                access: browser.dataset.access || 'public',
                signature: browser.dataset.signature || ''
            });

            browser.classList.add('is-loading');
            if (loading) loading.hidden = false;
            if (live) live.textContent = 'Loading repository content';

            try {
                const response = await fetch(endpoint + '?' + params.toString(), {
                    method: 'GET',
                    credentials: 'include',
                    headers: { 'Accept': 'application/json', 'X-WP-Nonce': browser.dataset.restNonce || '' }
                });
                const data = await response.json();
                if (!response.ok) {
                    throw new Error((data && data.message) ? data.message : 'Unable to load GitHub content.');
                }
                content.innerHTML = data.html || '';
                browser.dataset.path = data.path || '';
                if (live) live.textContent = 'Repository content updated';
                content.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            } catch (error) {
                content.innerHTML = '<div class="cmgc-error"></div>';
                const errorBox = content.querySelector('.cmgc-error');
                if (errorBox) errorBox.textContent = error.message || 'Unable to load GitHub content.';
                if (live) live.textContent = 'Repository content failed to load';
            } finally {
                browser.classList.remove('is-loading');
                if (loading) loading.hidden = true;
            }
        }

        function setBranch(branch) {
            if (!branch) return;

            browser.dataset.branch = branch;
            if (currentBranch) currentBranch.textContent = branch;

            browser.querySelectorAll('.cmgc-branch-option').forEach(function (item) {
                const selected = item.getAttribute('data-cmgc-branch') === branch;
                item.classList.toggle('is-current', selected);
                const check = item.querySelector('.cmgc-branch-check');
                if (check) check.textContent = selected ? '✓' : '';
            });

            if (branchMenu) branchMenu.removeAttribute('open');
        }

        function selectBranch(button) {
            const branch = button.getAttribute('data-cmgc-branch') || '';
            if (!branch) return;

            setBranch(branch);
            browser.dataset.path = '';
            browse('');
        }

        browser.addEventListener('click', function (event) {
            const branchOption = event.target.closest('.cmgc-branch-option[data-cmgc-branch]');
            if (branchOption && browser.contains(branchOption)) {
                event.preventDefault();
                selectBranch(branchOption);
                return;
            }

            const nav = event.target.closest('.cmgc-nav-link[data-cmgc-path]');
            if (nav && browser.contains(nav)) {
                event.preventDefault();

                const targetBranch = nav.getAttribute('data-cmgc-branch') || browser.dataset.branch || '';
                const targetPath = nav.getAttribute('data-cmgc-path') || '';

                if (targetBranch && targetBranch !== (browser.dataset.branch || '')) {
                    setBranch(targetBranch);
                }

                browse(targetPath);
                return;
            }

            const refresh = event.target.closest('.cmgc-refresh-button');
            if (refresh && browser.contains(refresh)) {
                event.preventDefault();
                browse(browser.dataset.path || '');
            }
        });
    }

    function initAll(root) {
        (root || document).querySelectorAll('.cmgc-browser').forEach(initBrowser);
    }

    // Expose a tiny initializer so Content → GitHub can inject an internal
    // repository browser after an AJAX action and activate it immediately.
    window.CMWLInitGithubBrowsers = initAll;

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () { initAll(document); });
    } else {
        initAll(document);
    }

    if (window.jQuery) {
        window.jQuery(window).on('elementor/frontend/init', function () {
            if (window.elementorFrontend && elementorFrontend.hooks) {
                elementorFrontend.hooks.addAction('frontend/element_ready/cmgc_github_browser.default', function ($scope) {
                    initAll($scope && $scope[0] ? $scope[0] : document);
                });
            }
        });
    }
})();
