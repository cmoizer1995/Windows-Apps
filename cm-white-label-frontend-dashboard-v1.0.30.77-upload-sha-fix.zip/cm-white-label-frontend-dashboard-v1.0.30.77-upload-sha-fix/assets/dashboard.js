jQuery(function($){
  $('#cm_pick_featured').on('click', function(e){
    e.preventDefault();
    var frame = wp.media({title:'Choose featured image', multiple:false, library:{type:'image'}});
    frame.on('select', function(){
      var img = frame.state().get('selection').first().toJSON();
      $('#cm_featured_id').val(img.id);
      $('#cm_featured_label').text(img.title || img.filename || 'Image selected');
    });
    frame.open();
  });
  $(document).on('click', '[data-cm-delete-confirm]', function(){ return true; });

  function cmIsInstalledPwa(){
    return window.matchMedia('(display-mode: standalone)').matches ||
      window.navigator.standalone === true ||
      document.documentElement.classList.contains('cm-installed-pwa');
  }

  // Inside the installed PWA, keep navigation in the existing app window.
  // Opening a named/new window on iOS displays Safari's sheet with an X button,
  // which makes dashboard pages look as though they have left the PWA.
  $(document).on('click', 'a[target="_blank"], a[data-cm-pwa-popup="1"], a.cm-pwa-popup', function(e){
    if (!cmIsInstalledPwa() || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    var href = this.href;
    if (!href || href.indexOf('javascript:') === 0 || href.indexOf('mailto:') === 0 || href.indexOf('tel:') === 0) return;
    e.preventDefault();
    window.location.assign(href);
  });

  $(document).on('submit', 'form[target], form[data-cm-pwa-popup-form="1"]', function(){
    if (!cmIsInstalledPwa()) return;
    this.removeAttribute('target');
    this.removeAttribute('data-cm-pwa-popup-form');
  });

  function cmOpenPwaPopup(url, name){
    var w = Math.min(window.screen.availWidth || 1200, 1180);
    var h = Math.min(window.screen.availHeight || 850, 820);
    var left = Math.max(0, ((window.screen.availWidth || w) - w) / 2);
    var top = Math.max(0, ((window.screen.availHeight || h) - h) / 2);
    var features = [
      'popup=yes',
      'width=' + Math.round(w),
      'height=' + Math.round(h),
      'left=' + Math.round(left),
      'top=' + Math.round(top),
      'menubar=no',
      'toolbar=no',
      'location=no',
      'status=no',
      'scrollbars=yes',
      'resizable=yes'
    ].join(',');
    var win = window.open(url || 'about:blank', name || 'cmWlfdPwaPopup', features);
    if (win) {
      try { win.focus(); } catch(e) {}
    }
    return win;
  }

  $(document).on('click', 'a[data-cm-pwa-popup="1"], a.cm-pwa-popup[target="_blank"]', function(e){
    var href = this.href;
    if (!href || href.indexOf('javascript:') === 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    if (cmIsInstalledPwa()) {
      e.preventDefault();
      window.location.assign(href);
      return;
    }
    var win = cmOpenPwaPopup(href, this.getAttribute('data-cm-popup-name') || 'cmWlfdPwaPopup');
    if (win) e.preventDefault();
  });

  $(document).on('submit', 'form[data-cm-pwa-popup-form="1"]', function(){
    cmOpenPwaPopup('about:blank', this.getAttribute('target') || 'cmWlfdPwaPopup');
  });

  $(document).on('click', 'button[name="cm_open_elementor"]', function(){
    var form = this.form;
    if (!form) return;
    if (cmIsInstalledPwa()) {
      form.removeAttribute('target');
      form.removeAttribute('data-cm-pwa-popup-form');
      return;
    }
    form.setAttribute('target', 'cmWlfdPwaPopup');
    form.setAttribute('data-cm-pwa-popup-form', '1');
    cmOpenPwaPopup('about:blank', 'cmWlfdPwaPopup');
  });

  $(document).on('click', 'button[name="cm_save_submit"]', function(){
    var form = this.form;
    if (!form) return;
    form.removeAttribute('target');
    form.removeAttribute('data-cm-pwa-popup-form');
  });

  $(document).on('submit', 'form[data-cm-refresh-origin="1"]', function(){
    // Keep opening Elementor in the new tab, but refresh the dashboard page we came from
    // so the newly-created page/template appears in the Elementor list afterwards.
    window.setTimeout(function(){ window.location.reload(); }, 900);
  });
  $(document).on('click', '.cm-condition-toggle', function(e){
    e.preventDefault();
    var id = $(this).attr('data-condition-target');
    $('.cm-condition-popup').not('#'+id).removeClass('is-open');
    $('#'+id).toggleClass('is-open');
  });
  $(document).on('click', '.cm-condition-close', function(e){
    e.preventDefault();
    $(this).closest('.cm-condition-popup').removeClass('is-open');
  });

  function cmAcfHumanValue($field){
    var v = '';
    var $input = $field.find('input:not([type="hidden"]):not([type="button"]):not([type="submit"]), textarea, select').filter(':visible').first();
    if ($input.length) {
      if ($input.is('select')) v = $input.find('option:selected').text();
      else v = $input.val();
    }
    return $.trim(v || '');
  }

  function cmAcfLabel($field){
    var label = $.trim($field.children('.acf-label').find('label').first().clone().children().remove().end().text() || '');
    return label.replace(/\s+/g, ' ');
  }

  function cmAcfRowSummary($row){
    var event = '', time = '';
    var parts = [];
    $row.find('> .acf-fields > .acf-field, > td.acf-fields > .acf-field, > .acf-field').each(function(){
      var $field = $(this);
      var name = String($field.data('name') || '').toLowerCase();
      var label = cmAcfLabel($field);
      var hay = (name + ' ' + label).toLowerCase();
      var value = cmAcfHumanValue($field);
      if (!value) return;
      if (!event && /(event|title|name|headline|match|fixture|update)/.test(hay)) event = value;
      if (!time && /(time|date|start|end|kick|publish|when)/.test(hay)) time = value;
      if (parts.length < 2 && !/(image|file|gallery|wysiwyg|content|body|text)/.test(hay)) parts.push(value);
    });
    if (!event && parts[0]) event = parts[0];
    if (!time && parts[1]) time = parts[1];
    if (!event) event = 'ACF update';
    var summary = '<strong>' + $('<div>').text(event).html() + '</strong>';
    if (time) summary += ' <span>' + $('<div>').text(time).html() + '</span>';
    return summary;
  }

  function cmAcfRefreshSummaries(){
    $('.cm-acf .acf-repeater .acf-row:not(.acf-clone)').each(function(){
      var $row = $(this);
      if (!$row.find('> .cm-acf-row-summary').length) {
        $row.prepend('<button type="button" class="cm-acf-row-summary" aria-expanded="true"></button>');
      }
      $row.find('> .cm-acf-row-summary').html(cmAcfRowSummary($row));
    });
  }

  function cmAcfSetRow($row, open){
    $row.toggleClass('cm-acf-collapsed', !open);
    $row.find('> .cm-acf-row-summary').attr('aria-expanded', open ? 'true' : 'false');
  }

  function cmAcfInit(){
    cmAcfRefreshSummaries();
    if ($('.cm-acf').data('cm-acf-saved') == 1) {
      $('.cm-acf .acf-repeater .acf-row:not(.acf-clone)').each(function(){ cmAcfSetRow($(this), false); });
    }
  }

  $(document).on('click', '.cm-acf-row-summary', function(e){
    e.preventDefault();
    var $row = $(this).closest('.acf-row');
    cmAcfSetRow($row, $row.hasClass('cm-acf-collapsed'));
  });

  $(document).on('click', '.cm-acf-open-all', function(e){
    e.preventDefault();
    $('.cm-acf .acf-repeater .acf-row:not(.acf-clone)').each(function(){ cmAcfSetRow($(this), true); });
  });

  $(document).on('click', '.cm-acf-close-all', function(e){
    e.preventDefault();
    cmAcfRefreshSummaries();
    $('.cm-acf .acf-repeater .acf-row:not(.acf-clone)').each(function(){ cmAcfSetRow($(this), false); });
  });

  $(document).on('input change', '.cm-acf input, .cm-acf textarea, .cm-acf select', function(){
    window.clearTimeout(window.cmAcfSummaryTimer);
    window.cmAcfSummaryTimer = window.setTimeout(cmAcfRefreshSummaries, 150);
  });

  if (window.acf && acf.addAction) {
    acf.addAction('append', function($el){
      window.setTimeout(function(){
        cmAcfRefreshSummaries();
        $el.find('.acf-row:not(.acf-clone)').each(function(){ cmAcfSetRow($(this), true); });
      }, 150);
    });
  }

  window.setTimeout(cmAcfInit, 450);

});

// v1.0.27 — live clock and active mobile menu positioning.
jQuery(function($){
  function pad(n){ return String(n).padStart(2, '0'); }
  function startClock(){
    var $clock = $('.cm-live-clock').first();
    if (!$clock.length) return;
    var raw = $clock.attr('data-cm-now');
    var base = raw ? new Date(raw) : new Date();
    if (isNaN(base.getTime())) base = new Date();
    var started = Date.now();
    function tick(){
      var d = new Date(base.getTime() + (Date.now() - started));
      $clock.text(pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()));
    }
    tick();
    window.setInterval(tick, 1000);
  }
  function keepActiveMenuVisible(){
    var nav = document.querySelector('.cm-wlfd-sidebar nav');
    var active = document.querySelector('.cm-wlfd-sidebar a.is-active');
    if (!nav || !active) return;
    window.setTimeout(function(){
      if (window.matchMedia('(max-width: 800px)').matches) {
        var left = active.offsetLeft - 14;
        nav.scrollTo({left:left, behavior:'auto'});
      }
    }, 80);
  }
  startClock();
  keepActiveMenuVisible();
});




/* v1.0.30.51 — Classic Editor media caption fallback + local pencil override support.
 * Media Library caption is used as the default when inserting an image.
 * The pencil/edit caption remains local to the post content and does NOT update the original attachment caption.
 */
jQuery(function($){
  function cmWlfdPlainText(value){
    return $('<div>').html(value || '').text();
  }
  function cmWlfdAttachmentCaption(attachment){
    if (!attachment) return '';
    var caption = attachment.caption || '';
    if (caption && typeof caption === 'object') caption = caption.rendered || caption.raw || '';
    return $.trim(cmWlfdPlainText(caption));
  }
  function cmWlfdLocalCaption(props, attachment){
    props = props || {};
    var local = $.trim(cmWlfdPlainText(props.caption || ''));
    if (local) return local;
    return cmWlfdAttachmentCaption(attachment);
  }
  function cmWlfdAttachmentId(attachment, props){
    return parseInt((attachment && attachment.id) || (props && props.attachment_id) || 0, 10) || 0;
  }
  function cmWlfdBuildCaptionedImage(props, attachment, originalHtml){
    var id = cmWlfdAttachmentId(attachment, props);
    if (!id || !originalHtml || originalHtml.indexOf('[caption') !== -1) return originalHtml;
    var caption = cmWlfdLocalCaption(props, attachment);
    if (!caption) return originalHtml;
    var width = parseInt(props && props.width, 10) || parseInt(attachment && attachment.width, 10) || '';
    var align = (props && props.align) ? String(props.align).replace(/[^a-z0-9_-]/ig, '') : '';
    var attrs = ' id="attachment_' + id + '"';
    if (align) attrs += ' align="align' + align + '"';
    if (width) attrs += ' width="' + width + '"';
    return '[caption' + attrs + ']' + originalHtml + ' ' + caption + '[/caption]';
  }
  function cmWlfdPatchMediaSend(){
    if (!window.wp || !wp.media || !wp.media.editor || !wp.media.editor.send || !wp.media.editor.send.attachment) return false;
    if (wp.media.editor.send.attachment.cmWlfdCaptionPatch) return true;
    var original = wp.media.editor.send.attachment;
    wp.media.editor.send.attachment = function(props, attachment){
      props = props || {};
      var localCaption = cmWlfdLocalCaption(props, attachment);
      if (!$.trim(cmWlfdPlainText(props.caption || '')) && localCaption) {
        // Fill only the local insert props. This never writes back to the Media Library attachment.
        props.caption = localCaption;
      }
      var html = original.call(this, props, attachment);
      return cmWlfdBuildCaptionedImage(props, attachment, html) || html;
    };
    wp.media.editor.send.attachment.cmWlfdCaptionPatch = true;
    return true;
  }
  if (!cmWlfdPatchMediaSend()) {
    var tries = 0;
    var timer = window.setInterval(function(){
      tries++;
      if (cmWlfdPatchMediaSend() || tries > 40) window.clearInterval(timer);
    }, 250);
  }
});

/* v1.0.30.50 — frontend media library attachment details editor */
jQuery(function($){
  function cmMediaEscape(s){ return $('<div>').text(s || '').html(); }
  function cmMediaSelect($card){
    if (!$card || !$card.length) return;
    var $wrap = $card.closest('[data-cm-media-browser]');
    $wrap.find('.cm-media-card').removeClass('is-selected').attr('aria-pressed','false');
    $card.addClass('is-selected').attr('aria-pressed','true');
    var id = $card.data('id') || '';
    $wrap.find('[data-cm-media-id]').val(id);
    $wrap.find('[data-cm-media-title]').val($card.data('title') || '');
    $wrap.find('[data-cm-media-caption]').val($card.data('caption') || '');
    $wrap.find('[data-cm-media-alt]').val($card.data('alt') || '');
    $wrap.find('[data-cm-media-description]').val($card.data('description') || '');
    $wrap.find('[data-cm-media-filename]').text($card.data('filename') || '');
    $wrap.find('[data-cm-media-date]').text($card.data('date') || '');
    $wrap.find('[data-cm-media-mime]').text($card.data('mime') || '');
    $wrap.find('[data-cm-media-url]').attr('href', $card.data('url') || '#');
    var $img = $card.find('img').first();
    var html = $img.length ? '<img src="' + cmMediaEscape($img.attr('src')) + '" alt="">' : '<span class="dashicons dashicons-media-default"></span>';
    $wrap.find('[data-cm-media-preview]').html(html);
    $wrap.find('.cm-media-edit-form button[type="submit"]').prop('disabled', !id);
  }
  $(document).on('click', '.cm-media-card', function(e){
    e.preventDefault();
    cmMediaSelect($(this));
  });
  $(document).on('input', '.cm-media-search', function(){
    var q = String($(this).val() || '').toLowerCase();
    var $wrap = $(this).closest('[data-cm-media-browser]');
    $wrap.find('.cm-media-card').each(function(){
      var hay = String($(this).attr('data-search') || '').toLowerCase();
      $(this).toggle(!q || hay.indexOf(q) !== -1);
    });
  });
  $('.cm-media-card.is-selected').first().attr('aria-pressed','true');
});

/* v1.0.30.52 — remove the old dashboard service worker/cache without touching WordPress cookies. */
(function(){
  if (!window.localStorage || localStorage.getItem('cmWlfdAuthCleanup3052') === '1') return;
  localStorage.setItem('cmWlfdAuthCleanup3052', '1');
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.getRegistrations().then(function(regs){
      regs.forEach(function(reg){
        var u = (reg.active && reg.active.scriptURL) || '';
        if (u.indexOf('dashboard-sw.js') !== -1) reg.unregister();
      });
    }).catch(function(){});
  }
  if ('caches' in window) {
    caches.keys().then(function(keys){
      keys.forEach(function(key){
        if (key.indexOf('cm-wlfd-dashboard-') === 0) caches.delete(key);
      });
    }).catch(function(){});
  }
})();


jQuery(function($){
    const $list = $('#cm-dashboard-note-list');
    if (!$list.length) return;

    function renumber(){
        $list.children('.cm-dashboard-note-row').each(function(i){
            $(this).find('[name]').each(function(){
                this.name = this.name.replace(/cm_corkboard_notes\[[^\]]+\]/, 'cm_corkboard_notes['+i+']');
            });
        });
    }

    $('#cm-dashboard-add-note').on('click', function(e){
        e.preventDefault();
        const template = document.getElementById('cm-dashboard-note-template');
        if (!template) return;

        const index = $list.children('.cm-dashboard-note-row').length;
        const html = template.innerHTML.replaceAll('__INDEX__', index);
        const $newRow = $(html).appendTo($list);
        renumber();

        // Move the editor directly to the newly-created card and put the cursor
        // in its Task title field after the browser has finished laying it out.
        window.requestAnimationFrame(function(){
            const row = $newRow.get(0);
            const title = $newRow.find('input[name$="[title]"]').first().get(0);
            if (row && typeof row.scrollIntoView === 'function') {
                row.scrollIntoView({behavior:'smooth', block:'start', inline:'nearest'});
            }
            window.setTimeout(function(){
                if (title) {
                    try { title.focus({preventScroll:true}); }
                    catch(err) { title.focus(); }
                }
            }, 350);
        });
    });

    $list.on('click','.cm-dashboard-remove-note',function(){
        $(this).closest('.cm-dashboard-note-row').remove();
        renumber();
    });

    $list.on('click','.cm-dashboard-pick-note-image',function(e){
        e.preventDefault();
        const $input = $(this).siblings('.cm-dashboard-note-image');
        const frame = wp.media({title:'Choose task image',button:{text:'Use image'},multiple:false});
        frame.on('select',function(){
            const item = frame.state().get('selection').first().toJSON();
            $input.val(item.url);
        });
        frame.open();
    });

    if ($.fn.sortable) {
        $list.sortable({handle:'.cm-dashboard-note-handle',items:'> .cm-dashboard-note-row',update:renumber});
    }
});


/* Private Corkboard AJAX save + content-only live view refresh */
jQuery(function($){
    if (typeof cmWlfdCorkboardRefresh === 'undefined') return;

    const $editor = $('.cm-corkboard-dashboard-editor[data-cm-ajax-save="1"]');
    if ($editor.length) {
        $editor.on('submit', function(e){
            e.preventDefault();
            const form = this;
            const $form = $(form);
            const $button = $form.find('button[type="submit"]').first();
            const originalText = $button.text();

            if (window.tinyMCE && tinyMCE.triggerSave) tinyMCE.triggerSave();
            const data = new FormData(form);
            data.set('action', cmWlfdCorkboardRefresh.saveAction || 'cm_wlfd_save_corkboard_ajax');

            $button.prop('disabled', true).text('Saving…');
            $form.find('.cm-corkboard-ajax-status').remove();

            $.ajax({
                url: cmWlfdCorkboardRefresh.ajaxUrl,
                method: 'POST',
                data: data,
                processData: false,
                contentType: false,
                cache: false
            }).done(function(response){
                if (!response || !response.success || !response.data) {
                    throw new Error((response && response.data && response.data.message) || 'Board could not be saved.');
                }
                const d = response.data;
                $form.find('input[name="post_id"]').val(d.post_id);
                $button.text('Update Board');
                if (!$form.find('.cm-editor-actions .cm-corkboard-view-link').length && d.view_url) {
                    $form.find('.cm-editor-actions').append('<a class="cm-btn ghost cm-corkboard-view-link" href="'+$('<div>').text(d.view_url).html()+'">View in Dashboard</a>');
                }
                $('<span class="cm-corkboard-ajax-status" role="status">Board saved — live view updated.</span>').appendTo($form.find('.cm-editor-actions'));
                try {
                    localStorage.setItem('cmWlfdCorkboardUpdated', JSON.stringify({post_id:parseInt(d.post_id,10), modified:d.modified, time:Date.now()}));
                } catch(err) {}
                if (history.replaceState && d.edit_url) history.replaceState({}, '', d.edit_url);
                window.setTimeout(function(){ $form.find('.cm-corkboard-ajax-status').fadeOut(200, function(){ $(this).remove(); }); }, 2500);
            }).fail(function(xhr){
                const message = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message ? xhr.responseJSON.data.message : 'Board could not be saved.';
                $('<span class="cm-corkboard-ajax-status is-error" role="alert"></span>').text(message).appendTo($form.find('.cm-editor-actions'));
                $button.text(originalText);
            }).always(function(){
                $button.prop('disabled', false);
            });
        });
    }

    const $header = $('.cm-corkboard-view-header');
    if (!$header.length) return;

    const postId = parseInt($header.attr('data-cm-corkboard-id'), 10);
    let knownModified = $header.attr('data-cm-corkboard-modified') || '';
    let checking = false;

    function replaceBoardContent(force){
        if (checking || document.hidden || !postId) return;
        checking = true;
        const scrollX = window.scrollX;
        const scrollY = window.scrollY;

        $.get(cmWlfdCorkboardRefresh.ajaxUrl, {
            action: cmWlfdCorkboardRefresh.contentAction || 'cm_wlfd_corkboard_content',
            post_id: postId,
            nonce: cmWlfdCorkboardRefresh.nonce
        }).done(function(response){
            if (!response || !response.success || !response.data) return;
            const d = response.data;
            if (!force && knownModified && d.modified === knownModified) return;
            knownModified = d.modified || knownModified;
            $header.attr('data-cm-corkboard-modified', knownModified);
            if (d.title) $header.find('h2').text(d.title);
            const $newContent = $(d.html);
            const $oldContent = $('.cm-corkboard-live-content').first();
            if ($oldContent.length) $oldContent.replaceWith($newContent);
            else $header.after($newContent);
            window.scrollTo(scrollX, scrollY);
        }).always(function(){ checking = false; });
    }

    function checkBoard(){
        if (checking || document.hidden || !postId) return;
        $.get(cmWlfdCorkboardRefresh.ajaxUrl, {
            action: 'cm_wlfd_corkboard_modified',
            post_id: postId,
            nonce: cmWlfdCorkboardRefresh.nonce
        }).done(function(response){
            if (response && response.success && response.data && response.data.modified) {
                if (knownModified && response.data.modified !== knownModified) replaceBoardContent(true);
                else knownModified = response.data.modified;
            }
        });
    }

    window.addEventListener('storage', function(event){
        if (event.key !== 'cmWlfdCorkboardUpdated' || !event.newValue) return;
        try {
            const data = JSON.parse(event.newValue);
            if (parseInt(data.post_id,10) === postId) replaceBoardContent(true);
        } catch(err) {}
    });

    window.setInterval(checkBoard, parseInt(cmWlfdCorkboardRefresh.interval, 10) || 2000);
    document.addEventListener('visibilitychange', function(){ if (!document.hidden) checkBoard(); });
});


/* v1.0.30.64 — Corkboard presentation/full-screen control. */
jQuery(function($){
    const $presentation = $('.cm-corkboard-presentation').first();
    const $button = $presentation.find('.cm-corkboard-fullscreen-button').first();
    if (!$presentation.length || !$button.length) return;

    const presentation = $presentation.get(0);
    let fauxFullscreen = false;

    function nativeFullscreenElement(){
        return document.fullscreenElement || document.webkitFullscreenElement || null;
    }

    function setButtonState(active){
        $button.attr('aria-pressed', active ? 'true' : 'false');
        $button.find('.cm-corkboard-fullscreen-label').text(active ? 'Exit Full Screen' : 'Full Screen');
        $button.find('.dashicons').toggleClass('dashicons-fullscreen-alt', !active).toggleClass('dashicons-no-alt', active);
    }

    function enterFauxFullscreen(){
        fauxFullscreen = true;
        $('body').addClass('cm-corkboard-faux-fullscreen');
        $presentation.addClass('is-faux-fullscreen');
        setButtonState(true);
        window.scrollTo(0, 0);
    }

    function exitFauxFullscreen(){
        fauxFullscreen = false;
        $('body').removeClass('cm-corkboard-faux-fullscreen');
        $presentation.removeClass('is-faux-fullscreen');
        setButtonState(false);
    }

    $button.on('click', function(){
        const activeNative = nativeFullscreenElement() === presentation;
        if (activeNative) {
            const exit = document.exitFullscreen || document.webkitExitFullscreen;
            if (exit) exit.call(document);
            return;
        }
        if (fauxFullscreen) {
            exitFauxFullscreen();
            return;
        }

        const request = presentation.requestFullscreen || presentation.webkitRequestFullscreen;
        if (request) {
            try {
                const result = request.call(presentation);
                if (result && typeof result.catch === 'function') result.catch(enterFauxFullscreen);
            } catch(err) {
                enterFauxFullscreen();
            }
        } else {
            enterFauxFullscreen();
        }
    });

    $(document).on('fullscreenchange webkitfullscreenchange', function(){
        const active = nativeFullscreenElement() === presentation;
        $presentation.toggleClass('is-native-fullscreen', active);
        if (!active && fauxFullscreen) return;
        setButtonState(active);
    });

    $(document).on('keydown', function(e){
        if (e.key === 'Escape' && fauxFullscreen) exitFauxFullscreen();
    });
});

/* v1.0.30.71 — Content tabs AJAX includes the built-in GitHub content editor tab. */
jQuery(function($){
  var req = null;

  function cmWlfdSetContentTab(tab, href, push){
    if (!window.cmWlfdTabs || !cmWlfdTabs.ajaxUrl || !tab) {
      if (href) window.location.href = href;
      return;
    }

    var $panel = $('#cm-wlfd-tab-panel');
    var $tabs = $('.cm-tab[data-cm-tab]');
    if (!$panel.length) {
      if (href) window.location.href = href;
      return;
    }

    $tabs.removeClass('is-active').attr('aria-selected', 'false');
    $('.cm-tab[data-cm-tab="' + tab + '"]').addClass('is-active').attr('aria-selected', 'true');
    $panel.addClass('is-loading').attr('aria-busy', 'true');

    if (req && req.readyState !== 4) req.abort();
    req = $.ajax({
      url: cmWlfdTabs.ajaxUrl,
      method: 'POST',
      dataType: 'json',
      data: {
        action: cmWlfdTabs.action || 'cm_wlfd_content_tab',
        nonce: cmWlfdTabs.nonce,
        tab: tab
      }
    }).done(function(res){
      if (!res || !res.success || !res.data || typeof res.data.html === 'undefined') {
        if (href) window.location.href = href;
        return;
      }
      $panel.html(res.data.html);
      if (push && href && window.history && window.history.pushState) {
        window.history.pushState({cmWlfdTab: tab}, '', href);
      }
    }).fail(function(xhr, status){
      if (status === 'abort') return;
      if (href) window.location.href = href;
    }).always(function(){
      $panel.removeClass('is-loading').attr('aria-busy', 'false');
    });
  }

  $(document).on('click', '.cm-tab[data-cm-tab]', function(e){
    var tab = $(this).data('cm-tab');
    var href = this.href;
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    e.preventDefault();
    if ($(this).hasClass('is-active')) return;
    cmWlfdSetContentTab(tab, href, true);
  });

  window.addEventListener('popstate', function(){
    var params = new URLSearchParams(window.location.search);
    var tab = params.get('tab') || 'blog';
    cmWlfdSetContentTab(tab, window.location.href, false);
  });
});
